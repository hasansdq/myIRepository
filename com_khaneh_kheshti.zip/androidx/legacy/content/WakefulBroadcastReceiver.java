package androidx.legacy.content;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.Log;
import android.util.SparseArray;

@Deprecated
public abstract class WakefulBroadcastReceiver extends BroadcastReceiver
{
  private static final String EXTRA_WAKE_LOCK_ID = "androidx.contentpager.content.wakelockid";
  private static int mNextId = 1;
  private static final SparseArray<PowerManager.WakeLock> sActiveWakeLocks = new SparseArray();

  public static boolean completeWakefulIntent(Intent paramIntent)
  {
    boolean bool = false;
    int i = paramIntent.getIntExtra("androidx.contentpager.content.wakelockid", 0);
    if (i == 0);
    while (true)
    {
      return bool;
      synchronized (sActiveWakeLocks)
      {
        PowerManager.WakeLock localWakeLock = (PowerManager.WakeLock)sActiveWakeLocks.get(i);
        if (localWakeLock != null)
        {
          localWakeLock.release();
          sActiveWakeLocks.remove(i);
          bool = true;
          continue;
        }
        Log.w("WakefulBroadcastReceiv.", "No active wake lock id #" + i);
        bool = true;
      }
    }
  }

  public static ComponentName startWakefulService(Context paramContext, Intent paramIntent)
  {
    ComponentName localComponentName;
    synchronized (sActiveWakeLocks)
    {
      int i = mNextId;
      mNextId = 1 + mNextId;
      if (mNextId <= 0)
        mNextId = 1;
      paramIntent.putExtra("androidx.contentpager.content.wakelockid", i);
      localComponentName = paramContext.startService(paramIntent);
      if (localComponentName == null)
      {
        localComponentName = null;
      }
      else
      {
        PowerManager.WakeLock localWakeLock = ((PowerManager)paramContext.getSystemService("power")).newWakeLock(1, "androidx.core:wake:" + localComponentName.flattenToShortString());
        localWakeLock.setReferenceCounted(false);
        localWakeLock.acquire(60000L);
        sActiveWakeLocks.put(i, localWakeLock);
      }
    }
    return localComponentName;
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.legacy.content.WakefulBroadcastReceiver
 * JD-Core Version:    0.6.2
 */