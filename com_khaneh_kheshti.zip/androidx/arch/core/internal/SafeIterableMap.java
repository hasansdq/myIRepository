package androidx.arch.core.internal;

import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.WeakHashMap;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public class SafeIterableMap<K, V>
  implements Iterable<Map.Entry<K, V>>
{
  private Entry<K, V> mEnd;
  private WeakHashMap<SupportRemove<K, V>, Boolean> mIterators = new WeakHashMap();
  private int mSize = 0;
  Entry<K, V> mStart;

  public Iterator<Map.Entry<K, V>> descendingIterator()
  {
    DescendingIterator localDescendingIterator = new DescendingIterator(this.mEnd, this.mStart);
    this.mIterators.put(localDescendingIterator, Boolean.valueOf(false));
    return localDescendingIterator;
  }

  public Map.Entry<K, V> eldest()
  {
    return this.mStart;
  }

  public boolean equals(Object paramObject)
  {
    boolean bool1 = true;
    boolean bool2 = false;
    if (paramObject == this)
      bool2 = bool1;
    Iterator localIterator1;
    Iterator localIterator2;
    while (true)
    {
      return bool2;
      if ((paramObject instanceof SafeIterableMap))
      {
        SafeIterableMap localSafeIterableMap = (SafeIterableMap)paramObject;
        if (size() == localSafeIterableMap.size())
        {
          localIterator1 = iterator();
          localIterator2 = localSafeIterableMap.iterator();
          Map.Entry localEntry;
          Object localObject;
          do
          {
            if ((!localIterator1.hasNext()) || (!localIterator2.hasNext()))
              break label122;
            localEntry = (Map.Entry)localIterator1.next();
            localObject = localIterator2.next();
            if ((localEntry == null) && (localObject != null))
              break;
          }
          while ((localEntry == null) || (localEntry.equals(localObject)));
        }
      }
    }
    label122: if ((!localIterator1.hasNext()) && (!localIterator2.hasNext()));
    while (true)
    {
      bool2 = bool1;
      break;
      bool1 = false;
    }
  }

  protected Entry<K, V> get(K paramK)
  {
    for (Entry localEntry = this.mStart; ; localEntry = localEntry.mNext)
      if ((localEntry == null) || (localEntry.mKey.equals(paramK)))
        return localEntry;
  }

  public int hashCode()
  {
    int i = 0;
    Iterator localIterator = iterator();
    while (localIterator.hasNext())
      i += ((Map.Entry)localIterator.next()).hashCode();
    return i;
  }

  @NonNull
  public Iterator<Map.Entry<K, V>> iterator()
  {
    AscendingIterator localAscendingIterator = new AscendingIterator(this.mStart, this.mEnd);
    this.mIterators.put(localAscendingIterator, Boolean.valueOf(false));
    return localAscendingIterator;
  }

  public SafeIterableMap<K, V>.IteratorWithAdditions iteratorWithAdditions()
  {
    IteratorWithAdditions localIteratorWithAdditions = new IteratorWithAdditions();
    this.mIterators.put(localIteratorWithAdditions, Boolean.valueOf(false));
    return localIteratorWithAdditions;
  }

  public Map.Entry<K, V> newest()
  {
    return this.mEnd;
  }

  protected Entry<K, V> put(@NonNull K paramK, @NonNull V paramV)
  {
    Entry localEntry = new Entry(paramK, paramV);
    this.mSize = (1 + this.mSize);
    if (this.mEnd == null)
      this.mStart = localEntry;
    for (this.mEnd = this.mStart; ; this.mEnd = localEntry)
    {
      return localEntry;
      this.mEnd.mNext = localEntry;
      localEntry.mPrevious = this.mEnd;
    }
  }

  public V putIfAbsent(@NonNull K paramK, @NonNull V paramV)
  {
    Entry localEntry = get(paramK);
    if (localEntry != null);
    for (Object localObject = localEntry.mValue; ; localObject = null)
    {
      return localObject;
      put(paramK, paramV);
    }
  }

  public V remove(@NonNull K paramK)
  {
    Object localObject = null;
    Entry localEntry = get(paramK);
    if (localEntry == null)
      return localObject;
    this.mSize = (-1 + this.mSize);
    if (!this.mIterators.isEmpty())
    {
      Iterator localIterator = this.mIterators.keySet().iterator();
      while (localIterator.hasNext())
        ((SupportRemove)localIterator.next()).supportRemove(localEntry);
    }
    if (localEntry.mPrevious != null)
    {
      localEntry.mPrevious.mNext = localEntry.mNext;
      label95: if (localEntry.mNext == null)
        break label142;
      localEntry.mNext.mPrevious = localEntry.mPrevious;
    }
    while (true)
    {
      localEntry.mNext = null;
      localEntry.mPrevious = null;
      localObject = localEntry.mValue;
      break;
      this.mStart = localEntry.mNext;
      break label95;
      label142: this.mEnd = localEntry.mPrevious;
    }
  }

  public int size()
  {
    return this.mSize;
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("[");
    Iterator localIterator = iterator();
    while (localIterator.hasNext())
    {
      localStringBuilder.append(((Map.Entry)localIterator.next()).toString());
      if (localIterator.hasNext())
        localStringBuilder.append(", ");
    }
    localStringBuilder.append("]");
    return localStringBuilder.toString();
  }

  static class AscendingIterator<K, V> extends SafeIterableMap.ListIterator<K, V>
  {
    AscendingIterator(SafeIterableMap.Entry<K, V> paramEntry1, SafeIterableMap.Entry<K, V> paramEntry2)
    {
      super(paramEntry2);
    }

    SafeIterableMap.Entry<K, V> backward(SafeIterableMap.Entry<K, V> paramEntry)
    {
      return paramEntry.mPrevious;
    }

    SafeIterableMap.Entry<K, V> forward(SafeIterableMap.Entry<K, V> paramEntry)
    {
      return paramEntry.mNext;
    }
  }

  private static class DescendingIterator<K, V> extends SafeIterableMap.ListIterator<K, V>
  {
    DescendingIterator(SafeIterableMap.Entry<K, V> paramEntry1, SafeIterableMap.Entry<K, V> paramEntry2)
    {
      super(paramEntry2);
    }

    SafeIterableMap.Entry<K, V> backward(SafeIterableMap.Entry<K, V> paramEntry)
    {
      return paramEntry.mNext;
    }

    SafeIterableMap.Entry<K, V> forward(SafeIterableMap.Entry<K, V> paramEntry)
    {
      return paramEntry.mPrevious;
    }
  }

  static class Entry<K, V>
    implements Map.Entry<K, V>
  {

    @NonNull
    final K mKey;
    Entry<K, V> mNext;
    Entry<K, V> mPrevious;

    @NonNull
    final V mValue;

    Entry(@NonNull K paramK, @NonNull V paramV)
    {
      this.mKey = paramK;
      this.mValue = paramV;
    }

    public boolean equals(Object paramObject)
    {
      boolean bool = true;
      if (paramObject == this);
      while (true)
      {
        return bool;
        if (!(paramObject instanceof Entry))
        {
          bool = false;
        }
        else
        {
          Entry localEntry = (Entry)paramObject;
          if ((!this.mKey.equals(localEntry.mKey)) || (!this.mValue.equals(localEntry.mValue)))
            bool = false;
        }
      }
    }

    @NonNull
    public K getKey()
    {
      return this.mKey;
    }

    @NonNull
    public V getValue()
    {
      return this.mValue;
    }

    public int hashCode()
    {
      return this.mKey.hashCode() ^ this.mValue.hashCode();
    }

    public V setValue(V paramV)
    {
      throw new UnsupportedOperationException("An entry modification is not supported");
    }

    public String toString()
    {
      return this.mKey + "=" + this.mValue;
    }
  }

  private class IteratorWithAdditions
    implements Iterator<Map.Entry<K, V>>, SafeIterableMap.SupportRemove<K, V>
  {
    private boolean mBeforeStart = true;
    private SafeIterableMap.Entry<K, V> mCurrent;

    IteratorWithAdditions()
    {
    }

    public boolean hasNext()
    {
      boolean bool = true;
      if (this.mBeforeStart)
        if (SafeIterableMap.this.mStart == null);
      while (true)
      {
        return bool;
        bool = false;
        continue;
        if ((this.mCurrent == null) || (this.mCurrent.mNext == null))
          bool = false;
      }
    }

    public Map.Entry<K, V> next()
    {
      if (this.mBeforeStart)
      {
        this.mBeforeStart = false;
        this.mCurrent = SafeIterableMap.this.mStart;
        return this.mCurrent;
      }
      if (this.mCurrent != null);
      for (SafeIterableMap.Entry localEntry = this.mCurrent.mNext; ; localEntry = null)
      {
        this.mCurrent = localEntry;
        break;
      }
    }

    public void supportRemove(@NonNull SafeIterableMap.Entry<K, V> paramEntry)
    {
      if (paramEntry == this.mCurrent)
      {
        this.mCurrent = this.mCurrent.mPrevious;
        if (this.mCurrent != null)
          break label34;
      }
      label34: for (boolean bool = true; ; bool = false)
      {
        this.mBeforeStart = bool;
        return;
      }
    }
  }

  private static abstract class ListIterator<K, V>
    implements Iterator<Map.Entry<K, V>>, SafeIterableMap.SupportRemove<K, V>
  {
    SafeIterableMap.Entry<K, V> mExpectedEnd;
    SafeIterableMap.Entry<K, V> mNext;

    ListIterator(SafeIterableMap.Entry<K, V> paramEntry1, SafeIterableMap.Entry<K, V> paramEntry2)
    {
      this.mExpectedEnd = paramEntry2;
      this.mNext = paramEntry1;
    }

    private SafeIterableMap.Entry<K, V> nextNode()
    {
      if ((this.mNext == this.mExpectedEnd) || (this.mExpectedEnd == null));
      for (Object localObject = null; ; localObject = forward(this.mNext))
        return localObject;
    }

    abstract SafeIterableMap.Entry<K, V> backward(SafeIterableMap.Entry<K, V> paramEntry);

    abstract SafeIterableMap.Entry<K, V> forward(SafeIterableMap.Entry<K, V> paramEntry);

    public boolean hasNext()
    {
      if (this.mNext != null);
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    public Map.Entry<K, V> next()
    {
      SafeIterableMap.Entry localEntry = this.mNext;
      this.mNext = nextNode();
      return localEntry;
    }

    public void supportRemove(@NonNull SafeIterableMap.Entry<K, V> paramEntry)
    {
      if ((this.mExpectedEnd == paramEntry) && (paramEntry == this.mNext))
      {
        this.mNext = null;
        this.mExpectedEnd = null;
      }
      if (this.mExpectedEnd == paramEntry)
        this.mExpectedEnd = backward(this.mExpectedEnd);
      if (this.mNext == paramEntry)
        this.mNext = nextNode();
    }
  }

  static abstract interface SupportRemove<K, V>
  {
    public abstract void supportRemove(@NonNull SafeIterableMap.Entry<K, V> paramEntry);
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.arch.core.internal.SafeIterableMap
 * JD-Core Version:    0.6.2
 */