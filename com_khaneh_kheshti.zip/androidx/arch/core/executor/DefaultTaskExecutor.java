package androidx.arch.core.executor;

import android.os.Handler;
import android.os.Looper;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public class DefaultTaskExecutor extends TaskExecutor
{
  private final ExecutorService mDiskIO = Executors.newFixedThreadPool(2, new ThreadFactory()
  {
    private static final String THREAD_NAME_STEM = "arch_disk_io_%d";
    private final AtomicInteger mThreadId = new AtomicInteger(0);

    public Thread newThread(Runnable paramAnonymousRunnable)
    {
      Thread localThread = new Thread(paramAnonymousRunnable);
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = Integer.valueOf(this.mThreadId.getAndIncrement());
      localThread.setName(String.format("arch_disk_io_%d", arrayOfObject));
      return localThread;
    }
  });
  private final Object mLock = new Object();

  @Nullable
  private volatile Handler mMainHandler;

  public void executeOnDiskIO(Runnable paramRunnable)
  {
    this.mDiskIO.execute(paramRunnable);
  }

  public boolean isMainThread()
  {
    if (Looper.getMainLooper().getThread() == Thread.currentThread());
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public void postToMainThread(Runnable paramRunnable)
  {
    if (this.mMainHandler == null);
    synchronized (this.mLock)
    {
      if (this.mMainHandler == null)
        this.mMainHandler = new Handler(Looper.getMainLooper());
      this.mMainHandler.post(paramRunnable);
      return;
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.arch.core.executor.DefaultTaskExecutor
 * JD-Core Version:    0.6.2
 */