package androidx.arch.core.executor;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import java.util.concurrent.Executor;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public class ArchTaskExecutor extends TaskExecutor
{

  @NonNull
  private static final Executor sIOThreadExecutor = new Executor()
  {
    public void execute(Runnable paramAnonymousRunnable)
    {
      ArchTaskExecutor.getInstance().executeOnDiskIO(paramAnonymousRunnable);
    }
  };
  private static volatile ArchTaskExecutor sInstance;

  @NonNull
  private static final Executor sMainThreadExecutor = new Executor()
  {
    public void execute(Runnable paramAnonymousRunnable)
    {
      ArchTaskExecutor.getInstance().postToMainThread(paramAnonymousRunnable);
    }
  };

  @NonNull
  private TaskExecutor mDefaultTaskExecutor = new DefaultTaskExecutor();

  @NonNull
  private TaskExecutor mDelegate = this.mDefaultTaskExecutor;

  @NonNull
  public static Executor getIOThreadExecutor()
  {
    return sIOThreadExecutor;
  }

  @NonNull
  public static ArchTaskExecutor getInstance()
  {
    ArchTaskExecutor localArchTaskExecutor;
    if (sInstance != null)
      localArchTaskExecutor = sInstance;
    while (true)
    {
      return localArchTaskExecutor;
      try
      {
        if (sInstance == null)
          sInstance = new ArchTaskExecutor();
        localArchTaskExecutor = sInstance;
      }
      finally
      {
      }
    }
  }

  @NonNull
  public static Executor getMainThreadExecutor()
  {
    return sMainThreadExecutor;
  }

  public void executeOnDiskIO(Runnable paramRunnable)
  {
    this.mDelegate.executeOnDiskIO(paramRunnable);
  }

  public boolean isMainThread()
  {
    return this.mDelegate.isMainThread();
  }

  public void postToMainThread(Runnable paramRunnable)
  {
    this.mDelegate.postToMainThread(paramRunnable);
  }

  public void setDelegate(@Nullable TaskExecutor paramTaskExecutor)
  {
    if (paramTaskExecutor == null)
      paramTaskExecutor = this.mDefaultTaskExecutor;
    this.mDelegate = paramTaskExecutor;
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.arch.core.executor.ArchTaskExecutor
 * JD-Core Version:    0.6.2
 */