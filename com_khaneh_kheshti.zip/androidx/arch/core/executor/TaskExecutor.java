package androidx.arch.core.executor;

import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public abstract class TaskExecutor
{
  public abstract void executeOnDiskIO(@NonNull Runnable paramRunnable);

  public void executeOnMainThread(@NonNull Runnable paramRunnable)
  {
    if (isMainThread())
      paramRunnable.run();
    while (true)
    {
      return;
      postToMainThread(paramRunnable);
    }
  }

  public abstract boolean isMainThread();

  public abstract void postToMainThread(@NonNull Runnable paramRunnable);
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.arch.core.executor.TaskExecutor
 * JD-Core Version:    0.6.2
 */