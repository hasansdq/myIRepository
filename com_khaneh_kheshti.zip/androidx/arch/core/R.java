package androidx.arch.core;

public final class R
{
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.arch.core.R
 * JD-Core Version:    0.6.2
 */