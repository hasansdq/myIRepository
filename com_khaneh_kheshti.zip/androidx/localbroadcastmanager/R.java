package androidx.localbroadcastmanager;

public final class R
{
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.localbroadcastmanager.R
 * JD-Core Version:    0.6.2
 */