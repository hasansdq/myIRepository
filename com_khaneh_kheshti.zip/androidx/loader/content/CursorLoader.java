package androidx.loader.content;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.os.CancellationSignal;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Arrays;

public class CursorLoader extends AsyncTaskLoader<Cursor>
{
  CancellationSignal mCancellationSignal;
  Cursor mCursor;
  final Loader<Cursor>.ForceLoadContentObserver mObserver = new Loader.ForceLoadContentObserver(this);
  String[] mProjection;
  String mSelection;
  String[] mSelectionArgs;
  String mSortOrder;
  Uri mUri;

  public CursorLoader(@NonNull Context paramContext)
  {
    super(paramContext);
  }

  public CursorLoader(@NonNull Context paramContext, @NonNull Uri paramUri, @Nullable String[] paramArrayOfString1, @Nullable String paramString1, @Nullable String[] paramArrayOfString2, @Nullable String paramString2)
  {
    super(paramContext);
    this.mUri = paramUri;
    this.mProjection = paramArrayOfString1;
    this.mSelection = paramString1;
    this.mSelectionArgs = paramArrayOfString2;
    this.mSortOrder = paramString2;
  }

  public void cancelLoadInBackground()
  {
    super.cancelLoadInBackground();
    try
    {
      if (this.mCancellationSignal != null)
        this.mCancellationSignal.cancel();
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void deliverResult(Cursor paramCursor)
  {
    if (isReset())
      if (paramCursor != null)
        paramCursor.close();
    while (true)
    {
      return;
      Cursor localCursor = this.mCursor;
      this.mCursor = paramCursor;
      if (isStarted())
        super.deliverResult(paramCursor);
      if ((localCursor != null) && (localCursor != paramCursor) && (!localCursor.isClosed()))
        localCursor.close();
    }
  }

  @Deprecated
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    super.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mUri=");
    paramPrintWriter.println(this.mUri);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mProjection=");
    paramPrintWriter.println(Arrays.toString(this.mProjection));
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mSelection=");
    paramPrintWriter.println(this.mSelection);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mSelectionArgs=");
    paramPrintWriter.println(Arrays.toString(this.mSelectionArgs));
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mSortOrder=");
    paramPrintWriter.println(this.mSortOrder);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mCursor=");
    paramPrintWriter.println(this.mCursor);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mContentChanged=");
    paramPrintWriter.println(this.mContentChanged);
  }

  @Nullable
  public String[] getProjection()
  {
    return this.mProjection;
  }

  @Nullable
  public String getSelection()
  {
    return this.mSelection;
  }

  @Nullable
  public String[] getSelectionArgs()
  {
    return this.mSelectionArgs;
  }

  @Nullable
  public String getSortOrder()
  {
    return this.mSortOrder;
  }

  @NonNull
  public Uri getUri()
  {
    return this.mUri;
  }

  // ERROR //
  public Cursor loadInBackground()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual 137	androidx/loader/content/CursorLoader:isLoadInBackgroundCanceled	()Z
    //   6: ifeq +16 -> 22
    //   9: new 139	androidx/core/os/OperationCanceledException
    //   12: dup
    //   13: invokespecial 141	androidx/core/os/OperationCanceledException:<init>	()V
    //   16: athrow
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    //   22: aload_0
    //   23: new 52	androidx/core/os/CancellationSignal
    //   26: dup
    //   27: invokespecial 142	androidx/core/os/CancellationSignal:<init>	()V
    //   30: putfield 50	androidx/loader/content/CursorLoader:mCancellationSignal	Landroidx/core/os/CancellationSignal;
    //   33: aload_0
    //   34: monitorexit
    //   35: aload_0
    //   36: invokevirtual 146	androidx/loader/content/CursorLoader:getContext	()Landroid/content/Context;
    //   39: invokevirtual 152	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   42: aload_0
    //   43: getfield 36	androidx/loader/content/CursorLoader:mUri	Landroid/net/Uri;
    //   46: aload_0
    //   47: getfield 38	androidx/loader/content/CursorLoader:mProjection	[Ljava/lang/String;
    //   50: aload_0
    //   51: getfield 40	androidx/loader/content/CursorLoader:mSelection	Ljava/lang/String;
    //   54: aload_0
    //   55: getfield 42	androidx/loader/content/CursorLoader:mSelectionArgs	[Ljava/lang/String;
    //   58: aload_0
    //   59: getfield 44	androidx/loader/content/CursorLoader:mSortOrder	Ljava/lang/String;
    //   62: aload_0
    //   63: getfield 50	androidx/loader/content/CursorLoader:mCancellationSignal	Landroidx/core/os/CancellationSignal;
    //   66: invokestatic 158	androidx/core/content/ContentResolverCompat:query	(Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Landroidx/core/os/CancellationSignal;)Landroid/database/Cursor;
    //   69: astore 4
    //   71: aload 4
    //   73: ifnull +22 -> 95
    //   76: aload 4
    //   78: invokeinterface 162 1 0
    //   83: pop
    //   84: aload 4
    //   86: aload_0
    //   87: getfield 32	androidx/loader/content/CursorLoader:mObserver	Landroidx/loader/content/Loader$ForceLoadContentObserver;
    //   90: invokeinterface 166 2 0
    //   95: aload_0
    //   96: monitorenter
    //   97: aload_0
    //   98: aconst_null
    //   99: putfield 50	androidx/loader/content/CursorLoader:mCancellationSignal	Landroidx/core/os/CancellationSignal;
    //   102: aload_0
    //   103: monitorexit
    //   104: aload 4
    //   106: areturn
    //   107: astore 6
    //   109: aload 4
    //   111: invokeinterface 66 1 0
    //   116: aload 6
    //   118: athrow
    //   119: astore_2
    //   120: aload_0
    //   121: monitorenter
    //   122: aload_0
    //   123: aconst_null
    //   124: putfield 50	androidx/loader/content/CursorLoader:mCancellationSignal	Landroidx/core/os/CancellationSignal;
    //   127: aload_0
    //   128: monitorexit
    //   129: aload_2
    //   130: athrow
    //   131: astore 5
    //   133: aload_0
    //   134: monitorexit
    //   135: aload 5
    //   137: athrow
    //   138: astore_3
    //   139: aload_0
    //   140: monitorexit
    //   141: aload_3
    //   142: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   2	20	17	finally
    //   22	35	17	finally
    //   76	95	107	java/lang/RuntimeException
    //   35	71	119	finally
    //   76	95	119	finally
    //   109	119	119	finally
    //   97	104	131	finally
    //   133	135	131	finally
    //   122	129	138	finally
    //   139	141	138	finally
  }

  public void onCanceled(Cursor paramCursor)
  {
    if ((paramCursor != null) && (!paramCursor.isClosed()))
      paramCursor.close();
  }

  protected void onReset()
  {
    super.onReset();
    onStopLoading();
    if ((this.mCursor != null) && (!this.mCursor.isClosed()))
      this.mCursor.close();
    this.mCursor = null;
  }

  protected void onStartLoading()
  {
    if (this.mCursor != null)
      deliverResult(this.mCursor);
    if ((takeContentChanged()) || (this.mCursor == null))
      forceLoad();
  }

  protected void onStopLoading()
  {
    cancelLoad();
  }

  public void setProjection(@Nullable String[] paramArrayOfString)
  {
    this.mProjection = paramArrayOfString;
  }

  public void setSelection(@Nullable String paramString)
  {
    this.mSelection = paramString;
  }

  public void setSelectionArgs(@Nullable String[] paramArrayOfString)
  {
    this.mSelectionArgs = paramArrayOfString;
  }

  public void setSortOrder(@Nullable String paramString)
  {
    this.mSortOrder = paramString;
  }

  public void setUri(@NonNull Uri paramUri)
  {
    this.mUri = paramUri;
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.loader.content.CursorLoader
 * JD-Core Version:    0.6.2
 */