package androidx.print;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.CancellationSignal.OnCancelListener;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintAttributes.Builder;
import android.print.PrintAttributes.Margins;
import android.print.PrintAttributes.MediaSize;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentAdapter.LayoutResultCallback;
import android.print.PrintDocumentAdapter.WriteResultCallback;
import android.print.PrintDocumentInfo;
import android.print.PrintDocumentInfo.Builder;
import android.print.PrintManager;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import java.io.FileNotFoundException;

public final class PrintHelper
{

  @SuppressLint({"InlinedApi"})
  public static final int COLOR_MODE_COLOR = 2;

  @SuppressLint({"InlinedApi"})
  public static final int COLOR_MODE_MONOCHROME = 1;
  static final boolean IS_MIN_MARGINS_HANDLING_CORRECT = false;
  private static final String LOG_TAG = "PrintHelper";
  private static final int MAX_PRINT_SIZE = 3500;
  public static final int ORIENTATION_LANDSCAPE = 1;
  public static final int ORIENTATION_PORTRAIT = 2;
  static final boolean PRINT_ACTIVITY_RESPECTS_ORIENTATION = false;
  public static final int SCALE_MODE_FILL = 2;
  public static final int SCALE_MODE_FIT = 1;
  int mColorMode = 2;
  final Context mContext;
  BitmapFactory.Options mDecodeOptions = null;
  final Object mLock = new Object();
  int mOrientation = 1;
  int mScaleMode = 2;

  static
  {
    boolean bool1 = true;
    boolean bool2;
    if ((Build.VERSION.SDK_INT < 20) || (Build.VERSION.SDK_INT > 23))
    {
      bool2 = bool1;
      PRINT_ACTIVITY_RESPECTS_ORIENTATION = bool2;
      if (Build.VERSION.SDK_INT == 23)
        break label42;
    }
    while (true)
    {
      IS_MIN_MARGINS_HANDLING_CORRECT = bool1;
      return;
      bool2 = false;
      break;
      label42: bool1 = false;
    }
  }

  public PrintHelper(@NonNull Context paramContext)
  {
    this.mContext = paramContext;
  }

  static Bitmap convertBitmapForColorMode(Bitmap paramBitmap, int paramInt)
  {
    if (paramInt != 1);
    while (true)
    {
      return paramBitmap;
      Bitmap localBitmap = Bitmap.createBitmap(paramBitmap.getWidth(), paramBitmap.getHeight(), Bitmap.Config.ARGB_8888);
      Canvas localCanvas = new Canvas(localBitmap);
      Paint localPaint = new Paint();
      ColorMatrix localColorMatrix = new ColorMatrix();
      localColorMatrix.setSaturation(0.0F);
      localPaint.setColorFilter(new ColorMatrixColorFilter(localColorMatrix));
      localCanvas.drawBitmap(paramBitmap, 0.0F, 0.0F, localPaint);
      localCanvas.setBitmap(null);
      paramBitmap = localBitmap;
    }
  }

  @RequiresApi(19)
  private static PrintAttributes.Builder copyAttributes(PrintAttributes paramPrintAttributes)
  {
    PrintAttributes.Builder localBuilder = new PrintAttributes.Builder().setMediaSize(paramPrintAttributes.getMediaSize()).setResolution(paramPrintAttributes.getResolution()).setMinMargins(paramPrintAttributes.getMinMargins());
    if (paramPrintAttributes.getColorMode() != 0)
      localBuilder.setColorMode(paramPrintAttributes.getColorMode());
    if ((Build.VERSION.SDK_INT >= 23) && (paramPrintAttributes.getDuplexMode() != 0))
      localBuilder.setDuplexMode(paramPrintAttributes.getDuplexMode());
    return localBuilder;
  }

  static Matrix getMatrix(int paramInt1, int paramInt2, RectF paramRectF, int paramInt3)
  {
    Matrix localMatrix = new Matrix();
    float f1 = paramRectF.width() / paramInt1;
    if (paramInt3 == 2);
    for (float f2 = Math.max(f1, paramRectF.height() / paramInt2); ; f2 = Math.min(f1, paramRectF.height() / paramInt2))
    {
      localMatrix.postScale(f2, f2);
      localMatrix.postTranslate((paramRectF.width() - f2 * paramInt1) / 2.0F, (paramRectF.height() - f2 * paramInt2) / 2.0F);
      return localMatrix;
    }
  }

  static boolean isPortrait(Bitmap paramBitmap)
  {
    if (paramBitmap.getWidth() <= paramBitmap.getHeight());
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  // ERROR //
  private Bitmap loadBitmap(Uri paramUri, BitmapFactory.Options paramOptions)
    throws FileNotFoundException
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnull +10 -> 11
    //   4: aload_0
    //   5: getfield 63	androidx/print/PrintHelper:mContext	Landroid/content/Context;
    //   8: ifnonnull +13 -> 21
    //   11: new 201	java/lang/IllegalArgumentException
    //   14: dup
    //   15: ldc 203
    //   17: invokespecial 206	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   20: athrow
    //   21: aconst_null
    //   22: astore_3
    //   23: aload_0
    //   24: getfield 63	androidx/print/PrintHelper:mContext	Landroid/content/Context;
    //   27: invokevirtual 212	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   30: aload_1
    //   31: invokevirtual 218	android/content/ContentResolver:openInputStream	(Landroid/net/Uri;)Ljava/io/InputStream;
    //   34: astore_3
    //   35: aload_3
    //   36: aconst_null
    //   37: aload_2
    //   38: invokestatic 224	android/graphics/BitmapFactory:decodeStream	(Ljava/io/InputStream;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
    //   41: astore 7
    //   43: aload_3
    //   44: ifnull +7 -> 51
    //   47: aload_3
    //   48: invokevirtual 229	java/io/InputStream:close	()V
    //   51: aload 7
    //   53: areturn
    //   54: astore 8
    //   56: ldc 19
    //   58: ldc 231
    //   60: aload 8
    //   62: invokestatic 237	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   65: pop
    //   66: goto -15 -> 51
    //   69: astore 4
    //   71: aload_3
    //   72: ifnull +7 -> 79
    //   75: aload_3
    //   76: invokevirtual 229	java/io/InputStream:close	()V
    //   79: aload 4
    //   81: athrow
    //   82: astore 5
    //   84: ldc 19
    //   86: ldc 231
    //   88: aload 5
    //   90: invokestatic 237	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   93: pop
    //   94: goto -15 -> 79
    //
    // Exception table:
    //   from	to	target	type
    //   47	51	54	java/io/IOException
    //   23	43	69	finally
    //   75	79	82	java/io/IOException
  }

  public static boolean systemSupportsPrint()
  {
    if (Build.VERSION.SDK_INT >= 19);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public int getColorMode()
  {
    return this.mColorMode;
  }

  public int getOrientation()
  {
    if ((Build.VERSION.SDK_INT >= 19) && (this.mOrientation == 0));
    for (int i = 1; ; i = this.mOrientation)
      return i;
  }

  public int getScaleMode()
  {
    return this.mScaleMode;
  }

  // ERROR //
  Bitmap loadConstrainedBitmap(Uri paramUri)
    throws FileNotFoundException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_1
    //   3: ifnull +10 -> 13
    //   6: aload_0
    //   7: getfield 63	androidx/print/PrintHelper:mContext	Landroid/content/Context;
    //   10: ifnonnull +13 -> 23
    //   13: new 201	java/lang/IllegalArgumentException
    //   16: dup
    //   17: ldc 245
    //   19: invokespecial 206	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   22: athrow
    //   23: new 247	android/graphics/BitmapFactory$Options
    //   26: dup
    //   27: invokespecial 248	android/graphics/BitmapFactory$Options:<init>	()V
    //   30: astore_3
    //   31: aload_3
    //   32: iconst_1
    //   33: putfield 251	android/graphics/BitmapFactory$Options:inJustDecodeBounds	Z
    //   36: aload_0
    //   37: aload_1
    //   38: aload_3
    //   39: invokespecial 253	androidx/print/PrintHelper:loadBitmap	(Landroid/net/Uri;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
    //   42: pop
    //   43: aload_3
    //   44: getfield 256	android/graphics/BitmapFactory$Options:outWidth	I
    //   47: istore 5
    //   49: aload_3
    //   50: getfield 259	android/graphics/BitmapFactory$Options:outHeight	I
    //   53: istore 6
    //   55: iload 5
    //   57: ifle +8 -> 65
    //   60: iload 6
    //   62: ifgt +5 -> 67
    //   65: aload_2
    //   66: areturn
    //   67: iload 5
    //   69: iload 6
    //   71: invokestatic 262	java/lang/Math:max	(II)I
    //   74: istore 7
    //   76: iconst_1
    //   77: istore 8
    //   79: iload 7
    //   81: sipush 3500
    //   84: if_icmple +18 -> 102
    //   87: iload 7
    //   89: iconst_1
    //   90: iushr
    //   91: istore 7
    //   93: iload 8
    //   95: iconst_1
    //   96: ishl
    //   97: istore 8
    //   99: goto -20 -> 79
    //   102: iload 8
    //   104: ifle -39 -> 65
    //   107: iload 5
    //   109: iload 6
    //   111: invokestatic 264	java/lang/Math:min	(II)I
    //   114: iload 8
    //   116: idiv
    //   117: ifle -52 -> 65
    //   120: aload_0
    //   121: getfield 55	androidx/print/PrintHelper:mLock	Ljava/lang/Object;
    //   124: astore 9
    //   126: aload 9
    //   128: monitorenter
    //   129: aload_0
    //   130: new 247	android/graphics/BitmapFactory$Options
    //   133: dup
    //   134: invokespecial 248	android/graphics/BitmapFactory$Options:<init>	()V
    //   137: putfield 53	androidx/print/PrintHelper:mDecodeOptions	Landroid/graphics/BitmapFactory$Options;
    //   140: aload_0
    //   141: getfield 53	androidx/print/PrintHelper:mDecodeOptions	Landroid/graphics/BitmapFactory$Options;
    //   144: iconst_1
    //   145: putfield 267	android/graphics/BitmapFactory$Options:inMutable	Z
    //   148: aload_0
    //   149: getfield 53	androidx/print/PrintHelper:mDecodeOptions	Landroid/graphics/BitmapFactory$Options;
    //   152: iload 8
    //   154: putfield 270	android/graphics/BitmapFactory$Options:inSampleSize	I
    //   157: aload_0
    //   158: getfield 53	androidx/print/PrintHelper:mDecodeOptions	Landroid/graphics/BitmapFactory$Options;
    //   161: astore 11
    //   163: aload 9
    //   165: monitorexit
    //   166: aload_0
    //   167: aload_1
    //   168: aload 11
    //   170: invokespecial 253	androidx/print/PrintHelper:loadBitmap	(Landroid/net/Uri;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
    //   173: astore 15
    //   175: aload 15
    //   177: astore_2
    //   178: aload_0
    //   179: getfield 55	androidx/print/PrintHelper:mLock	Ljava/lang/Object;
    //   182: astore 16
    //   184: aload 16
    //   186: monitorenter
    //   187: aload_0
    //   188: aconst_null
    //   189: putfield 53	androidx/print/PrintHelper:mDecodeOptions	Landroid/graphics/BitmapFactory$Options;
    //   192: aload 16
    //   194: monitorexit
    //   195: goto -130 -> 65
    //   198: astore 17
    //   200: aload 16
    //   202: monitorexit
    //   203: aload 17
    //   205: athrow
    //   206: astore 10
    //   208: aload 9
    //   210: monitorexit
    //   211: aload 10
    //   213: athrow
    //   214: astore 12
    //   216: aload_0
    //   217: getfield 55	androidx/print/PrintHelper:mLock	Ljava/lang/Object;
    //   220: astore 13
    //   222: aload 13
    //   224: monitorenter
    //   225: aload_0
    //   226: aconst_null
    //   227: putfield 53	androidx/print/PrintHelper:mDecodeOptions	Landroid/graphics/BitmapFactory$Options;
    //   230: aload 13
    //   232: monitorexit
    //   233: aload 12
    //   235: athrow
    //   236: astore 14
    //   238: aload 13
    //   240: monitorexit
    //   241: aload 14
    //   243: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   187	203	198	finally
    //   129	166	206	finally
    //   208	211	206	finally
    //   166	175	214	finally
    //   225	233	236	finally
    //   238	241	236	finally
  }

  public void printBitmap(@NonNull String paramString, @NonNull Bitmap paramBitmap)
  {
    printBitmap(paramString, paramBitmap, null);
  }

  public void printBitmap(@NonNull String paramString, @NonNull Bitmap paramBitmap, @Nullable OnPrintFinishCallback paramOnPrintFinishCallback)
  {
    if ((Build.VERSION.SDK_INT < 19) || (paramBitmap == null))
      return;
    PrintManager localPrintManager = (PrintManager)this.mContext.getSystemService("print");
    if (isPortrait(paramBitmap));
    for (PrintAttributes.MediaSize localMediaSize = PrintAttributes.MediaSize.UNKNOWN_PORTRAIT; ; localMediaSize = PrintAttributes.MediaSize.UNKNOWN_LANDSCAPE)
    {
      PrintAttributes localPrintAttributes = new PrintAttributes.Builder().setMediaSize(localMediaSize).setColorMode(this.mColorMode).build();
      localPrintManager.print(paramString, new PrintBitmapAdapter(paramString, this.mScaleMode, paramBitmap, paramOnPrintFinishCallback), localPrintAttributes);
      break;
    }
  }

  public void printBitmap(@NonNull String paramString, @NonNull Uri paramUri)
    throws FileNotFoundException
  {
    printBitmap(paramString, paramUri, null);
  }

  public void printBitmap(@NonNull String paramString, @NonNull Uri paramUri, @Nullable OnPrintFinishCallback paramOnPrintFinishCallback)
    throws FileNotFoundException
  {
    if (Build.VERSION.SDK_INT < 19)
      return;
    PrintUriAdapter localPrintUriAdapter = new PrintUriAdapter(paramString, paramUri, paramOnPrintFinishCallback, this.mScaleMode);
    PrintManager localPrintManager = (PrintManager)this.mContext.getSystemService("print");
    PrintAttributes.Builder localBuilder = new PrintAttributes.Builder();
    localBuilder.setColorMode(this.mColorMode);
    if ((this.mOrientation == 1) || (this.mOrientation == 0))
      localBuilder.setMediaSize(PrintAttributes.MediaSize.UNKNOWN_LANDSCAPE);
    while (true)
    {
      localPrintManager.print(paramString, localPrintUriAdapter, localBuilder.build());
      break;
      if (this.mOrientation == 2)
        localBuilder.setMediaSize(PrintAttributes.MediaSize.UNKNOWN_PORTRAIT);
    }
  }

  public void setColorMode(int paramInt)
  {
    this.mColorMode = paramInt;
  }

  public void setOrientation(int paramInt)
  {
    this.mOrientation = paramInt;
  }

  public void setScaleMode(int paramInt)
  {
    this.mScaleMode = paramInt;
  }

  @RequiresApi(19)
  void writeBitmap(final PrintAttributes paramPrintAttributes, final int paramInt, final Bitmap paramBitmap, final ParcelFileDescriptor paramParcelFileDescriptor, final CancellationSignal paramCancellationSignal, final PrintDocumentAdapter.WriteResultCallback paramWriteResultCallback)
  {
    if (IS_MIN_MARGINS_HANDLING_CORRECT);
    for (final PrintAttributes localPrintAttributes = paramPrintAttributes; ; localPrintAttributes = copyAttributes(paramPrintAttributes).setMinMargins(new PrintAttributes.Margins(0, 0, 0, 0)).build())
    {
      new AsyncTask()
      {
        // ERROR //
        protected Throwable doInBackground(Void[] paramAnonymousArrayOfVoid)
        {
          // Byte code:
          //   0: aconst_null
          //   1: astore_2
          //   2: aload_0
          //   3: getfield 31	androidx/print/PrintHelper$1:val$cancellationSignal	Landroid/os/CancellationSignal;
          //   6: invokevirtual 63	android/os/CancellationSignal:isCanceled	()Z
          //   9: ifeq +6 -> 15
          //   12: goto +388 -> 400
          //   15: new 65	android/print/pdf/PrintedPdfDocument
          //   18: dup
          //   19: aload_0
          //   20: getfield 29	androidx/print/PrintHelper$1:this$0	Landroidx/print/PrintHelper;
          //   23: getfield 69	androidx/print/PrintHelper:mContext	Landroid/content/Context;
          //   26: aload_0
          //   27: getfield 33	androidx/print/PrintHelper$1:val$pdfAttributes	Landroid/print/PrintAttributes;
          //   30: invokespecial 72	android/print/pdf/PrintedPdfDocument:<init>	(Landroid/content/Context;Landroid/print/PrintAttributes;)V
          //   33: astore_3
          //   34: aload_0
          //   35: getfield 35	androidx/print/PrintHelper$1:val$bitmap	Landroid/graphics/Bitmap;
          //   38: aload_0
          //   39: getfield 33	androidx/print/PrintHelper$1:val$pdfAttributes	Landroid/print/PrintAttributes;
          //   42: invokevirtual 78	android/print/PrintAttributes:getColorMode	()I
          //   45: invokestatic 82	androidx/print/PrintHelper:convertBitmapForColorMode	(Landroid/graphics/Bitmap;I)Landroid/graphics/Bitmap;
          //   48: astore 4
          //   50: aload_0
          //   51: getfield 31	androidx/print/PrintHelper$1:val$cancellationSignal	Landroid/os/CancellationSignal;
          //   54: invokevirtual 63	android/os/CancellationSignal:isCanceled	()Z
          //   57: istore 5
          //   59: iload 5
          //   61: ifne +339 -> 400
          //   64: aload_3
          //   65: iconst_1
          //   66: invokevirtual 86	android/print/pdf/PrintedPdfDocument:startPage	(I)Landroid/graphics/pdf/PdfDocument$Page;
          //   69: astore 9
          //   71: getstatic 90	androidx/print/PrintHelper:IS_MIN_MARGINS_HANDLING_CORRECT	Z
          //   74: ifeq +123 -> 197
          //   77: new 92	android/graphics/RectF
          //   80: dup
          //   81: aload 9
          //   83: invokevirtual 98	android/graphics/pdf/PdfDocument$Page:getInfo	()Landroid/graphics/pdf/PdfDocument$PageInfo;
          //   86: invokevirtual 104	android/graphics/pdf/PdfDocument$PageInfo:getContentRect	()Landroid/graphics/Rect;
          //   89: invokespecial 107	android/graphics/RectF:<init>	(Landroid/graphics/Rect;)V
          //   92: astore 10
          //   94: aload 4
          //   96: invokevirtual 112	android/graphics/Bitmap:getWidth	()I
          //   99: aload 4
          //   101: invokevirtual 115	android/graphics/Bitmap:getHeight	()I
          //   104: aload 10
          //   106: aload_0
          //   107: getfield 39	androidx/print/PrintHelper$1:val$fittingMode	I
          //   110: invokestatic 119	androidx/print/PrintHelper:getMatrix	(IILandroid/graphics/RectF;I)Landroid/graphics/Matrix;
          //   113: astore 11
          //   115: getstatic 90	androidx/print/PrintHelper:IS_MIN_MARGINS_HANDLING_CORRECT	Z
          //   118: ifeq +180 -> 298
          //   121: aload 9
          //   123: invokevirtual 123	android/graphics/pdf/PdfDocument$Page:getCanvas	()Landroid/graphics/Canvas;
          //   126: aload 4
          //   128: aload 11
          //   130: aconst_null
          //   131: invokevirtual 129	android/graphics/Canvas:drawBitmap	(Landroid/graphics/Bitmap;Landroid/graphics/Matrix;Landroid/graphics/Paint;)V
          //   134: aload_3
          //   135: aload 9
          //   137: invokevirtual 133	android/print/pdf/PrintedPdfDocument:finishPage	(Landroid/graphics/pdf/PdfDocument$Page;)V
          //   140: aload_0
          //   141: getfield 31	androidx/print/PrintHelper$1:val$cancellationSignal	Landroid/os/CancellationSignal;
          //   144: invokevirtual 63	android/os/CancellationSignal:isCanceled	()Z
          //   147: istore 14
          //   149: iload 14
          //   151: ifeq +177 -> 328
          //   154: aload_3
          //   155: invokevirtual 136	android/print/pdf/PrintedPdfDocument:close	()V
          //   158: aload_0
          //   159: getfield 41	androidx/print/PrintHelper$1:val$fileDescriptor	Landroid/os/ParcelFileDescriptor;
          //   162: astore 17
          //   164: aload 17
          //   166: ifnull +10 -> 176
          //   169: aload_0
          //   170: getfield 41	androidx/print/PrintHelper$1:val$fileDescriptor	Landroid/os/ParcelFileDescriptor;
          //   173: invokevirtual 139	android/os/ParcelFileDescriptor:close	()V
          //   176: aload 4
          //   178: aload_0
          //   179: getfield 35	androidx/print/PrintHelper$1:val$bitmap	Landroid/graphics/Bitmap;
          //   182: if_acmpeq +218 -> 400
          //   185: aload 4
          //   187: invokevirtual 142	android/graphics/Bitmap:recycle	()V
          //   190: goto +210 -> 400
          //   193: astore_2
          //   194: goto +206 -> 400
          //   197: new 65	android/print/pdf/PrintedPdfDocument
          //   200: dup
          //   201: aload_0
          //   202: getfield 29	androidx/print/PrintHelper$1:this$0	Landroidx/print/PrintHelper;
          //   205: getfield 69	androidx/print/PrintHelper:mContext	Landroid/content/Context;
          //   208: aload_0
          //   209: getfield 37	androidx/print/PrintHelper$1:val$attributes	Landroid/print/PrintAttributes;
          //   212: invokespecial 72	android/print/pdf/PrintedPdfDocument:<init>	(Landroid/content/Context;Landroid/print/PrintAttributes;)V
          //   215: astore 19
          //   217: aload 19
          //   219: iconst_1
          //   220: invokevirtual 86	android/print/pdf/PrintedPdfDocument:startPage	(I)Landroid/graphics/pdf/PdfDocument$Page;
          //   223: astore 20
          //   225: new 92	android/graphics/RectF
          //   228: dup
          //   229: aload 20
          //   231: invokevirtual 98	android/graphics/pdf/PdfDocument$Page:getInfo	()Landroid/graphics/pdf/PdfDocument$PageInfo;
          //   234: invokevirtual 104	android/graphics/pdf/PdfDocument$PageInfo:getContentRect	()Landroid/graphics/Rect;
          //   237: invokespecial 107	android/graphics/RectF:<init>	(Landroid/graphics/Rect;)V
          //   240: astore 10
          //   242: aload 19
          //   244: aload 20
          //   246: invokevirtual 133	android/print/pdf/PrintedPdfDocument:finishPage	(Landroid/graphics/pdf/PdfDocument$Page;)V
          //   249: aload 19
          //   251: invokevirtual 136	android/print/pdf/PrintedPdfDocument:close	()V
          //   254: goto -160 -> 94
          //   257: astore 6
          //   259: aload_3
          //   260: invokevirtual 136	android/print/pdf/PrintedPdfDocument:close	()V
          //   263: aload_0
          //   264: getfield 41	androidx/print/PrintHelper$1:val$fileDescriptor	Landroid/os/ParcelFileDescriptor;
          //   267: astore 7
          //   269: aload 7
          //   271: ifnull +10 -> 281
          //   274: aload_0
          //   275: getfield 41	androidx/print/PrintHelper$1:val$fileDescriptor	Landroid/os/ParcelFileDescriptor;
          //   278: invokevirtual 139	android/os/ParcelFileDescriptor:close	()V
          //   281: aload 4
          //   283: aload_0
          //   284: getfield 35	androidx/print/PrintHelper$1:val$bitmap	Landroid/graphics/Bitmap;
          //   287: if_acmpeq +8 -> 295
          //   290: aload 4
          //   292: invokevirtual 142	android/graphics/Bitmap:recycle	()V
          //   295: aload 6
          //   297: athrow
          //   298: aload 11
          //   300: aload 10
          //   302: getfield 146	android/graphics/RectF:left	F
          //   305: aload 10
          //   307: getfield 149	android/graphics/RectF:top	F
          //   310: invokevirtual 155	android/graphics/Matrix:postTranslate	(FF)Z
          //   313: pop
          //   314: aload 9
          //   316: invokevirtual 123	android/graphics/pdf/PdfDocument$Page:getCanvas	()Landroid/graphics/Canvas;
          //   319: aload 10
          //   321: invokevirtual 159	android/graphics/Canvas:clipRect	(Landroid/graphics/RectF;)Z
          //   324: pop
          //   325: goto -204 -> 121
          //   328: aload_3
          //   329: new 161	java/io/FileOutputStream
          //   332: dup
          //   333: aload_0
          //   334: getfield 41	androidx/print/PrintHelper$1:val$fileDescriptor	Landroid/os/ParcelFileDescriptor;
          //   337: invokevirtual 165	android/os/ParcelFileDescriptor:getFileDescriptor	()Ljava/io/FileDescriptor;
          //   340: invokespecial 168	java/io/FileOutputStream:<init>	(Ljava/io/FileDescriptor;)V
          //   343: invokevirtual 172	android/print/pdf/PrintedPdfDocument:writeTo	(Ljava/io/OutputStream;)V
          //   346: aload_3
          //   347: invokevirtual 136	android/print/pdf/PrintedPdfDocument:close	()V
          //   350: aload_0
          //   351: getfield 41	androidx/print/PrintHelper$1:val$fileDescriptor	Landroid/os/ParcelFileDescriptor;
          //   354: astore 15
          //   356: aload 15
          //   358: ifnull +10 -> 368
          //   361: aload_0
          //   362: getfield 41	androidx/print/PrintHelper$1:val$fileDescriptor	Landroid/os/ParcelFileDescriptor;
          //   365: invokevirtual 139	android/os/ParcelFileDescriptor:close	()V
          //   368: aload 4
          //   370: aload_0
          //   371: getfield 35	androidx/print/PrintHelper$1:val$bitmap	Landroid/graphics/Bitmap;
          //   374: if_acmpeq +26 -> 400
          //   377: aload 4
          //   379: invokevirtual 142	android/graphics/Bitmap:recycle	()V
          //   382: goto +18 -> 400
          //   385: astore 8
          //   387: goto -106 -> 281
          //   390: astore 16
          //   392: goto -24 -> 368
          //   395: astore 18
          //   397: goto -221 -> 176
          //   400: aload_2
          //   401: areturn
          //
          // Exception table:
          //   from	to	target	type
          //   2	59	193	java/lang/Throwable
          //   154	164	193	java/lang/Throwable
          //   169	176	193	java/lang/Throwable
          //   176	190	193	java/lang/Throwable
          //   259	269	193	java/lang/Throwable
          //   274	281	193	java/lang/Throwable
          //   281	298	193	java/lang/Throwable
          //   346	356	193	java/lang/Throwable
          //   361	368	193	java/lang/Throwable
          //   368	382	193	java/lang/Throwable
          //   64	149	257	finally
          //   197	254	257	finally
          //   298	346	257	finally
          //   274	281	385	java/io/IOException
          //   361	368	390	java/io/IOException
          //   169	176	395	java/io/IOException
        }

        protected void onPostExecute(Throwable paramAnonymousThrowable)
        {
          if (paramCancellationSignal.isCanceled())
            paramWriteResultCallback.onWriteCancelled();
          while (true)
          {
            return;
            if (paramAnonymousThrowable == null)
            {
              PrintDocumentAdapter.WriteResultCallback localWriteResultCallback = paramWriteResultCallback;
              PageRange[] arrayOfPageRange = new PageRange[1];
              arrayOfPageRange[0] = PageRange.ALL_PAGES;
              localWriteResultCallback.onWriteFinished(arrayOfPageRange);
            }
            else
            {
              Log.e("PrintHelper", "Error writing printed content", paramAnonymousThrowable);
              paramWriteResultCallback.onWriteFailed(null);
            }
          }
        }
      }
      .execute(new Void[0]);
      return;
    }
  }

  public static abstract interface OnPrintFinishCallback
  {
    public abstract void onFinish();
  }

  @RequiresApi(19)
  private class PrintBitmapAdapter extends PrintDocumentAdapter
  {
    private PrintAttributes mAttributes;
    private final Bitmap mBitmap;
    private final PrintHelper.OnPrintFinishCallback mCallback;
    private final int mFittingMode;
    private final String mJobName;

    PrintBitmapAdapter(String paramInt, int paramBitmap, Bitmap paramOnPrintFinishCallback, PrintHelper.OnPrintFinishCallback arg5)
    {
      this.mJobName = paramInt;
      this.mFittingMode = paramBitmap;
      this.mBitmap = paramOnPrintFinishCallback;
      Object localObject;
      this.mCallback = localObject;
    }

    public void onFinish()
    {
      if (this.mCallback != null)
        this.mCallback.onFinish();
    }

    public void onLayout(PrintAttributes paramPrintAttributes1, PrintAttributes paramPrintAttributes2, CancellationSignal paramCancellationSignal, PrintDocumentAdapter.LayoutResultCallback paramLayoutResultCallback, Bundle paramBundle)
    {
      int i = 1;
      this.mAttributes = paramPrintAttributes2;
      PrintDocumentInfo localPrintDocumentInfo = new PrintDocumentInfo.Builder(this.mJobName).setContentType(i).setPageCount(i).build();
      if (!paramPrintAttributes2.equals(paramPrintAttributes1));
      while (true)
      {
        paramLayoutResultCallback.onLayoutFinished(localPrintDocumentInfo, i);
        return;
        int j = 0;
      }
    }

    public void onWrite(PageRange[] paramArrayOfPageRange, ParcelFileDescriptor paramParcelFileDescriptor, CancellationSignal paramCancellationSignal, PrintDocumentAdapter.WriteResultCallback paramWriteResultCallback)
    {
      PrintHelper.this.writeBitmap(this.mAttributes, this.mFittingMode, this.mBitmap, paramParcelFileDescriptor, paramCancellationSignal, paramWriteResultCallback);
    }
  }

  @RequiresApi(19)
  private class PrintUriAdapter extends PrintDocumentAdapter
  {
    PrintAttributes mAttributes;
    Bitmap mBitmap;
    final PrintHelper.OnPrintFinishCallback mCallback;
    final int mFittingMode;
    final Uri mImageFile;
    final String mJobName;
    AsyncTask<Uri, Boolean, Bitmap> mLoadBitmap;

    PrintUriAdapter(String paramUri, Uri paramOnPrintFinishCallback, PrintHelper.OnPrintFinishCallback paramInt, int arg5)
    {
      this.mJobName = paramUri;
      this.mImageFile = paramOnPrintFinishCallback;
      this.mCallback = paramInt;
      int i;
      this.mFittingMode = i;
      this.mBitmap = null;
    }

    void cancelLoad()
    {
      synchronized (PrintHelper.this.mLock)
      {
        if (PrintHelper.this.mDecodeOptions != null)
        {
          if (Build.VERSION.SDK_INT < 24)
            PrintHelper.this.mDecodeOptions.requestCancelDecode();
          PrintHelper.this.mDecodeOptions = null;
        }
        return;
      }
    }

    public void onFinish()
    {
      super.onFinish();
      cancelLoad();
      if (this.mLoadBitmap != null)
        this.mLoadBitmap.cancel(true);
      if (this.mCallback != null)
        this.mCallback.onFinish();
      if (this.mBitmap != null)
      {
        this.mBitmap.recycle();
        this.mBitmap = null;
      }
    }

    public void onLayout(final PrintAttributes paramPrintAttributes1, final PrintAttributes paramPrintAttributes2, final CancellationSignal paramCancellationSignal, final PrintDocumentAdapter.LayoutResultCallback paramLayoutResultCallback, Bundle paramBundle)
    {
      int i = 1;
      while (true)
      {
        try
        {
          this.mAttributes = paramPrintAttributes2;
          if (paramCancellationSignal.isCanceled())
          {
            paramLayoutResultCallback.onLayoutCancelled();
            return;
          }
        }
        finally
        {
        }
        if (this.mBitmap != null)
        {
          PrintDocumentInfo localPrintDocumentInfo = new PrintDocumentInfo.Builder(this.mJobName).setContentType(i).setPageCount(i).build();
          if (!paramPrintAttributes2.equals(paramPrintAttributes1));
          while (true)
          {
            paramLayoutResultCallback.onLayoutFinished(localPrintDocumentInfo, i);
            break;
            int j = 0;
          }
        }
        this.mLoadBitmap = new AsyncTask()
        {
          protected Bitmap doInBackground(Uri[] paramAnonymousArrayOfUri)
          {
            try
            {
              Bitmap localBitmap2 = PrintHelper.this.loadConstrainedBitmap(PrintHelper.PrintUriAdapter.this.mImageFile);
              localBitmap1 = localBitmap2;
              return localBitmap1;
            }
            catch (FileNotFoundException localFileNotFoundException)
            {
              while (true)
                Bitmap localBitmap1 = null;
            }
          }

          protected void onCancelled(Bitmap paramAnonymousBitmap)
          {
            paramLayoutResultCallback.onLayoutCancelled();
            PrintHelper.PrintUriAdapter.this.mLoadBitmap = null;
          }

          protected void onPostExecute(Bitmap paramAnonymousBitmap)
          {
            super.onPostExecute(paramAnonymousBitmap);
            if ((paramAnonymousBitmap != null) && ((!PrintHelper.PRINT_ACTIVITY_RESPECTS_ORIENTATION) || (PrintHelper.this.mOrientation == 0)));
            while (true)
            {
              try
              {
                PrintAttributes.MediaSize localMediaSize = PrintHelper.PrintUriAdapter.this.mAttributes.getMediaSize();
                if ((localMediaSize != null) && (localMediaSize.isPortrait() != PrintHelper.isPortrait(paramAnonymousBitmap)))
                {
                  Matrix localMatrix = new Matrix();
                  localMatrix.postRotate(90.0F);
                  int i = paramAnonymousBitmap.getWidth();
                  int j = paramAnonymousBitmap.getHeight();
                  paramAnonymousBitmap = Bitmap.createBitmap(paramAnonymousBitmap, 0, 0, i, j, localMatrix, true);
                }
                PrintHelper.PrintUriAdapter.this.mBitmap = paramAnonymousBitmap;
                if (paramAnonymousBitmap == null)
                  break label188;
                PrintDocumentInfo localPrintDocumentInfo = new PrintDocumentInfo.Builder(PrintHelper.PrintUriAdapter.this.mJobName).setContentType(1).setPageCount(1).build();
                if (!paramPrintAttributes2.equals(paramPrintAttributes1))
                {
                  bool = true;
                  paramLayoutResultCallback.onLayoutFinished(localPrintDocumentInfo, bool);
                  PrintHelper.PrintUriAdapter.this.mLoadBitmap = null;
                  return;
                }
              }
              finally
              {
              }
              boolean bool = false;
              continue;
              label188: paramLayoutResultCallback.onLayoutFailed(null);
            }
          }

          protected void onPreExecute()
          {
            paramCancellationSignal.setOnCancelListener(new CancellationSignal.OnCancelListener()
            {
              public void onCancel()
              {
                PrintHelper.PrintUriAdapter.this.cancelLoad();
                PrintHelper.PrintUriAdapter.1.this.cancel(false);
              }
            });
          }
        }
        .execute(new Uri[0]);
      }
    }

    public void onWrite(PageRange[] paramArrayOfPageRange, ParcelFileDescriptor paramParcelFileDescriptor, CancellationSignal paramCancellationSignal, PrintDocumentAdapter.WriteResultCallback paramWriteResultCallback)
    {
      PrintHelper.this.writeBitmap(this.mAttributes, this.mFittingMode, this.mBitmap, paramParcelFileDescriptor, paramCancellationSignal, paramWriteResultCallback);
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.print.PrintHelper
 * JD-Core Version:    0.6.2
 */