package androidx.appcompat.view;

public abstract interface CollapsibleActionView
{
  public abstract void onActionViewCollapsed();

  public abstract void onActionViewExpanded();
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.CollapsibleActionView
 * JD-Core Version:    0.6.2
 */