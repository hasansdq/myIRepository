package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import androidx.annotation.RestrictTo;
import java.util.ArrayList;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public class MenuAdapter extends BaseAdapter
{
  MenuBuilder mAdapterMenu;
  private int mExpandedIndex = -1;
  private boolean mForceShowIcon;
  private final LayoutInflater mInflater;
  private final int mItemLayoutRes;
  private final boolean mOverflowOnly;

  public MenuAdapter(MenuBuilder paramMenuBuilder, LayoutInflater paramLayoutInflater, boolean paramBoolean, int paramInt)
  {
    this.mOverflowOnly = paramBoolean;
    this.mInflater = paramLayoutInflater;
    this.mAdapterMenu = paramMenuBuilder;
    this.mItemLayoutRes = paramInt;
    findExpandedIndex();
  }

  void findExpandedIndex()
  {
    MenuItemImpl localMenuItemImpl = this.mAdapterMenu.getExpandedItem();
    int j;
    if (localMenuItemImpl != null)
    {
      ArrayList localArrayList = this.mAdapterMenu.getNonActionItems();
      int i = localArrayList.size();
      j = 0;
      if (j < i)
        if ((MenuItemImpl)localArrayList.get(j) != localMenuItemImpl);
    }
    for (this.mExpandedIndex = j; ; this.mExpandedIndex = -1)
    {
      return;
      j++;
      break;
    }
  }

  public MenuBuilder getAdapterMenu()
  {
    return this.mAdapterMenu;
  }

  public int getCount()
  {
    ArrayList localArrayList;
    if (this.mOverflowOnly)
    {
      localArrayList = this.mAdapterMenu.getNonActionItems();
      if (this.mExpandedIndex >= 0)
        break label40;
    }
    label40: for (int i = localArrayList.size(); ; i = -1 + localArrayList.size())
    {
      return i;
      localArrayList = this.mAdapterMenu.getVisibleItems();
      break;
    }
  }

  public boolean getForceShowIcon()
  {
    return this.mForceShowIcon;
  }

  public MenuItemImpl getItem(int paramInt)
  {
    if (this.mOverflowOnly);
    for (ArrayList localArrayList = this.mAdapterMenu.getNonActionItems(); ; localArrayList = this.mAdapterMenu.getVisibleItems())
    {
      if ((this.mExpandedIndex >= 0) && (paramInt >= this.mExpandedIndex))
        paramInt++;
      return (MenuItemImpl)localArrayList.get(paramInt);
    }
  }

  public long getItemId(int paramInt)
  {
    return paramInt;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    if (paramView == null)
      paramView = this.mInflater.inflate(this.mItemLayoutRes, paramViewGroup, false);
    int i = getItem(paramInt).getGroupId();
    int j;
    ListMenuItemView localListMenuItemView;
    if (paramInt - 1 >= 0)
    {
      j = getItem(paramInt - 1).getGroupId();
      localListMenuItemView = (ListMenuItemView)paramView;
      if ((!this.mAdapterMenu.isGroupDividerEnabled()) || (i == j))
        break label122;
    }
    label122: for (boolean bool = true; ; bool = false)
    {
      localListMenuItemView.setGroupDividerEnabled(bool);
      MenuView.ItemView localItemView = (MenuView.ItemView)paramView;
      if (this.mForceShowIcon)
        ((ListMenuItemView)paramView).setForceShowIcon(true);
      localItemView.initialize(getItem(paramInt), 0);
      return paramView;
      j = i;
      break;
    }
  }

  public void notifyDataSetChanged()
  {
    findExpandedIndex();
    super.notifyDataSetChanged();
  }

  public void setForceShowIcon(boolean paramBoolean)
  {
    this.mForceShowIcon = paramBoolean;
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.menu.MenuAdapter
 * JD-Core Version:    0.6.2
 */