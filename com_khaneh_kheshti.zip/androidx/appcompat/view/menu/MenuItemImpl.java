package androidx.appcompat.view.menu;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.Log;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MenuItem.OnActionExpandListener;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewDebug.CapturedViewProperty;
import android.widget.LinearLayout;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R.string;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.core.internal.view.SupportMenuItem;
import androidx.core.view.ActionProvider.VisibilityListener;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public final class MenuItemImpl
  implements SupportMenuItem
{
  private static final int CHECKABLE = 1;
  private static final int CHECKED = 2;
  private static final int ENABLED = 16;
  private static final int EXCLUSIVE = 4;
  private static final int HIDDEN = 8;
  private static final int IS_ACTION = 32;
  static final int NO_ICON = 0;
  private static final int SHOW_AS_ACTION_MASK = 3;
  private static final String TAG = "MenuItemImpl";
  private androidx.core.view.ActionProvider mActionProvider;
  private View mActionView;
  private final int mCategoryOrder;
  private MenuItem.OnMenuItemClickListener mClickListener;
  private CharSequence mContentDescription;
  private int mFlags = 16;
  private final int mGroup;
  private boolean mHasIconTint = false;
  private boolean mHasIconTintMode = false;
  private Drawable mIconDrawable;
  private int mIconResId = 0;
  private ColorStateList mIconTintList = null;
  private PorterDuff.Mode mIconTintMode = null;
  private final int mId;
  private Intent mIntent;
  private boolean mIsActionViewExpanded = false;
  private Runnable mItemCallback;
  MenuBuilder mMenu;
  private ContextMenu.ContextMenuInfo mMenuInfo;
  private boolean mNeedToApplyIconTint = false;
  private MenuItem.OnActionExpandListener mOnActionExpandListener;
  private final int mOrdering;
  private char mShortcutAlphabeticChar;
  private int mShortcutAlphabeticModifiers = 4096;
  private char mShortcutNumericChar;
  private int mShortcutNumericModifiers = 4096;
  private int mShowAsAction = 0;
  private SubMenuBuilder mSubMenu;
  private CharSequence mTitle;
  private CharSequence mTitleCondensed;
  private CharSequence mTooltipText;

  MenuItemImpl(MenuBuilder paramMenuBuilder, int paramInt1, int paramInt2, int paramInt3, int paramInt4, CharSequence paramCharSequence, int paramInt5)
  {
    this.mMenu = paramMenuBuilder;
    this.mId = paramInt2;
    this.mGroup = paramInt1;
    this.mCategoryOrder = paramInt3;
    this.mOrdering = paramInt4;
    this.mTitle = paramCharSequence;
    this.mShowAsAction = paramInt5;
  }

  private static void appendModifier(StringBuilder paramStringBuilder, int paramInt1, int paramInt2, String paramString)
  {
    if ((paramInt1 & paramInt2) == paramInt2)
      paramStringBuilder.append(paramString);
  }

  private Drawable applyIconTintIfNecessary(Drawable paramDrawable)
  {
    if ((paramDrawable != null) && (this.mNeedToApplyIconTint) && ((this.mHasIconTint) || (this.mHasIconTintMode)))
    {
      paramDrawable = DrawableCompat.wrap(paramDrawable).mutate();
      if (this.mHasIconTint)
        DrawableCompat.setTintList(paramDrawable, this.mIconTintList);
      if (this.mHasIconTintMode)
        DrawableCompat.setTintMode(paramDrawable, this.mIconTintMode);
      this.mNeedToApplyIconTint = false;
    }
    return paramDrawable;
  }

  public void actionFormatChanged()
  {
    this.mMenu.onItemActionRequestChanged(this);
  }

  public boolean collapseActionView()
  {
    boolean bool = false;
    if ((0x8 & this.mShowAsAction) == 0);
    while (true)
    {
      return bool;
      if (this.mActionView == null)
        bool = true;
      else if ((this.mOnActionExpandListener == null) || (this.mOnActionExpandListener.onMenuItemActionCollapse(this)))
        bool = this.mMenu.collapseItemActionView(this);
    }
  }

  public boolean expandActionView()
  {
    boolean bool = false;
    if (!hasCollapsibleActionView());
    while (true)
    {
      return bool;
      if ((this.mOnActionExpandListener == null) || (this.mOnActionExpandListener.onMenuItemActionExpand(this)))
        bool = this.mMenu.expandItemActionView(this);
    }
  }

  public android.view.ActionProvider getActionProvider()
  {
    throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.getActionProvider()");
  }

  public View getActionView()
  {
    View localView;
    if (this.mActionView != null)
      localView = this.mActionView;
    while (true)
    {
      return localView;
      if (this.mActionProvider != null)
      {
        this.mActionView = this.mActionProvider.onCreateActionView(this);
        localView = this.mActionView;
      }
      else
      {
        localView = null;
      }
    }
  }

  public int getAlphabeticModifiers()
  {
    return this.mShortcutAlphabeticModifiers;
  }

  public char getAlphabeticShortcut()
  {
    return this.mShortcutAlphabeticChar;
  }

  Runnable getCallback()
  {
    return this.mItemCallback;
  }

  public CharSequence getContentDescription()
  {
    return this.mContentDescription;
  }

  public int getGroupId()
  {
    return this.mGroup;
  }

  public Drawable getIcon()
  {
    Drawable localDrawable1;
    if (this.mIconDrawable != null)
      localDrawable1 = applyIconTintIfNecessary(this.mIconDrawable);
    while (true)
    {
      return localDrawable1;
      if (this.mIconResId != 0)
      {
        Drawable localDrawable2 = AppCompatResources.getDrawable(this.mMenu.getContext(), this.mIconResId);
        this.mIconResId = 0;
        this.mIconDrawable = localDrawable2;
        localDrawable1 = applyIconTintIfNecessary(localDrawable2);
      }
      else
      {
        localDrawable1 = null;
      }
    }
  }

  public ColorStateList getIconTintList()
  {
    return this.mIconTintList;
  }

  public PorterDuff.Mode getIconTintMode()
  {
    return this.mIconTintMode;
  }

  public Intent getIntent()
  {
    return this.mIntent;
  }

  @ViewDebug.CapturedViewProperty
  public int getItemId()
  {
    return this.mId;
  }

  public ContextMenu.ContextMenuInfo getMenuInfo()
  {
    return this.mMenuInfo;
  }

  public int getNumericModifiers()
  {
    return this.mShortcutNumericModifiers;
  }

  public char getNumericShortcut()
  {
    return this.mShortcutNumericChar;
  }

  public int getOrder()
  {
    return this.mCategoryOrder;
  }

  public int getOrdering()
  {
    return this.mOrdering;
  }

  char getShortcut()
  {
    if (this.mMenu.isQwertyMode());
    for (char c = this.mShortcutAlphabeticChar; ; c = this.mShortcutNumericChar)
      return c;
  }

  String getShortcutLabel()
  {
    char c = getShortcut();
    String str;
    if (c == 0)
    {
      str = "";
      return str;
    }
    Resources localResources = this.mMenu.getContext().getResources();
    StringBuilder localStringBuilder = new StringBuilder();
    if (ViewConfiguration.get(this.mMenu.getContext()).hasPermanentMenuKey())
      localStringBuilder.append(localResources.getString(R.string.abc_prepend_shortcut_label));
    int i;
    if (this.mMenu.isQwertyMode())
    {
      i = this.mShortcutAlphabeticModifiers;
      label80: appendModifier(localStringBuilder, i, 65536, localResources.getString(R.string.abc_menu_meta_shortcut_label));
      appendModifier(localStringBuilder, i, 4096, localResources.getString(R.string.abc_menu_ctrl_shortcut_label));
      appendModifier(localStringBuilder, i, 2, localResources.getString(R.string.abc_menu_alt_shortcut_label));
      appendModifier(localStringBuilder, i, 1, localResources.getString(R.string.abc_menu_shift_shortcut_label));
      appendModifier(localStringBuilder, i, 4, localResources.getString(R.string.abc_menu_sym_shortcut_label));
      appendModifier(localStringBuilder, i, 8, localResources.getString(R.string.abc_menu_function_shortcut_label));
      switch (c)
      {
      default:
        localStringBuilder.append(c);
      case '\n':
      case '\b':
      case ' ':
      }
    }
    while (true)
    {
      str = localStringBuilder.toString();
      break;
      i = this.mShortcutNumericModifiers;
      break label80;
      localStringBuilder.append(localResources.getString(R.string.abc_menu_enter_shortcut_label));
      continue;
      localStringBuilder.append(localResources.getString(R.string.abc_menu_delete_shortcut_label));
      continue;
      localStringBuilder.append(localResources.getString(R.string.abc_menu_space_shortcut_label));
    }
  }

  public SubMenu getSubMenu()
  {
    return this.mSubMenu;
  }

  public androidx.core.view.ActionProvider getSupportActionProvider()
  {
    return this.mActionProvider;
  }

  @ViewDebug.CapturedViewProperty
  public CharSequence getTitle()
  {
    return this.mTitle;
  }

  public CharSequence getTitleCondensed()
  {
    if (this.mTitleCondensed != null);
    for (Object localObject = this.mTitleCondensed; ; localObject = this.mTitle)
    {
      if ((Build.VERSION.SDK_INT < 18) && (localObject != null) && (!(localObject instanceof String)))
        localObject = ((CharSequence)localObject).toString();
      return localObject;
    }
  }

  CharSequence getTitleForItemView(MenuView.ItemView paramItemView)
  {
    if ((paramItemView != null) && (paramItemView.prefersCondensedTitle()));
    for (CharSequence localCharSequence = getTitleCondensed(); ; localCharSequence = getTitle())
      return localCharSequence;
  }

  public CharSequence getTooltipText()
  {
    return this.mTooltipText;
  }

  public boolean hasCollapsibleActionView()
  {
    boolean bool = false;
    if ((0x8 & this.mShowAsAction) != 0)
    {
      if ((this.mActionView == null) && (this.mActionProvider != null))
        this.mActionView = this.mActionProvider.onCreateActionView(this);
      if (this.mActionView != null)
        bool = true;
    }
    return bool;
  }

  public boolean hasSubMenu()
  {
    if (this.mSubMenu != null);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean invoke()
  {
    boolean bool = true;
    if ((this.mClickListener != null) && (this.mClickListener.onMenuItemClick(this)));
    while (true)
    {
      return bool;
      if (!this.mMenu.dispatchMenuItemSelected(this.mMenu, this))
        if (this.mItemCallback != null)
          this.mItemCallback.run();
        else if (this.mIntent != null)
          try
          {
            this.mMenu.getContext().startActivity(this.mIntent);
          }
          catch (ActivityNotFoundException localActivityNotFoundException)
          {
            Log.e("MenuItemImpl", "Can't find activity to handle intent; ignoring", localActivityNotFoundException);
          }
        else if ((this.mActionProvider == null) || (!this.mActionProvider.onPerformDefaultAction()))
          bool = false;
    }
  }

  public boolean isActionButton()
  {
    if ((0x20 & this.mFlags) == 32);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isActionViewExpanded()
  {
    return this.mIsActionViewExpanded;
  }

  public boolean isCheckable()
  {
    int i = 1;
    if ((0x1 & this.mFlags) == i);
    while (true)
    {
      return i;
      int j = 0;
    }
  }

  public boolean isChecked()
  {
    if ((0x2 & this.mFlags) == 2);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isEnabled()
  {
    if ((0x10 & this.mFlags) != 0);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isExclusiveCheckable()
  {
    if ((0x4 & this.mFlags) != 0);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isVisible()
  {
    boolean bool = true;
    if ((this.mActionProvider != null) && (this.mActionProvider.overridesItemVisibility()))
      if (((0x8 & this.mFlags) != 0) || (!this.mActionProvider.isVisible()));
    while (true)
    {
      return bool;
      bool = false;
      continue;
      if ((0x8 & this.mFlags) != 0)
        bool = false;
    }
  }

  public boolean requestsActionButton()
  {
    int i = 1;
    if ((0x1 & this.mShowAsAction) == i);
    while (true)
    {
      return i;
      int j = 0;
    }
  }

  public boolean requiresActionButton()
  {
    if ((0x2 & this.mShowAsAction) == 2);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public MenuItem setActionProvider(android.view.ActionProvider paramActionProvider)
  {
    throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.setActionProvider()");
  }

  public SupportMenuItem setActionView(int paramInt)
  {
    Context localContext = this.mMenu.getContext();
    setActionView(LayoutInflater.from(localContext).inflate(paramInt, new LinearLayout(localContext), false));
    return this;
  }

  public SupportMenuItem setActionView(View paramView)
  {
    this.mActionView = paramView;
    this.mActionProvider = null;
    if ((paramView != null) && (paramView.getId() == -1) && (this.mId > 0))
      paramView.setId(this.mId);
    this.mMenu.onItemActionRequestChanged(this);
    return this;
  }

  public void setActionViewExpanded(boolean paramBoolean)
  {
    this.mIsActionViewExpanded = paramBoolean;
    this.mMenu.onItemsChanged(false);
  }

  public MenuItem setAlphabeticShortcut(char paramChar)
  {
    if (this.mShortcutAlphabeticChar == paramChar);
    while (true)
    {
      return this;
      this.mShortcutAlphabeticChar = Character.toLowerCase(paramChar);
      this.mMenu.onItemsChanged(false);
    }
  }

  public MenuItem setAlphabeticShortcut(char paramChar, int paramInt)
  {
    if ((this.mShortcutAlphabeticChar == paramChar) && (this.mShortcutAlphabeticModifiers == paramInt));
    while (true)
    {
      return this;
      this.mShortcutAlphabeticChar = Character.toLowerCase(paramChar);
      this.mShortcutAlphabeticModifiers = KeyEvent.normalizeMetaState(paramInt);
      this.mMenu.onItemsChanged(false);
    }
  }

  public MenuItem setCallback(Runnable paramRunnable)
  {
    this.mItemCallback = paramRunnable;
    return this;
  }

  public MenuItem setCheckable(boolean paramBoolean)
  {
    int i = this.mFlags;
    int j = 0xFFFFFFFE & this.mFlags;
    if (paramBoolean);
    for (int k = 1; ; k = 0)
    {
      this.mFlags = (k | j);
      if (i != this.mFlags)
        this.mMenu.onItemsChanged(false);
      return this;
    }
  }

  public MenuItem setChecked(boolean paramBoolean)
  {
    if ((0x4 & this.mFlags) != 0)
      this.mMenu.setExclusiveItemChecked(this);
    while (true)
    {
      return this;
      setCheckedInt(paramBoolean);
    }
  }

  void setCheckedInt(boolean paramBoolean)
  {
    int i = this.mFlags;
    int j = 0xFFFFFFFD & this.mFlags;
    if (paramBoolean);
    for (int k = 2; ; k = 0)
    {
      this.mFlags = (k | j);
      if (i != this.mFlags)
        this.mMenu.onItemsChanged(false);
      return;
    }
  }

  public SupportMenuItem setContentDescription(CharSequence paramCharSequence)
  {
    this.mContentDescription = paramCharSequence;
    this.mMenu.onItemsChanged(false);
    return this;
  }

  public MenuItem setEnabled(boolean paramBoolean)
  {
    if (paramBoolean);
    for (this.mFlags = (0x10 | this.mFlags); ; this.mFlags = (0xFFFFFFEF & this.mFlags))
    {
      this.mMenu.onItemsChanged(false);
      return this;
    }
  }

  public void setExclusiveCheckable(boolean paramBoolean)
  {
    int i = 0xFFFFFFFB & this.mFlags;
    if (paramBoolean);
    for (int j = 4; ; j = 0)
    {
      this.mFlags = (j | i);
      return;
    }
  }

  public MenuItem setIcon(int paramInt)
  {
    this.mIconDrawable = null;
    this.mIconResId = paramInt;
    this.mNeedToApplyIconTint = true;
    this.mMenu.onItemsChanged(false);
    return this;
  }

  public MenuItem setIcon(Drawable paramDrawable)
  {
    this.mIconResId = 0;
    this.mIconDrawable = paramDrawable;
    this.mNeedToApplyIconTint = true;
    this.mMenu.onItemsChanged(false);
    return this;
  }

  public MenuItem setIconTintList(@Nullable ColorStateList paramColorStateList)
  {
    this.mIconTintList = paramColorStateList;
    this.mHasIconTint = true;
    this.mNeedToApplyIconTint = true;
    this.mMenu.onItemsChanged(false);
    return this;
  }

  public MenuItem setIconTintMode(PorterDuff.Mode paramMode)
  {
    this.mIconTintMode = paramMode;
    this.mHasIconTintMode = true;
    this.mNeedToApplyIconTint = true;
    this.mMenu.onItemsChanged(false);
    return this;
  }

  public MenuItem setIntent(Intent paramIntent)
  {
    this.mIntent = paramIntent;
    return this;
  }

  public void setIsActionButton(boolean paramBoolean)
  {
    if (paramBoolean);
    for (this.mFlags = (0x20 | this.mFlags); ; this.mFlags = (0xFFFFFFDF & this.mFlags))
      return;
  }

  void setMenuInfo(ContextMenu.ContextMenuInfo paramContextMenuInfo)
  {
    this.mMenuInfo = paramContextMenuInfo;
  }

  public MenuItem setNumericShortcut(char paramChar)
  {
    if (this.mShortcutNumericChar == paramChar);
    while (true)
    {
      return this;
      this.mShortcutNumericChar = paramChar;
      this.mMenu.onItemsChanged(false);
    }
  }

  public MenuItem setNumericShortcut(char paramChar, int paramInt)
  {
    if ((this.mShortcutNumericChar == paramChar) && (this.mShortcutNumericModifiers == paramInt));
    while (true)
    {
      return this;
      this.mShortcutNumericChar = paramChar;
      this.mShortcutNumericModifiers = KeyEvent.normalizeMetaState(paramInt);
      this.mMenu.onItemsChanged(false);
    }
  }

  public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener paramOnActionExpandListener)
  {
    this.mOnActionExpandListener = paramOnActionExpandListener;
    return this;
  }

  public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener paramOnMenuItemClickListener)
  {
    this.mClickListener = paramOnMenuItemClickListener;
    return this;
  }

  public MenuItem setShortcut(char paramChar1, char paramChar2)
  {
    this.mShortcutNumericChar = paramChar1;
    this.mShortcutAlphabeticChar = Character.toLowerCase(paramChar2);
    this.mMenu.onItemsChanged(false);
    return this;
  }

  public MenuItem setShortcut(char paramChar1, char paramChar2, int paramInt1, int paramInt2)
  {
    this.mShortcutNumericChar = paramChar1;
    this.mShortcutNumericModifiers = KeyEvent.normalizeMetaState(paramInt1);
    this.mShortcutAlphabeticChar = Character.toLowerCase(paramChar2);
    this.mShortcutAlphabeticModifiers = KeyEvent.normalizeMetaState(paramInt2);
    this.mMenu.onItemsChanged(false);
    return this;
  }

  public void setShowAsAction(int paramInt)
  {
    switch (paramInt & 0x3)
    {
    default:
      throw new IllegalArgumentException("SHOW_AS_ACTION_ALWAYS, SHOW_AS_ACTION_IF_ROOM, and SHOW_AS_ACTION_NEVER are mutually exclusive.");
    case 0:
    case 1:
    case 2:
    }
    this.mShowAsAction = paramInt;
    this.mMenu.onItemActionRequestChanged(this);
  }

  public SupportMenuItem setShowAsActionFlags(int paramInt)
  {
    setShowAsAction(paramInt);
    return this;
  }

  public void setSubMenu(SubMenuBuilder paramSubMenuBuilder)
  {
    this.mSubMenu = paramSubMenuBuilder;
    paramSubMenuBuilder.setHeaderTitle(getTitle());
  }

  public SupportMenuItem setSupportActionProvider(androidx.core.view.ActionProvider paramActionProvider)
  {
    if (this.mActionProvider != null)
      this.mActionProvider.reset();
    this.mActionView = null;
    this.mActionProvider = paramActionProvider;
    this.mMenu.onItemsChanged(true);
    if (this.mActionProvider != null)
      this.mActionProvider.setVisibilityListener(new ActionProvider.VisibilityListener()
      {
        public void onActionProviderVisibilityChanged(boolean paramAnonymousBoolean)
        {
          MenuItemImpl.this.mMenu.onItemVisibleChanged(MenuItemImpl.this);
        }
      });
    return this;
  }

  public MenuItem setTitle(int paramInt)
  {
    return setTitle(this.mMenu.getContext().getString(paramInt));
  }

  public MenuItem setTitle(CharSequence paramCharSequence)
  {
    this.mTitle = paramCharSequence;
    this.mMenu.onItemsChanged(false);
    if (this.mSubMenu != null)
      this.mSubMenu.setHeaderTitle(paramCharSequence);
    return this;
  }

  public MenuItem setTitleCondensed(CharSequence paramCharSequence)
  {
    this.mTitleCondensed = paramCharSequence;
    if (paramCharSequence == null);
    this.mMenu.onItemsChanged(false);
    return this;
  }

  public SupportMenuItem setTooltipText(CharSequence paramCharSequence)
  {
    this.mTooltipText = paramCharSequence;
    this.mMenu.onItemsChanged(false);
    return this;
  }

  public MenuItem setVisible(boolean paramBoolean)
  {
    if (setVisibleInt(paramBoolean))
      this.mMenu.onItemVisibleChanged(this);
    return this;
  }

  boolean setVisibleInt(boolean paramBoolean)
  {
    boolean bool = false;
    int i = this.mFlags;
    int j = 0xFFFFFFF7 & this.mFlags;
    if (paramBoolean);
    for (int k = 0; ; k = 8)
    {
      this.mFlags = (k | j);
      if (i != this.mFlags)
        bool = true;
      return bool;
    }
  }

  public boolean shouldShowIcon()
  {
    return this.mMenu.getOptionalIconsVisible();
  }

  boolean shouldShowShortcut()
  {
    if ((this.mMenu.isShortcutsVisible()) && (getShortcut() != 0));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean showsTextAsAction()
  {
    if ((0x4 & this.mShowAsAction) == 4);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public String toString()
  {
    if (this.mTitle != null);
    for (String str = this.mTitle.toString(); ; str = null)
      return str;
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.menu.MenuItemImpl
 * JD-Core Version:    0.6.2
 */