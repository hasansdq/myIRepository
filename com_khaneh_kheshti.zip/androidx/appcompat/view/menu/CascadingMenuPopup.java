package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.View.OnKeyListener;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;
import androidx.annotation.AttrRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StyleRes;
import androidx.appcompat.R.dimen;
import androidx.appcompat.R.layout;
import androidx.appcompat.widget.MenuItemHoverListener;
import androidx.appcompat.widget.MenuPopupWindow;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

final class CascadingMenuPopup extends MenuPopup
  implements MenuPresenter, View.OnKeyListener, PopupWindow.OnDismissListener
{
  static final int HORIZ_POSITION_LEFT = 0;
  static final int HORIZ_POSITION_RIGHT = 1;
  private static final int ITEM_LAYOUT = 0;
  static final int SUBMENU_TIMEOUT_MS = 200;
  private View mAnchorView;
  private final View.OnAttachStateChangeListener mAttachStateChangeListener = new View.OnAttachStateChangeListener()
  {
    public void onViewAttachedToWindow(View paramAnonymousView)
    {
    }

    public void onViewDetachedFromWindow(View paramAnonymousView)
    {
      if (CascadingMenuPopup.this.mTreeObserver != null)
      {
        if (!CascadingMenuPopup.this.mTreeObserver.isAlive())
          CascadingMenuPopup.this.mTreeObserver = paramAnonymousView.getViewTreeObserver();
        CascadingMenuPopup.this.mTreeObserver.removeGlobalOnLayoutListener(CascadingMenuPopup.this.mGlobalLayoutListener);
      }
      paramAnonymousView.removeOnAttachStateChangeListener(this);
    }
  };
  private final Context mContext;
  private int mDropDownGravity = 0;
  private boolean mForceShowIcon;
  final ViewTreeObserver.OnGlobalLayoutListener mGlobalLayoutListener = new ViewTreeObserver.OnGlobalLayoutListener()
  {
    public void onGlobalLayout()
    {
      if ((CascadingMenuPopup.this.isShowing()) && (CascadingMenuPopup.this.mShowingMenus.size() > 0) && (!((CascadingMenuPopup.CascadingMenuInfo)CascadingMenuPopup.this.mShowingMenus.get(0)).window.isModal()))
      {
        View localView = CascadingMenuPopup.this.mShownAnchorView;
        if ((localView != null) && (localView.isShown()))
          break label77;
        CascadingMenuPopup.this.dismiss();
      }
      while (true)
      {
        return;
        label77: Iterator localIterator = CascadingMenuPopup.this.mShowingMenus.iterator();
        while (localIterator.hasNext())
          ((CascadingMenuPopup.CascadingMenuInfo)localIterator.next()).window.show();
      }
    }
  };
  private boolean mHasXOffset;
  private boolean mHasYOffset;
  private int mLastPosition;
  private final MenuItemHoverListener mMenuItemHoverListener = new MenuItemHoverListener()
  {
    public void onItemHoverEnter(@NonNull final MenuBuilder paramAnonymousMenuBuilder, @NonNull final MenuItem paramAnonymousMenuItem)
    {
      CascadingMenuPopup.this.mSubMenuHoverHandler.removeCallbacksAndMessages(null);
      int i = -1;
      int j = 0;
      int k = CascadingMenuPopup.this.mShowingMenus.size();
      while (true)
      {
        if (j < k)
        {
          if (paramAnonymousMenuBuilder == ((CascadingMenuPopup.CascadingMenuInfo)CascadingMenuPopup.this.mShowingMenus.get(j)).menu)
            i = j;
        }
        else
        {
          if (i != -1)
            break;
          return;
        }
        j++;
      }
      int m = i + 1;
      if (m < CascadingMenuPopup.this.mShowingMenus.size());
      for (final CascadingMenuPopup.CascadingMenuInfo localCascadingMenuInfo = (CascadingMenuPopup.CascadingMenuInfo)CascadingMenuPopup.this.mShowingMenus.get(m); ; localCascadingMenuInfo = null)
      {
        Runnable local1 = new Runnable()
        {
          public void run()
          {
            if (localCascadingMenuInfo != null)
            {
              CascadingMenuPopup.this.mShouldCloseImmediately = true;
              localCascadingMenuInfo.menu.close(false);
              CascadingMenuPopup.this.mShouldCloseImmediately = false;
            }
            if ((paramAnonymousMenuItem.isEnabled()) && (paramAnonymousMenuItem.hasSubMenu()))
              paramAnonymousMenuBuilder.performItemAction(paramAnonymousMenuItem, 4);
          }
        };
        long l = 200L + SystemClock.uptimeMillis();
        CascadingMenuPopup.this.mSubMenuHoverHandler.postAtTime(local1, paramAnonymousMenuBuilder, l);
        break;
      }
    }

    public void onItemHoverExit(@NonNull MenuBuilder paramAnonymousMenuBuilder, @NonNull MenuItem paramAnonymousMenuItem)
    {
      CascadingMenuPopup.this.mSubMenuHoverHandler.removeCallbacksAndMessages(paramAnonymousMenuBuilder);
    }
  };
  private final int mMenuMaxWidth;
  private PopupWindow.OnDismissListener mOnDismissListener;
  private final boolean mOverflowOnly;
  private final List<MenuBuilder> mPendingMenus = new ArrayList();
  private final int mPopupStyleAttr;
  private final int mPopupStyleRes;
  private MenuPresenter.Callback mPresenterCallback;
  private int mRawDropDownGravity = 0;
  boolean mShouldCloseImmediately;
  private boolean mShowTitle;
  final List<CascadingMenuInfo> mShowingMenus = new ArrayList();
  View mShownAnchorView;
  final Handler mSubMenuHoverHandler;
  ViewTreeObserver mTreeObserver;
  private int mXOffset;
  private int mYOffset;

  public CascadingMenuPopup(@NonNull Context paramContext, @NonNull View paramView, @AttrRes int paramInt1, @StyleRes int paramInt2, boolean paramBoolean)
  {
    this.mContext = paramContext;
    this.mAnchorView = paramView;
    this.mPopupStyleAttr = paramInt1;
    this.mPopupStyleRes = paramInt2;
    this.mOverflowOnly = paramBoolean;
    this.mForceShowIcon = false;
    this.mLastPosition = getInitialMenuPosition();
    Resources localResources = paramContext.getResources();
    this.mMenuMaxWidth = Math.max(localResources.getDisplayMetrics().widthPixels / 2, localResources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
    this.mSubMenuHoverHandler = new Handler();
  }

  private MenuPopupWindow createPopupWindow()
  {
    MenuPopupWindow localMenuPopupWindow = new MenuPopupWindow(this.mContext, null, this.mPopupStyleAttr, this.mPopupStyleRes);
    localMenuPopupWindow.setHoverListener(this.mMenuItemHoverListener);
    localMenuPopupWindow.setOnItemClickListener(this);
    localMenuPopupWindow.setOnDismissListener(this);
    localMenuPopupWindow.setAnchorView(this.mAnchorView);
    localMenuPopupWindow.setDropDownGravity(this.mDropDownGravity);
    localMenuPopupWindow.setModal(true);
    localMenuPopupWindow.setInputMethodMode(2);
    return localMenuPopupWindow;
  }

  private int findIndexOfAddedMenu(@NonNull MenuBuilder paramMenuBuilder)
  {
    int i = 0;
    int j = this.mShowingMenus.size();
    if (i < j)
      if (paramMenuBuilder != ((CascadingMenuInfo)this.mShowingMenus.get(i)).menu);
    while (true)
    {
      return i;
      i++;
      break;
      i = -1;
    }
  }

  private MenuItem findMenuItemForSubmenu(@NonNull MenuBuilder paramMenuBuilder1, @NonNull MenuBuilder paramMenuBuilder2)
  {
    int i = 0;
    int j = paramMenuBuilder1.size();
    MenuItem localMenuItem;
    if (i < j)
    {
      localMenuItem = paramMenuBuilder1.getItem(i);
      if ((!localMenuItem.hasSubMenu()) || (paramMenuBuilder2 != localMenuItem.getSubMenu()));
    }
    while (true)
    {
      return localMenuItem;
      i++;
      break;
      localMenuItem = null;
    }
  }

  @Nullable
  private View findParentViewForSubmenu(@NonNull CascadingMenuInfo paramCascadingMenuInfo, @NonNull MenuBuilder paramMenuBuilder)
  {
    View localView = null;
    MenuItem localMenuItem = findMenuItemForSubmenu(paramCascadingMenuInfo.menu, paramMenuBuilder);
    if (localMenuItem == null)
      return localView;
    ListView localListView = paramCascadingMenuInfo.getListView();
    ListAdapter localListAdapter = localListView.getAdapter();
    int i;
    MenuAdapter localMenuAdapter;
    label65: int j;
    int k;
    int m;
    if ((localListAdapter instanceof HeaderViewListAdapter))
    {
      HeaderViewListAdapter localHeaderViewListAdapter = (HeaderViewListAdapter)localListAdapter;
      i = localHeaderViewListAdapter.getHeadersCount();
      localMenuAdapter = (MenuAdapter)localHeaderViewListAdapter.getWrappedAdapter();
      j = -1;
      k = 0;
      m = localMenuAdapter.getCount();
    }
    while (true)
    {
      if (k < m)
      {
        if (localMenuItem == localMenuAdapter.getItem(k))
          j = k;
      }
      else
      {
        if (j == -1)
          break;
        int n = j + i - localListView.getFirstVisiblePosition();
        if ((n < 0) || (n >= localListView.getChildCount()))
          break;
        localView = localListView.getChildAt(n);
        break;
        i = 0;
        localMenuAdapter = (MenuAdapter)localListAdapter;
        break label65;
      }
      k++;
    }
  }

  private int getInitialMenuPosition()
  {
    int i = 1;
    if (ViewCompat.getLayoutDirection(this.mAnchorView) == i)
      i = 0;
    return i;
  }

  private int getNextMenuPosition(int paramInt)
  {
    ListView localListView = ((CascadingMenuInfo)this.mShowingMenus.get(-1 + this.mShowingMenus.size())).getListView();
    int[] arrayOfInt = new int[2];
    localListView.getLocationOnScreen(arrayOfInt);
    Rect localRect = new Rect();
    this.mShownAnchorView.getWindowVisibleDisplayFrame(localRect);
    int i;
    if (this.mLastPosition == 1)
      if (paramInt + (arrayOfInt[0] + localListView.getWidth()) > localRect.right)
        i = 0;
    while (true)
    {
      return i;
      i = 1;
      continue;
      if (arrayOfInt[0] - paramInt < 0)
        i = 1;
      else
        i = 0;
    }
  }

  private void showMenu(@NonNull MenuBuilder paramMenuBuilder)
  {
    LayoutInflater localLayoutInflater = LayoutInflater.from(this.mContext);
    MenuAdapter localMenuAdapter = new MenuAdapter(paramMenuBuilder, localLayoutInflater, this.mOverflowOnly, ITEM_LAYOUT);
    int i;
    MenuPopupWindow localMenuPopupWindow;
    CascadingMenuInfo localCascadingMenuInfo1;
    View localView;
    label133: int k;
    label167: int m;
    int n;
    label194: int i1;
    if ((!isShowing()) && (this.mForceShowIcon))
    {
      localMenuAdapter.setForceShowIcon(true);
      i = measureIndividualMenuWidth(localMenuAdapter, null, this.mContext, this.mMenuMaxWidth);
      localMenuPopupWindow = createPopupWindow();
      localMenuPopupWindow.setAdapter(localMenuAdapter);
      localMenuPopupWindow.setContentWidth(i);
      localMenuPopupWindow.setDropDownGravity(this.mDropDownGravity);
      if (this.mShowingMenus.size() <= 0)
        break label377;
      localCascadingMenuInfo1 = (CascadingMenuInfo)this.mShowingMenus.get(-1 + this.mShowingMenus.size());
      localView = findParentViewForSubmenu(localCascadingMenuInfo1, paramMenuBuilder);
      if (localView == null)
        break label525;
      localMenuPopupWindow.setTouchModal(false);
      localMenuPopupWindow.setEnterTransition(null);
      int j = getNextMenuPosition(i);
      if (j != 1)
        break label386;
      k = 1;
      this.mLastPosition = j;
      if (Build.VERSION.SDK_INT < 26)
        break label392;
      localMenuPopupWindow.setAnchorView(localView);
      m = 0;
      n = 0;
      if ((0x5 & this.mDropDownGravity) != 5)
        break label497;
      if (k == 0)
        break label484;
      i1 = m + i;
      label216: localMenuPopupWindow.setHorizontalOffset(i1);
      localMenuPopupWindow.setOverlapAnchor(true);
      localMenuPopupWindow.setVerticalOffset(n);
    }
    while (true)
    {
      CascadingMenuInfo localCascadingMenuInfo2 = new CascadingMenuInfo(localMenuPopupWindow, paramMenuBuilder, this.mLastPosition);
      this.mShowingMenus.add(localCascadingMenuInfo2);
      localMenuPopupWindow.show();
      ListView localListView = localMenuPopupWindow.getListView();
      localListView.setOnKeyListener(this);
      if ((localCascadingMenuInfo1 == null) && (this.mShowTitle) && (paramMenuBuilder.getHeaderTitle() != null))
      {
        FrameLayout localFrameLayout = (FrameLayout)localLayoutInflater.inflate(R.layout.abc_popup_menu_header_item_layout, localListView, false);
        TextView localTextView = (TextView)localFrameLayout.findViewById(16908310);
        localFrameLayout.setEnabled(false);
        localTextView.setText(paramMenuBuilder.getHeaderTitle());
        localListView.addHeaderView(localFrameLayout, null, false);
        localMenuPopupWindow.show();
      }
      return;
      if (!isShowing())
        break;
      localMenuAdapter.setForceShowIcon(MenuPopup.shouldPreserveIconSpacing(paramMenuBuilder));
      break;
      label377: localCascadingMenuInfo1 = null;
      localView = null;
      break label133;
      label386: k = 0;
      break label167;
      label392: int[] arrayOfInt1 = new int[2];
      this.mAnchorView.getLocationOnScreen(arrayOfInt1);
      int[] arrayOfInt2 = new int[2];
      localView.getLocationOnScreen(arrayOfInt2);
      if ((0x7 & this.mDropDownGravity) == 5)
      {
        arrayOfInt1[0] += this.mAnchorView.getWidth();
        arrayOfInt2[0] += localView.getWidth();
      }
      m = arrayOfInt2[0] - arrayOfInt1[0];
      n = arrayOfInt2[1] - arrayOfInt1[1];
      break label194;
      label484: i1 = m - localView.getWidth();
      break label216;
      label497: if (k != 0)
      {
        i1 = m + localView.getWidth();
        break label216;
      }
      i1 = m - i;
      break label216;
      label525: if (this.mHasXOffset)
        localMenuPopupWindow.setHorizontalOffset(this.mXOffset);
      if (this.mHasYOffset)
        localMenuPopupWindow.setVerticalOffset(this.mYOffset);
      localMenuPopupWindow.setEpicenterBounds(getEpicenterBounds());
    }
  }

  public void addMenu(MenuBuilder paramMenuBuilder)
  {
    paramMenuBuilder.addMenuPresenter(this, this.mContext);
    if (isShowing())
      showMenu(paramMenuBuilder);
    while (true)
    {
      return;
      this.mPendingMenus.add(paramMenuBuilder);
    }
  }

  protected boolean closeMenuOnSubMenuOpened()
  {
    return false;
  }

  public void dismiss()
  {
    int i = this.mShowingMenus.size();
    if (i > 0)
    {
      CascadingMenuInfo[] arrayOfCascadingMenuInfo = (CascadingMenuInfo[])this.mShowingMenus.toArray(new CascadingMenuInfo[i]);
      for (int j = i - 1; j >= 0; j--)
      {
        CascadingMenuInfo localCascadingMenuInfo = arrayOfCascadingMenuInfo[j];
        if (localCascadingMenuInfo.window.isShowing())
          localCascadingMenuInfo.window.dismiss();
      }
    }
  }

  public boolean flagActionItems()
  {
    return false;
  }

  public ListView getListView()
  {
    if (this.mShowingMenus.isEmpty());
    for (ListView localListView = null; ; localListView = ((CascadingMenuInfo)this.mShowingMenus.get(-1 + this.mShowingMenus.size())).getListView())
      return localListView;
  }

  public boolean isShowing()
  {
    if ((this.mShowingMenus.size() > 0) && (((CascadingMenuInfo)this.mShowingMenus.get(0)).window.isShowing()));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean)
  {
    int i = findIndexOfAddedMenu(paramMenuBuilder);
    if (i < 0);
    while (true)
    {
      return;
      int j = i + 1;
      if (j < this.mShowingMenus.size())
        ((CascadingMenuInfo)this.mShowingMenus.get(j)).menu.close(false);
      CascadingMenuInfo localCascadingMenuInfo = (CascadingMenuInfo)this.mShowingMenus.remove(i);
      localCascadingMenuInfo.menu.removeMenuPresenter(this);
      if (this.mShouldCloseImmediately)
      {
        localCascadingMenuInfo.window.setExitTransition(null);
        localCascadingMenuInfo.window.setAnimationStyle(0);
      }
      localCascadingMenuInfo.window.dismiss();
      int k = this.mShowingMenus.size();
      if (k > 0);
      for (this.mLastPosition = ((CascadingMenuInfo)this.mShowingMenus.get(k - 1)).position; ; this.mLastPosition = getInitialMenuPosition())
      {
        if (k != 0)
          break label241;
        dismiss();
        if (this.mPresenterCallback != null)
          this.mPresenterCallback.onCloseMenu(paramMenuBuilder, true);
        if (this.mTreeObserver != null)
        {
          if (this.mTreeObserver.isAlive())
            this.mTreeObserver.removeGlobalOnLayoutListener(this.mGlobalLayoutListener);
          this.mTreeObserver = null;
        }
        this.mShownAnchorView.removeOnAttachStateChangeListener(this.mAttachStateChangeListener);
        this.mOnDismissListener.onDismiss();
        break;
      }
      label241: if (paramBoolean)
        ((CascadingMenuInfo)this.mShowingMenus.get(0)).menu.close(false);
    }
  }

  public void onDismiss()
  {
    Object localObject = null;
    int i = 0;
    int j = this.mShowingMenus.size();
    while (true)
    {
      if (i < j)
      {
        CascadingMenuInfo localCascadingMenuInfo = (CascadingMenuInfo)this.mShowingMenus.get(i);
        if (!localCascadingMenuInfo.window.isShowing())
          localObject = localCascadingMenuInfo;
      }
      else
      {
        if (localObject != null)
          localObject.menu.close(false);
        return;
      }
      i++;
    }
  }

  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent)
  {
    int i = 1;
    if ((paramKeyEvent.getAction() == i) && (paramInt == 82))
      dismiss();
    while (true)
    {
      return i;
      int j = 0;
    }
  }

  public void onRestoreInstanceState(Parcelable paramParcelable)
  {
  }

  public Parcelable onSaveInstanceState()
  {
    return null;
  }

  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder)
  {
    boolean bool = true;
    Iterator localIterator = this.mShowingMenus.iterator();
    while (localIterator.hasNext())
    {
      CascadingMenuInfo localCascadingMenuInfo = (CascadingMenuInfo)localIterator.next();
      if (paramSubMenuBuilder == localCascadingMenuInfo.menu)
        localCascadingMenuInfo.getListView().requestFocus();
    }
    while (true)
    {
      return bool;
      if (paramSubMenuBuilder.hasVisibleItems())
      {
        addMenu(paramSubMenuBuilder);
        if (this.mPresenterCallback != null)
          this.mPresenterCallback.onOpenSubMenu(paramSubMenuBuilder);
      }
      else
      {
        bool = false;
      }
    }
  }

  public void setAnchorView(@NonNull View paramView)
  {
    if (this.mAnchorView != paramView)
    {
      this.mAnchorView = paramView;
      this.mDropDownGravity = GravityCompat.getAbsoluteGravity(this.mRawDropDownGravity, ViewCompat.getLayoutDirection(this.mAnchorView));
    }
  }

  public void setCallback(MenuPresenter.Callback paramCallback)
  {
    this.mPresenterCallback = paramCallback;
  }

  public void setForceShowIcon(boolean paramBoolean)
  {
    this.mForceShowIcon = paramBoolean;
  }

  public void setGravity(int paramInt)
  {
    if (this.mRawDropDownGravity != paramInt)
    {
      this.mRawDropDownGravity = paramInt;
      this.mDropDownGravity = GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection(this.mAnchorView));
    }
  }

  public void setHorizontalOffset(int paramInt)
  {
    this.mHasXOffset = true;
    this.mXOffset = paramInt;
  }

  public void setOnDismissListener(PopupWindow.OnDismissListener paramOnDismissListener)
  {
    this.mOnDismissListener = paramOnDismissListener;
  }

  public void setShowTitle(boolean paramBoolean)
  {
    this.mShowTitle = paramBoolean;
  }

  public void setVerticalOffset(int paramInt)
  {
    this.mHasYOffset = true;
    this.mYOffset = paramInt;
  }

  public void show()
  {
    if (isShowing());
    do
    {
      return;
      Iterator localIterator = this.mPendingMenus.iterator();
      while (localIterator.hasNext())
        showMenu((MenuBuilder)localIterator.next());
      this.mPendingMenus.clear();
      this.mShownAnchorView = this.mAnchorView;
    }
    while (this.mShownAnchorView == null);
    if (this.mTreeObserver == null);
    for (int i = 1; ; i = 0)
    {
      this.mTreeObserver = this.mShownAnchorView.getViewTreeObserver();
      if (i != 0)
        this.mTreeObserver.addOnGlobalLayoutListener(this.mGlobalLayoutListener);
      this.mShownAnchorView.addOnAttachStateChangeListener(this.mAttachStateChangeListener);
      break;
    }
  }

  public void updateMenuView(boolean paramBoolean)
  {
    Iterator localIterator = this.mShowingMenus.iterator();
    while (localIterator.hasNext())
      toMenuAdapter(((CascadingMenuInfo)localIterator.next()).getListView().getAdapter()).notifyDataSetChanged();
  }

  private static class CascadingMenuInfo
  {
    public final MenuBuilder menu;
    public final int position;
    public final MenuPopupWindow window;

    public CascadingMenuInfo(@NonNull MenuPopupWindow paramMenuPopupWindow, @NonNull MenuBuilder paramMenuBuilder, int paramInt)
    {
      this.window = paramMenuPopupWindow;
      this.menu = paramMenuBuilder;
      this.position = paramInt;
    }

    public ListView getListView()
    {
      return this.window.getListView();
    }
  }

  @Retention(RetentionPolicy.SOURCE)
  public static @interface HorizPosition
  {
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.menu.CascadingMenuPopup
 * JD-Core Version:    0.6.2
 */