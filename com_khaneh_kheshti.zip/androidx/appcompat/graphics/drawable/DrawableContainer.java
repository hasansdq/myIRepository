package androidx.appcompat.graphics.drawable;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.graphics.drawable.Drawable.ConstantState;
import android.os.Build.VERSION;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.SparseArray;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.core.graphics.drawable.DrawableCompat;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
class DrawableContainer extends Drawable
  implements Drawable.Callback
{
  private static final boolean DEBUG = false;
  private static final boolean DEFAULT_DITHER = true;
  private static final String TAG = "DrawableContainer";
  private int mAlpha = 255;
  private Runnable mAnimationRunnable;
  private BlockInvalidateCallback mBlockInvalidateCallback;
  private int mCurIndex = -1;
  private Drawable mCurrDrawable;
  private DrawableContainerState mDrawableContainerState;
  private long mEnterAnimationEnd;
  private long mExitAnimationEnd;
  private boolean mHasAlpha;
  private Rect mHotspotBounds;
  private Drawable mLastDrawable;
  private int mLastIndex = -1;
  private boolean mMutated;

  private void initializeDrawableForDisplay(Drawable paramDrawable)
  {
    if (this.mBlockInvalidateCallback == null)
      this.mBlockInvalidateCallback = new BlockInvalidateCallback();
    paramDrawable.setCallback(this.mBlockInvalidateCallback.wrap(paramDrawable.getCallback()));
    try
    {
      if ((this.mDrawableContainerState.mEnterFadeDuration <= 0) && (this.mHasAlpha))
        paramDrawable.setAlpha(this.mAlpha);
      if (this.mDrawableContainerState.mHasColorFilter)
        paramDrawable.setColorFilter(this.mDrawableContainerState.mColorFilter);
      while (true)
      {
        paramDrawable.setVisible(isVisible(), true);
        paramDrawable.setDither(this.mDrawableContainerState.mDither);
        paramDrawable.setState(getState());
        paramDrawable.setLevel(getLevel());
        paramDrawable.setBounds(getBounds());
        if (Build.VERSION.SDK_INT >= 23)
          paramDrawable.setLayoutDirection(getLayoutDirection());
        if (Build.VERSION.SDK_INT >= 19)
          paramDrawable.setAutoMirrored(this.mDrawableContainerState.mAutoMirrored);
        Rect localRect = this.mHotspotBounds;
        if ((Build.VERSION.SDK_INT >= 21) && (localRect != null))
          paramDrawable.setHotspotBounds(localRect.left, localRect.top, localRect.right, localRect.bottom);
        return;
        if (this.mDrawableContainerState.mHasTintList)
          DrawableCompat.setTintList(paramDrawable, this.mDrawableContainerState.mTintList);
        if (this.mDrawableContainerState.mHasTintMode)
          DrawableCompat.setTintMode(paramDrawable, this.mDrawableContainerState.mTintMode);
      }
    }
    finally
    {
      paramDrawable.setCallback(this.mBlockInvalidateCallback.unwrap());
    }
  }

  @SuppressLint({"WrongConstant"})
  @TargetApi(23)
  private boolean needsMirroring()
  {
    int i = 1;
    if ((isAutoMirrored()) && (getLayoutDirection() == i));
    while (true)
    {
      return i;
      int j = 0;
    }
  }

  static int resolveDensity(@Nullable Resources paramResources, int paramInt)
  {
    if (paramResources == null);
    for (int i = paramInt; ; i = paramResources.getDisplayMetrics().densityDpi)
    {
      if (i == 0)
        i = 160;
      return i;
    }
  }

  void animate(boolean paramBoolean)
  {
    this.mHasAlpha = true;
    long l = SystemClock.uptimeMillis();
    int i = 0;
    if (this.mCurrDrawable != null)
      if (this.mEnterAnimationEnd != 0L)
      {
        if (this.mEnterAnimationEnd <= l)
        {
          this.mCurrDrawable.setAlpha(this.mAlpha);
          this.mEnterAnimationEnd = 0L;
        }
      }
      else
      {
        if (this.mLastDrawable == null)
          break label228;
        if (this.mExitAnimationEnd != 0L)
        {
          if (this.mExitAnimationEnd > l)
            break label183;
          this.mLastDrawable.setVisible(false, false);
          this.mLastDrawable = null;
          this.mLastIndex = -1;
          this.mExitAnimationEnd = 0L;
        }
      }
    while (true)
    {
      if ((paramBoolean) && (i != 0))
        scheduleSelf(this.mAnimationRunnable, 16L + l);
      return;
      int k = (int)(255L * (this.mEnterAnimationEnd - l)) / this.mDrawableContainerState.mEnterFadeDuration;
      this.mCurrDrawable.setAlpha((255 - k) * this.mAlpha / 255);
      i = 1;
      break;
      this.mEnterAnimationEnd = 0L;
      break;
      label183: int j = (int)(255L * (this.mExitAnimationEnd - l)) / this.mDrawableContainerState.mExitFadeDuration;
      this.mLastDrawable.setAlpha(j * this.mAlpha / 255);
      i = 1;
      continue;
      label228: this.mExitAnimationEnd = 0L;
    }
  }

  @RequiresApi(21)
  public void applyTheme(@NonNull Resources.Theme paramTheme)
  {
    this.mDrawableContainerState.applyTheme(paramTheme);
  }

  @RequiresApi(21)
  public boolean canApplyTheme()
  {
    return this.mDrawableContainerState.canApplyTheme();
  }

  void clearMutated()
  {
    this.mDrawableContainerState.clearMutated();
    this.mMutated = false;
  }

  DrawableContainerState cloneConstantState()
  {
    return this.mDrawableContainerState;
  }

  public void draw(@NonNull Canvas paramCanvas)
  {
    if (this.mCurrDrawable != null)
      this.mCurrDrawable.draw(paramCanvas);
    if (this.mLastDrawable != null)
      this.mLastDrawable.draw(paramCanvas);
  }

  public int getAlpha()
  {
    return this.mAlpha;
  }

  public int getChangingConfigurations()
  {
    return super.getChangingConfigurations() | this.mDrawableContainerState.getChangingConfigurations();
  }

  public final Drawable.ConstantState getConstantState()
  {
    if (this.mDrawableContainerState.canConstantState())
      this.mDrawableContainerState.mChangingConfigurations = getChangingConfigurations();
    for (DrawableContainerState localDrawableContainerState = this.mDrawableContainerState; ; localDrawableContainerState = null)
      return localDrawableContainerState;
  }

  @NonNull
  public Drawable getCurrent()
  {
    return this.mCurrDrawable;
  }

  int getCurrentIndex()
  {
    return this.mCurIndex;
  }

  public void getHotspotBounds(@NonNull Rect paramRect)
  {
    if (this.mHotspotBounds != null)
      paramRect.set(this.mHotspotBounds);
    while (true)
    {
      return;
      super.getHotspotBounds(paramRect);
    }
  }

  public int getIntrinsicHeight()
  {
    int i;
    if (this.mDrawableContainerState.isConstantSize())
      i = this.mDrawableContainerState.getConstantHeight();
    while (true)
    {
      return i;
      if (this.mCurrDrawable != null)
        i = this.mCurrDrawable.getIntrinsicHeight();
      else
        i = -1;
    }
  }

  public int getIntrinsicWidth()
  {
    int i;
    if (this.mDrawableContainerState.isConstantSize())
      i = this.mDrawableContainerState.getConstantWidth();
    while (true)
    {
      return i;
      if (this.mCurrDrawable != null)
        i = this.mCurrDrawable.getIntrinsicWidth();
      else
        i = -1;
    }
  }

  public int getMinimumHeight()
  {
    int i;
    if (this.mDrawableContainerState.isConstantSize())
      i = this.mDrawableContainerState.getConstantMinimumHeight();
    while (true)
    {
      return i;
      if (this.mCurrDrawable != null)
        i = this.mCurrDrawable.getMinimumHeight();
      else
        i = 0;
    }
  }

  public int getMinimumWidth()
  {
    int i;
    if (this.mDrawableContainerState.isConstantSize())
      i = this.mDrawableContainerState.getConstantMinimumWidth();
    while (true)
    {
      return i;
      if (this.mCurrDrawable != null)
        i = this.mCurrDrawable.getMinimumWidth();
      else
        i = 0;
    }
  }

  public int getOpacity()
  {
    if ((this.mCurrDrawable == null) || (!this.mCurrDrawable.isVisible()));
    for (int i = -2; ; i = this.mDrawableContainerState.getOpacity())
      return i;
  }

  @RequiresApi(21)
  public void getOutline(@NonNull Outline paramOutline)
  {
    if (this.mCurrDrawable != null)
      this.mCurrDrawable.getOutline(paramOutline);
  }

  public boolean getPadding(@NonNull Rect paramRect)
  {
    Rect localRect = this.mDrawableContainerState.getConstantPadding();
    boolean bool;
    if (localRect != null)
    {
      paramRect.set(localRect);
      if ((localRect.left | localRect.top | localRect.bottom | localRect.right) != 0)
        bool = true;
    }
    while (true)
    {
      if (needsMirroring())
      {
        int i = paramRect.left;
        paramRect.left = paramRect.right;
        paramRect.right = i;
      }
      return bool;
      bool = false;
      continue;
      if (this.mCurrDrawable != null)
        bool = this.mCurrDrawable.getPadding(paramRect);
      else
        bool = super.getPadding(paramRect);
    }
  }

  public void invalidateDrawable(@NonNull Drawable paramDrawable)
  {
    if (this.mDrawableContainerState != null)
      this.mDrawableContainerState.invalidateCache();
    if ((paramDrawable == this.mCurrDrawable) && (getCallback() != null))
      getCallback().invalidateDrawable(this);
  }

  public boolean isAutoMirrored()
  {
    return this.mDrawableContainerState.mAutoMirrored;
  }

  public boolean isStateful()
  {
    return this.mDrawableContainerState.isStateful();
  }

  public void jumpToCurrentState()
  {
    int i = 0;
    if (this.mLastDrawable != null)
    {
      this.mLastDrawable.jumpToCurrentState();
      this.mLastDrawable = null;
      this.mLastIndex = -1;
      i = 1;
    }
    if (this.mCurrDrawable != null)
    {
      this.mCurrDrawable.jumpToCurrentState();
      if (this.mHasAlpha)
        this.mCurrDrawable.setAlpha(this.mAlpha);
    }
    if (this.mExitAnimationEnd != 0L)
    {
      this.mExitAnimationEnd = 0L;
      i = 1;
    }
    if (this.mEnterAnimationEnd != 0L)
    {
      this.mEnterAnimationEnd = 0L;
      i = 1;
    }
    if (i != 0)
      invalidateSelf();
  }

  @NonNull
  public Drawable mutate()
  {
    if ((!this.mMutated) && (super.mutate() == this))
    {
      DrawableContainerState localDrawableContainerState = cloneConstantState();
      localDrawableContainerState.mutate();
      setConstantState(localDrawableContainerState);
      this.mMutated = true;
    }
    return this;
  }

  protected void onBoundsChange(Rect paramRect)
  {
    if (this.mLastDrawable != null)
      this.mLastDrawable.setBounds(paramRect);
    if (this.mCurrDrawable != null)
      this.mCurrDrawable.setBounds(paramRect);
  }

  public boolean onLayoutDirectionChanged(int paramInt)
  {
    return this.mDrawableContainerState.setLayoutDirection(paramInt, getCurrentIndex());
  }

  protected boolean onLevelChange(int paramInt)
  {
    boolean bool;
    if (this.mLastDrawable != null)
      bool = this.mLastDrawable.setLevel(paramInt);
    while (true)
    {
      return bool;
      if (this.mCurrDrawable != null)
        bool = this.mCurrDrawable.setLevel(paramInt);
      else
        bool = false;
    }
  }

  protected boolean onStateChange(int[] paramArrayOfInt)
  {
    boolean bool;
    if (this.mLastDrawable != null)
      bool = this.mLastDrawable.setState(paramArrayOfInt);
    while (true)
    {
      return bool;
      if (this.mCurrDrawable != null)
        bool = this.mCurrDrawable.setState(paramArrayOfInt);
      else
        bool = false;
    }
  }

  public void scheduleDrawable(@NonNull Drawable paramDrawable, @NonNull Runnable paramRunnable, long paramLong)
  {
    if ((paramDrawable == this.mCurrDrawable) && (getCallback() != null))
      getCallback().scheduleDrawable(this, paramRunnable, paramLong);
  }

  boolean selectDrawable(int paramInt)
  {
    boolean bool = false;
    if (paramInt == this.mCurIndex)
      return bool;
    long l = SystemClock.uptimeMillis();
    if (this.mDrawableContainerState.mExitFadeDuration > 0)
    {
      if (this.mLastDrawable != null)
        this.mLastDrawable.setVisible(false, false);
      if (this.mCurrDrawable != null)
      {
        this.mLastDrawable = this.mCurrDrawable;
        this.mLastIndex = this.mCurIndex;
        this.mExitAnimationEnd = (l + this.mDrawableContainerState.mExitFadeDuration);
        label80: if ((paramInt < 0) || (paramInt >= this.mDrawableContainerState.mNumChildren))
          break label240;
        Drawable localDrawable = this.mDrawableContainerState.getChild(paramInt);
        this.mCurrDrawable = localDrawable;
        this.mCurIndex = paramInt;
        if (localDrawable != null)
        {
          if (this.mDrawableContainerState.mEnterFadeDuration > 0)
            this.mEnterAnimationEnd = (l + this.mDrawableContainerState.mEnterFadeDuration);
          initializeDrawableForDisplay(localDrawable);
        }
        label151: if ((this.mEnterAnimationEnd != 0L) || (this.mExitAnimationEnd != 0L))
        {
          if (this.mAnimationRunnable != null)
            break label253;
          this.mAnimationRunnable = new Runnable()
          {
            public void run()
            {
              DrawableContainer.this.animate(true);
              DrawableContainer.this.invalidateSelf();
            }
          };
        }
      }
    }
    while (true)
    {
      animate(true);
      invalidateSelf();
      bool = true;
      break;
      this.mLastDrawable = null;
      this.mLastIndex = -1;
      this.mExitAnimationEnd = 0L;
      break label80;
      if (this.mCurrDrawable == null)
        break label80;
      this.mCurrDrawable.setVisible(false, false);
      break label80;
      label240: this.mCurrDrawable = null;
      this.mCurIndex = -1;
      break label151;
      label253: unscheduleSelf(this.mAnimationRunnable);
    }
  }

  public void setAlpha(int paramInt)
  {
    if ((!this.mHasAlpha) || (this.mAlpha != paramInt))
    {
      this.mHasAlpha = true;
      this.mAlpha = paramInt;
      if (this.mCurrDrawable != null)
      {
        if (this.mEnterAnimationEnd != 0L)
          break label50;
        this.mCurrDrawable.setAlpha(paramInt);
      }
    }
    while (true)
    {
      return;
      label50: animate(false);
    }
  }

  public void setAutoMirrored(boolean paramBoolean)
  {
    if (this.mDrawableContainerState.mAutoMirrored != paramBoolean)
    {
      this.mDrawableContainerState.mAutoMirrored = paramBoolean;
      if (this.mCurrDrawable != null)
        DrawableCompat.setAutoMirrored(this.mCurrDrawable, this.mDrawableContainerState.mAutoMirrored);
    }
  }

  public void setColorFilter(ColorFilter paramColorFilter)
  {
    this.mDrawableContainerState.mHasColorFilter = true;
    if (this.mDrawableContainerState.mColorFilter != paramColorFilter)
    {
      this.mDrawableContainerState.mColorFilter = paramColorFilter;
      if (this.mCurrDrawable != null)
        this.mCurrDrawable.setColorFilter(paramColorFilter);
    }
  }

  protected void setConstantState(DrawableContainerState paramDrawableContainerState)
  {
    this.mDrawableContainerState = paramDrawableContainerState;
    if (this.mCurIndex >= 0)
    {
      this.mCurrDrawable = paramDrawableContainerState.getChild(this.mCurIndex);
      if (this.mCurrDrawable != null)
        initializeDrawableForDisplay(this.mCurrDrawable);
    }
    this.mLastIndex = -1;
    this.mLastDrawable = null;
  }

  void setCurrentIndex(int paramInt)
  {
    selectDrawable(paramInt);
  }

  public void setDither(boolean paramBoolean)
  {
    if (this.mDrawableContainerState.mDither != paramBoolean)
    {
      this.mDrawableContainerState.mDither = paramBoolean;
      if (this.mCurrDrawable != null)
        this.mCurrDrawable.setDither(this.mDrawableContainerState.mDither);
    }
  }

  public void setEnterFadeDuration(int paramInt)
  {
    this.mDrawableContainerState.mEnterFadeDuration = paramInt;
  }

  public void setExitFadeDuration(int paramInt)
  {
    this.mDrawableContainerState.mExitFadeDuration = paramInt;
  }

  public void setHotspot(float paramFloat1, float paramFloat2)
  {
    if (this.mCurrDrawable != null)
      DrawableCompat.setHotspot(this.mCurrDrawable, paramFloat1, paramFloat2);
  }

  public void setHotspotBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.mHotspotBounds == null)
      this.mHotspotBounds = new Rect(paramInt1, paramInt2, paramInt3, paramInt4);
    while (true)
    {
      if (this.mCurrDrawable != null)
        DrawableCompat.setHotspotBounds(this.mCurrDrawable, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
      this.mHotspotBounds.set(paramInt1, paramInt2, paramInt3, paramInt4);
    }
  }

  public void setTintList(ColorStateList paramColorStateList)
  {
    this.mDrawableContainerState.mHasTintList = true;
    if (this.mDrawableContainerState.mTintList != paramColorStateList)
    {
      this.mDrawableContainerState.mTintList = paramColorStateList;
      DrawableCompat.setTintList(this.mCurrDrawable, paramColorStateList);
    }
  }

  public void setTintMode(@NonNull PorterDuff.Mode paramMode)
  {
    this.mDrawableContainerState.mHasTintMode = true;
    if (this.mDrawableContainerState.mTintMode != paramMode)
    {
      this.mDrawableContainerState.mTintMode = paramMode;
      DrawableCompat.setTintMode(this.mCurrDrawable, paramMode);
    }
  }

  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2)
  {
    boolean bool = super.setVisible(paramBoolean1, paramBoolean2);
    if (this.mLastDrawable != null)
      this.mLastDrawable.setVisible(paramBoolean1, paramBoolean2);
    if (this.mCurrDrawable != null)
      this.mCurrDrawable.setVisible(paramBoolean1, paramBoolean2);
    return bool;
  }

  public void unscheduleDrawable(@NonNull Drawable paramDrawable, @NonNull Runnable paramRunnable)
  {
    if ((paramDrawable == this.mCurrDrawable) && (getCallback() != null))
      getCallback().unscheduleDrawable(this, paramRunnable);
  }

  final void updateDensity(Resources paramResources)
  {
    this.mDrawableContainerState.updateDensity(paramResources);
  }

  static class BlockInvalidateCallback
    implements Drawable.Callback
  {
    private Drawable.Callback mCallback;

    public void invalidateDrawable(@NonNull Drawable paramDrawable)
    {
    }

    public void scheduleDrawable(@NonNull Drawable paramDrawable, @NonNull Runnable paramRunnable, long paramLong)
    {
      if (this.mCallback != null)
        this.mCallback.scheduleDrawable(paramDrawable, paramRunnable, paramLong);
    }

    public void unscheduleDrawable(@NonNull Drawable paramDrawable, @NonNull Runnable paramRunnable)
    {
      if (this.mCallback != null)
        this.mCallback.unscheduleDrawable(paramDrawable, paramRunnable);
    }

    public Drawable.Callback unwrap()
    {
      Drawable.Callback localCallback = this.mCallback;
      this.mCallback = null;
      return localCallback;
    }

    public BlockInvalidateCallback wrap(Drawable.Callback paramCallback)
    {
      this.mCallback = paramCallback;
      return this;
    }
  }

  static abstract class DrawableContainerState extends Drawable.ConstantState
  {
    boolean mAutoMirrored;
    boolean mCanConstantState;
    int mChangingConfigurations;
    boolean mCheckedConstantSize;
    boolean mCheckedConstantState;
    boolean mCheckedOpacity;
    boolean mCheckedPadding;
    boolean mCheckedStateful;
    int mChildrenChangingConfigurations;
    ColorFilter mColorFilter;
    int mConstantHeight;
    int mConstantMinimumHeight;
    int mConstantMinimumWidth;
    Rect mConstantPadding;
    boolean mConstantSize = false;
    int mConstantWidth;
    int mDensity = 160;
    boolean mDither = true;
    SparseArray<Drawable.ConstantState> mDrawableFutures;
    Drawable[] mDrawables;
    int mEnterFadeDuration = 0;
    int mExitFadeDuration = 0;
    boolean mHasColorFilter;
    boolean mHasTintList;
    boolean mHasTintMode;
    int mLayoutDirection;
    boolean mMutated;
    int mNumChildren;
    int mOpacity;
    final DrawableContainer mOwner;
    Resources mSourceRes;
    boolean mStateful;
    ColorStateList mTintList;
    PorterDuff.Mode mTintMode;
    boolean mVariablePadding = false;

    DrawableContainerState(DrawableContainerState paramDrawableContainerState, DrawableContainer paramDrawableContainer, Resources paramResources)
    {
      this.mOwner = paramDrawableContainer;
      Resources localResources;
      int i;
      label64: Drawable[] arrayOfDrawable;
      label382: int k;
      if (paramResources != null)
      {
        localResources = paramResources;
        this.mSourceRes = localResources;
        if (paramDrawableContainerState == null)
          break label457;
        i = paramDrawableContainerState.mDensity;
        this.mDensity = DrawableContainer.resolveDensity(paramResources, i);
        if (paramDrawableContainerState == null)
          break label496;
        this.mChangingConfigurations = paramDrawableContainerState.mChangingConfigurations;
        this.mChildrenChangingConfigurations = paramDrawableContainerState.mChildrenChangingConfigurations;
        this.mCheckedConstantState = true;
        this.mCanConstantState = true;
        this.mVariablePadding = paramDrawableContainerState.mVariablePadding;
        this.mConstantSize = paramDrawableContainerState.mConstantSize;
        this.mDither = paramDrawableContainerState.mDither;
        this.mMutated = paramDrawableContainerState.mMutated;
        this.mLayoutDirection = paramDrawableContainerState.mLayoutDirection;
        this.mEnterFadeDuration = paramDrawableContainerState.mEnterFadeDuration;
        this.mExitFadeDuration = paramDrawableContainerState.mExitFadeDuration;
        this.mAutoMirrored = paramDrawableContainerState.mAutoMirrored;
        this.mColorFilter = paramDrawableContainerState.mColorFilter;
        this.mHasColorFilter = paramDrawableContainerState.mHasColorFilter;
        this.mTintList = paramDrawableContainerState.mTintList;
        this.mTintMode = paramDrawableContainerState.mTintMode;
        this.mHasTintList = paramDrawableContainerState.mHasTintList;
        this.mHasTintMode = paramDrawableContainerState.mHasTintMode;
        if (paramDrawableContainerState.mDensity == this.mDensity)
        {
          if (paramDrawableContainerState.mCheckedPadding)
          {
            this.mConstantPadding = new Rect(paramDrawableContainerState.mConstantPadding);
            this.mCheckedPadding = true;
          }
          if (paramDrawableContainerState.mCheckedConstantSize)
          {
            this.mConstantWidth = paramDrawableContainerState.mConstantWidth;
            this.mConstantHeight = paramDrawableContainerState.mConstantHeight;
            this.mConstantMinimumWidth = paramDrawableContainerState.mConstantMinimumWidth;
            this.mConstantMinimumHeight = paramDrawableContainerState.mConstantMinimumHeight;
            this.mCheckedConstantSize = true;
          }
        }
        if (paramDrawableContainerState.mCheckedOpacity)
        {
          this.mOpacity = paramDrawableContainerState.mOpacity;
          this.mCheckedOpacity = true;
        }
        if (paramDrawableContainerState.mCheckedStateful)
        {
          this.mStateful = paramDrawableContainerState.mStateful;
          this.mCheckedStateful = true;
        }
        arrayOfDrawable = paramDrawableContainerState.mDrawables;
        this.mDrawables = new Drawable[arrayOfDrawable.length];
        this.mNumChildren = paramDrawableContainerState.mNumChildren;
        SparseArray localSparseArray = paramDrawableContainerState.mDrawableFutures;
        if (localSparseArray == null)
          break label463;
        this.mDrawableFutures = localSparseArray.clone();
        int j = this.mNumChildren;
        k = 0;
        label391: if (k >= j)
          return;
        if (arrayOfDrawable[k] != null)
        {
          Drawable.ConstantState localConstantState = arrayOfDrawable[k].getConstantState();
          if (localConstantState == null)
            break label481;
          this.mDrawableFutures.put(k, localConstantState);
        }
      }
      while (true)
      {
        k++;
        break label391;
        if (paramDrawableContainerState != null)
        {
          localResources = paramDrawableContainerState.mSourceRes;
          break;
        }
        localResources = null;
        break;
        label457: i = 0;
        break label64;
        label463: this.mDrawableFutures = new SparseArray(this.mNumChildren);
        break label382;
        label481: this.mDrawables[k] = arrayOfDrawable[k];
      }
      label496: this.mDrawables = new Drawable[10];
      this.mNumChildren = 0;
    }

    private void createAllFutures()
    {
      if (this.mDrawableFutures != null)
      {
        int i = this.mDrawableFutures.size();
        for (int j = 0; j < i; j++)
        {
          int k = this.mDrawableFutures.keyAt(j);
          Drawable.ConstantState localConstantState = (Drawable.ConstantState)this.mDrawableFutures.valueAt(j);
          this.mDrawables[k] = prepareDrawable(localConstantState.newDrawable(this.mSourceRes));
        }
        this.mDrawableFutures = null;
      }
    }

    private Drawable prepareDrawable(Drawable paramDrawable)
    {
      if (Build.VERSION.SDK_INT >= 23)
        paramDrawable.setLayoutDirection(this.mLayoutDirection);
      Drawable localDrawable = paramDrawable.mutate();
      localDrawable.setCallback(this.mOwner);
      return localDrawable;
    }

    public final int addChild(Drawable paramDrawable)
    {
      int i = this.mNumChildren;
      if (i >= this.mDrawables.length)
        growArray(i, i + 10);
      paramDrawable.mutate();
      paramDrawable.setVisible(false, true);
      paramDrawable.setCallback(this.mOwner);
      this.mDrawables[i] = paramDrawable;
      this.mNumChildren = (1 + this.mNumChildren);
      this.mChildrenChangingConfigurations |= paramDrawable.getChangingConfigurations();
      invalidateCache();
      this.mConstantPadding = null;
      this.mCheckedPadding = false;
      this.mCheckedConstantSize = false;
      this.mCheckedConstantState = false;
      return i;
    }

    @RequiresApi(21)
    final void applyTheme(Resources.Theme paramTheme)
    {
      if (paramTheme != null)
      {
        createAllFutures();
        int i = this.mNumChildren;
        Drawable[] arrayOfDrawable = this.mDrawables;
        for (int j = 0; j < i; j++)
          if ((arrayOfDrawable[j] != null) && (arrayOfDrawable[j].canApplyTheme()))
          {
            arrayOfDrawable[j].applyTheme(paramTheme);
            this.mChildrenChangingConfigurations |= arrayOfDrawable[j].getChangingConfigurations();
          }
        updateDensity(paramTheme.getResources());
      }
    }

    @RequiresApi(21)
    public boolean canApplyTheme()
    {
      boolean bool = true;
      int i = this.mNumChildren;
      Drawable[] arrayOfDrawable = this.mDrawables;
      int j = 0;
      if (j < i)
      {
        Drawable localDrawable = arrayOfDrawable[j];
        if (localDrawable != null)
          if (!localDrawable.canApplyTheme())
            break label69;
      }
      while (true)
      {
        return bool;
        Drawable.ConstantState localConstantState = (Drawable.ConstantState)this.mDrawableFutures.get(j);
        if ((localConstantState == null) || (!localConstantState.canApplyTheme()))
        {
          label69: j++;
          break;
          bool = false;
        }
      }
    }

    public boolean canConstantState()
    {
      boolean bool = false;
      while (true)
      {
        int j;
        try
        {
          if (this.mCheckedConstantState)
          {
            bool = this.mCanConstantState;
            return bool;
          }
          createAllFutures();
          this.mCheckedConstantState = true;
          int i = this.mNumChildren;
          Drawable[] arrayOfDrawable = this.mDrawables;
          j = 0;
          if (j >= i)
            break label79;
          if (arrayOfDrawable[j].getConstantState() == null)
          {
            this.mCanConstantState = false;
            continue;
          }
        }
        finally
        {
        }
        j++;
        continue;
        label79: this.mCanConstantState = true;
        bool = true;
      }
    }

    final void clearMutated()
    {
      this.mMutated = false;
    }

    protected void computeConstantSize()
    {
      this.mCheckedConstantSize = true;
      createAllFutures();
      int i = this.mNumChildren;
      Drawable[] arrayOfDrawable = this.mDrawables;
      this.mConstantHeight = -1;
      this.mConstantWidth = -1;
      this.mConstantMinimumHeight = 0;
      this.mConstantMinimumWidth = 0;
      for (int j = 0; j < i; j++)
      {
        Drawable localDrawable = arrayOfDrawable[j];
        int k = localDrawable.getIntrinsicWidth();
        if (k > this.mConstantWidth)
          this.mConstantWidth = k;
        int m = localDrawable.getIntrinsicHeight();
        if (m > this.mConstantHeight)
          this.mConstantHeight = m;
        int n = localDrawable.getMinimumWidth();
        if (n > this.mConstantMinimumWidth)
          this.mConstantMinimumWidth = n;
        int i1 = localDrawable.getMinimumHeight();
        if (i1 > this.mConstantMinimumHeight)
          this.mConstantMinimumHeight = i1;
      }
    }

    final int getCapacity()
    {
      return this.mDrawables.length;
    }

    public int getChangingConfigurations()
    {
      return this.mChangingConfigurations | this.mChildrenChangingConfigurations;
    }

    public final Drawable getChild(int paramInt)
    {
      Object localObject = this.mDrawables[paramInt];
      if (localObject != null);
      while (true)
      {
        return localObject;
        if (this.mDrawableFutures != null)
        {
          int i = this.mDrawableFutures.indexOfKey(paramInt);
          if (i >= 0)
          {
            Drawable localDrawable = prepareDrawable(((Drawable.ConstantState)this.mDrawableFutures.valueAt(i)).newDrawable(this.mSourceRes));
            this.mDrawables[paramInt] = localDrawable;
            this.mDrawableFutures.removeAt(i);
            if (this.mDrawableFutures.size() == 0)
              this.mDrawableFutures = null;
            localObject = localDrawable;
          }
        }
        else
        {
          localObject = null;
        }
      }
    }

    public final int getChildCount()
    {
      return this.mNumChildren;
    }

    public final int getConstantHeight()
    {
      if (!this.mCheckedConstantSize)
        computeConstantSize();
      return this.mConstantHeight;
    }

    public final int getConstantMinimumHeight()
    {
      if (!this.mCheckedConstantSize)
        computeConstantSize();
      return this.mConstantMinimumHeight;
    }

    public final int getConstantMinimumWidth()
    {
      if (!this.mCheckedConstantSize)
        computeConstantSize();
      return this.mConstantMinimumWidth;
    }

    public final Rect getConstantPadding()
    {
      Rect localRect1;
      if (this.mVariablePadding)
        localRect1 = null;
      while (true)
      {
        return localRect1;
        if ((this.mConstantPadding != null) || (this.mCheckedPadding))
        {
          localRect1 = this.mConstantPadding;
        }
        else
        {
          createAllFutures();
          localRect1 = null;
          Rect localRect2 = new Rect();
          int i = this.mNumChildren;
          Drawable[] arrayOfDrawable = this.mDrawables;
          for (int j = 0; j < i; j++)
            if (arrayOfDrawable[j].getPadding(localRect2))
            {
              if (localRect1 == null)
                localRect1 = new Rect(0, 0, 0, 0);
              if (localRect2.left > localRect1.left)
                localRect1.left = localRect2.left;
              if (localRect2.top > localRect1.top)
                localRect1.top = localRect2.top;
              if (localRect2.right > localRect1.right)
                localRect1.right = localRect2.right;
              if (localRect2.bottom > localRect1.bottom)
                localRect1.bottom = localRect2.bottom;
            }
          this.mCheckedPadding = true;
          this.mConstantPadding = localRect1;
        }
      }
    }

    public final int getConstantWidth()
    {
      if (!this.mCheckedConstantSize)
        computeConstantSize();
      return this.mConstantWidth;
    }

    public final int getEnterFadeDuration()
    {
      return this.mEnterFadeDuration;
    }

    public final int getExitFadeDuration()
    {
      return this.mExitFadeDuration;
    }

    public final int getOpacity()
    {
      int j;
      if (this.mCheckedOpacity)
        j = this.mOpacity;
      while (true)
      {
        return j;
        createAllFutures();
        int i = this.mNumChildren;
        Drawable[] arrayOfDrawable = this.mDrawables;
        if (i > 0);
        for (j = arrayOfDrawable[0].getOpacity(); ; j = -2)
          for (int k = 1; k < i; k++)
            j = Drawable.resolveOpacity(j, arrayOfDrawable[k].getOpacity());
        this.mOpacity = j;
        this.mCheckedOpacity = true;
      }
    }

    public void growArray(int paramInt1, int paramInt2)
    {
      Drawable[] arrayOfDrawable = new Drawable[paramInt2];
      System.arraycopy(this.mDrawables, 0, arrayOfDrawable, 0, paramInt1);
      this.mDrawables = arrayOfDrawable;
    }

    void invalidateCache()
    {
      this.mCheckedOpacity = false;
      this.mCheckedStateful = false;
    }

    public final boolean isConstantSize()
    {
      return this.mConstantSize;
    }

    public final boolean isStateful()
    {
      if (this.mCheckedStateful)
      {
        bool = this.mStateful;
        return bool;
      }
      createAllFutures();
      int i = this.mNumChildren;
      Drawable[] arrayOfDrawable = this.mDrawables;
      boolean bool = false;
      for (int j = 0; ; j++)
        if (j < i)
        {
          if (arrayOfDrawable[j].isStateful())
            bool = true;
        }
        else
        {
          this.mStateful = bool;
          this.mCheckedStateful = true;
          break;
        }
    }

    void mutate()
    {
      int i = this.mNumChildren;
      Drawable[] arrayOfDrawable = this.mDrawables;
      for (int j = 0; j < i; j++)
        if (arrayOfDrawable[j] != null)
          arrayOfDrawable[j].mutate();
      this.mMutated = true;
    }

    public final void setConstantSize(boolean paramBoolean)
    {
      this.mConstantSize = paramBoolean;
    }

    public final void setEnterFadeDuration(int paramInt)
    {
      this.mEnterFadeDuration = paramInt;
    }

    public final void setExitFadeDuration(int paramInt)
    {
      this.mExitFadeDuration = paramInt;
    }

    final boolean setLayoutDirection(int paramInt1, int paramInt2)
    {
      boolean bool1 = false;
      int i = this.mNumChildren;
      Drawable[] arrayOfDrawable = this.mDrawables;
      for (int j = 0; j < i; j++)
        if (arrayOfDrawable[j] != null)
        {
          boolean bool2 = false;
          if (Build.VERSION.SDK_INT >= 23)
            bool2 = arrayOfDrawable[j].setLayoutDirection(paramInt1);
          if (j == paramInt2)
            bool1 = bool2;
        }
      this.mLayoutDirection = paramInt1;
      return bool1;
    }

    public final void setVariablePadding(boolean paramBoolean)
    {
      this.mVariablePadding = paramBoolean;
    }

    final void updateDensity(Resources paramResources)
    {
      if (paramResources != null)
      {
        this.mSourceRes = paramResources;
        int i = DrawableContainer.resolveDensity(paramResources, this.mDensity);
        int j = this.mDensity;
        this.mDensity = i;
        if (j != i)
        {
          this.mCheckedConstantSize = false;
          this.mCheckedPadding = false;
        }
      }
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.graphics.drawable.DrawableContainer
 * JD-Core Version:    0.6.2
 */