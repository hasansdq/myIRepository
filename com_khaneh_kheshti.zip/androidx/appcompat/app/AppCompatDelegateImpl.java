package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.LayoutInflater.Factory2;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.view.Window;
import android.view.Window.Callback;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.VisibleForTesting;
import androidx.appcompat.R.attr;
import androidx.appcompat.R.color;
import androidx.appcompat.R.id;
import androidx.appcompat.R.layout;
import androidx.appcompat.R.style;
import androidx.appcompat.R.styleable;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.appcompat.view.ContextThemeWrapper;
import androidx.appcompat.view.StandaloneActionMode;
import androidx.appcompat.view.SupportActionModeWrapper.CallbackWrapper;
import androidx.appcompat.view.SupportMenuInflater;
import androidx.appcompat.view.WindowCallbackWrapper;
import androidx.appcompat.view.menu.ListMenuPresenter;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.view.menu.MenuBuilder.Callback;
import androidx.appcompat.view.menu.MenuPresenter.Callback;
import androidx.appcompat.view.menu.MenuView;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.AppCompatDrawableManager;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.ContentFrameLayout.OnAttachListener;
import androidx.appcompat.widget.DecorContentParent;
import androidx.appcompat.widget.FitWindowsViewGroup;
import androidx.appcompat.widget.FitWindowsViewGroup.OnFitSystemWindowsListener;
import androidx.appcompat.widget.TintTypedArray;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.VectorEnabledTintResources;
import androidx.appcompat.widget.ViewStubCompat;
import androidx.appcompat.widget.ViewUtils;
import androidx.core.app.NavUtils;
import androidx.core.view.KeyEventDispatcher;
import androidx.core.view.KeyEventDispatcher.Component;
import androidx.core.view.LayoutInflaterCompat;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.ViewCompat;
import androidx.core.view.ViewPropertyAnimatorCompat;
import androidx.core.view.ViewPropertyAnimatorListenerAdapter;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.widget.PopupWindowCompat;
import java.lang.reflect.Constructor;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;

class AppCompatDelegateImpl extends AppCompatDelegate
  implements MenuBuilder.Callback, LayoutInflater.Factory2
{
  private static final boolean DEBUG = false;
  static final String EXCEPTION_HANDLER_MESSAGE_SUFFIX = ". If the resource you are trying to use is a vector resource, you may be referencing it in an unsupported way. See AppCompatDelegate.setCompatVectorFromResourcesEnabled() for more info.";
  private static final boolean IS_PRE_LOLLIPOP = false;
  private static final String KEY_LOCAL_NIGHT_MODE = "appcompat:local_night_mode";
  private static boolean sInstalledExceptionHandler;
  private static final int[] sWindowBackgroundStyleable;
  ActionBar mActionBar;
  private ActionMenuPresenterCallback mActionMenuPresenterCallback;
  androidx.appcompat.view.ActionMode mActionMode;
  PopupWindow mActionModePopup;
  ActionBarContextView mActionModeView;
  final AppCompatCallback mAppCompatCallback;
  private AppCompatViewInflater mAppCompatViewInflater;
  final Window.Callback mAppCompatWindowCallback;
  private boolean mApplyDayNightCalled;
  private AutoNightModeManager mAutoNightModeManager;
  private boolean mClosingActionMenu;
  final Context mContext;
  private DecorContentParent mDecorContentParent;
  private boolean mEnableDefaultActionBarUp;
  ViewPropertyAnimatorCompat mFadeAnim = null;
  private boolean mFeatureIndeterminateProgress;
  private boolean mFeatureProgress;
  private boolean mHandleNativeActionModes = true;
  boolean mHasActionBar;
  int mInvalidatePanelMenuFeatures;
  boolean mInvalidatePanelMenuPosted;
  private final Runnable mInvalidatePanelMenuRunnable = new Runnable()
  {
    public void run()
    {
      if ((0x1 & AppCompatDelegateImpl.this.mInvalidatePanelMenuFeatures) != 0)
        AppCompatDelegateImpl.this.doInvalidatePanelMenu(0);
      if ((0x1000 & AppCompatDelegateImpl.this.mInvalidatePanelMenuFeatures) != 0)
        AppCompatDelegateImpl.this.doInvalidatePanelMenu(108);
      AppCompatDelegateImpl.this.mInvalidatePanelMenuPosted = false;
      AppCompatDelegateImpl.this.mInvalidatePanelMenuFeatures = 0;
    }
  };
  boolean mIsDestroyed;
  boolean mIsFloating;
  private int mLocalNightMode = -100;
  private boolean mLongPressBackDown;
  MenuInflater mMenuInflater;
  final Window.Callback mOriginalWindowCallback;
  boolean mOverlayActionBar;
  boolean mOverlayActionMode;
  private PanelMenuPresenterCallback mPanelMenuPresenterCallback;
  private PanelFeatureState[] mPanels;
  private PanelFeatureState mPreparedPanel;
  Runnable mShowActionModePopup;
  private View mStatusGuard;
  private ViewGroup mSubDecor;
  private boolean mSubDecorInstalled;
  private Rect mTempRect1;
  private Rect mTempRect2;
  private CharSequence mTitle;
  private TextView mTitleView;
  final Window mWindow;
  boolean mWindowNoTitle;

  static
  {
    if (Build.VERSION.SDK_INT < 21);
    for (boolean bool = true; ; bool = false)
    {
      IS_PRE_LOLLIPOP = bool;
      sWindowBackgroundStyleable = new int[] { 16842836 };
      if ((IS_PRE_LOLLIPOP) && (!sInstalledExceptionHandler))
      {
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler()
        {
          private boolean shouldWrapException(Throwable paramAnonymousThrowable)
          {
            boolean bool = false;
            if ((paramAnonymousThrowable instanceof Resources.NotFoundException))
            {
              String str = paramAnonymousThrowable.getMessage();
              if ((str != null) && ((str.contains("drawable")) || (str.contains("Drawable"))))
                bool = true;
            }
            return bool;
          }

          public void uncaughtException(Thread paramAnonymousThread, Throwable paramAnonymousThrowable)
          {
            if (shouldWrapException(paramAnonymousThrowable))
            {
              Resources.NotFoundException localNotFoundException = new Resources.NotFoundException(paramAnonymousThrowable.getMessage() + ". If the resource you are trying to use is a vector resource, you may be referencing it in an unsupported way. See AppCompatDelegate.setCompatVectorFromResourcesEnabled() for more info.");
              localNotFoundException.initCause(paramAnonymousThrowable.getCause());
              localNotFoundException.setStackTrace(paramAnonymousThrowable.getStackTrace());
              this.val$defHandler.uncaughtException(paramAnonymousThread, localNotFoundException);
            }
            while (true)
            {
              return;
              this.val$defHandler.uncaughtException(paramAnonymousThread, paramAnonymousThrowable);
            }
          }
        });
        sInstalledExceptionHandler = true;
      }
      return;
    }
  }

  AppCompatDelegateImpl(Context paramContext, Window paramWindow, AppCompatCallback paramAppCompatCallback)
  {
    this.mContext = paramContext;
    this.mWindow = paramWindow;
    this.mAppCompatCallback = paramAppCompatCallback;
    this.mOriginalWindowCallback = this.mWindow.getCallback();
    if ((this.mOriginalWindowCallback instanceof AppCompatWindowCallback))
      throw new IllegalStateException("AppCompat has already installed itself into the Window");
    this.mAppCompatWindowCallback = new AppCompatWindowCallback(this.mOriginalWindowCallback);
    this.mWindow.setCallback(this.mAppCompatWindowCallback);
    TintTypedArray localTintTypedArray = TintTypedArray.obtainStyledAttributes(paramContext, null, sWindowBackgroundStyleable);
    Drawable localDrawable = localTintTypedArray.getDrawableIfKnown(0);
    if (localDrawable != null)
      this.mWindow.setBackgroundDrawable(localDrawable);
    localTintTypedArray.recycle();
  }

  private void applyFixedSizeWindow()
  {
    ContentFrameLayout localContentFrameLayout = (ContentFrameLayout)this.mSubDecor.findViewById(16908290);
    View localView = this.mWindow.getDecorView();
    localContentFrameLayout.setDecorPadding(localView.getPaddingLeft(), localView.getPaddingTop(), localView.getPaddingRight(), localView.getPaddingBottom());
    TypedArray localTypedArray = this.mContext.obtainStyledAttributes(R.styleable.AppCompatTheme);
    localTypedArray.getValue(R.styleable.AppCompatTheme_windowMinWidthMajor, localContentFrameLayout.getMinWidthMajor());
    localTypedArray.getValue(R.styleable.AppCompatTheme_windowMinWidthMinor, localContentFrameLayout.getMinWidthMinor());
    if (localTypedArray.hasValue(R.styleable.AppCompatTheme_windowFixedWidthMajor))
      localTypedArray.getValue(R.styleable.AppCompatTheme_windowFixedWidthMajor, localContentFrameLayout.getFixedWidthMajor());
    if (localTypedArray.hasValue(R.styleable.AppCompatTheme_windowFixedWidthMinor))
      localTypedArray.getValue(R.styleable.AppCompatTheme_windowFixedWidthMinor, localContentFrameLayout.getFixedWidthMinor());
    if (localTypedArray.hasValue(R.styleable.AppCompatTheme_windowFixedHeightMajor))
      localTypedArray.getValue(R.styleable.AppCompatTheme_windowFixedHeightMajor, localContentFrameLayout.getFixedHeightMajor());
    if (localTypedArray.hasValue(R.styleable.AppCompatTheme_windowFixedHeightMinor))
      localTypedArray.getValue(R.styleable.AppCompatTheme_windowFixedHeightMinor, localContentFrameLayout.getFixedHeightMinor());
    localTypedArray.recycle();
    localContentFrameLayout.requestLayout();
  }

  private ViewGroup createSubDecor()
  {
    TypedArray localTypedArray = this.mContext.obtainStyledAttributes(R.styleable.AppCompatTheme);
    if (!localTypedArray.hasValue(R.styleable.AppCompatTheme_windowActionBar))
    {
      localTypedArray.recycle();
      throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
    }
    LayoutInflater localLayoutInflater;
    ViewGroup localViewGroup1;
    if (localTypedArray.getBoolean(R.styleable.AppCompatTheme_windowNoTitle, false))
    {
      requestWindowFeature(1);
      if (localTypedArray.getBoolean(R.styleable.AppCompatTheme_windowActionBarOverlay, false))
        requestWindowFeature(109);
      if (localTypedArray.getBoolean(R.styleable.AppCompatTheme_windowActionModeOverlay, false))
        requestWindowFeature(10);
      this.mIsFloating = localTypedArray.getBoolean(R.styleable.AppCompatTheme_android_windowIsFloating, false);
      localTypedArray.recycle();
      this.mWindow.getDecorView();
      localLayoutInflater = LayoutInflater.from(this.mContext);
      localViewGroup1 = null;
      if (this.mWindowNoTitle)
        break label446;
      if (!this.mIsFloating)
        break label278;
      localViewGroup1 = (ViewGroup)localLayoutInflater.inflate(R.layout.abc_dialog_title_material, null);
      this.mOverlayActionBar = false;
      this.mHasActionBar = false;
    }
    while (true)
    {
      if (localViewGroup1 != null)
        break label529;
      throw new IllegalArgumentException("AppCompat does not support the current theme features: { windowActionBar: " + this.mHasActionBar + ", windowActionBarOverlay: " + this.mOverlayActionBar + ", android:windowIsFloating: " + this.mIsFloating + ", windowActionModeOverlay: " + this.mOverlayActionMode + ", windowNoTitle: " + this.mWindowNoTitle + " }");
      if (!localTypedArray.getBoolean(R.styleable.AppCompatTheme_windowActionBar, false))
        break;
      requestWindowFeature(108);
      break;
      label278: if (this.mHasActionBar)
      {
        TypedValue localTypedValue = new TypedValue();
        this.mContext.getTheme().resolveAttribute(R.attr.actionBarTheme, localTypedValue, true);
        if (localTypedValue.resourceId != 0);
        for (Object localObject = new ContextThemeWrapper(this.mContext, localTypedValue.resourceId); ; localObject = this.mContext)
        {
          localViewGroup1 = (ViewGroup)LayoutInflater.from((Context)localObject).inflate(R.layout.abc_screen_toolbar, null);
          this.mDecorContentParent = ((DecorContentParent)localViewGroup1.findViewById(R.id.decor_content_parent));
          this.mDecorContentParent.setWindowCallback(getWindowCallback());
          if (this.mOverlayActionBar)
            this.mDecorContentParent.initFeature(109);
          if (this.mFeatureProgress)
            this.mDecorContentParent.initFeature(2);
          if (!this.mFeatureIndeterminateProgress)
            break;
          this.mDecorContentParent.initFeature(5);
          break;
        }
        label446: if (this.mOverlayActionMode);
        for (localViewGroup1 = (ViewGroup)localLayoutInflater.inflate(R.layout.abc_screen_simple_overlay_action_mode, null); ; localViewGroup1 = (ViewGroup)localLayoutInflater.inflate(R.layout.abc_screen_simple, null))
        {
          if (Build.VERSION.SDK_INT < 21)
            break label508;
          ViewCompat.setOnApplyWindowInsetsListener(localViewGroup1, new OnApplyWindowInsetsListener()
          {
            public WindowInsetsCompat onApplyWindowInsets(View paramAnonymousView, WindowInsetsCompat paramAnonymousWindowInsetsCompat)
            {
              int i = paramAnonymousWindowInsetsCompat.getSystemWindowInsetTop();
              int j = AppCompatDelegateImpl.this.updateStatusGuard(i);
              if (i != j)
                paramAnonymousWindowInsetsCompat = paramAnonymousWindowInsetsCompat.replaceSystemWindowInsets(paramAnonymousWindowInsetsCompat.getSystemWindowInsetLeft(), j, paramAnonymousWindowInsetsCompat.getSystemWindowInsetRight(), paramAnonymousWindowInsetsCompat.getSystemWindowInsetBottom());
              return ViewCompat.onApplyWindowInsets(paramAnonymousView, paramAnonymousWindowInsetsCompat);
            }
          });
          break;
        }
        label508: ((FitWindowsViewGroup)localViewGroup1).setOnFitSystemWindowsListener(new FitWindowsViewGroup.OnFitSystemWindowsListener()
        {
          public void onFitSystemWindows(Rect paramAnonymousRect)
          {
            paramAnonymousRect.top = AppCompatDelegateImpl.this.updateStatusGuard(paramAnonymousRect.top);
          }
        });
      }
    }
    label529: if (this.mDecorContentParent == null)
      this.mTitleView = ((TextView)localViewGroup1.findViewById(R.id.title));
    ViewUtils.makeOptionalFitsSystemWindows(localViewGroup1);
    ContentFrameLayout localContentFrameLayout = (ContentFrameLayout)localViewGroup1.findViewById(R.id.action_bar_activity_content);
    ViewGroup localViewGroup2 = (ViewGroup)this.mWindow.findViewById(16908290);
    if (localViewGroup2 != null)
    {
      while (localViewGroup2.getChildCount() > 0)
      {
        View localView = localViewGroup2.getChildAt(0);
        localViewGroup2.removeViewAt(0);
        localContentFrameLayout.addView(localView);
      }
      localViewGroup2.setId(-1);
      localContentFrameLayout.setId(16908290);
      if ((localViewGroup2 instanceof FrameLayout))
        ((FrameLayout)localViewGroup2).setForeground(null);
    }
    this.mWindow.setContentView(localViewGroup1);
    localContentFrameLayout.setAttachListener(new ContentFrameLayout.OnAttachListener()
    {
      public void onAttachedFromWindow()
      {
      }

      public void onDetachedFromWindow()
      {
        AppCompatDelegateImpl.this.dismissPopups();
      }
    });
    return localViewGroup1;
  }

  private void ensureAutoNightModeManager()
  {
    if (this.mAutoNightModeManager == null)
      this.mAutoNightModeManager = new AutoNightModeManager(TwilightManager.getInstance(this.mContext));
  }

  private void ensureSubDecor()
  {
    CharSequence localCharSequence;
    if (!this.mSubDecorInstalled)
    {
      this.mSubDecor = createSubDecor();
      localCharSequence = getTitle();
      if (!TextUtils.isEmpty(localCharSequence))
      {
        if (this.mDecorContentParent == null)
          break label93;
        this.mDecorContentParent.setWindowTitle(localCharSequence);
      }
    }
    while (true)
    {
      applyFixedSizeWindow();
      onSubDecorInstalled(this.mSubDecor);
      this.mSubDecorInstalled = true;
      PanelFeatureState localPanelFeatureState = getPanelState(0, false);
      if ((!this.mIsDestroyed) && ((localPanelFeatureState == null) || (localPanelFeatureState.menu == null)))
        invalidatePanelMenu(108);
      return;
      label93: if (peekSupportActionBar() != null)
        peekSupportActionBar().setWindowTitle(localCharSequence);
      else if (this.mTitleView != null)
        this.mTitleView.setText(localCharSequence);
    }
  }

  private int getNightMode()
  {
    if (this.mLocalNightMode != -100);
    for (int i = this.mLocalNightMode; ; i = getDefaultNightMode())
      return i;
  }

  private void initWindowDecorActionBar()
  {
    ensureSubDecor();
    if ((!this.mHasActionBar) || (this.mActionBar != null));
    label101: 
    while (true)
    {
      return;
      if ((this.mOriginalWindowCallback instanceof Activity))
        this.mActionBar = new WindowDecorActionBar((Activity)this.mOriginalWindowCallback, this.mOverlayActionBar);
      while (true)
      {
        if (this.mActionBar == null)
          break label101;
        this.mActionBar.setDefaultDisplayHomeAsUpEnabled(this.mEnableDefaultActionBarUp);
        break;
        if ((this.mOriginalWindowCallback instanceof Dialog))
          this.mActionBar = new WindowDecorActionBar((Dialog)this.mOriginalWindowCallback);
      }
    }
  }

  private boolean initializePanelContent(PanelFeatureState paramPanelFeatureState)
  {
    boolean bool = true;
    if (paramPanelFeatureState.createdPanelView != null)
      paramPanelFeatureState.shownPanelView = paramPanelFeatureState.createdPanelView;
    while (true)
    {
      return bool;
      if (paramPanelFeatureState.menu == null)
      {
        bool = false;
      }
      else
      {
        if (this.mPanelMenuPresenterCallback == null)
          this.mPanelMenuPresenterCallback = new PanelMenuPresenterCallback();
        paramPanelFeatureState.shownPanelView = ((View)paramPanelFeatureState.getListMenuView(this.mPanelMenuPresenterCallback));
        if (paramPanelFeatureState.shownPanelView == null)
          bool = false;
      }
    }
  }

  private boolean initializePanelDecor(PanelFeatureState paramPanelFeatureState)
  {
    paramPanelFeatureState.setStyle(getActionBarThemedContext());
    paramPanelFeatureState.decorView = new ListMenuDecorView(paramPanelFeatureState.listPresenterContext);
    paramPanelFeatureState.gravity = 81;
    return true;
  }

  private boolean initializePanelMenu(PanelFeatureState paramPanelFeatureState)
  {
    Object localObject = this.mContext;
    TypedValue localTypedValue;
    Resources.Theme localTheme1;
    Resources.Theme localTheme2;
    if (((paramPanelFeatureState.featureId == 0) || (paramPanelFeatureState.featureId == 108)) && (this.mDecorContentParent != null))
    {
      localTypedValue = new TypedValue();
      localTheme1 = ((Context)localObject).getTheme();
      localTheme1.resolveAttribute(R.attr.actionBarTheme, localTypedValue, true);
      localTheme2 = null;
      if (localTypedValue.resourceId == 0)
        break label191;
      localTheme2 = ((Context)localObject).getResources().newTheme();
      localTheme2.setTo(localTheme1);
      localTheme2.applyStyle(localTypedValue.resourceId, true);
      localTheme2.resolveAttribute(R.attr.actionBarWidgetTheme, localTypedValue, true);
    }
    while (true)
    {
      if (localTypedValue.resourceId != 0)
      {
        if (localTheme2 == null)
        {
          localTheme2 = ((Context)localObject).getResources().newTheme();
          localTheme2.setTo(localTheme1);
        }
        localTheme2.applyStyle(localTypedValue.resourceId, true);
      }
      if (localTheme2 != null)
      {
        ContextThemeWrapper localContextThemeWrapper = new ContextThemeWrapper((Context)localObject, 0);
        localContextThemeWrapper.getTheme().setTo(localTheme2);
        localObject = localContextThemeWrapper;
      }
      MenuBuilder localMenuBuilder = new MenuBuilder((Context)localObject);
      localMenuBuilder.setCallback(this);
      paramPanelFeatureState.setMenu(localMenuBuilder);
      return true;
      label191: localTheme1.resolveAttribute(R.attr.actionBarWidgetTheme, localTypedValue, true);
    }
  }

  private void invalidatePanelMenu(int paramInt)
  {
    this.mInvalidatePanelMenuFeatures |= 1 << paramInt;
    if (!this.mInvalidatePanelMenuPosted)
    {
      ViewCompat.postOnAnimation(this.mWindow.getDecorView(), this.mInvalidatePanelMenuRunnable);
      this.mInvalidatePanelMenuPosted = true;
    }
  }

  private boolean onKeyDownPanel(int paramInt, KeyEvent paramKeyEvent)
  {
    PanelFeatureState localPanelFeatureState;
    if (paramKeyEvent.getRepeatCount() == 0)
    {
      localPanelFeatureState = getPanelState(paramInt, true);
      if (localPanelFeatureState.isOpen);
    }
    for (boolean bool = preparePanel(localPanelFeatureState, paramKeyEvent); ; bool = false)
      return bool;
  }

  private boolean onKeyUpPanel(int paramInt, KeyEvent paramKeyEvent)
  {
    boolean bool1;
    if (this.mActionMode != null)
      bool1 = false;
    while (true)
    {
      return bool1;
      bool1 = false;
      PanelFeatureState localPanelFeatureState = getPanelState(paramInt, true);
      if ((paramInt == 0) && (this.mDecorContentParent != null) && (this.mDecorContentParent.canShowOverflowMenu()) && (!ViewConfiguration.get(this.mContext).hasPermanentMenuKey()))
        if (!this.mDecorContentParent.isOverflowMenuShowing())
          if ((!this.mIsDestroyed) && (preparePanel(localPanelFeatureState, paramKeyEvent)))
            bool1 = this.mDecorContentParent.showOverflowMenu();
      while (true)
      {
        if (!bool1)
          break label223;
        AudioManager localAudioManager = (AudioManager)this.mContext.getSystemService("audio");
        if (localAudioManager == null)
          break label225;
        localAudioManager.playSoundEffect(0);
        break;
        bool1 = this.mDecorContentParent.hideOverflowMenu();
        continue;
        if ((localPanelFeatureState.isOpen) || (localPanelFeatureState.isHandled))
        {
          bool1 = localPanelFeatureState.isOpen;
          closePanel(localPanelFeatureState, true);
        }
        else if (localPanelFeatureState.isPrepared)
        {
          boolean bool2 = true;
          if (localPanelFeatureState.refreshMenuContent)
          {
            localPanelFeatureState.isPrepared = false;
            bool2 = preparePanel(localPanelFeatureState, paramKeyEvent);
          }
          if (bool2)
          {
            openPanel(localPanelFeatureState, paramKeyEvent);
            bool1 = true;
          }
        }
      }
      label223: continue;
      label225: Log.w("AppCompatDelegate", "Couldn't get audio manager");
    }
  }

  private void openPanel(PanelFeatureState paramPanelFeatureState, KeyEvent paramKeyEvent)
  {
    if ((paramPanelFeatureState.isOpen) || (this.mIsDestroyed));
    label85: label89: label91: WindowManager localWindowManager;
    int i;
    do
    {
      do
      {
        while (true)
        {
          return;
          if (paramPanelFeatureState.featureId == 0)
            if ((0xF & this.mContext.getResources().getConfiguration().screenLayout) != 4)
              break label85;
          for (int k = 1; ; k = 0)
          {
            if (k != 0)
              break label89;
            Window.Callback localCallback = getWindowCallback();
            if ((localCallback == null) || (localCallback.onMenuOpened(paramPanelFeatureState.featureId, paramPanelFeatureState.menu)))
              break label91;
            closePanel(paramPanelFeatureState, true);
            break;
          }
        }
        localWindowManager = (WindowManager)this.mContext.getSystemService("window");
      }
      while ((localWindowManager == null) || (!preparePanel(paramPanelFeatureState, paramKeyEvent)));
      i = -2;
      if ((paramPanelFeatureState.decorView != null) && (!paramPanelFeatureState.refreshDecorView))
        break label382;
      if (paramPanelFeatureState.decorView != null)
        break;
    }
    while ((!initializePanelDecor(paramPanelFeatureState)) || (paramPanelFeatureState.decorView == null));
    label160: if ((initializePanelContent(paramPanelFeatureState)) && (paramPanelFeatureState.hasPanelItems()))
    {
      ViewGroup.LayoutParams localLayoutParams1 = paramPanelFeatureState.shownPanelView.getLayoutParams();
      if (localLayoutParams1 == null)
        localLayoutParams1 = new ViewGroup.LayoutParams(-2, -2);
      int j = paramPanelFeatureState.background;
      paramPanelFeatureState.decorView.setBackgroundResource(j);
      ViewParent localViewParent = paramPanelFeatureState.shownPanelView.getParent();
      if ((localViewParent != null) && ((localViewParent instanceof ViewGroup)))
        ((ViewGroup)localViewParent).removeView(paramPanelFeatureState.shownPanelView);
      paramPanelFeatureState.decorView.addView(paramPanelFeatureState.shownPanelView, localLayoutParams1);
      if (!paramPanelFeatureState.shownPanelView.hasFocus())
        paramPanelFeatureState.shownPanelView.requestFocus();
    }
    while (true)
    {
      paramPanelFeatureState.isHandled = false;
      WindowManager.LayoutParams localLayoutParams = new WindowManager.LayoutParams(i, -2, paramPanelFeatureState.x, paramPanelFeatureState.y, 1002, 8519680, -3);
      localLayoutParams.gravity = paramPanelFeatureState.gravity;
      localLayoutParams.windowAnimations = paramPanelFeatureState.windowAnimations;
      localWindowManager.addView(paramPanelFeatureState.decorView, localLayoutParams);
      paramPanelFeatureState.isOpen = true;
      break;
      if ((!paramPanelFeatureState.refreshDecorView) || (paramPanelFeatureState.decorView.getChildCount() <= 0))
        break label160;
      paramPanelFeatureState.decorView.removeAllViews();
      break label160;
      break;
      label382: if (paramPanelFeatureState.createdPanelView != null)
      {
        ViewGroup.LayoutParams localLayoutParams2 = paramPanelFeatureState.createdPanelView.getLayoutParams();
        if ((localLayoutParams2 != null) && (localLayoutParams2.width == -1))
          i = -1;
      }
    }
  }

  private boolean performPanelShortcut(PanelFeatureState paramPanelFeatureState, int paramInt1, KeyEvent paramKeyEvent, int paramInt2)
  {
    boolean bool;
    if (paramKeyEvent.isSystem())
      bool = false;
    while (true)
    {
      return bool;
      bool = false;
      if (((paramPanelFeatureState.isPrepared) || (preparePanel(paramPanelFeatureState, paramKeyEvent))) && (paramPanelFeatureState.menu != null))
        bool = paramPanelFeatureState.menu.performShortcut(paramInt1, paramKeyEvent, paramInt2);
      if ((bool) && ((paramInt2 & 0x1) == 0) && (this.mDecorContentParent == null))
        closePanel(paramPanelFeatureState, true);
    }
  }

  private boolean preparePanel(PanelFeatureState paramPanelFeatureState, KeyEvent paramKeyEvent)
  {
    boolean bool1 = false;
    if (this.mIsDestroyed);
    while (true)
    {
      return bool1;
      if (paramPanelFeatureState.isPrepared)
      {
        bool1 = true;
      }
      else
      {
        if ((this.mPreparedPanel != null) && (this.mPreparedPanel != paramPanelFeatureState))
          closePanel(this.mPreparedPanel, false);
        Window.Callback localCallback = getWindowCallback();
        if (localCallback != null)
          paramPanelFeatureState.createdPanelView = localCallback.onCreatePanelView(paramPanelFeatureState.featureId);
        if ((paramPanelFeatureState.featureId == 0) || (paramPanelFeatureState.featureId == 108));
        for (int i = 1; ; i = 0)
        {
          if ((i != 0) && (this.mDecorContentParent != null))
            this.mDecorContentParent.setMenuPrepared();
          if ((paramPanelFeatureState.createdPanelView != null) || ((i != 0) && ((peekSupportActionBar() instanceof ToolbarActionBar))))
            break label423;
          if ((paramPanelFeatureState.menu != null) && (!paramPanelFeatureState.refreshMenuContent))
            break label289;
          if ((paramPanelFeatureState.menu == null) && ((!initializePanelMenu(paramPanelFeatureState)) || (paramPanelFeatureState.menu == null)))
            break;
          if ((i != 0) && (this.mDecorContentParent != null))
          {
            if (this.mActionMenuPresenterCallback == null)
              this.mActionMenuPresenterCallback = new ActionMenuPresenterCallback();
            this.mDecorContentParent.setMenu(paramPanelFeatureState.menu, this.mActionMenuPresenterCallback);
          }
          paramPanelFeatureState.menu.stopDispatchingItemsChanged();
          if (localCallback.onCreatePanelMenu(paramPanelFeatureState.featureId, paramPanelFeatureState.menu))
            break label284;
          paramPanelFeatureState.setMenu(null);
          if ((i == 0) || (this.mDecorContentParent == null))
            break;
          this.mDecorContentParent.setMenu(null, this.mActionMenuPresenterCallback);
          break;
        }
        label284: paramPanelFeatureState.refreshMenuContent = false;
        label289: paramPanelFeatureState.menu.stopDispatchingItemsChanged();
        if (paramPanelFeatureState.frozenActionViewState != null)
        {
          paramPanelFeatureState.menu.restoreActionViewStates(paramPanelFeatureState.frozenActionViewState);
          paramPanelFeatureState.frozenActionViewState = null;
        }
        if (localCallback.onPreparePanel(0, paramPanelFeatureState.createdPanelView, paramPanelFeatureState.menu))
          break;
        if ((i != 0) && (this.mDecorContentParent != null))
          this.mDecorContentParent.setMenu(null, this.mActionMenuPresenterCallback);
        paramPanelFeatureState.menu.startDispatchingItemsChanged();
      }
    }
    int j;
    if (paramKeyEvent != null)
    {
      j = paramKeyEvent.getDeviceId();
      label384: if (KeyCharacterMap.load(j).getKeyboardType() == 1)
        break label449;
    }
    label423: label449: for (boolean bool2 = true; ; bool2 = false)
    {
      paramPanelFeatureState.qwertyMode = bool2;
      paramPanelFeatureState.menu.setQwertyMode(paramPanelFeatureState.qwertyMode);
      paramPanelFeatureState.menu.startDispatchingItemsChanged();
      paramPanelFeatureState.isPrepared = true;
      paramPanelFeatureState.isHandled = false;
      this.mPreparedPanel = paramPanelFeatureState;
      bool1 = true;
      break;
      j = -1;
      break label384;
    }
  }

  private void reopenMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean)
  {
    Window.Callback localCallback;
    if ((this.mDecorContentParent != null) && (this.mDecorContentParent.canShowOverflowMenu()) && ((!ViewConfiguration.get(this.mContext).hasPermanentMenuKey()) || (this.mDecorContentParent.isOverflowMenuShowPending())))
    {
      localCallback = getWindowCallback();
      if ((!this.mDecorContentParent.isOverflowMenuShowing()) || (!paramBoolean))
        if ((localCallback != null) && (!this.mIsDestroyed))
        {
          if ((this.mInvalidatePanelMenuPosted) && ((0x1 & this.mInvalidatePanelMenuFeatures) != 0))
          {
            this.mWindow.getDecorView().removeCallbacks(this.mInvalidatePanelMenuRunnable);
            this.mInvalidatePanelMenuRunnable.run();
          }
          PanelFeatureState localPanelFeatureState2 = getPanelState(0, true);
          if ((localPanelFeatureState2.menu != null) && (!localPanelFeatureState2.refreshMenuContent) && (localCallback.onPreparePanel(0, localPanelFeatureState2.createdPanelView, localPanelFeatureState2.menu)))
          {
            localCallback.onMenuOpened(108, localPanelFeatureState2.menu);
            this.mDecorContentParent.showOverflowMenu();
          }
        }
    }
    while (true)
    {
      return;
      this.mDecorContentParent.hideOverflowMenu();
      if (!this.mIsDestroyed)
      {
        localCallback.onPanelClosed(108, getPanelState(0, true).menu);
        continue;
        PanelFeatureState localPanelFeatureState1 = getPanelState(0, true);
        localPanelFeatureState1.refreshDecorView = true;
        closePanel(localPanelFeatureState1, false);
        openPanel(localPanelFeatureState1, null);
      }
    }
  }

  private int sanitizeWindowFeatureId(int paramInt)
  {
    if (paramInt == 8)
    {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
      paramInt = 108;
    }
    while (true)
    {
      return paramInt;
      if (paramInt == 9)
      {
        Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
        paramInt = 109;
      }
    }
  }

  private boolean shouldInheritContext(ViewParent paramViewParent)
  {
    boolean bool;
    if (paramViewParent == null)
    {
      bool = false;
      return bool;
    }
    View localView = this.mWindow.getDecorView();
    while (true)
    {
      if (paramViewParent == null)
      {
        bool = true;
        break;
      }
      if ((paramViewParent == localView) || (!(paramViewParent instanceof View)) || (ViewCompat.isAttachedToWindow((View)paramViewParent)))
      {
        bool = false;
        break;
      }
      paramViewParent = paramViewParent.getParent();
    }
  }

  private boolean shouldRecreateOnNightModeChange()
  {
    boolean bool = true;
    PackageManager localPackageManager;
    if ((this.mApplyDayNightCalled) && ((this.mContext instanceof Activity)))
      localPackageManager = this.mContext.getPackageManager();
    while (true)
    {
      try
      {
        int i = localPackageManager.getActivityInfo(new ComponentName(this.mContext, this.mContext.getClass()), 0).configChanges;
        if ((i & 0x200) == 0)
          return bool;
        bool = false;
        continue;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", localNameNotFoundException);
        continue;
      }
      bool = false;
    }
  }

  private void throwFeatureRequestIfSubDecorInstalled()
  {
    if (this.mSubDecorInstalled)
      throw new AndroidRuntimeException("Window feature must be requested before adding content");
  }

  private boolean updateForNightMode(int paramInt)
  {
    Resources localResources = this.mContext.getResources();
    Configuration localConfiguration1 = localResources.getConfiguration();
    int i = 0x30 & localConfiguration1.uiMode;
    int j;
    if (paramInt == 2)
    {
      j = 32;
      if (i == j)
        break label123;
      if (!shouldRecreateOnNightModeChange())
        break label68;
      ((Activity)this.mContext).recreate();
    }
    label55: label68: label123: for (boolean bool = true; ; bool = false)
    {
      return bool;
      j = 16;
      break;
      Configuration localConfiguration2 = new Configuration(localConfiguration1);
      DisplayMetrics localDisplayMetrics = localResources.getDisplayMetrics();
      localConfiguration2.uiMode = (j | 0xFFFFFFCF & localConfiguration2.uiMode);
      localResources.updateConfiguration(localConfiguration2, localDisplayMetrics);
      if (Build.VERSION.SDK_INT >= 26)
        break label55;
      ResourcesFlusher.flush(localResources);
      break label55;
    }
  }

  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams)
  {
    ensureSubDecor();
    ((ViewGroup)this.mSubDecor.findViewById(16908290)).addView(paramView, paramLayoutParams);
    this.mOriginalWindowCallback.onContentChanged();
  }

  public boolean applyDayNight()
  {
    boolean bool = false;
    int i = getNightMode();
    int j = mapNightMode(i);
    if (j != -1)
      bool = updateForNightMode(j);
    if (i == 0)
    {
      ensureAutoNightModeManager();
      this.mAutoNightModeManager.setup();
    }
    this.mApplyDayNightCalled = true;
    return bool;
  }

  void callOnPanelClosed(int paramInt, PanelFeatureState paramPanelFeatureState, Menu paramMenu)
  {
    if (paramMenu == null)
    {
      if ((paramPanelFeatureState == null) && (paramInt >= 0) && (paramInt < this.mPanels.length))
        paramPanelFeatureState = this.mPanels[paramInt];
      if (paramPanelFeatureState != null)
        paramMenu = paramPanelFeatureState.menu;
    }
    if ((paramPanelFeatureState != null) && (!paramPanelFeatureState.isOpen));
    while (true)
    {
      return;
      if (!this.mIsDestroyed)
        this.mOriginalWindowCallback.onPanelClosed(paramInt, paramMenu);
    }
  }

  void checkCloseActionMenu(MenuBuilder paramMenuBuilder)
  {
    if (this.mClosingActionMenu);
    while (true)
    {
      return;
      this.mClosingActionMenu = true;
      this.mDecorContentParent.dismissPopups();
      Window.Callback localCallback = getWindowCallback();
      if ((localCallback != null) && (!this.mIsDestroyed))
        localCallback.onPanelClosed(108, paramMenuBuilder);
      this.mClosingActionMenu = false;
    }
  }

  void closePanel(int paramInt)
  {
    closePanel(getPanelState(paramInt, true), true);
  }

  void closePanel(PanelFeatureState paramPanelFeatureState, boolean paramBoolean)
  {
    if ((paramBoolean) && (paramPanelFeatureState.featureId == 0) && (this.mDecorContentParent != null) && (this.mDecorContentParent.isOverflowMenuShowing()))
      checkCloseActionMenu(paramPanelFeatureState.menu);
    while (true)
    {
      return;
      WindowManager localWindowManager = (WindowManager)this.mContext.getSystemService("window");
      if ((localWindowManager != null) && (paramPanelFeatureState.isOpen) && (paramPanelFeatureState.decorView != null))
      {
        localWindowManager.removeView(paramPanelFeatureState.decorView);
        if (paramBoolean)
          callOnPanelClosed(paramPanelFeatureState.featureId, paramPanelFeatureState, null);
      }
      paramPanelFeatureState.isPrepared = false;
      paramPanelFeatureState.isHandled = false;
      paramPanelFeatureState.isOpen = false;
      paramPanelFeatureState.shownPanelView = null;
      paramPanelFeatureState.refreshDecorView = true;
      if (this.mPreparedPanel == paramPanelFeatureState)
        this.mPreparedPanel = null;
    }
  }

  public View createView(View paramView, String paramString, @NonNull Context paramContext, @NonNull AttributeSet paramAttributeSet)
  {
    String str;
    boolean bool;
    if (this.mAppCompatViewInflater == null)
    {
      str = this.mContext.obtainStyledAttributes(R.styleable.AppCompatTheme).getString(R.styleable.AppCompatTheme_viewInflaterClass);
      if ((str == null) || (AppCompatViewInflater.class.getName().equals(str)))
        this.mAppCompatViewInflater = new AppCompatViewInflater();
    }
    else
    {
      bool = false;
      if (IS_PRE_LOLLIPOP)
      {
        if (!(paramAttributeSet instanceof XmlPullParser))
          break label198;
        if (((XmlPullParser)paramAttributeSet).getDepth() <= 1)
          break label192;
        bool = true;
      }
    }
    while (true)
    {
      while (true)
      {
        return this.mAppCompatViewInflater.createView(paramView, paramString, paramContext, paramAttributeSet, bool, IS_PRE_LOLLIPOP, true, VectorEnabledTintResources.shouldBeUsed());
        try
        {
          this.mAppCompatViewInflater = ((AppCompatViewInflater)Class.forName(str).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]));
        }
        catch (Throwable localThrowable)
        {
          Log.i("AppCompatDelegate", "Failed to instantiate custom view inflater " + str + ". Falling back to default.", localThrowable);
          this.mAppCompatViewInflater = new AppCompatViewInflater();
        }
      }
      break;
      label192: bool = false;
      continue;
      label198: bool = shouldInheritContext((ViewParent)paramView);
    }
  }

  void dismissPopups()
  {
    if (this.mDecorContentParent != null)
      this.mDecorContentParent.dismissPopups();
    if (this.mActionModePopup != null)
    {
      this.mWindow.getDecorView().removeCallbacks(this.mShowActionModePopup);
      if (!this.mActionModePopup.isShowing());
    }
    try
    {
      this.mActionModePopup.dismiss();
      label55: this.mActionModePopup = null;
      endOnGoingFadeAnimation();
      PanelFeatureState localPanelFeatureState = getPanelState(0, false);
      if ((localPanelFeatureState != null) && (localPanelFeatureState.menu != null))
        localPanelFeatureState.menu.close();
      return;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      break label55;
    }
  }

  boolean dispatchKeyEvent(KeyEvent paramKeyEvent)
  {
    boolean bool1 = true;
    if (((this.mOriginalWindowCallback instanceof KeyEventDispatcher.Component)) || ((this.mOriginalWindowCallback instanceof AppCompatDialog)))
    {
      View localView = this.mWindow.getDecorView();
      if ((localView == null) || (!KeyEventDispatcher.dispatchBeforeHierarchy(localView, paramKeyEvent)));
    }
    while (true)
    {
      return bool1;
      if ((paramKeyEvent.getKeyCode() != 82) || (!this.mOriginalWindowCallback.dispatchKeyEvent(paramKeyEvent)))
      {
        int i = paramKeyEvent.getKeyCode();
        if (paramKeyEvent.getAction() == 0);
        for (boolean bool2 = bool1; ; bool2 = false)
        {
          if (!bool2)
            break label104;
          bool1 = onKeyDown(i, paramKeyEvent);
          break;
        }
        label104: bool1 = onKeyUp(i, paramKeyEvent);
      }
    }
  }

  void doInvalidatePanelMenu(int paramInt)
  {
    PanelFeatureState localPanelFeatureState1 = getPanelState(paramInt, true);
    if (localPanelFeatureState1.menu != null)
    {
      Bundle localBundle = new Bundle();
      localPanelFeatureState1.menu.saveActionViewStates(localBundle);
      if (localBundle.size() > 0)
        localPanelFeatureState1.frozenActionViewState = localBundle;
      localPanelFeatureState1.menu.stopDispatchingItemsChanged();
      localPanelFeatureState1.menu.clear();
    }
    localPanelFeatureState1.refreshMenuContent = true;
    localPanelFeatureState1.refreshDecorView = true;
    if (((paramInt == 108) || (paramInt == 0)) && (this.mDecorContentParent != null))
    {
      PanelFeatureState localPanelFeatureState2 = getPanelState(0, false);
      if (localPanelFeatureState2 != null)
      {
        localPanelFeatureState2.isPrepared = false;
        preparePanel(localPanelFeatureState2, null);
      }
    }
  }

  void endOnGoingFadeAnimation()
  {
    if (this.mFadeAnim != null)
      this.mFadeAnim.cancel();
  }

  PanelFeatureState findMenuPanel(Menu paramMenu)
  {
    PanelFeatureState[] arrayOfPanelFeatureState = this.mPanels;
    int i;
    int j;
    label15: PanelFeatureState localPanelFeatureState;
    if (arrayOfPanelFeatureState != null)
    {
      i = arrayOfPanelFeatureState.length;
      j = 0;
      if (j >= i)
        break label55;
      localPanelFeatureState = arrayOfPanelFeatureState[j];
      if ((localPanelFeatureState == null) || (localPanelFeatureState.menu != paramMenu))
        break label49;
    }
    while (true)
    {
      return localPanelFeatureState;
      i = 0;
      break;
      label49: j++;
      break label15;
      label55: localPanelFeatureState = null;
    }
  }

  @Nullable
  public <T extends View> T findViewById(@IdRes int paramInt)
  {
    ensureSubDecor();
    return this.mWindow.findViewById(paramInt);
  }

  final Context getActionBarThemedContext()
  {
    Context localContext = null;
    ActionBar localActionBar = getSupportActionBar();
    if (localActionBar != null)
      localContext = localActionBar.getThemedContext();
    if (localContext == null)
      localContext = this.mContext;
    return localContext;
  }

  @VisibleForTesting
  final AutoNightModeManager getAutoNightModeManager()
  {
    ensureAutoNightModeManager();
    return this.mAutoNightModeManager;
  }

  public final ActionBarDrawerToggle.Delegate getDrawerToggleDelegate()
  {
    return new ActionBarDrawableToggleImpl();
  }

  public MenuInflater getMenuInflater()
  {
    if (this.mMenuInflater == null)
    {
      initWindowDecorActionBar();
      if (this.mActionBar == null)
        break label43;
    }
    label43: for (Context localContext = this.mActionBar.getThemedContext(); ; localContext = this.mContext)
    {
      this.mMenuInflater = new SupportMenuInflater(localContext);
      return this.mMenuInflater;
    }
  }

  protected PanelFeatureState getPanelState(int paramInt, boolean paramBoolean)
  {
    Object localObject = this.mPanels;
    if ((localObject == null) || (localObject.length <= paramInt))
    {
      PanelFeatureState[] arrayOfPanelFeatureState = new PanelFeatureState[paramInt + 1];
      if (localObject != null)
        System.arraycopy(localObject, 0, arrayOfPanelFeatureState, 0, localObject.length);
      localObject = arrayOfPanelFeatureState;
      this.mPanels = arrayOfPanelFeatureState;
    }
    PanelFeatureState localPanelFeatureState = localObject[paramInt];
    if (localPanelFeatureState == null)
    {
      localPanelFeatureState = new PanelFeatureState(paramInt);
      localObject[paramInt] = localPanelFeatureState;
    }
    return localPanelFeatureState;
  }

  ViewGroup getSubDecor()
  {
    return this.mSubDecor;
  }

  public ActionBar getSupportActionBar()
  {
    initWindowDecorActionBar();
    return this.mActionBar;
  }

  final CharSequence getTitle()
  {
    if ((this.mOriginalWindowCallback instanceof Activity));
    for (CharSequence localCharSequence = ((Activity)this.mOriginalWindowCallback).getTitle(); ; localCharSequence = this.mTitle)
      return localCharSequence;
  }

  final Window.Callback getWindowCallback()
  {
    return this.mWindow.getCallback();
  }

  public boolean hasWindowFeature(int paramInt)
  {
    boolean bool1 = false;
    switch (sanitizeWindowFeatureId(paramInt))
    {
    default:
      if ((!bool1) && (!this.mWindow.hasFeature(paramInt)))
        break;
    case 108:
    case 109:
    case 10:
    case 2:
    case 5:
    case 1:
    }
    for (boolean bool2 = true; ; bool2 = false)
    {
      return bool2;
      bool1 = this.mHasActionBar;
      break;
      bool1 = this.mOverlayActionBar;
      break;
      bool1 = this.mOverlayActionMode;
      break;
      bool1 = this.mFeatureProgress;
      break;
      bool1 = this.mFeatureIndeterminateProgress;
      break;
      bool1 = this.mWindowNoTitle;
      break;
    }
  }

  public void installViewFactory()
  {
    LayoutInflater localLayoutInflater = LayoutInflater.from(this.mContext);
    if (localLayoutInflater.getFactory() == null)
      LayoutInflaterCompat.setFactory2(localLayoutInflater, this);
    while (true)
    {
      return;
      if (!(localLayoutInflater.getFactory2() instanceof AppCompatDelegateImpl))
        Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
    }
  }

  public void invalidateOptionsMenu()
  {
    ActionBar localActionBar = getSupportActionBar();
    if ((localActionBar != null) && (localActionBar.invalidateOptionsMenu()));
    while (true)
    {
      return;
      invalidatePanelMenu(0);
    }
  }

  public boolean isHandleNativeActionModesEnabled()
  {
    return this.mHandleNativeActionModes;
  }

  int mapNightMode(int paramInt)
  {
    switch (paramInt)
    {
    default:
    case 0:
    case -100:
    }
    while (true)
    {
      return paramInt;
      if ((Build.VERSION.SDK_INT >= 23) && (((UiModeManager)this.mContext.getSystemService(UiModeManager.class)).getNightMode() == 0))
      {
        paramInt = -1;
      }
      else
      {
        ensureAutoNightModeManager();
        paramInt = this.mAutoNightModeManager.getApplyableNightMode();
        continue;
        paramInt = -1;
      }
    }
  }

  boolean onBackPressed()
  {
    boolean bool = true;
    if (this.mActionMode != null)
      this.mActionMode.finish();
    while (true)
    {
      return bool;
      ActionBar localActionBar = getSupportActionBar();
      if ((localActionBar == null) || (!localActionBar.collapseActionView()))
        bool = false;
    }
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    if ((this.mHasActionBar) && (this.mSubDecorInstalled))
    {
      ActionBar localActionBar = getSupportActionBar();
      if (localActionBar != null)
        localActionBar.onConfigurationChanged(paramConfiguration);
    }
    AppCompatDrawableManager.get().onConfigurationChanged(this.mContext);
    applyDayNight();
  }

  public void onCreate(Bundle paramBundle)
  {
    Object localObject;
    if ((this.mOriginalWindowCallback instanceof Activity))
      localObject = null;
    try
    {
      String str = NavUtils.getParentActivityName((Activity)this.mOriginalWindowCallback);
      localObject = str;
      label27: ActionBar localActionBar;
      if (localObject != null)
      {
        localActionBar = peekSupportActionBar();
        if (localActionBar != null)
          break label73;
        this.mEnableDefaultActionBarUp = true;
      }
      while (true)
      {
        if ((paramBundle != null) && (this.mLocalNightMode == -100))
          this.mLocalNightMode = paramBundle.getInt("appcompat:local_night_mode", -100);
        return;
        label73: localActionBar.setDefaultDisplayHomeAsUpEnabled(true);
      }
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      break label27;
    }
  }

  public final View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet)
  {
    return createView(paramView, paramString, paramContext, paramAttributeSet);
  }

  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet)
  {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }

  public void onDestroy()
  {
    if (this.mInvalidatePanelMenuPosted)
      this.mWindow.getDecorView().removeCallbacks(this.mInvalidatePanelMenuRunnable);
    this.mIsDestroyed = true;
    if (this.mActionBar != null)
      this.mActionBar.onDestroy();
    if (this.mAutoNightModeManager != null)
      this.mAutoNightModeManager.cleanup();
  }

  boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    boolean bool = true;
    switch (paramInt)
    {
    default:
      bool = false;
    case 82:
      while (true)
      {
        return bool;
        onKeyDownPanel(0, paramKeyEvent);
      }
    case 4:
    }
    if ((0x80 & paramKeyEvent.getFlags()) != 0);
    while (true)
    {
      this.mLongPressBackDown = bool;
      break;
      bool = false;
    }
  }

  boolean onKeyShortcut(int paramInt, KeyEvent paramKeyEvent)
  {
    int i = 1;
    ActionBar localActionBar = getSupportActionBar();
    if ((localActionBar != null) && (localActionBar.onKeyShortcut(paramInt, paramKeyEvent)));
    while (true)
    {
      return i;
      if ((this.mPreparedPanel != null) && (performPanelShortcut(this.mPreparedPanel, paramKeyEvent.getKeyCode(), paramKeyEvent, i)))
      {
        if (this.mPreparedPanel != null)
          this.mPreparedPanel.isHandled = i;
      }
      else if (this.mPreparedPanel == null)
      {
        PanelFeatureState localPanelFeatureState = getPanelState(0, i);
        preparePanel(localPanelFeatureState, paramKeyEvent);
        boolean bool = performPanelShortcut(localPanelFeatureState, paramKeyEvent.getKeyCode(), paramKeyEvent, i);
        localPanelFeatureState.isPrepared = false;
        if (bool);
      }
      else
      {
        int j = 0;
      }
    }
  }

  boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent)
  {
    boolean bool1 = true;
    switch (paramInt)
    {
    default:
      bool1 = false;
    case 82:
    case 4:
    }
    while (true)
    {
      return bool1;
      onKeyUpPanel(0, paramKeyEvent);
      continue;
      boolean bool2 = this.mLongPressBackDown;
      this.mLongPressBackDown = false;
      PanelFeatureState localPanelFeatureState = getPanelState(0, false);
      if ((localPanelFeatureState != null) && (localPanelFeatureState.isOpen))
      {
        if (!bool2)
          closePanel(localPanelFeatureState, bool1);
      }
      else
        if (!onBackPressed())
          break;
    }
  }

  public boolean onMenuItemSelected(MenuBuilder paramMenuBuilder, MenuItem paramMenuItem)
  {
    Window.Callback localCallback = getWindowCallback();
    PanelFeatureState localPanelFeatureState;
    if ((localCallback != null) && (!this.mIsDestroyed))
    {
      localPanelFeatureState = findMenuPanel(paramMenuBuilder.getRootMenu());
      if (localPanelFeatureState == null);
    }
    for (boolean bool = localCallback.onMenuItemSelected(localPanelFeatureState.featureId, paramMenuItem); ; bool = false)
      return bool;
  }

  public void onMenuModeChange(MenuBuilder paramMenuBuilder)
  {
    reopenMenu(paramMenuBuilder, true);
  }

  void onMenuOpened(int paramInt)
  {
    if (paramInt == 108)
    {
      ActionBar localActionBar = getSupportActionBar();
      if (localActionBar != null)
        localActionBar.dispatchMenuVisibilityChanged(true);
    }
  }

  void onPanelClosed(int paramInt)
  {
    if (paramInt == 108)
    {
      ActionBar localActionBar = getSupportActionBar();
      if (localActionBar != null)
        localActionBar.dispatchMenuVisibilityChanged(false);
    }
    while (true)
    {
      return;
      if (paramInt == 0)
      {
        PanelFeatureState localPanelFeatureState = getPanelState(paramInt, true);
        if (localPanelFeatureState.isOpen)
          closePanel(localPanelFeatureState, false);
      }
    }
  }

  public void onPostCreate(Bundle paramBundle)
  {
    ensureSubDecor();
  }

  public void onPostResume()
  {
    ActionBar localActionBar = getSupportActionBar();
    if (localActionBar != null)
      localActionBar.setShowHideAnimationEnabled(true);
  }

  public void onSaveInstanceState(Bundle paramBundle)
  {
    if (this.mLocalNightMode != -100)
      paramBundle.putInt("appcompat:local_night_mode", this.mLocalNightMode);
  }

  public void onStart()
  {
    applyDayNight();
  }

  public void onStop()
  {
    ActionBar localActionBar = getSupportActionBar();
    if (localActionBar != null)
      localActionBar.setShowHideAnimationEnabled(false);
    if (this.mAutoNightModeManager != null)
      this.mAutoNightModeManager.cleanup();
  }

  void onSubDecorInstalled(ViewGroup paramViewGroup)
  {
  }

  final ActionBar peekSupportActionBar()
  {
    return this.mActionBar;
  }

  public boolean requestWindowFeature(int paramInt)
  {
    boolean bool = false;
    int i = sanitizeWindowFeatureId(paramInt);
    if ((this.mWindowNoTitle) && (i == 108));
    while (true)
    {
      return bool;
      if ((this.mHasActionBar) && (i == 1))
        this.mHasActionBar = false;
      switch (i)
      {
      default:
        bool = this.mWindow.requestFeature(i);
        break;
      case 108:
        throwFeatureRequestIfSubDecorInstalled();
        this.mHasActionBar = true;
        bool = true;
        break;
      case 109:
        throwFeatureRequestIfSubDecorInstalled();
        this.mOverlayActionBar = true;
        bool = true;
        break;
      case 10:
        throwFeatureRequestIfSubDecorInstalled();
        this.mOverlayActionMode = true;
        bool = true;
        break;
      case 2:
        throwFeatureRequestIfSubDecorInstalled();
        this.mFeatureProgress = true;
        bool = true;
        break;
      case 5:
        throwFeatureRequestIfSubDecorInstalled();
        this.mFeatureIndeterminateProgress = true;
        bool = true;
        break;
      case 1:
        throwFeatureRequestIfSubDecorInstalled();
        this.mWindowNoTitle = true;
        bool = true;
      }
    }
  }

  public void setContentView(int paramInt)
  {
    ensureSubDecor();
    ViewGroup localViewGroup = (ViewGroup)this.mSubDecor.findViewById(16908290);
    localViewGroup.removeAllViews();
    LayoutInflater.from(this.mContext).inflate(paramInt, localViewGroup);
    this.mOriginalWindowCallback.onContentChanged();
  }

  public void setContentView(View paramView)
  {
    ensureSubDecor();
    ViewGroup localViewGroup = (ViewGroup)this.mSubDecor.findViewById(16908290);
    localViewGroup.removeAllViews();
    localViewGroup.addView(paramView);
    this.mOriginalWindowCallback.onContentChanged();
  }

  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams)
  {
    ensureSubDecor();
    ViewGroup localViewGroup = (ViewGroup)this.mSubDecor.findViewById(16908290);
    localViewGroup.removeAllViews();
    localViewGroup.addView(paramView, paramLayoutParams);
    this.mOriginalWindowCallback.onContentChanged();
  }

  public void setHandleNativeActionModesEnabled(boolean paramBoolean)
  {
    this.mHandleNativeActionModes = paramBoolean;
  }

  public void setLocalNightMode(int paramInt)
  {
    switch (paramInt)
    {
    default:
      Log.i("AppCompatDelegate", "setLocalNightMode() called with an unknown mode");
    case -1:
    case 0:
    case 1:
    case 2:
    }
    while (true)
    {
      return;
      if (this.mLocalNightMode != paramInt)
      {
        this.mLocalNightMode = paramInt;
        if (this.mApplyDayNightCalled)
          applyDayNight();
      }
    }
  }

  public void setSupportActionBar(Toolbar paramToolbar)
  {
    if (!(this.mOriginalWindowCallback instanceof Activity))
      return;
    ActionBar localActionBar = getSupportActionBar();
    if ((localActionBar instanceof WindowDecorActionBar))
      throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
    this.mMenuInflater = null;
    if (localActionBar != null)
      localActionBar.onDestroy();
    if (paramToolbar != null)
    {
      ToolbarActionBar localToolbarActionBar = new ToolbarActionBar(paramToolbar, ((Activity)this.mOriginalWindowCallback).getTitle(), this.mAppCompatWindowCallback);
      this.mActionBar = localToolbarActionBar;
      this.mWindow.setCallback(localToolbarActionBar.getWrappedWindowCallback());
    }
    while (true)
    {
      invalidateOptionsMenu();
      break;
      this.mActionBar = null;
      this.mWindow.setCallback(this.mAppCompatWindowCallback);
    }
  }

  public final void setTitle(CharSequence paramCharSequence)
  {
    this.mTitle = paramCharSequence;
    if (this.mDecorContentParent != null)
      this.mDecorContentParent.setWindowTitle(paramCharSequence);
    while (true)
    {
      return;
      if (peekSupportActionBar() != null)
        peekSupportActionBar().setWindowTitle(paramCharSequence);
      else if (this.mTitleView != null)
        this.mTitleView.setText(paramCharSequence);
    }
  }

  final boolean shouldAnimateActionModeView()
  {
    if ((this.mSubDecorInstalled) && (this.mSubDecor != null) && (ViewCompat.isLaidOut(this.mSubDecor)));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public androidx.appcompat.view.ActionMode startSupportActionMode(@NonNull androidx.appcompat.view.ActionMode.Callback paramCallback)
  {
    if (paramCallback == null)
      throw new IllegalArgumentException("ActionMode callback can not be null.");
    if (this.mActionMode != null)
      this.mActionMode.finish();
    ActionModeCallbackWrapperV9 localActionModeCallbackWrapperV9 = new ActionModeCallbackWrapperV9(paramCallback);
    ActionBar localActionBar = getSupportActionBar();
    if (localActionBar != null)
    {
      this.mActionMode = localActionBar.startActionMode(localActionModeCallbackWrapperV9);
      if ((this.mActionMode != null) && (this.mAppCompatCallback != null))
        this.mAppCompatCallback.onSupportActionModeStarted(this.mActionMode);
    }
    if (this.mActionMode == null)
      this.mActionMode = startSupportActionModeFromWindow(localActionModeCallbackWrapperV9);
    return this.mActionMode;
  }

  androidx.appcompat.view.ActionMode startSupportActionModeFromWindow(@NonNull androidx.appcompat.view.ActionMode.Callback paramCallback)
  {
    endOnGoingFadeAnimation();
    if (this.mActionMode != null)
      this.mActionMode.finish();
    if (!(paramCallback instanceof ActionModeCallbackWrapperV9))
      paramCallback = new ActionModeCallbackWrapperV9(paramCallback);
    Object localObject1 = null;
    if ((this.mAppCompatCallback != null) && (!this.mIsDestroyed));
    try
    {
      androidx.appcompat.view.ActionMode localActionMode = this.mAppCompatCallback.onWindowStartingSupportActionMode(paramCallback);
      localObject1 = localActionMode;
      label66: if (localObject1 != null)
        this.mActionMode = localObject1;
      while (true)
      {
        if ((this.mActionMode != null) && (this.mAppCompatCallback != null))
          this.mAppCompatCallback.onSupportActionModeStarted(this.mActionMode);
        return this.mActionMode;
        Object localObject2;
        label213: boolean bool;
        if (this.mActionModeView == null)
        {
          if (!this.mIsFloating)
            break label506;
          TypedValue localTypedValue = new TypedValue();
          Resources.Theme localTheme1 = this.mContext.getTheme();
          localTheme1.resolveAttribute(R.attr.actionBarTheme, localTypedValue, true);
          if (localTypedValue.resourceId != 0)
          {
            Resources.Theme localTheme2 = this.mContext.getResources().newTheme();
            localTheme2.setTo(localTheme1);
            localTheme2.applyStyle(localTypedValue.resourceId, true);
            localObject2 = new ContextThemeWrapper(this.mContext, 0);
            ((Context)localObject2).getTheme().setTo(localTheme2);
            this.mActionModeView = new ActionBarContextView((Context)localObject2);
            this.mActionModePopup = new PopupWindow((Context)localObject2, null, R.attr.actionModePopupWindowStyle);
            PopupWindowCompat.setWindowLayoutType(this.mActionModePopup, 2);
            this.mActionModePopup.setContentView(this.mActionModeView);
            this.mActionModePopup.setWidth(-1);
            ((Context)localObject2).getTheme().resolveAttribute(R.attr.actionBarSize, localTypedValue, true);
            int i = TypedValue.complexToDimensionPixelSize(localTypedValue.data, ((Context)localObject2).getResources().getDisplayMetrics());
            this.mActionModeView.setContentHeight(i);
            this.mActionModePopup.setHeight(-2);
            this.mShowActionModePopup = new Runnable()
            {
              public void run()
              {
                AppCompatDelegateImpl.this.mActionModePopup.showAtLocation(AppCompatDelegateImpl.this.mActionModeView, 55, 0, 0);
                AppCompatDelegateImpl.this.endOnGoingFadeAnimation();
                if (AppCompatDelegateImpl.this.shouldAnimateActionModeView())
                {
                  AppCompatDelegateImpl.this.mActionModeView.setAlpha(0.0F);
                  AppCompatDelegateImpl.this.mFadeAnim = ViewCompat.animate(AppCompatDelegateImpl.this.mActionModeView).alpha(1.0F);
                  AppCompatDelegateImpl.this.mFadeAnim.setListener(new ViewPropertyAnimatorListenerAdapter()
                  {
                    public void onAnimationEnd(View paramAnonymous2View)
                    {
                      AppCompatDelegateImpl.this.mActionModeView.setAlpha(1.0F);
                      AppCompatDelegateImpl.this.mFadeAnim.setListener(null);
                      AppCompatDelegateImpl.this.mFadeAnim = null;
                    }

                    public void onAnimationStart(View paramAnonymous2View)
                    {
                      AppCompatDelegateImpl.this.mActionModeView.setVisibility(0);
                    }
                  });
                }
                while (true)
                {
                  return;
                  AppCompatDelegateImpl.this.mActionModeView.setAlpha(1.0F);
                  AppCompatDelegateImpl.this.mActionModeView.setVisibility(0);
                }
              }
            };
          }
        }
        else
        {
          label333: if (this.mActionModeView == null)
            break label551;
          endOnGoingFadeAnimation();
          this.mActionModeView.killMode();
          Context localContext = this.mActionModeView.getContext();
          ActionBarContextView localActionBarContextView = this.mActionModeView;
          if (this.mActionModePopup != null)
            break label553;
          bool = true;
          label375: StandaloneActionMode localStandaloneActionMode = new StandaloneActionMode(localContext, localActionBarContextView, paramCallback, bool);
          if (!paramCallback.onCreateActionMode(localStandaloneActionMode, localStandaloneActionMode.getMenu()))
            break label613;
          localStandaloneActionMode.invalidate();
          this.mActionModeView.initForMode(localStandaloneActionMode);
          this.mActionMode = localStandaloneActionMode;
          if (!shouldAnimateActionModeView())
            break label559;
          this.mActionModeView.setAlpha(0.0F);
          this.mFadeAnim = ViewCompat.animate(this.mActionModeView).alpha(1.0F);
          this.mFadeAnim.setListener(new ViewPropertyAnimatorListenerAdapter()
          {
            public void onAnimationEnd(View paramAnonymousView)
            {
              AppCompatDelegateImpl.this.mActionModeView.setAlpha(1.0F);
              AppCompatDelegateImpl.this.mFadeAnim.setListener(null);
              AppCompatDelegateImpl.this.mFadeAnim = null;
            }

            public void onAnimationStart(View paramAnonymousView)
            {
              AppCompatDelegateImpl.this.mActionModeView.setVisibility(0);
              AppCompatDelegateImpl.this.mActionModeView.sendAccessibilityEvent(32);
              if ((AppCompatDelegateImpl.this.mActionModeView.getParent() instanceof View))
                ViewCompat.requestApplyInsets((View)AppCompatDelegateImpl.this.mActionModeView.getParent());
            }
          });
        }
        while (true)
        {
          if (this.mActionModePopup == null)
            break label611;
          this.mWindow.getDecorView().post(this.mShowActionModePopup);
          break;
          localObject2 = this.mContext;
          break label213;
          label506: ViewStubCompat localViewStubCompat = (ViewStubCompat)this.mSubDecor.findViewById(R.id.action_mode_bar_stub);
          if (localViewStubCompat == null)
            break label333;
          localViewStubCompat.setLayoutInflater(LayoutInflater.from(getActionBarThemedContext()));
          this.mActionModeView = ((ActionBarContextView)localViewStubCompat.inflate());
          break label333;
          label551: break;
          label553: bool = false;
          break label375;
          label559: this.mActionModeView.setAlpha(1.0F);
          this.mActionModeView.setVisibility(0);
          this.mActionModeView.sendAccessibilityEvent(32);
          if ((this.mActionModeView.getParent() instanceof View))
            ViewCompat.requestApplyInsets((View)this.mActionModeView.getParent());
        }
        label611: continue;
        label613: this.mActionMode = null;
      }
    }
    catch (AbstractMethodError localAbstractMethodError)
    {
      break label66;
    }
  }

  int updateStatusGuard(int paramInt)
  {
    int i = 0;
    int j = 0;
    ViewGroup.MarginLayoutParams localMarginLayoutParams;
    int k;
    int m;
    if ((this.mActionModeView != null) && ((this.mActionModeView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)))
    {
      localMarginLayoutParams = (ViewGroup.MarginLayoutParams)this.mActionModeView.getLayoutParams();
      k = 0;
      if (!this.mActionModeView.isShown())
        break label311;
      if (this.mTempRect1 == null)
      {
        this.mTempRect1 = new Rect();
        this.mTempRect2 = new Rect();
      }
      Rect localRect1 = this.mTempRect1;
      Rect localRect2 = this.mTempRect2;
      localRect1.set(0, paramInt, 0, 0);
      ViewUtils.computeFitSystemWindows(this.mSubDecor, localRect1, localRect2);
      if (localRect2.top != 0)
        break label264;
      m = paramInt;
      if (localMarginLayoutParams.topMargin != m)
      {
        k = 1;
        localMarginLayoutParams.topMargin = paramInt;
        if (this.mStatusGuard != null)
          break label270;
        this.mStatusGuard = new View(this.mContext);
        this.mStatusGuard.setBackgroundColor(this.mContext.getResources().getColor(R.color.abc_input_method_navigation_guard));
        this.mSubDecor.addView(this.mStatusGuard, -1, new ViewGroup.LayoutParams(-1, paramInt));
      }
      label203: if (this.mStatusGuard == null)
        break label306;
      j = 1;
      label212: if ((!this.mOverlayActionMode) && (j != 0))
        paramInt = 0;
      label225: if (k != 0)
        this.mActionModeView.setLayoutParams(localMarginLayoutParams);
    }
    View localView;
    if (this.mStatusGuard != null)
    {
      localView = this.mStatusGuard;
      if (j == 0)
        break label331;
    }
    while (true)
    {
      localView.setVisibility(i);
      return paramInt;
      label264: m = 0;
      break;
      label270: ViewGroup.LayoutParams localLayoutParams = this.mStatusGuard.getLayoutParams();
      if (localLayoutParams.height == paramInt)
        break label203;
      localLayoutParams.height = paramInt;
      this.mStatusGuard.setLayoutParams(localLayoutParams);
      break label203;
      label306: j = 0;
      break label212;
      label311: if (localMarginLayoutParams.topMargin == 0)
        break label225;
      k = 1;
      localMarginLayoutParams.topMargin = 0;
      break label225;
      label331: i = 8;
    }
  }

  private class ActionBarDrawableToggleImpl
    implements ActionBarDrawerToggle.Delegate
  {
    ActionBarDrawableToggleImpl()
    {
    }

    public Context getActionBarThemedContext()
    {
      return AppCompatDelegateImpl.this.getActionBarThemedContext();
    }

    public Drawable getThemeUpIndicator()
    {
      Context localContext = getActionBarThemedContext();
      int[] arrayOfInt = new int[1];
      arrayOfInt[0] = R.attr.homeAsUpIndicator;
      TintTypedArray localTintTypedArray = TintTypedArray.obtainStyledAttributes(localContext, null, arrayOfInt);
      Drawable localDrawable = localTintTypedArray.getDrawable(0);
      localTintTypedArray.recycle();
      return localDrawable;
    }

    public boolean isNavigationVisible()
    {
      ActionBar localActionBar = AppCompatDelegateImpl.this.getSupportActionBar();
      if ((localActionBar != null) && ((0x4 & localActionBar.getDisplayOptions()) != 0));
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    public void setActionBarDescription(int paramInt)
    {
      ActionBar localActionBar = AppCompatDelegateImpl.this.getSupportActionBar();
      if (localActionBar != null)
        localActionBar.setHomeActionContentDescription(paramInt);
    }

    public void setActionBarUpIndicator(Drawable paramDrawable, int paramInt)
    {
      ActionBar localActionBar = AppCompatDelegateImpl.this.getSupportActionBar();
      if (localActionBar != null)
      {
        localActionBar.setHomeAsUpIndicator(paramDrawable);
        localActionBar.setHomeActionContentDescription(paramInt);
      }
    }
  }

  private final class ActionMenuPresenterCallback
    implements MenuPresenter.Callback
  {
    ActionMenuPresenterCallback()
    {
    }

    public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean)
    {
      AppCompatDelegateImpl.this.checkCloseActionMenu(paramMenuBuilder);
    }

    public boolean onOpenSubMenu(MenuBuilder paramMenuBuilder)
    {
      Window.Callback localCallback = AppCompatDelegateImpl.this.getWindowCallback();
      if (localCallback != null)
        localCallback.onMenuOpened(108, paramMenuBuilder);
      return true;
    }
  }

  class ActionModeCallbackWrapperV9
    implements androidx.appcompat.view.ActionMode.Callback
  {
    private androidx.appcompat.view.ActionMode.Callback mWrapped;

    public ActionModeCallbackWrapperV9(androidx.appcompat.view.ActionMode.Callback arg2)
    {
      Object localObject;
      this.mWrapped = localObject;
    }

    public boolean onActionItemClicked(androidx.appcompat.view.ActionMode paramActionMode, MenuItem paramMenuItem)
    {
      return this.mWrapped.onActionItemClicked(paramActionMode, paramMenuItem);
    }

    public boolean onCreateActionMode(androidx.appcompat.view.ActionMode paramActionMode, Menu paramMenu)
    {
      return this.mWrapped.onCreateActionMode(paramActionMode, paramMenu);
    }

    public void onDestroyActionMode(androidx.appcompat.view.ActionMode paramActionMode)
    {
      this.mWrapped.onDestroyActionMode(paramActionMode);
      if (AppCompatDelegateImpl.this.mActionModePopup != null)
        AppCompatDelegateImpl.this.mWindow.getDecorView().removeCallbacks(AppCompatDelegateImpl.this.mShowActionModePopup);
      if (AppCompatDelegateImpl.this.mActionModeView != null)
      {
        AppCompatDelegateImpl.this.endOnGoingFadeAnimation();
        AppCompatDelegateImpl.this.mFadeAnim = ViewCompat.animate(AppCompatDelegateImpl.this.mActionModeView).alpha(0.0F);
        AppCompatDelegateImpl.this.mFadeAnim.setListener(new ViewPropertyAnimatorListenerAdapter()
        {
          public void onAnimationEnd(View paramAnonymousView)
          {
            AppCompatDelegateImpl.this.mActionModeView.setVisibility(8);
            if (AppCompatDelegateImpl.this.mActionModePopup != null)
              AppCompatDelegateImpl.this.mActionModePopup.dismiss();
            while (true)
            {
              AppCompatDelegateImpl.this.mActionModeView.removeAllViews();
              AppCompatDelegateImpl.this.mFadeAnim.setListener(null);
              AppCompatDelegateImpl.this.mFadeAnim = null;
              return;
              if ((AppCompatDelegateImpl.this.mActionModeView.getParent() instanceof View))
                ViewCompat.requestApplyInsets((View)AppCompatDelegateImpl.this.mActionModeView.getParent());
            }
          }
        });
      }
      if (AppCompatDelegateImpl.this.mAppCompatCallback != null)
        AppCompatDelegateImpl.this.mAppCompatCallback.onSupportActionModeFinished(AppCompatDelegateImpl.this.mActionMode);
      AppCompatDelegateImpl.this.mActionMode = null;
    }

    public boolean onPrepareActionMode(androidx.appcompat.view.ActionMode paramActionMode, Menu paramMenu)
    {
      return this.mWrapped.onPrepareActionMode(paramActionMode, paramMenu);
    }
  }

  class AppCompatWindowCallback extends WindowCallbackWrapper
  {
    AppCompatWindowCallback(Window.Callback arg2)
    {
      super();
    }

    public boolean dispatchKeyEvent(KeyEvent paramKeyEvent)
    {
      if ((AppCompatDelegateImpl.this.dispatchKeyEvent(paramKeyEvent)) || (super.dispatchKeyEvent(paramKeyEvent)));
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent)
    {
      if ((super.dispatchKeyShortcutEvent(paramKeyEvent)) || (AppCompatDelegateImpl.this.onKeyShortcut(paramKeyEvent.getKeyCode(), paramKeyEvent)));
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    public void onContentChanged()
    {
    }

    public boolean onCreatePanelMenu(int paramInt, Menu paramMenu)
    {
      if ((paramInt == 0) && (!(paramMenu instanceof MenuBuilder)));
      for (boolean bool = false; ; bool = super.onCreatePanelMenu(paramInt, paramMenu))
        return bool;
    }

    public boolean onMenuOpened(int paramInt, Menu paramMenu)
    {
      super.onMenuOpened(paramInt, paramMenu);
      AppCompatDelegateImpl.this.onMenuOpened(paramInt);
      return true;
    }

    public void onPanelClosed(int paramInt, Menu paramMenu)
    {
      super.onPanelClosed(paramInt, paramMenu);
      AppCompatDelegateImpl.this.onPanelClosed(paramInt);
    }

    public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu)
    {
      MenuBuilder localMenuBuilder;
      boolean bool;
      if ((paramMenu instanceof MenuBuilder))
      {
        localMenuBuilder = (MenuBuilder)paramMenu;
        if ((paramInt != 0) || (localMenuBuilder != null))
          break label34;
        bool = false;
      }
      while (true)
      {
        return bool;
        localMenuBuilder = null;
        break;
        label34: if (localMenuBuilder != null)
          localMenuBuilder.setOverrideVisibleItems(true);
        bool = super.onPreparePanel(paramInt, paramView, paramMenu);
        if (localMenuBuilder != null)
          localMenuBuilder.setOverrideVisibleItems(false);
      }
    }

    @RequiresApi(24)
    public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> paramList, Menu paramMenu, int paramInt)
    {
      AppCompatDelegateImpl.PanelFeatureState localPanelFeatureState = AppCompatDelegateImpl.this.getPanelState(0, true);
      if ((localPanelFeatureState != null) && (localPanelFeatureState.menu != null))
        super.onProvideKeyboardShortcuts(paramList, localPanelFeatureState.menu, paramInt);
      while (true)
      {
        return;
        super.onProvideKeyboardShortcuts(paramList, paramMenu, paramInt);
      }
    }

    public android.view.ActionMode onWindowStartingActionMode(android.view.ActionMode.Callback paramCallback)
    {
      android.view.ActionMode localActionMode;
      if (Build.VERSION.SDK_INT >= 23)
        localActionMode = null;
      while (true)
      {
        return localActionMode;
        if (AppCompatDelegateImpl.this.isHandleNativeActionModesEnabled())
          localActionMode = startAsSupportActionMode(paramCallback);
        else
          localActionMode = super.onWindowStartingActionMode(paramCallback);
      }
    }

    @RequiresApi(23)
    public android.view.ActionMode onWindowStartingActionMode(android.view.ActionMode.Callback paramCallback, int paramInt)
    {
      if (AppCompatDelegateImpl.this.isHandleNativeActionModesEnabled())
        switch (paramInt)
        {
        default:
        case 0:
        }
      for (android.view.ActionMode localActionMode = super.onWindowStartingActionMode(paramCallback, paramInt); ; localActionMode = startAsSupportActionMode(paramCallback))
        return localActionMode;
    }

    final android.view.ActionMode startAsSupportActionMode(android.view.ActionMode.Callback paramCallback)
    {
      SupportActionModeWrapper.CallbackWrapper localCallbackWrapper = new SupportActionModeWrapper.CallbackWrapper(AppCompatDelegateImpl.this.mContext, paramCallback);
      androidx.appcompat.view.ActionMode localActionMode = AppCompatDelegateImpl.this.startSupportActionMode(localCallbackWrapper);
      if (localActionMode != null);
      for (android.view.ActionMode localActionMode1 = localCallbackWrapper.getActionModeWrapper(localActionMode); ; localActionMode1 = null)
        return localActionMode1;
    }
  }

  @VisibleForTesting
  final class AutoNightModeManager
  {
    private BroadcastReceiver mAutoTimeChangeReceiver;
    private IntentFilter mAutoTimeChangeReceiverFilter;
    private boolean mIsNight;
    private TwilightManager mTwilightManager;

    AutoNightModeManager(TwilightManager arg2)
    {
      Object localObject;
      this.mTwilightManager = localObject;
      this.mIsNight = localObject.isNight();
    }

    void cleanup()
    {
      if (this.mAutoTimeChangeReceiver != null)
      {
        AppCompatDelegateImpl.this.mContext.unregisterReceiver(this.mAutoTimeChangeReceiver);
        this.mAutoTimeChangeReceiver = null;
      }
    }

    void dispatchTimeChanged()
    {
      boolean bool = this.mTwilightManager.isNight();
      if (bool != this.mIsNight)
      {
        this.mIsNight = bool;
        AppCompatDelegateImpl.this.applyDayNight();
      }
    }

    int getApplyableNightMode()
    {
      this.mIsNight = this.mTwilightManager.isNight();
      if (this.mIsNight);
      for (int i = 2; ; i = 1)
        return i;
    }

    void setup()
    {
      cleanup();
      if (this.mAutoTimeChangeReceiver == null)
        this.mAutoTimeChangeReceiver = new BroadcastReceiver()
        {
          public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
          {
            AppCompatDelegateImpl.AutoNightModeManager.this.dispatchTimeChanged();
          }
        };
      if (this.mAutoTimeChangeReceiverFilter == null)
      {
        this.mAutoTimeChangeReceiverFilter = new IntentFilter();
        this.mAutoTimeChangeReceiverFilter.addAction("android.intent.action.TIME_SET");
        this.mAutoTimeChangeReceiverFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
        this.mAutoTimeChangeReceiverFilter.addAction("android.intent.action.TIME_TICK");
      }
      AppCompatDelegateImpl.this.mContext.registerReceiver(this.mAutoTimeChangeReceiver, this.mAutoTimeChangeReceiverFilter);
    }
  }

  private class ListMenuDecorView extends ContentFrameLayout
  {
    public ListMenuDecorView(Context arg2)
    {
      super();
    }

    private boolean isOutOfBounds(int paramInt1, int paramInt2)
    {
      if ((paramInt1 < -5) || (paramInt2 < -5) || (paramInt1 > 5 + getWidth()) || (paramInt2 > 5 + getHeight()));
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    public boolean dispatchKeyEvent(KeyEvent paramKeyEvent)
    {
      if ((AppCompatDelegateImpl.this.dispatchKeyEvent(paramKeyEvent)) || (super.dispatchKeyEvent(paramKeyEvent)));
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent)
    {
      if ((paramMotionEvent.getAction() == 0) && (isOutOfBounds((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY())))
        AppCompatDelegateImpl.this.closePanel(0);
      for (boolean bool = true; ; bool = super.onInterceptTouchEvent(paramMotionEvent))
        return bool;
    }

    public void setBackgroundResource(int paramInt)
    {
      setBackgroundDrawable(AppCompatResources.getDrawable(getContext(), paramInt));
    }
  }

  protected static final class PanelFeatureState
  {
    int background;
    View createdPanelView;
    ViewGroup decorView;
    int featureId;
    Bundle frozenActionViewState;
    Bundle frozenMenuState;
    int gravity;
    boolean isHandled;
    boolean isOpen;
    boolean isPrepared;
    ListMenuPresenter listMenuPresenter;
    Context listPresenterContext;
    MenuBuilder menu;
    public boolean qwertyMode;
    boolean refreshDecorView;
    boolean refreshMenuContent;
    View shownPanelView;
    boolean wasLastOpen;
    int windowAnimations;
    int x;
    int y;

    PanelFeatureState(int paramInt)
    {
      this.featureId = paramInt;
      this.refreshDecorView = false;
    }

    void applyFrozenState()
    {
      if ((this.menu != null) && (this.frozenMenuState != null))
      {
        this.menu.restorePresenterStates(this.frozenMenuState);
        this.frozenMenuState = null;
      }
    }

    public void clearMenuPresenters()
    {
      if (this.menu != null)
        this.menu.removeMenuPresenter(this.listMenuPresenter);
      this.listMenuPresenter = null;
    }

    MenuView getListMenuView(MenuPresenter.Callback paramCallback)
    {
      if (this.menu == null);
      for (MenuView localMenuView = null; ; localMenuView = this.listMenuPresenter.getMenuView(this.decorView))
      {
        return localMenuView;
        if (this.listMenuPresenter == null)
        {
          this.listMenuPresenter = new ListMenuPresenter(this.listPresenterContext, R.layout.abc_list_menu_item_layout);
          this.listMenuPresenter.setCallback(paramCallback);
          this.menu.addMenuPresenter(this.listMenuPresenter);
        }
      }
    }

    public boolean hasPanelItems()
    {
      boolean bool = true;
      if (this.shownPanelView == null);
      for (bool = false; ; bool = false)
        do
          return bool;
        while ((this.createdPanelView != null) || (this.listMenuPresenter.getAdapter().getCount() > 0));
    }

    void onRestoreInstanceState(Parcelable paramParcelable)
    {
      SavedState localSavedState = (SavedState)paramParcelable;
      this.featureId = localSavedState.featureId;
      this.wasLastOpen = localSavedState.isOpen;
      this.frozenMenuState = localSavedState.menuState;
      this.shownPanelView = null;
      this.decorView = null;
    }

    Parcelable onSaveInstanceState()
    {
      SavedState localSavedState = new SavedState();
      localSavedState.featureId = this.featureId;
      localSavedState.isOpen = this.isOpen;
      if (this.menu != null)
      {
        localSavedState.menuState = new Bundle();
        this.menu.savePresenterStates(localSavedState.menuState);
      }
      return localSavedState;
    }

    void setMenu(MenuBuilder paramMenuBuilder)
    {
      if (paramMenuBuilder == this.menu);
      while (true)
      {
        return;
        if (this.menu != null)
          this.menu.removeMenuPresenter(this.listMenuPresenter);
        this.menu = paramMenuBuilder;
        if ((paramMenuBuilder != null) && (this.listMenuPresenter != null))
          paramMenuBuilder.addMenuPresenter(this.listMenuPresenter);
      }
    }

    void setStyle(Context paramContext)
    {
      TypedValue localTypedValue = new TypedValue();
      Resources.Theme localTheme = paramContext.getResources().newTheme();
      localTheme.setTo(paramContext.getTheme());
      localTheme.resolveAttribute(R.attr.actionBarPopupTheme, localTypedValue, true);
      if (localTypedValue.resourceId != 0)
        localTheme.applyStyle(localTypedValue.resourceId, true);
      localTheme.resolveAttribute(R.attr.panelMenuListTheme, localTypedValue, true);
      if (localTypedValue.resourceId != 0)
        localTheme.applyStyle(localTypedValue.resourceId, true);
      while (true)
      {
        ContextThemeWrapper localContextThemeWrapper = new ContextThemeWrapper(paramContext, 0);
        localContextThemeWrapper.getTheme().setTo(localTheme);
        this.listPresenterContext = localContextThemeWrapper;
        TypedArray localTypedArray = localContextThemeWrapper.obtainStyledAttributes(R.styleable.AppCompatTheme);
        this.background = localTypedArray.getResourceId(R.styleable.AppCompatTheme_panelBackground, 0);
        this.windowAnimations = localTypedArray.getResourceId(R.styleable.AppCompatTheme_android_windowAnimationStyle, 0);
        localTypedArray.recycle();
        return;
        localTheme.applyStyle(R.style.Theme_AppCompat_CompactMenu, true);
      }
    }

    private static class SavedState
      implements Parcelable
    {
      public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.ClassLoaderCreator()
      {
        public AppCompatDelegateImpl.PanelFeatureState.SavedState createFromParcel(Parcel paramAnonymousParcel)
        {
          return AppCompatDelegateImpl.PanelFeatureState.SavedState.readFromParcel(paramAnonymousParcel, null);
        }

        public AppCompatDelegateImpl.PanelFeatureState.SavedState createFromParcel(Parcel paramAnonymousParcel, ClassLoader paramAnonymousClassLoader)
        {
          return AppCompatDelegateImpl.PanelFeatureState.SavedState.readFromParcel(paramAnonymousParcel, paramAnonymousClassLoader);
        }

        public AppCompatDelegateImpl.PanelFeatureState.SavedState[] newArray(int paramAnonymousInt)
        {
          return new AppCompatDelegateImpl.PanelFeatureState.SavedState[paramAnonymousInt];
        }
      };
      int featureId;
      boolean isOpen;
      Bundle menuState;

      static SavedState readFromParcel(Parcel paramParcel, ClassLoader paramClassLoader)
      {
        int i = 1;
        SavedState localSavedState = new SavedState();
        localSavedState.featureId = paramParcel.readInt();
        if (paramParcel.readInt() == i);
        while (true)
        {
          localSavedState.isOpen = i;
          if (localSavedState.isOpen)
            localSavedState.menuState = paramParcel.readBundle(paramClassLoader);
          return localSavedState;
          i = 0;
        }
      }

      public int describeContents()
      {
        return 0;
      }

      public void writeToParcel(Parcel paramParcel, int paramInt)
      {
        paramParcel.writeInt(this.featureId);
        if (this.isOpen);
        for (int i = 1; ; i = 0)
        {
          paramParcel.writeInt(i);
          if (this.isOpen)
            paramParcel.writeBundle(this.menuState);
          return;
        }
      }
    }
  }

  private final class PanelMenuPresenterCallback
    implements MenuPresenter.Callback
  {
    PanelMenuPresenterCallback()
    {
    }

    public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean)
    {
      MenuBuilder localMenuBuilder = paramMenuBuilder.getRootMenu();
      int i;
      AppCompatDelegateImpl.PanelFeatureState localPanelFeatureState;
      if (localMenuBuilder != paramMenuBuilder)
      {
        i = 1;
        AppCompatDelegateImpl localAppCompatDelegateImpl = AppCompatDelegateImpl.this;
        if (i != 0)
          paramMenuBuilder = localMenuBuilder;
        localPanelFeatureState = localAppCompatDelegateImpl.findMenuPanel(paramMenuBuilder);
        if (localPanelFeatureState != null)
        {
          if (i == 0)
            break label76;
          AppCompatDelegateImpl.this.callOnPanelClosed(localPanelFeatureState.featureId, localPanelFeatureState, localMenuBuilder);
          AppCompatDelegateImpl.this.closePanel(localPanelFeatureState, true);
        }
      }
      while (true)
      {
        return;
        i = 0;
        break;
        label76: AppCompatDelegateImpl.this.closePanel(localPanelFeatureState, paramBoolean);
      }
    }

    public boolean onOpenSubMenu(MenuBuilder paramMenuBuilder)
    {
      if ((paramMenuBuilder == null) && (AppCompatDelegateImpl.this.mHasActionBar))
      {
        Window.Callback localCallback = AppCompatDelegateImpl.this.getWindowCallback();
        if ((localCallback != null) && (!AppCompatDelegateImpl.this.mIsDestroyed))
          localCallback.onMenuOpened(108, paramMenuBuilder);
      }
      return true;
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.app.AppCompatDelegateImpl
 * JD-Core Version:    0.6.2
 */