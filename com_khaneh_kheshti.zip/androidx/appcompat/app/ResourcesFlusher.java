package androidx.appcompat.app;

import android.content.res.Resources;
import android.os.Build.VERSION;
import android.util.Log;
import android.util.LongSparseArray;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import java.lang.reflect.Field;
import java.util.Map;

class ResourcesFlusher
{
  private static final String TAG = "ResourcesFlusher";
  private static Field sDrawableCacheField;
  private static boolean sDrawableCacheFieldFetched;
  private static Field sResourcesImplField;
  private static boolean sResourcesImplFieldFetched;
  private static Class sThemedResourceCacheClazz;
  private static boolean sThemedResourceCacheClazzFetched;
  private static Field sThemedResourceCache_mUnthemedEntriesField;
  private static boolean sThemedResourceCache_mUnthemedEntriesFieldFetched;

  static void flush(@NonNull Resources paramResources)
  {
    if (Build.VERSION.SDK_INT >= 28);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 24)
        flushNougats(paramResources);
      else if (Build.VERSION.SDK_INT >= 23)
        flushMarshmallows(paramResources);
      else if (Build.VERSION.SDK_INT >= 21)
        flushLollipops(paramResources);
    }
  }

  @RequiresApi(21)
  private static void flushLollipops(@NonNull Resources paramResources)
  {
    if (!sDrawableCacheFieldFetched);
    try
    {
      sDrawableCacheField = Resources.class.getDeclaredField("mDrawableCache");
      sDrawableCacheField.setAccessible(true);
      sDrawableCacheFieldFetched = true;
      if (sDrawableCacheField != null)
        localMap = null;
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      try
      {
        Map localMap = (Map)sDrawableCacheField.get(paramResources);
        if (localMap != null)
          localMap.clear();
        return;
        localNoSuchFieldException = localNoSuchFieldException;
        Log.e("ResourcesFlusher", "Could not retrieve Resources#mDrawableCache field", localNoSuchFieldException);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        while (true)
          Log.e("ResourcesFlusher", "Could not retrieve value from Resources#mDrawableCache", localIllegalAccessException);
      }
    }
  }

  @RequiresApi(23)
  private static void flushMarshmallows(@NonNull Resources paramResources)
  {
    if (!sDrawableCacheFieldFetched);
    try
    {
      sDrawableCacheField = Resources.class.getDeclaredField("mDrawableCache");
      sDrawableCacheField.setAccessible(true);
      sDrawableCacheFieldFetched = true;
      localObject1 = null;
      if (sDrawableCacheField == null);
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      try
      {
        Object localObject2 = sDrawableCacheField.get(paramResources);
        localObject1 = localObject2;
        if (localObject1 == null)
        {
          return;
          localNoSuchFieldException = localNoSuchFieldException;
          Log.e("ResourcesFlusher", "Could not retrieve Resources#mDrawableCache field", localNoSuchFieldException);
        }
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        while (true)
        {
          Object localObject1;
          Log.e("ResourcesFlusher", "Could not retrieve value from Resources#mDrawableCache", localIllegalAccessException);
          continue;
          flushThemedResourcesCache(localObject1);
        }
      }
    }
  }

  @RequiresApi(24)
  private static void flushNougats(@NonNull Resources paramResources)
  {
    if (!sResourcesImplFieldFetched);
    while (true)
    {
      Object localObject1;
      try
      {
        sResourcesImplField = Resources.class.getDeclaredField("mResourcesImpl");
        sResourcesImplField.setAccessible(true);
        sResourcesImplFieldFetched = true;
        if (sResourcesImplField == null)
          return;
      }
      catch (NoSuchFieldException localNoSuchFieldException2)
      {
        Log.e("ResourcesFlusher", "Could not retrieve Resources#mResourcesImpl field", localNoSuchFieldException2);
        continue;
        localObject1 = null;
      }
      try
      {
        Object localObject4 = sResourcesImplField.get(paramResources);
        localObject1 = localObject4;
        if (localObject1 == null)
          continue;
        if (sDrawableCacheFieldFetched);
      }
      catch (IllegalAccessException localNoSuchFieldException1)
      {
        try
        {
          sDrawableCacheField = localObject1.getClass().getDeclaredField("mDrawableCache");
          sDrawableCacheField.setAccessible(true);
          sDrawableCacheFieldFetched = true;
          localObject2 = null;
          if (sDrawableCacheField == null);
        }
        catch (NoSuchFieldException localNoSuchFieldException1)
        {
          try
          {
            while (true)
            {
              Object localObject3 = sDrawableCacheField.get(localObject1);
              Object localObject2 = localObject3;
              if (localObject2 == null)
                break;
              flushThemedResourcesCache(localObject2);
              break;
              localIllegalAccessException1 = localIllegalAccessException1;
              Log.e("ResourcesFlusher", "Could not retrieve value from Resources#mResourcesImpl", localIllegalAccessException1);
            }
            localNoSuchFieldException1 = localNoSuchFieldException1;
            Log.e("ResourcesFlusher", "Could not retrieve ResourcesImpl#mDrawableCache field", localNoSuchFieldException1);
          }
          catch (IllegalAccessException localIllegalAccessException2)
          {
            while (true)
              Log.e("ResourcesFlusher", "Could not retrieve value from ResourcesImpl#mDrawableCache", localIllegalAccessException2);
          }
        }
      }
    }
  }

  @RequiresApi(16)
  private static void flushThemedResourcesCache(@NonNull Object paramObject)
  {
    if (!sThemedResourceCacheClazzFetched);
    while (true)
    {
      try
      {
        sThemedResourceCacheClazz = Class.forName("android.content.res.ThemedResourceCache");
        sThemedResourceCacheClazzFetched = true;
        if (sThemedResourceCacheClazz == null)
          return;
      }
      catch (ClassNotFoundException localClassNotFoundException)
      {
        Log.e("ResourcesFlusher", "Could not find ThemedResourceCache class", localClassNotFoundException);
        continue;
      }
      if (!sThemedResourceCache_mUnthemedEntriesFieldFetched);
      try
      {
        sThemedResourceCache_mUnthemedEntriesField = sThemedResourceCacheClazz.getDeclaredField("mUnthemedEntries");
        sThemedResourceCache_mUnthemedEntriesField.setAccessible(true);
        sThemedResourceCache_mUnthemedEntriesFieldFetched = true;
        if (sThemedResourceCache_mUnthemedEntriesField == null)
          continue;
        localLongSparseArray = null;
      }
      catch (NoSuchFieldException localNoSuchFieldException)
      {
        try
        {
          LongSparseArray localLongSparseArray = (LongSparseArray)sThemedResourceCache_mUnthemedEntriesField.get(paramObject);
          if (localLongSparseArray == null)
            continue;
          localLongSparseArray.clear();
          continue;
          localNoSuchFieldException = localNoSuchFieldException;
          Log.e("ResourcesFlusher", "Could not retrieve ThemedResourceCache#mUnthemedEntries field", localNoSuchFieldException);
        }
        catch (IllegalAccessException localIllegalAccessException)
        {
          while (true)
            Log.e("ResourcesFlusher", "Could not retrieve value from ThemedResourceCache#mUnthemedEntries", localIllegalAccessException);
        }
      }
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.app.ResourcesFlusher
 * JD-Core Version:    0.6.2
 */