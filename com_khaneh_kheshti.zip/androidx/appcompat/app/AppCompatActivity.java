package androidx.appcompat.app;

import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import androidx.annotation.CallSuper;
import androidx.annotation.IdRes;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StyleRes;
import androidx.appcompat.view.ActionMode;
import androidx.appcompat.view.ActionMode.Callback;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.VectorEnabledTintResources;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NavUtils;
import androidx.core.app.TaskStackBuilder;
import androidx.core.app.TaskStackBuilder.SupportParentable;
import androidx.fragment.app.FragmentActivity;

public class AppCompatActivity extends FragmentActivity
  implements AppCompatCallback, TaskStackBuilder.SupportParentable, ActionBarDrawerToggle.DelegateProvider
{
  private AppCompatDelegate mDelegate;
  private Resources mResources;
  private int mThemeId = 0;

  private boolean performMenuItemShortcut(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((Build.VERSION.SDK_INT < 26) && (!paramKeyEvent.isCtrlPressed()) && (!KeyEvent.metaStateHasNoModifiers(paramKeyEvent.getMetaState())) && (paramKeyEvent.getRepeatCount() == 0) && (!KeyEvent.isModifierKey(paramKeyEvent.getKeyCode())))
    {
      Window localWindow = getWindow();
      if ((localWindow == null) || (localWindow.getDecorView() == null) || (!localWindow.getDecorView().dispatchKeyShortcutEvent(paramKeyEvent)));
    }
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams)
  {
    getDelegate().addContentView(paramView, paramLayoutParams);
  }

  public void closeOptionsMenu()
  {
    ActionBar localActionBar = getSupportActionBar();
    if ((getWindow().hasFeature(0)) && ((localActionBar == null) || (!localActionBar.closeOptionsMenu())))
      super.closeOptionsMenu();
  }

  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent)
  {
    int i = paramKeyEvent.getKeyCode();
    ActionBar localActionBar = getSupportActionBar();
    if ((i == 82) && (localActionBar != null) && (localActionBar.onMenuKeyEvent(paramKeyEvent)));
    for (boolean bool = true; ; bool = super.dispatchKeyEvent(paramKeyEvent))
      return bool;
  }

  public <T extends View> T findViewById(@IdRes int paramInt)
  {
    return getDelegate().findViewById(paramInt);
  }

  @NonNull
  public AppCompatDelegate getDelegate()
  {
    if (this.mDelegate == null)
      this.mDelegate = AppCompatDelegate.create(this, this);
    return this.mDelegate;
  }

  @Nullable
  public ActionBarDrawerToggle.Delegate getDrawerToggleDelegate()
  {
    return getDelegate().getDrawerToggleDelegate();
  }

  public MenuInflater getMenuInflater()
  {
    return getDelegate().getMenuInflater();
  }

  public Resources getResources()
  {
    if ((this.mResources == null) && (VectorEnabledTintResources.shouldBeUsed()))
      this.mResources = new VectorEnabledTintResources(this, super.getResources());
    if (this.mResources == null);
    for (Resources localResources = super.getResources(); ; localResources = this.mResources)
      return localResources;
  }

  @Nullable
  public ActionBar getSupportActionBar()
  {
    return getDelegate().getSupportActionBar();
  }

  @Nullable
  public Intent getSupportParentActivityIntent()
  {
    return NavUtils.getParentActivityIntent(this);
  }

  public void invalidateOptionsMenu()
  {
    getDelegate().invalidateOptionsMenu();
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    getDelegate().onConfigurationChanged(paramConfiguration);
    if (this.mResources != null)
    {
      DisplayMetrics localDisplayMetrics = super.getResources().getDisplayMetrics();
      this.mResources.updateConfiguration(paramConfiguration, localDisplayMetrics);
    }
  }

  public void onContentChanged()
  {
    onSupportContentChanged();
  }

  protected void onCreate(@Nullable Bundle paramBundle)
  {
    AppCompatDelegate localAppCompatDelegate = getDelegate();
    localAppCompatDelegate.installViewFactory();
    localAppCompatDelegate.onCreate(paramBundle);
    if ((localAppCompatDelegate.applyDayNight()) && (this.mThemeId != 0))
    {
      if (Build.VERSION.SDK_INT < 23)
        break label55;
      onApplyThemeResource(getTheme(), this.mThemeId, false);
    }
    while (true)
    {
      super.onCreate(paramBundle);
      return;
      label55: setTheme(this.mThemeId);
    }
  }

  public void onCreateSupportNavigateUpTaskStack(@NonNull TaskStackBuilder paramTaskStackBuilder)
  {
    paramTaskStackBuilder.addParentStack(this);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    getDelegate().onDestroy();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (performMenuItemShortcut(paramInt, paramKeyEvent));
    for (boolean bool = true; ; bool = super.onKeyDown(paramInt, paramKeyEvent))
      return bool;
  }

  public final boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem)
  {
    boolean bool;
    if (super.onMenuItemSelected(paramInt, paramMenuItem))
      bool = true;
    while (true)
    {
      return bool;
      ActionBar localActionBar = getSupportActionBar();
      if ((paramMenuItem.getItemId() == 16908332) && (localActionBar != null) && ((0x4 & localActionBar.getDisplayOptions()) != 0))
        bool = onSupportNavigateUp();
      else
        bool = false;
    }
  }

  public boolean onMenuOpened(int paramInt, Menu paramMenu)
  {
    return super.onMenuOpened(paramInt, paramMenu);
  }

  public void onPanelClosed(int paramInt, Menu paramMenu)
  {
    super.onPanelClosed(paramInt, paramMenu);
  }

  protected void onPostCreate(@Nullable Bundle paramBundle)
  {
    super.onPostCreate(paramBundle);
    getDelegate().onPostCreate(paramBundle);
  }

  protected void onPostResume()
  {
    super.onPostResume();
    getDelegate().onPostResume();
  }

  public void onPrepareSupportNavigateUpTaskStack(@NonNull TaskStackBuilder paramTaskStackBuilder)
  {
  }

  protected void onSaveInstanceState(Bundle paramBundle)
  {
    super.onSaveInstanceState(paramBundle);
    getDelegate().onSaveInstanceState(paramBundle);
  }

  protected void onStart()
  {
    super.onStart();
    getDelegate().onStart();
  }

  protected void onStop()
  {
    super.onStop();
    getDelegate().onStop();
  }

  @CallSuper
  public void onSupportActionModeFinished(@NonNull ActionMode paramActionMode)
  {
  }

  @CallSuper
  public void onSupportActionModeStarted(@NonNull ActionMode paramActionMode)
  {
  }

  @Deprecated
  public void onSupportContentChanged()
  {
  }

  public boolean onSupportNavigateUp()
  {
    Intent localIntent = getSupportParentActivityIntent();
    if (localIntent != null)
      if (supportShouldUpRecreateTask(localIntent))
      {
        TaskStackBuilder localTaskStackBuilder = TaskStackBuilder.create(this);
        onCreateSupportNavigateUpTaskStack(localTaskStackBuilder);
        onPrepareSupportNavigateUpTaskStack(localTaskStackBuilder);
        localTaskStackBuilder.startActivities();
      }
    while (true)
    {
      try
      {
        ActivityCompat.finishAffinity(this);
        bool = true;
        return bool;
      }
      catch (IllegalStateException localIllegalStateException)
      {
        finish();
        continue;
      }
      supportNavigateUpTo(localIntent);
      continue;
      boolean bool = false;
    }
  }

  protected void onTitleChanged(CharSequence paramCharSequence, int paramInt)
  {
    super.onTitleChanged(paramCharSequence, paramInt);
    getDelegate().setTitle(paramCharSequence);
  }

  @Nullable
  public ActionMode onWindowStartingSupportActionMode(@NonNull ActionMode.Callback paramCallback)
  {
    return null;
  }

  public void openOptionsMenu()
  {
    ActionBar localActionBar = getSupportActionBar();
    if ((getWindow().hasFeature(0)) && ((localActionBar == null) || (!localActionBar.openOptionsMenu())))
      super.openOptionsMenu();
  }

  public void setContentView(@LayoutRes int paramInt)
  {
    getDelegate().setContentView(paramInt);
  }

  public void setContentView(View paramView)
  {
    getDelegate().setContentView(paramView);
  }

  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams)
  {
    getDelegate().setContentView(paramView, paramLayoutParams);
  }

  public void setSupportActionBar(@Nullable Toolbar paramToolbar)
  {
    getDelegate().setSupportActionBar(paramToolbar);
  }

  @Deprecated
  public void setSupportProgress(int paramInt)
  {
  }

  @Deprecated
  public void setSupportProgressBarIndeterminate(boolean paramBoolean)
  {
  }

  @Deprecated
  public void setSupportProgressBarIndeterminateVisibility(boolean paramBoolean)
  {
  }

  @Deprecated
  public void setSupportProgressBarVisibility(boolean paramBoolean)
  {
  }

  public void setTheme(@StyleRes int paramInt)
  {
    super.setTheme(paramInt);
    this.mThemeId = paramInt;
  }

  @Nullable
  public ActionMode startSupportActionMode(@NonNull ActionMode.Callback paramCallback)
  {
    return getDelegate().startSupportActionMode(paramCallback);
  }

  public void supportInvalidateOptionsMenu()
  {
    getDelegate().invalidateOptionsMenu();
  }

  public void supportNavigateUpTo(@NonNull Intent paramIntent)
  {
    NavUtils.navigateUpTo(this, paramIntent);
  }

  public boolean supportRequestWindowFeature(int paramInt)
  {
    return getDelegate().requestWindowFeature(paramInt);
  }

  public boolean supportShouldUpRecreateTask(@NonNull Intent paramIntent)
  {
    return NavUtils.shouldUpRecreateTask(this, paramIntent);
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.app.AppCompatActivity
 * JD-Core Version:    0.6.2
 */