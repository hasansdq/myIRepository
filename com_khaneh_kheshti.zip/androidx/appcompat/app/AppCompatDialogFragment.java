package androidx.appcompat.app;

import android.app.Dialog;
import android.os.Bundle;
import android.view.Window;
import androidx.annotation.RestrictTo;
import androidx.fragment.app.DialogFragment;

public class AppCompatDialogFragment extends DialogFragment
{
  public Dialog onCreateDialog(Bundle paramBundle)
  {
    return new AppCompatDialog(getContext(), getTheme());
  }

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public void setupDialog(Dialog paramDialog, int paramInt)
  {
    AppCompatDialog localAppCompatDialog;
    if ((paramDialog instanceof AppCompatDialog))
    {
      localAppCompatDialog = (AppCompatDialog)paramDialog;
      switch (paramInt)
      {
      default:
      case 3:
      case 1:
      case 2:
      }
    }
    while (true)
    {
      return;
      paramDialog.getWindow().addFlags(24);
      localAppCompatDialog.supportRequestWindowFeature(1);
      continue;
      super.setupDialog(paramDialog, paramInt);
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.app.AppCompatDialogFragment
 * JD-Core Version:    0.6.2
 */