package androidx.appcompat.content.res;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.Log;
import android.util.SparseArray;
import android.util.TypedValue;
import androidx.annotation.ColorRes;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatDrawableManager;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ColorStateListInflaterCompat;
import java.util.WeakHashMap;

public final class AppCompatResources
{
  private static final String LOG_TAG = "AppCompatResources";
  private static final ThreadLocal<TypedValue> TL_TYPED_VALUE = new ThreadLocal();
  private static final Object sColorStateCacheLock = new Object();
  private static final WeakHashMap<Context, SparseArray<ColorStateListCacheEntry>> sColorStateCaches = new WeakHashMap(0);

  private static void addColorStateListToCache(@NonNull Context paramContext, @ColorRes int paramInt, @NonNull ColorStateList paramColorStateList)
  {
    synchronized (sColorStateCacheLock)
    {
      SparseArray localSparseArray = (SparseArray)sColorStateCaches.get(paramContext);
      if (localSparseArray == null)
      {
        localSparseArray = new SparseArray();
        sColorStateCaches.put(paramContext, localSparseArray);
      }
      localSparseArray.append(paramInt, new ColorStateListCacheEntry(paramColorStateList, paramContext.getResources().getConfiguration()));
      return;
    }
  }

  @Nullable
  private static ColorStateList getCachedColorStateList(@NonNull Context paramContext, @ColorRes int paramInt)
  {
    ColorStateList localColorStateList;
    synchronized (sColorStateCacheLock)
    {
      SparseArray localSparseArray = (SparseArray)sColorStateCaches.get(paramContext);
      if ((localSparseArray != null) && (localSparseArray.size() > 0))
      {
        ColorStateListCacheEntry localColorStateListCacheEntry = (ColorStateListCacheEntry)localSparseArray.get(paramInt);
        if (localColorStateListCacheEntry != null)
        {
          if (localColorStateListCacheEntry.configuration.equals(paramContext.getResources().getConfiguration()))
          {
            localColorStateList = localColorStateListCacheEntry.value;
            break label96;
          }
          localSparseArray.remove(paramInt);
        }
      }
      localColorStateList = null;
    }
    label96: return localColorStateList;
  }

  public static ColorStateList getColorStateList(@NonNull Context paramContext, @ColorRes int paramInt)
  {
    ColorStateList localColorStateList;
    if (Build.VERSION.SDK_INT >= 23)
      localColorStateList = paramContext.getColorStateList(paramInt);
    while (true)
    {
      return localColorStateList;
      localColorStateList = getCachedColorStateList(paramContext, paramInt);
      if (localColorStateList == null)
      {
        localColorStateList = inflateColorStateList(paramContext, paramInt);
        if (localColorStateList != null)
          addColorStateListToCache(paramContext, paramInt, localColorStateList);
        else
          localColorStateList = ContextCompat.getColorStateList(paramContext, paramInt);
      }
    }
  }

  @Nullable
  public static Drawable getDrawable(@NonNull Context paramContext, @DrawableRes int paramInt)
  {
    return AppCompatDrawableManager.get().getDrawable(paramContext, paramInt);
  }

  @NonNull
  private static TypedValue getTypedValue()
  {
    TypedValue localTypedValue = (TypedValue)TL_TYPED_VALUE.get();
    if (localTypedValue == null)
    {
      localTypedValue = new TypedValue();
      TL_TYPED_VALUE.set(localTypedValue);
    }
    return localTypedValue;
  }

  @Nullable
  private static ColorStateList inflateColorStateList(Context paramContext, int paramInt)
  {
    Object localObject = null;
    if (isColorInt(paramContext, paramInt));
    while (true)
    {
      return localObject;
      Resources localResources = paramContext.getResources();
      XmlResourceParser localXmlResourceParser = localResources.getXml(paramInt);
      try
      {
        ColorStateList localColorStateList = ColorStateListInflaterCompat.createFromXml(localResources, localXmlResourceParser, paramContext.getTheme());
        localObject = localColorStateList;
      }
      catch (Exception localException)
      {
        Log.e("AppCompatResources", "Failed to inflate ColorStateList, leaving it to the framework", localException);
      }
    }
  }

  private static boolean isColorInt(@NonNull Context paramContext, @ColorRes int paramInt)
  {
    boolean bool = true;
    Resources localResources = paramContext.getResources();
    TypedValue localTypedValue = getTypedValue();
    localResources.getValue(paramInt, localTypedValue, bool);
    if ((localTypedValue.type >= 28) && (localTypedValue.type <= 31));
    while (true)
    {
      return bool;
      bool = false;
    }
  }

  private static class ColorStateListCacheEntry
  {
    final Configuration configuration;
    final ColorStateList value;

    ColorStateListCacheEntry(@NonNull ColorStateList paramColorStateList, @NonNull Configuration paramConfiguration)
    {
      this.value = paramColorStateList;
      this.configuration = paramConfiguration;
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.content.res.AppCompatResources
 * JD-Core Version:    0.6.2
 */