package androidx.appcompat.widget;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.TextView;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R.dimen;
import androidx.appcompat.R.id;
import androidx.appcompat.R.layout;
import androidx.appcompat.R.style;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
class TooltipPopup
{
  private static final String TAG = "TooltipPopup";
  private final View mContentView;
  private final Context mContext;
  private final WindowManager.LayoutParams mLayoutParams = new WindowManager.LayoutParams();
  private final TextView mMessageView;
  private final int[] mTmpAnchorPos = new int[2];
  private final int[] mTmpAppPos = new int[2];
  private final Rect mTmpDisplayFrame = new Rect();

  TooltipPopup(Context paramContext)
  {
    this.mContext = paramContext;
    this.mContentView = LayoutInflater.from(this.mContext).inflate(R.layout.abc_tooltip, null);
    this.mMessageView = ((TextView)this.mContentView.findViewById(R.id.message));
    this.mLayoutParams.setTitle(getClass().getSimpleName());
    this.mLayoutParams.packageName = this.mContext.getPackageName();
    this.mLayoutParams.type = 1002;
    this.mLayoutParams.width = -2;
    this.mLayoutParams.height = -2;
    this.mLayoutParams.format = -3;
    this.mLayoutParams.windowAnimations = R.style.Animation_AppCompat_Tooltip;
    this.mLayoutParams.flags = 24;
  }

  private void computePosition(View paramView, int paramInt1, int paramInt2, boolean paramBoolean, WindowManager.LayoutParams paramLayoutParams)
  {
    paramLayoutParams.token = paramView.getApplicationWindowToken();
    int i = this.mContext.getResources().getDimensionPixelOffset(R.dimen.tooltip_precise_anchor_threshold);
    int j;
    int k;
    int m;
    label72: int n;
    label98: int i1;
    View localView;
    if (paramView.getWidth() >= i)
    {
      j = paramInt1;
      if (paramView.getHeight() < i)
        break label138;
      int i8 = this.mContext.getResources().getDimensionPixelOffset(R.dimen.tooltip_precise_anchor_extra_offset);
      k = paramInt2 + i8;
      m = paramInt2 - i8;
      paramLayoutParams.gravity = 49;
      Resources localResources1 = this.mContext.getResources();
      if (!paramBoolean)
        break label150;
      n = R.dimen.tooltip_y_offset_touch;
      i1 = localResources1.getDimensionPixelOffset(n);
      localView = getAppRootView(paramView);
      if (localView != null)
        break label158;
      Log.e("TooltipPopup", "Cannot find app view");
    }
    while (true)
    {
      return;
      j = paramView.getWidth() / 2;
      break;
      label138: k = paramView.getHeight();
      m = 0;
      break label72;
      label150: n = R.dimen.tooltip_y_offset_non_touch;
      break label98;
      label158: localView.getWindowVisibleDisplayFrame(this.mTmpDisplayFrame);
      Resources localResources2;
      int i6;
      if ((this.mTmpDisplayFrame.left < 0) && (this.mTmpDisplayFrame.top < 0))
      {
        localResources2 = this.mContext.getResources();
        i6 = localResources2.getIdentifier("status_bar_height", "dimen", "android");
        if (i6 == 0)
          break label409;
      }
      int i3;
      int i4;
      int i5;
      label409: for (int i7 = localResources2.getDimensionPixelSize(i6); ; i7 = 0)
      {
        DisplayMetrics localDisplayMetrics = localResources2.getDisplayMetrics();
        this.mTmpDisplayFrame.set(0, i7, localDisplayMetrics.widthPixels, localDisplayMetrics.heightPixels);
        localView.getLocationOnScreen(this.mTmpAppPos);
        paramView.getLocationOnScreen(this.mTmpAnchorPos);
        int[] arrayOfInt1 = this.mTmpAnchorPos;
        arrayOfInt1[0] -= this.mTmpAppPos[0];
        int[] arrayOfInt2 = this.mTmpAnchorPos;
        arrayOfInt2[1] -= this.mTmpAppPos[1];
        paramLayoutParams.x = (j + this.mTmpAnchorPos[0] - localView.getWidth() / 2);
        int i2 = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.mContentView.measure(i2, i2);
        i3 = this.mContentView.getMeasuredHeight();
        i4 = m + this.mTmpAnchorPos[1] - i1 - i3;
        i5 = i1 + (k + this.mTmpAnchorPos[1]);
        if (!paramBoolean)
          break label425;
        if (i4 < 0)
          break label415;
        paramLayoutParams.y = i4;
        break;
      }
      label415: paramLayoutParams.y = i5;
      continue;
      label425: if (i5 + i3 <= this.mTmpDisplayFrame.height())
        paramLayoutParams.y = i5;
      else
        paramLayoutParams.y = i4;
    }
  }

  private static View getAppRootView(View paramView)
  {
    View localView = paramView.getRootView();
    ViewGroup.LayoutParams localLayoutParams = localView.getLayoutParams();
    if (((localLayoutParams instanceof WindowManager.LayoutParams)) && (((WindowManager.LayoutParams)localLayoutParams).type == 2));
    label72: 
    while (true)
    {
      return localView;
      for (Context localContext = paramView.getContext(); ; localContext = ((ContextWrapper)localContext).getBaseContext())
      {
        if (!(localContext instanceof ContextWrapper))
          break label72;
        if ((localContext instanceof Activity))
        {
          localView = ((Activity)localContext).getWindow().getDecorView();
          break;
        }
      }
    }
  }

  void hide()
  {
    if (!isShowing());
    while (true)
    {
      return;
      ((WindowManager)this.mContext.getSystemService("window")).removeView(this.mContentView);
    }
  }

  boolean isShowing()
  {
    if (this.mContentView.getParent() != null);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  void show(View paramView, int paramInt1, int paramInt2, boolean paramBoolean, CharSequence paramCharSequence)
  {
    if (isShowing())
      hide();
    this.mMessageView.setText(paramCharSequence);
    computePosition(paramView, paramInt1, paramInt2, paramBoolean, this.mLayoutParams);
    ((WindowManager)this.mContext.getSystemService("window")).addView(this.mContentView, this.mLayoutParams);
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.TooltipPopup
 * JD-Core Version:    0.6.2
 */