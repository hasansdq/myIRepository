package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.LayerDrawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import androidx.annotation.ColorInt;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R.attr;
import androidx.appcompat.R.color;
import androidx.appcompat.R.drawable;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.appcompat.graphics.drawable.AnimatedStateListDrawableCompat;
import androidx.collection.ArrayMap;
import androidx.collection.LongSparseArray;
import androidx.collection.LruCache;
import androidx.collection.SparseArrayCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.ColorUtils;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat;
import androidx.vectordrawable.graphics.drawable.VectorDrawableCompat;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public final class AppCompatDrawableManager
{
  private static final int[] COLORFILTER_COLOR_BACKGROUND_MULTIPLY;
  private static final int[] COLORFILTER_COLOR_CONTROL_ACTIVATED;
  private static final int[] COLORFILTER_TINT_COLOR_CONTROL_NORMAL;
  private static final ColorFilterLruCache COLOR_FILTER_CACHE;
  private static final boolean DEBUG = false;
  private static final PorterDuff.Mode DEFAULT_MODE = PorterDuff.Mode.SRC_IN;
  private static AppCompatDrawableManager INSTANCE;
  private static final String PLATFORM_VD_CLAZZ = "android.graphics.drawable.VectorDrawable";
  private static final String SKIP_DRAWABLE_TAG = "appcompat_skip_skip";
  private static final String TAG = "AppCompatDrawableManag";
  private static final int[] TINT_CHECKABLE_BUTTON_LIST = arrayOfInt6;
  private static final int[] TINT_COLOR_CONTROL_NORMAL;
  private static final int[] TINT_COLOR_CONTROL_STATE_LIST;
  private ArrayMap<String, InflateDelegate> mDelegates;
  private final WeakHashMap<Context, LongSparseArray<WeakReference<Drawable.ConstantState>>> mDrawableCaches = new WeakHashMap(0);
  private boolean mHasCheckedVectorDrawableSetup;
  private SparseArrayCompat<String> mKnownDrawableIdTags;
  private WeakHashMap<Context, SparseArrayCompat<ColorStateList>> mTintLists;
  private TypedValue mTypedValue;

  static
  {
    COLOR_FILTER_CACHE = new ColorFilterLruCache(6);
    int[] arrayOfInt1 = new int[3];
    arrayOfInt1[0] = R.drawable.abc_textfield_search_default_mtrl_alpha;
    arrayOfInt1[1] = R.drawable.abc_textfield_default_mtrl_alpha;
    arrayOfInt1[2] = R.drawable.abc_ab_share_pack_mtrl_alpha;
    COLORFILTER_TINT_COLOR_CONTROL_NORMAL = arrayOfInt1;
    int[] arrayOfInt2 = new int[7];
    arrayOfInt2[0] = R.drawable.abc_ic_commit_search_api_mtrl_alpha;
    arrayOfInt2[1] = R.drawable.abc_seekbar_tick_mark_material;
    arrayOfInt2[2] = R.drawable.abc_ic_menu_share_mtrl_alpha;
    arrayOfInt2[3] = R.drawable.abc_ic_menu_copy_mtrl_am_alpha;
    arrayOfInt2[4] = R.drawable.abc_ic_menu_cut_mtrl_alpha;
    arrayOfInt2[5] = R.drawable.abc_ic_menu_selectall_mtrl_alpha;
    arrayOfInt2[6] = R.drawable.abc_ic_menu_paste_mtrl_am_alpha;
    TINT_COLOR_CONTROL_NORMAL = arrayOfInt2;
    int[] arrayOfInt3 = new int[10];
    arrayOfInt3[0] = R.drawable.abc_textfield_activated_mtrl_alpha;
    arrayOfInt3[1] = R.drawable.abc_textfield_search_activated_mtrl_alpha;
    arrayOfInt3[2] = R.drawable.abc_cab_background_top_mtrl_alpha;
    arrayOfInt3[3] = R.drawable.abc_text_cursor_material;
    arrayOfInt3[4] = R.drawable.abc_text_select_handle_left_mtrl_dark;
    arrayOfInt3[5] = R.drawable.abc_text_select_handle_middle_mtrl_dark;
    arrayOfInt3[6] = R.drawable.abc_text_select_handle_right_mtrl_dark;
    arrayOfInt3[7] = R.drawable.abc_text_select_handle_left_mtrl_light;
    arrayOfInt3[8] = R.drawable.abc_text_select_handle_middle_mtrl_light;
    arrayOfInt3[9] = R.drawable.abc_text_select_handle_right_mtrl_light;
    COLORFILTER_COLOR_CONTROL_ACTIVATED = arrayOfInt3;
    int[] arrayOfInt4 = new int[3];
    arrayOfInt4[0] = R.drawable.abc_popup_background_mtrl_mult;
    arrayOfInt4[1] = R.drawable.abc_cab_background_internal_bg;
    arrayOfInt4[2] = R.drawable.abc_menu_hardkey_panel_mtrl_mult;
    COLORFILTER_COLOR_BACKGROUND_MULTIPLY = arrayOfInt4;
    int[] arrayOfInt5 = new int[2];
    arrayOfInt5[0] = R.drawable.abc_tab_indicator_material;
    arrayOfInt5[1] = R.drawable.abc_textfield_search_material;
    TINT_COLOR_CONTROL_STATE_LIST = arrayOfInt5;
    int[] arrayOfInt6 = new int[2];
    arrayOfInt6[0] = R.drawable.abc_btn_check_material;
    arrayOfInt6[1] = R.drawable.abc_btn_radio_material;
  }

  private void addDelegate(@NonNull String paramString, @NonNull InflateDelegate paramInflateDelegate)
  {
    if (this.mDelegates == null)
      this.mDelegates = new ArrayMap();
    this.mDelegates.put(paramString, paramInflateDelegate);
  }

  private boolean addDrawableToCache(@NonNull Context paramContext, long paramLong, @NonNull Drawable paramDrawable)
  {
    try
    {
      Drawable.ConstantState localConstantState = paramDrawable.getConstantState();
      if (localConstantState != null)
      {
        LongSparseArray localLongSparseArray = (LongSparseArray)this.mDrawableCaches.get(paramContext);
        if (localLongSparseArray == null)
        {
          localLongSparseArray = new LongSparseArray();
          this.mDrawableCaches.put(paramContext, localLongSparseArray);
        }
        localLongSparseArray.put(paramLong, new WeakReference(localConstantState));
        bool = true;
        return bool;
      }
      boolean bool = false;
    }
    finally
    {
    }
  }

  private void addTintListToCache(@NonNull Context paramContext, @DrawableRes int paramInt, @NonNull ColorStateList paramColorStateList)
  {
    if (this.mTintLists == null)
      this.mTintLists = new WeakHashMap();
    SparseArrayCompat localSparseArrayCompat = (SparseArrayCompat)this.mTintLists.get(paramContext);
    if (localSparseArrayCompat == null)
    {
      localSparseArrayCompat = new SparseArrayCompat();
      this.mTintLists.put(paramContext, localSparseArrayCompat);
    }
    localSparseArrayCompat.append(paramInt, paramColorStateList);
  }

  private static boolean arrayContains(int[] paramArrayOfInt, int paramInt)
  {
    boolean bool = false;
    int i = paramArrayOfInt.length;
    for (int j = 0; ; j++)
      if (j < i)
      {
        if (paramArrayOfInt[j] == paramInt)
          bool = true;
      }
      else
        return bool;
  }

  private void checkVectorDrawableSetup(@NonNull Context paramContext)
  {
    if (this.mHasCheckedVectorDrawableSetup);
    Drawable localDrawable;
    do
    {
      return;
      this.mHasCheckedVectorDrawableSetup = true;
      localDrawable = getDrawable(paramContext, R.drawable.abc_vector_test);
    }
    while ((localDrawable != null) && (isVectorDrawable(localDrawable)));
    this.mHasCheckedVectorDrawableSetup = false;
    throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
  }

  private ColorStateList createBorderlessButtonColorStateList(@NonNull Context paramContext)
  {
    return createButtonColorStateList(paramContext, 0);
  }

  private ColorStateList createButtonColorStateList(@NonNull Context paramContext, @ColorInt int paramInt)
  {
    int[][] arrayOfInt = new int[4][];
    int[] arrayOfInt1 = new int[4];
    int i = ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorControlHighlight);
    int j = ThemeUtils.getDisabledThemeAttrColor(paramContext, R.attr.colorButtonNormal);
    arrayOfInt[0] = ThemeUtils.DISABLED_STATE_SET;
    arrayOfInt1[0] = j;
    int k = 0 + 1;
    arrayOfInt[k] = ThemeUtils.PRESSED_STATE_SET;
    arrayOfInt1[k] = ColorUtils.compositeColors(i, paramInt);
    int m = k + 1;
    arrayOfInt[m] = ThemeUtils.FOCUSED_STATE_SET;
    arrayOfInt1[m] = ColorUtils.compositeColors(i, paramInt);
    int n = m + 1;
    arrayOfInt[n] = ThemeUtils.EMPTY_STATE_SET;
    arrayOfInt1[n] = paramInt;
    (n + 1);
    return new ColorStateList(arrayOfInt, arrayOfInt1);
  }

  private static long createCacheKey(TypedValue paramTypedValue)
  {
    return paramTypedValue.assetCookie << 32 | paramTypedValue.data;
  }

  private ColorStateList createColoredButtonColorStateList(@NonNull Context paramContext)
  {
    return createButtonColorStateList(paramContext, ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorAccent));
  }

  private ColorStateList createDefaultButtonColorStateList(@NonNull Context paramContext)
  {
    return createButtonColorStateList(paramContext, ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorButtonNormal));
  }

  private Drawable createDrawableIfNeeded(@NonNull Context paramContext, @DrawableRes int paramInt)
  {
    if (this.mTypedValue == null)
      this.mTypedValue = new TypedValue();
    TypedValue localTypedValue = this.mTypedValue;
    paramContext.getResources().getValue(paramInt, localTypedValue, true);
    long l = createCacheKey(localTypedValue);
    Object localObject1 = getCachedDrawable(paramContext, l);
    if (localObject1 != null);
    for (Object localObject2 = localObject1; ; localObject2 = localObject1)
    {
      return localObject2;
      if (paramInt == R.drawable.abc_cab_background_top_material)
      {
        Drawable[] arrayOfDrawable = new Drawable[2];
        arrayOfDrawable[0] = getDrawable(paramContext, R.drawable.abc_cab_background_internal_bg);
        arrayOfDrawable[1] = getDrawable(paramContext, R.drawable.abc_cab_background_top_mtrl_alpha);
        localObject1 = new LayerDrawable(arrayOfDrawable);
      }
      if (localObject1 != null)
      {
        ((Drawable)localObject1).setChangingConfigurations(localTypedValue.changingConfigurations);
        addDrawableToCache(paramContext, l, (Drawable)localObject1);
      }
    }
  }

  private ColorStateList createSwitchThumbColorStateList(Context paramContext)
  {
    int[][] arrayOfInt = new int[3][];
    int[] arrayOfInt1 = new int[3];
    ColorStateList localColorStateList = ThemeUtils.getThemeAttrColorStateList(paramContext, R.attr.colorSwitchThumbNormal);
    if ((localColorStateList != null) && (localColorStateList.isStateful()))
    {
      arrayOfInt[0] = ThemeUtils.DISABLED_STATE_SET;
      arrayOfInt1[0] = localColorStateList.getColorForState(arrayOfInt[0], 0);
      int k = 0 + 1;
      arrayOfInt[k] = ThemeUtils.CHECKED_STATE_SET;
      arrayOfInt1[k] = ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorControlActivated);
      int m = k + 1;
      arrayOfInt[m] = ThemeUtils.EMPTY_STATE_SET;
      arrayOfInt1[m] = localColorStateList.getDefaultColor();
      (m + 1);
    }
    while (true)
    {
      return new ColorStateList(arrayOfInt, arrayOfInt1);
      arrayOfInt[0] = ThemeUtils.DISABLED_STATE_SET;
      arrayOfInt1[0] = ThemeUtils.getDisabledThemeAttrColor(paramContext, R.attr.colorSwitchThumbNormal);
      int i = 0 + 1;
      arrayOfInt[i] = ThemeUtils.CHECKED_STATE_SET;
      arrayOfInt1[i] = ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorControlActivated);
      int j = i + 1;
      arrayOfInt[j] = ThemeUtils.EMPTY_STATE_SET;
      arrayOfInt1[j] = ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorSwitchThumbNormal);
      (j + 1);
    }
  }

  private static PorterDuffColorFilter createTintFilter(ColorStateList paramColorStateList, PorterDuff.Mode paramMode, int[] paramArrayOfInt)
  {
    if ((paramColorStateList == null) || (paramMode == null));
    for (PorterDuffColorFilter localPorterDuffColorFilter = null; ; localPorterDuffColorFilter = getPorterDuffColorFilter(paramColorStateList.getColorForState(paramArrayOfInt, 0), paramMode))
      return localPorterDuffColorFilter;
  }

  public static AppCompatDrawableManager get()
  {
    try
    {
      if (INSTANCE == null)
      {
        INSTANCE = new AppCompatDrawableManager();
        installDefaultInflateDelegates(INSTANCE);
      }
      AppCompatDrawableManager localAppCompatDrawableManager = INSTANCE;
      return localAppCompatDrawableManager;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  private Drawable getCachedDrawable(@NonNull Context paramContext, long paramLong)
  {
    Drawable localDrawable = null;
    try
    {
      LongSparseArray localLongSparseArray = (LongSparseArray)this.mDrawableCaches.get(paramContext);
      if (localLongSparseArray == null);
      while (true)
      {
        return localDrawable;
        WeakReference localWeakReference = (WeakReference)localLongSparseArray.get(paramLong);
        if (localWeakReference != null)
        {
          Drawable.ConstantState localConstantState = (Drawable.ConstantState)localWeakReference.get();
          if (localConstantState != null)
            localDrawable = localConstantState.newDrawable(paramContext.getResources());
          else
            localLongSparseArray.delete(paramLong);
        }
      }
    }
    finally
    {
    }
  }

  public static PorterDuffColorFilter getPorterDuffColorFilter(int paramInt, PorterDuff.Mode paramMode)
  {
    try
    {
      PorterDuffColorFilter localPorterDuffColorFilter = COLOR_FILTER_CACHE.get(paramInt, paramMode);
      if (localPorterDuffColorFilter == null)
      {
        localPorterDuffColorFilter = new PorterDuffColorFilter(paramInt, paramMode);
        COLOR_FILTER_CACHE.put(paramInt, paramMode, localPorterDuffColorFilter);
      }
      return localPorterDuffColorFilter;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  private ColorStateList getTintListFromCache(@NonNull Context paramContext, @DrawableRes int paramInt)
  {
    ColorStateList localColorStateList = null;
    if (this.mTintLists != null)
    {
      SparseArrayCompat localSparseArrayCompat = (SparseArrayCompat)this.mTintLists.get(paramContext);
      if (localSparseArrayCompat != null)
        localColorStateList = (ColorStateList)localSparseArrayCompat.get(paramInt);
    }
    return localColorStateList;
  }

  static PorterDuff.Mode getTintMode(int paramInt)
  {
    PorterDuff.Mode localMode = null;
    if (paramInt == R.drawable.abc_switch_thumb_material)
      localMode = PorterDuff.Mode.MULTIPLY;
    return localMode;
  }

  private static void installDefaultInflateDelegates(@NonNull AppCompatDrawableManager paramAppCompatDrawableManager)
  {
    if (Build.VERSION.SDK_INT < 24)
    {
      paramAppCompatDrawableManager.addDelegate("vector", new VdcInflateDelegate());
      paramAppCompatDrawableManager.addDelegate("animated-vector", new AvdcInflateDelegate());
      paramAppCompatDrawableManager.addDelegate("animated-selector", new AsldcInflateDelegate());
    }
  }

  private static boolean isVectorDrawable(@NonNull Drawable paramDrawable)
  {
    if (((paramDrawable instanceof VectorDrawableCompat)) || ("android.graphics.drawable.VectorDrawable".equals(paramDrawable.getClass().getName())));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private Drawable loadDrawableFromDelegates(@NonNull Context paramContext, @DrawableRes int paramInt)
  {
    Drawable localDrawable;
    if ((this.mDelegates != null) && (!this.mDelegates.isEmpty()))
      if (this.mKnownDrawableIdTags != null)
      {
        String str2 = (String)this.mKnownDrawableIdTags.get(paramInt);
        if ((!"appcompat_skip_skip".equals(str2)) && ((str2 == null) || (this.mDelegates.get(str2) != null)))
          break label79;
        localDrawable = null;
      }
    while (true)
    {
      return localDrawable;
      this.mKnownDrawableIdTags = new SparseArrayCompat();
      label79: if (this.mTypedValue == null)
        this.mTypedValue = new TypedValue();
      TypedValue localTypedValue = this.mTypedValue;
      Resources localResources = paramContext.getResources();
      localResources.getValue(paramInt, localTypedValue, true);
      long l = createCacheKey(localTypedValue);
      localDrawable = getCachedDrawable(paramContext, l);
      if (localDrawable == null)
      {
        XmlResourceParser localXmlResourceParser;
        AttributeSet localAttributeSet;
        if ((localTypedValue.string != null) && (localTypedValue.string.toString().endsWith(".xml")))
          try
          {
            localXmlResourceParser = localResources.getXml(paramInt);
            localAttributeSet = Xml.asAttributeSet(localXmlResourceParser);
            int i;
            do
              i = localXmlResourceParser.next();
            while ((i != 2) && (i != 1));
            if (i != 2)
              throw new XmlPullParserException("No start tag found");
          }
          catch (Exception localException)
          {
            Log.e("AppCompatDrawableManag", "Exception while inflating drawable", localException);
          }
        while (true)
        {
          if (localDrawable != null)
            break label331;
          this.mKnownDrawableIdTags.append(paramInt, "appcompat_skip_skip");
          break;
          String str1 = localXmlResourceParser.getName();
          this.mKnownDrawableIdTags.append(paramInt, str1);
          InflateDelegate localInflateDelegate = (InflateDelegate)this.mDelegates.get(str1);
          if (localInflateDelegate != null)
            localDrawable = localInflateDelegate.createFromXmlInner(paramContext, localXmlResourceParser, localAttributeSet, paramContext.getTheme());
          if (localDrawable != null)
          {
            localDrawable.setChangingConfigurations(localTypedValue.changingConfigurations);
            boolean bool = addDrawableToCache(paramContext, l, localDrawable);
            if (!bool);
          }
        }
        label331: continue;
        localDrawable = null;
      }
    }
  }

  private void removeDelegate(@NonNull String paramString, @NonNull InflateDelegate paramInflateDelegate)
  {
    if ((this.mDelegates != null) && (this.mDelegates.get(paramString) == paramInflateDelegate))
      this.mDelegates.remove(paramString);
  }

  private static void setPorterDuffColorFilter(Drawable paramDrawable, int paramInt, PorterDuff.Mode paramMode)
  {
    if (DrawableUtils.canSafelyMutateDrawable(paramDrawable))
      paramDrawable = paramDrawable.mutate();
    if (paramMode == null)
      paramMode = DEFAULT_MODE;
    paramDrawable.setColorFilter(getPorterDuffColorFilter(paramInt, paramMode));
  }

  private Drawable tintDrawable(@NonNull Context paramContext, @DrawableRes int paramInt, boolean paramBoolean, @NonNull Drawable paramDrawable)
  {
    ColorStateList localColorStateList = getTintList(paramContext, paramInt);
    if (localColorStateList != null)
    {
      if (DrawableUtils.canSafelyMutateDrawable(paramDrawable))
        paramDrawable = paramDrawable.mutate();
      paramDrawable = DrawableCompat.wrap(paramDrawable);
      DrawableCompat.setTintList(paramDrawable, localColorStateList);
      PorterDuff.Mode localMode = getTintMode(paramInt);
      if (localMode != null)
        DrawableCompat.setTintMode(paramDrawable, localMode);
    }
    while (true)
    {
      return paramDrawable;
      if (paramInt == R.drawable.abc_seekbar_track_material)
      {
        LayerDrawable localLayerDrawable2 = (LayerDrawable)paramDrawable;
        setPorterDuffColorFilter(localLayerDrawable2.findDrawableByLayerId(16908288), ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorControlNormal), DEFAULT_MODE);
        setPorterDuffColorFilter(localLayerDrawable2.findDrawableByLayerId(16908303), ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorControlNormal), DEFAULT_MODE);
        setPorterDuffColorFilter(localLayerDrawable2.findDrawableByLayerId(16908301), ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorControlActivated), DEFAULT_MODE);
      }
      else if ((paramInt == R.drawable.abc_ratingbar_material) || (paramInt == R.drawable.abc_ratingbar_indicator_material) || (paramInt == R.drawable.abc_ratingbar_small_material))
      {
        LayerDrawable localLayerDrawable1 = (LayerDrawable)paramDrawable;
        setPorterDuffColorFilter(localLayerDrawable1.findDrawableByLayerId(16908288), ThemeUtils.getDisabledThemeAttrColor(paramContext, R.attr.colorControlNormal), DEFAULT_MODE);
        setPorterDuffColorFilter(localLayerDrawable1.findDrawableByLayerId(16908303), ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorControlActivated), DEFAULT_MODE);
        setPorterDuffColorFilter(localLayerDrawable1.findDrawableByLayerId(16908301), ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorControlActivated), DEFAULT_MODE);
      }
      else if ((!tintDrawableUsingColorFilter(paramContext, paramInt, paramDrawable)) && (paramBoolean))
      {
        paramDrawable = null;
      }
    }
  }

  static void tintDrawable(Drawable paramDrawable, TintInfo paramTintInfo, int[] paramArrayOfInt)
  {
    if ((DrawableUtils.canSafelyMutateDrawable(paramDrawable)) && (paramDrawable.mutate() != paramDrawable))
      Log.d("AppCompatDrawableManag", "Mutated drawable is not the same instance as the input.");
    label51: label64: label95: label108: 
    while (true)
    {
      return;
      ColorStateList localColorStateList;
      PorterDuff.Mode localMode;
      if ((paramTintInfo.mHasTintList) || (paramTintInfo.mHasTintMode))
        if (paramTintInfo.mHasTintList)
        {
          localColorStateList = paramTintInfo.mTintList;
          if (!paramTintInfo.mHasTintMode)
            break label95;
          localMode = paramTintInfo.mTintMode;
          paramDrawable.setColorFilter(createTintFilter(localColorStateList, localMode, paramArrayOfInt));
        }
      while (true)
      {
        if (Build.VERSION.SDK_INT > 23)
          break label108;
        paramDrawable.invalidateSelf();
        break;
        localColorStateList = null;
        break label51;
        localMode = DEFAULT_MODE;
        break label64;
        paramDrawable.clearColorFilter();
      }
    }
  }

  static boolean tintDrawableUsingColorFilter(@NonNull Context paramContext, @DrawableRes int paramInt, @NonNull Drawable paramDrawable)
  {
    PorterDuff.Mode localMode = DEFAULT_MODE;
    int i = 0;
    int j = 0;
    int k = -1;
    if (arrayContains(COLORFILTER_TINT_COLOR_CONTROL_NORMAL, paramInt))
    {
      j = R.attr.colorControlNormal;
      i = 1;
      if (i == 0)
        break label170;
      if (DrawableUtils.canSafelyMutateDrawable(paramDrawable))
        paramDrawable = paramDrawable.mutate();
      paramDrawable.setColorFilter(getPorterDuffColorFilter(ThemeUtils.getThemeAttrColor(paramContext, j), localMode));
      if (k != -1)
        paramDrawable.setAlpha(k);
    }
    label170: for (boolean bool = true; ; bool = false)
    {
      return bool;
      if (arrayContains(COLORFILTER_COLOR_CONTROL_ACTIVATED, paramInt))
      {
        j = R.attr.colorControlActivated;
        i = 1;
        break;
      }
      if (arrayContains(COLORFILTER_COLOR_BACKGROUND_MULTIPLY, paramInt))
      {
        j = 16842801;
        i = 1;
        localMode = PorterDuff.Mode.MULTIPLY;
        break;
      }
      if (paramInt == R.drawable.abc_list_divider_mtrl_alpha)
      {
        j = 16842800;
        i = 1;
        k = Math.round(40.799999F);
        break;
      }
      if (paramInt != R.drawable.abc_dialog_material_background)
        break;
      j = 16842801;
      i = 1;
      break;
    }
  }

  public Drawable getDrawable(@NonNull Context paramContext, @DrawableRes int paramInt)
  {
    try
    {
      Drawable localDrawable = getDrawable(paramContext, paramInt, false);
      return localDrawable;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  Drawable getDrawable(@NonNull Context paramContext, @DrawableRes int paramInt, boolean paramBoolean)
  {
    try
    {
      checkVectorDrawableSetup(paramContext);
      Drawable localDrawable = loadDrawableFromDelegates(paramContext, paramInt);
      if (localDrawable == null)
        localDrawable = createDrawableIfNeeded(paramContext, paramInt);
      if (localDrawable == null)
        localDrawable = ContextCompat.getDrawable(paramContext, paramInt);
      if (localDrawable != null)
        localDrawable = tintDrawable(paramContext, paramInt, paramBoolean, localDrawable);
      if (localDrawable != null)
        DrawableUtils.fixDrawable(localDrawable);
      return localDrawable;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  ColorStateList getTintList(@NonNull Context paramContext, @DrawableRes int paramInt)
  {
    try
    {
      Object localObject2 = getTintListFromCache(paramContext, paramInt);
      if (localObject2 == null)
      {
        if (paramInt != R.drawable.abc_edit_text_material)
          break label49;
        localObject2 = AppCompatResources.getColorStateList(paramContext, R.color.abc_tint_edittext);
      }
      while (true)
      {
        if (localObject2 != null)
          addTintListToCache(paramContext, paramInt, (ColorStateList)localObject2);
        return localObject2;
        label49: if (paramInt == R.drawable.abc_switch_track_mtrl_alpha)
        {
          localObject2 = AppCompatResources.getColorStateList(paramContext, R.color.abc_tint_switch_track);
        }
        else if (paramInt == R.drawable.abc_switch_thumb_material)
        {
          localObject2 = createSwitchThumbColorStateList(paramContext);
        }
        else if (paramInt == R.drawable.abc_btn_default_mtrl_shape)
        {
          localObject2 = createDefaultButtonColorStateList(paramContext);
        }
        else if (paramInt == R.drawable.abc_btn_borderless_material)
        {
          localObject2 = createBorderlessButtonColorStateList(paramContext);
        }
        else if (paramInt == R.drawable.abc_btn_colored_material)
        {
          localObject2 = createColoredButtonColorStateList(paramContext);
        }
        else if ((paramInt == R.drawable.abc_spinner_mtrl_am_alpha) || (paramInt == R.drawable.abc_spinner_textfield_background_material))
        {
          localObject2 = AppCompatResources.getColorStateList(paramContext, R.color.abc_tint_spinner);
        }
        else if (arrayContains(TINT_COLOR_CONTROL_NORMAL, paramInt))
        {
          localObject2 = ThemeUtils.getThemeAttrColorStateList(paramContext, R.attr.colorControlNormal);
        }
        else if (arrayContains(TINT_COLOR_CONTROL_STATE_LIST, paramInt))
        {
          localObject2 = AppCompatResources.getColorStateList(paramContext, R.color.abc_tint_default);
        }
        else if (arrayContains(TINT_CHECKABLE_BUTTON_LIST, paramInt))
        {
          localObject2 = AppCompatResources.getColorStateList(paramContext, R.color.abc_tint_btn_checkable);
        }
        else if (paramInt == R.drawable.abc_seekbar_thumb_material)
        {
          ColorStateList localColorStateList = AppCompatResources.getColorStateList(paramContext, R.color.abc_tint_seek_thumb);
          localObject2 = localColorStateList;
        }
      }
    }
    finally
    {
    }
  }

  public void onConfigurationChanged(@NonNull Context paramContext)
  {
    try
    {
      LongSparseArray localLongSparseArray = (LongSparseArray)this.mDrawableCaches.get(paramContext);
      if (localLongSparseArray != null)
        localLongSparseArray.clear();
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  Drawable onDrawableLoadedFromResources(@NonNull Context paramContext, @NonNull VectorEnabledTintResources paramVectorEnabledTintResources, @DrawableRes int paramInt)
  {
    try
    {
      Drawable localDrawable1 = loadDrawableFromDelegates(paramContext, paramInt);
      if (localDrawable1 == null)
        localDrawable1 = paramVectorEnabledTintResources.superGetDrawable(paramInt);
      if (localDrawable1 != null)
      {
        Drawable localDrawable3 = tintDrawable(paramContext, paramInt, false, localDrawable1);
        localDrawable2 = localDrawable3;
        return localDrawable2;
      }
      Drawable localDrawable2 = null;
    }
    finally
    {
    }
  }

  @RequiresApi(11)
  static class AsldcInflateDelegate
    implements AppCompatDrawableManager.InflateDelegate
  {
    public Drawable createFromXmlInner(@NonNull Context paramContext, @NonNull XmlPullParser paramXmlPullParser, @NonNull AttributeSet paramAttributeSet, @Nullable Resources.Theme paramTheme)
    {
      try
      {
        AnimatedStateListDrawableCompat localAnimatedStateListDrawableCompat2 = AnimatedStateListDrawableCompat.createFromXmlInner(paramContext, paramContext.getResources(), paramXmlPullParser, paramAttributeSet, paramTheme);
        localAnimatedStateListDrawableCompat1 = localAnimatedStateListDrawableCompat2;
        return localAnimatedStateListDrawableCompat1;
      }
      catch (Exception localException)
      {
        while (true)
        {
          Log.e("AsldcInflateDelegate", "Exception while inflating <animated-selector>", localException);
          AnimatedStateListDrawableCompat localAnimatedStateListDrawableCompat1 = null;
        }
      }
    }
  }

  private static class AvdcInflateDelegate
    implements AppCompatDrawableManager.InflateDelegate
  {
    public Drawable createFromXmlInner(@NonNull Context paramContext, @NonNull XmlPullParser paramXmlPullParser, @NonNull AttributeSet paramAttributeSet, @Nullable Resources.Theme paramTheme)
    {
      try
      {
        AnimatedVectorDrawableCompat localAnimatedVectorDrawableCompat2 = AnimatedVectorDrawableCompat.createFromXmlInner(paramContext, paramContext.getResources(), paramXmlPullParser, paramAttributeSet, paramTheme);
        localAnimatedVectorDrawableCompat1 = localAnimatedVectorDrawableCompat2;
        return localAnimatedVectorDrawableCompat1;
      }
      catch (Exception localException)
      {
        while (true)
        {
          Log.e("AvdcInflateDelegate", "Exception while inflating <animated-vector>", localException);
          AnimatedVectorDrawableCompat localAnimatedVectorDrawableCompat1 = null;
        }
      }
    }
  }

  private static class ColorFilterLruCache extends LruCache<Integer, PorterDuffColorFilter>
  {
    public ColorFilterLruCache(int paramInt)
    {
      super();
    }

    private static int generateCacheKey(int paramInt, PorterDuff.Mode paramMode)
    {
      return 31 * (paramInt + 31) + paramMode.hashCode();
    }

    PorterDuffColorFilter get(int paramInt, PorterDuff.Mode paramMode)
    {
      return (PorterDuffColorFilter)get(Integer.valueOf(generateCacheKey(paramInt, paramMode)));
    }

    PorterDuffColorFilter put(int paramInt, PorterDuff.Mode paramMode, PorterDuffColorFilter paramPorterDuffColorFilter)
    {
      return (PorterDuffColorFilter)put(Integer.valueOf(generateCacheKey(paramInt, paramMode)), paramPorterDuffColorFilter);
    }
  }

  private static abstract interface InflateDelegate
  {
    public abstract Drawable createFromXmlInner(@NonNull Context paramContext, @NonNull XmlPullParser paramXmlPullParser, @NonNull AttributeSet paramAttributeSet, @Nullable Resources.Theme paramTheme);
  }

  private static class VdcInflateDelegate
    implements AppCompatDrawableManager.InflateDelegate
  {
    public Drawable createFromXmlInner(@NonNull Context paramContext, @NonNull XmlPullParser paramXmlPullParser, @NonNull AttributeSet paramAttributeSet, @Nullable Resources.Theme paramTheme)
    {
      try
      {
        VectorDrawableCompat localVectorDrawableCompat2 = VectorDrawableCompat.createFromXmlInner(paramContext.getResources(), paramXmlPullParser, paramAttributeSet, paramTheme);
        localVectorDrawableCompat1 = localVectorDrawableCompat2;
        return localVectorDrawableCompat1;
      }
      catch (Exception localException)
      {
        while (true)
        {
          Log.e("VdcInflateDelegate", "Exception while inflating <vector>", localException);
          VectorDrawableCompat localVectorDrawableCompat1 = null;
        }
      }
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.AppCompatDrawableManager
 * JD-Core Version:    0.6.2
 */