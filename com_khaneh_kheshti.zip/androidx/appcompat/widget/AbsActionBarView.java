package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import androidx.appcompat.R.attr;
import androidx.appcompat.R.styleable;
import androidx.core.view.ViewCompat;
import androidx.core.view.ViewPropertyAnimatorCompat;
import androidx.core.view.ViewPropertyAnimatorListener;

abstract class AbsActionBarView extends ViewGroup
{
  private static final int FADE_DURATION = 200;
  protected ActionMenuPresenter mActionMenuPresenter;
  protected int mContentHeight;
  private boolean mEatingHover;
  private boolean mEatingTouch;
  protected ActionMenuView mMenuView;
  protected final Context mPopupContext;
  protected final VisibilityAnimListener mVisAnimListener = new VisibilityAnimListener();
  protected ViewPropertyAnimatorCompat mVisibilityAnim;

  AbsActionBarView(Context paramContext)
  {
    this(paramContext, null);
  }

  AbsActionBarView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  AbsActionBarView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    TypedValue localTypedValue = new TypedValue();
    if ((paramContext.getTheme().resolveAttribute(R.attr.actionBarPopupTheme, localTypedValue, true)) && (localTypedValue.resourceId != 0));
    for (this.mPopupContext = new ContextThemeWrapper(paramContext, localTypedValue.resourceId); ; this.mPopupContext = paramContext)
      return;
  }

  protected static int next(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    if (paramBoolean);
    for (int i = paramInt1 - paramInt2; ; i = paramInt1 + paramInt2)
      return i;
  }

  public void animateToVisibility(int paramInt)
  {
    setupAnimatorToVisibility(paramInt, 200L).start();
  }

  public boolean canShowOverflowMenu()
  {
    if ((isOverflowReserved()) && (getVisibility() == 0));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public void dismissPopupMenus()
  {
    if (this.mActionMenuPresenter != null)
      this.mActionMenuPresenter.dismissPopupMenus();
  }

  public int getAnimatedVisibility()
  {
    if (this.mVisibilityAnim != null);
    for (int i = this.mVisAnimListener.mFinalVisibility; ; i = getVisibility())
      return i;
  }

  public int getContentHeight()
  {
    return this.mContentHeight;
  }

  public boolean hideOverflowMenu()
  {
    if (this.mActionMenuPresenter != null);
    for (boolean bool = this.mActionMenuPresenter.hideOverflowMenu(); ; bool = false)
      return bool;
  }

  public boolean isOverflowMenuShowPending()
  {
    if (this.mActionMenuPresenter != null);
    for (boolean bool = this.mActionMenuPresenter.isOverflowMenuShowPending(); ; bool = false)
      return bool;
  }

  public boolean isOverflowMenuShowing()
  {
    if (this.mActionMenuPresenter != null);
    for (boolean bool = this.mActionMenuPresenter.isOverflowMenuShowing(); ; bool = false)
      return bool;
  }

  public boolean isOverflowReserved()
  {
    if ((this.mActionMenuPresenter != null) && (this.mActionMenuPresenter.isOverflowReserved()));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  protected int measureChildView(View paramView, int paramInt1, int paramInt2, int paramInt3)
  {
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1, -2147483648), paramInt2);
    return Math.max(0, paramInt1 - paramView.getMeasuredWidth() - paramInt3);
  }

  protected void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    TypedArray localTypedArray = getContext().obtainStyledAttributes(null, R.styleable.ActionBar, R.attr.actionBarStyle, 0);
    setContentHeight(localTypedArray.getLayoutDimension(R.styleable.ActionBar_height, 0));
    localTypedArray.recycle();
    if (this.mActionMenuPresenter != null)
      this.mActionMenuPresenter.onConfigurationChanged(paramConfiguration);
  }

  public boolean onHoverEvent(MotionEvent paramMotionEvent)
  {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.mEatingHover = false;
    if (!this.mEatingHover)
    {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if ((i == 9) && (!bool))
        this.mEatingHover = true;
    }
    if ((i == 10) || (i == 3))
      this.mEatingHover = false;
    return true;
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.mEatingTouch = false;
    if (!this.mEatingTouch)
    {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if ((i == 0) && (!bool))
        this.mEatingTouch = true;
    }
    if ((i == 1) || (i == 3))
      this.mEatingTouch = false;
    return true;
  }

  protected int positionChild(View paramView, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    int i = paramView.getMeasuredWidth();
    int j = paramView.getMeasuredHeight();
    int k = paramInt2 + (paramInt3 - j) / 2;
    if (paramBoolean)
      paramView.layout(paramInt1 - i, k, paramInt1, k + j);
    while (true)
    {
      if (paramBoolean)
        i = -i;
      return i;
      paramView.layout(paramInt1, k, paramInt1 + i, k + j);
    }
  }

  public void postShowOverflowMenu()
  {
    post(new Runnable()
    {
      public void run()
      {
        AbsActionBarView.this.showOverflowMenu();
      }
    });
  }

  public void setContentHeight(int paramInt)
  {
    this.mContentHeight = paramInt;
    requestLayout();
  }

  public void setVisibility(int paramInt)
  {
    if (paramInt != getVisibility())
    {
      if (this.mVisibilityAnim != null)
        this.mVisibilityAnim.cancel();
      super.setVisibility(paramInt);
    }
  }

  public ViewPropertyAnimatorCompat setupAnimatorToVisibility(int paramInt, long paramLong)
  {
    if (this.mVisibilityAnim != null)
      this.mVisibilityAnim.cancel();
    ViewPropertyAnimatorCompat localViewPropertyAnimatorCompat2;
    if (paramInt == 0)
    {
      if (getVisibility() != 0)
        setAlpha(0.0F);
      localViewPropertyAnimatorCompat2 = ViewCompat.animate(this).alpha(1.0F);
      localViewPropertyAnimatorCompat2.setDuration(paramLong);
      localViewPropertyAnimatorCompat2.setListener(this.mVisAnimListener.withFinalVisibility(localViewPropertyAnimatorCompat2, paramInt));
    }
    ViewPropertyAnimatorCompat localViewPropertyAnimatorCompat1;
    for (Object localObject = localViewPropertyAnimatorCompat2; ; localObject = localViewPropertyAnimatorCompat1)
    {
      return localObject;
      localViewPropertyAnimatorCompat1 = ViewCompat.animate(this).alpha(0.0F);
      localViewPropertyAnimatorCompat1.setDuration(paramLong);
      localViewPropertyAnimatorCompat1.setListener(this.mVisAnimListener.withFinalVisibility(localViewPropertyAnimatorCompat1, paramInt));
    }
  }

  public boolean showOverflowMenu()
  {
    if (this.mActionMenuPresenter != null);
    for (boolean bool = this.mActionMenuPresenter.showOverflowMenu(); ; bool = false)
      return bool;
  }

  protected class VisibilityAnimListener
    implements ViewPropertyAnimatorListener
  {
    private boolean mCanceled = false;
    int mFinalVisibility;

    protected VisibilityAnimListener()
    {
    }

    public void onAnimationCancel(View paramView)
    {
      this.mCanceled = true;
    }

    public void onAnimationEnd(View paramView)
    {
      if (this.mCanceled);
      while (true)
      {
        return;
        AbsActionBarView.this.mVisibilityAnim = null;
        AbsActionBarView.this.setVisibility(this.mFinalVisibility);
      }
    }

    public void onAnimationStart(View paramView)
    {
      AbsActionBarView.this.setVisibility(0);
      this.mCanceled = false;
    }

    public VisibilityAnimListener withFinalVisibility(ViewPropertyAnimatorCompat paramViewPropertyAnimatorCompat, int paramInt)
    {
      AbsActionBarView.this.mVisibilityAnim = paramViewPropertyAnimatorCompat;
      this.mFinalVisibility = paramInt;
      return this;
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.AbsActionBarView
 * JD-Core Version:    0.6.2
 */