package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.MeasureSpec;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R.id;
import androidx.appcompat.R.styleable;
import androidx.core.view.ViewCompat;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public class ButtonBarLayout extends LinearLayout
{
  private static final int PEEK_BUTTON_DP = 16;
  private boolean mAllowStacking;
  private int mLastWidthSize = -1;
  private int mMinimumHeight = 0;

  public ButtonBarLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.ButtonBarLayout);
    this.mAllowStacking = localTypedArray.getBoolean(R.styleable.ButtonBarLayout_allowStacking, true);
    localTypedArray.recycle();
  }

  private int getNextVisibleChildIndex(int paramInt)
  {
    int i = paramInt;
    int j = getChildCount();
    if (i < j)
      if (getChildAt(i).getVisibility() != 0);
    while (true)
    {
      return i;
      i++;
      break;
      i = -1;
    }
  }

  private boolean isStacked()
  {
    int i = 1;
    if (getOrientation() == i);
    while (true)
    {
      return i;
      int j = 0;
    }
  }

  private void setStacked(boolean paramBoolean)
  {
    int i;
    int j;
    label17: View localView;
    if (paramBoolean)
    {
      i = 1;
      setOrientation(i);
      if (!paramBoolean)
        break label86;
      j = 5;
      setGravity(j);
      localView = findViewById(R.id.spacer);
      if (localView != null)
        if (!paramBoolean)
          break label92;
    }
    label86: label92: for (int m = 8; ; m = 4)
    {
      localView.setVisibility(m);
      for (int k = -2 + getChildCount(); k >= 0; k--)
        bringChildToFront(getChildAt(k));
      i = 0;
      break;
      j = 80;
      break label17;
    }
  }

  public int getMinimumHeight()
  {
    return Math.max(this.mMinimumHeight, super.getMinimumHeight());
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i = View.MeasureSpec.getSize(paramInt1);
    if (this.mAllowStacking)
    {
      if ((i > this.mLastWidthSize) && (isStacked()))
        setStacked(false);
      this.mLastWidthSize = i;
    }
    int j = 0;
    int k;
    int i2;
    label103: int m;
    if ((!isStacked()) && (View.MeasureSpec.getMode(paramInt1) == 1073741824))
    {
      k = View.MeasureSpec.makeMeasureSpec(i, -2147483648);
      j = 1;
      super.onMeasure(k, paramInt2);
      if ((this.mAllowStacking) && (!isStacked()))
      {
        if ((0xFF000000 & getMeasuredWidthAndState()) != 16777216)
          break label259;
        i2 = 1;
        if (i2 != 0)
        {
          setStacked(true);
          j = 1;
        }
      }
      if (j != 0)
        super.onMeasure(paramInt1, paramInt2);
      m = 0;
      int n = getNextVisibleChildIndex(0);
      if (n >= 0)
      {
        View localView = getChildAt(n);
        LinearLayout.LayoutParams localLayoutParams = (LinearLayout.LayoutParams)localView.getLayoutParams();
        m = 0 + (getPaddingTop() + localView.getMeasuredHeight() + localLayoutParams.topMargin + localLayoutParams.bottomMargin);
        if (!isStacked())
          break label265;
        int i1 = getNextVisibleChildIndex(n + 1);
        if (i1 >= 0)
          m += getChildAt(i1).getPaddingTop() + (int)(16.0F * getResources().getDisplayMetrics().density);
      }
    }
    while (true)
    {
      if (ViewCompat.getMinimumHeight(this) != m)
        setMinimumHeight(m);
      return;
      k = paramInt1;
      break;
      label259: i2 = 0;
      break label103;
      label265: m += getPaddingBottom();
    }
  }

  public void setAllowStacking(boolean paramBoolean)
  {
    if (this.mAllowStacking != paramBoolean)
    {
      this.mAllowStacking = paramBoolean;
      if ((!this.mAllowStacking) && (getOrientation() == 1))
        setStacked(false);
      requestLayout();
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.ButtonBarLayout
 * JD-Core Version:    0.6.2
 */