package androidx.appcompat.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.os.Build.VERSION;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public class TintContextWrapper extends ContextWrapper
{
  private static final Object CACHE_LOCK = new Object();
  private static ArrayList<WeakReference<TintContextWrapper>> sCache;
  private final Resources mResources;
  private final Resources.Theme mTheme;

  private TintContextWrapper(@NonNull Context paramContext)
  {
    super(paramContext);
    if (VectorEnabledTintResources.shouldBeUsed())
    {
      this.mResources = new VectorEnabledTintResources(this, paramContext.getResources());
      this.mTheme = this.mResources.newTheme();
      this.mTheme.setTo(paramContext.getTheme());
    }
    while (true)
    {
      return;
      this.mResources = new TintResources(this, paramContext.getResources());
      this.mTheme = null;
    }
  }

  private static boolean shouldWrap(@NonNull Context paramContext)
  {
    boolean bool = false;
    if (((paramContext instanceof TintContextWrapper)) || ((paramContext.getResources() instanceof TintResources)) || ((paramContext.getResources() instanceof VectorEnabledTintResources)));
    while (true)
    {
      return bool;
      if ((Build.VERSION.SDK_INT < 21) || (VectorEnabledTintResources.shouldBeUsed()))
        bool = true;
    }
  }

  public static Context wrap(@NonNull Context paramContext)
  {
    if (shouldWrap(paramContext));
    while (true)
    {
      int i;
      int j;
      synchronized (CACHE_LOCK)
      {
        if (sCache == null)
        {
          sCache = new ArrayList();
          localObject1 = new TintContextWrapper(paramContext);
          sCache.add(new WeakReference(localObject1));
          break label188;
        }
        i = -1 + sCache.size();
        if (i >= 0)
        {
          WeakReference localWeakReference2 = (WeakReference)sCache.get(i);
          if ((localWeakReference2 != null) && (localWeakReference2.get() != null))
            break label190;
          sCache.remove(i);
          break label190;
        }
        j = -1 + sCache.size();
        if (j < 0)
          continue;
        WeakReference localWeakReference1 = (WeakReference)sCache.get(j);
        if (localWeakReference1 != null)
        {
          localObject1 = (TintContextWrapper)localWeakReference1.get();
          if ((localObject1 == null) || (((TintContextWrapper)localObject1).getBaseContext() != paramContext))
            break label180;
        }
      }
      Object localObject1 = null;
      continue;
      label180: j--;
      continue;
      localObject1 = paramContext;
      label188: return localObject1;
      label190: i--;
    }
  }

  public AssetManager getAssets()
  {
    return this.mResources.getAssets();
  }

  public Resources getResources()
  {
    return this.mResources;
  }

  public Resources.Theme getTheme()
  {
    if (this.mTheme == null);
    for (Resources.Theme localTheme = super.getTheme(); ; localTheme = this.mTheme)
      return localTheme;
  }

  public void setTheme(int paramInt)
  {
    if (this.mTheme == null)
      super.setTheme(paramInt);
    while (true)
    {
      return;
      this.mTheme.applyStyle(paramInt, true);
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.TintContextWrapper
 * JD-Core Version:    0.6.2
 */