package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import java.lang.ref.WeakReference;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public class VectorEnabledTintResources extends Resources
{
  public static final int MAX_SDK_WHERE_REQUIRED = 20;
  private static boolean sCompatVectorFromResourcesEnabled = false;
  private final WeakReference<Context> mContextRef;

  public VectorEnabledTintResources(@NonNull Context paramContext, @NonNull Resources paramResources)
  {
    super(paramResources.getAssets(), paramResources.getDisplayMetrics(), paramResources.getConfiguration());
    this.mContextRef = new WeakReference(paramContext);
  }

  public static boolean isCompatVectorFromResourcesEnabled()
  {
    return sCompatVectorFromResourcesEnabled;
  }

  public static void setCompatVectorFromResourcesEnabled(boolean paramBoolean)
  {
    sCompatVectorFromResourcesEnabled = paramBoolean;
  }

  public static boolean shouldBeUsed()
  {
    if ((isCompatVectorFromResourcesEnabled()) && (Build.VERSION.SDK_INT <= 20));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public Drawable getDrawable(int paramInt)
    throws Resources.NotFoundException
  {
    Context localContext = (Context)this.mContextRef.get();
    if (localContext != null);
    for (Drawable localDrawable = AppCompatDrawableManager.get().onDrawableLoadedFromResources(localContext, this, paramInt); ; localDrawable = super.getDrawable(paramInt))
      return localDrawable;
  }

  final Drawable superGetDrawable(int paramInt)
  {
    return super.getDrawable(paramInt);
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.VectorEnabledTintResources
 * JD-Core Version:    0.6.2
 */