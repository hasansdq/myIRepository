package androidx.appcompat.widget;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.View.OnTouchListener;
import android.view.ViewConfiguration;
import android.view.ViewParent;
import androidx.annotation.RestrictTo;
import androidx.appcompat.view.menu.ShowableListMenu;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public abstract class ForwardingListener
  implements View.OnTouchListener, View.OnAttachStateChangeListener
{
  private int mActivePointerId;
  private Runnable mDisallowIntercept;
  private boolean mForwarding;
  private final int mLongPressTimeout;
  private final float mScaledTouchSlop;
  final View mSrc;
  private final int mTapTimeout;
  private final int[] mTmpLocation = new int[2];
  private Runnable mTriggerLongPress;

  public ForwardingListener(View paramView)
  {
    this.mSrc = paramView;
    paramView.setLongClickable(true);
    paramView.addOnAttachStateChangeListener(this);
    this.mScaledTouchSlop = ViewConfiguration.get(paramView.getContext()).getScaledTouchSlop();
    this.mTapTimeout = ViewConfiguration.getTapTimeout();
    this.mLongPressTimeout = ((this.mTapTimeout + ViewConfiguration.getLongPressTimeout()) / 2);
  }

  private void clearCallbacks()
  {
    if (this.mTriggerLongPress != null)
      this.mSrc.removeCallbacks(this.mTriggerLongPress);
    if (this.mDisallowIntercept != null)
      this.mSrc.removeCallbacks(this.mDisallowIntercept);
  }

  private boolean onTouchForwarded(MotionEvent paramMotionEvent)
  {
    int i = 1;
    boolean bool1 = false;
    View localView = this.mSrc;
    ShowableListMenu localShowableListMenu = getPopup();
    if ((localShowableListMenu == null) || (!localShowableListMenu.isShowing()));
    DropDownListView localDropDownListView;
    do
    {
      return bool1;
      localDropDownListView = (DropDownListView)localShowableListMenu.getListView();
    }
    while ((localDropDownListView == null) || (!localDropDownListView.isShown()));
    MotionEvent localMotionEvent = MotionEvent.obtainNoHistory(paramMotionEvent);
    toGlobalMotionEvent(localView, localMotionEvent);
    toLocalMotionEvent(localDropDownListView, localMotionEvent);
    boolean bool2 = localDropDownListView.onForwardedEvent(localMotionEvent, this.mActivePointerId);
    localMotionEvent.recycle();
    int j = paramMotionEvent.getActionMasked();
    int k;
    if ((j != i) && (j != 3))
    {
      k = i;
      label121: if ((!bool2) || (k == 0))
        break label142;
    }
    while (true)
    {
      bool1 = i;
      break;
      k = 0;
      break label121;
      label142: i = 0;
    }
  }

  private boolean onTouchObserved(MotionEvent paramMotionEvent)
  {
    boolean bool = false;
    View localView = this.mSrc;
    if (!localView.isEnabled());
    while (true)
    {
      return bool;
      switch (paramMotionEvent.getActionMasked())
      {
      default:
        break;
      case 0:
        this.mActivePointerId = paramMotionEvent.getPointerId(0);
        if (this.mDisallowIntercept == null)
          this.mDisallowIntercept = new DisallowIntercept();
        localView.postDelayed(this.mDisallowIntercept, this.mTapTimeout);
        if (this.mTriggerLongPress == null)
          this.mTriggerLongPress = new TriggerLongPress();
        localView.postDelayed(this.mTriggerLongPress, this.mLongPressTimeout);
        break;
      case 2:
        int i = paramMotionEvent.findPointerIndex(this.mActivePointerId);
        if ((i >= 0) && (!pointInView(localView, paramMotionEvent.getX(i), paramMotionEvent.getY(i), this.mScaledTouchSlop)))
        {
          clearCallbacks();
          localView.getParent().requestDisallowInterceptTouchEvent(true);
          bool = true;
        }
        break;
      case 1:
      case 3:
        clearCallbacks();
      }
    }
  }

  private static boolean pointInView(View paramView, float paramFloat1, float paramFloat2, float paramFloat3)
  {
    if ((paramFloat1 >= -paramFloat3) && (paramFloat2 >= -paramFloat3) && (paramFloat1 < paramFloat3 + (paramView.getRight() - paramView.getLeft())) && (paramFloat2 < paramFloat3 + (paramView.getBottom() - paramView.getTop())));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private boolean toGlobalMotionEvent(View paramView, MotionEvent paramMotionEvent)
  {
    int[] arrayOfInt = this.mTmpLocation;
    paramView.getLocationOnScreen(arrayOfInt);
    paramMotionEvent.offsetLocation(arrayOfInt[0], arrayOfInt[1]);
    return true;
  }

  private boolean toLocalMotionEvent(View paramView, MotionEvent paramMotionEvent)
  {
    int[] arrayOfInt = this.mTmpLocation;
    paramView.getLocationOnScreen(arrayOfInt);
    paramMotionEvent.offsetLocation(-arrayOfInt[0], -arrayOfInt[1]);
    return true;
  }

  public abstract ShowableListMenu getPopup();

  protected boolean onForwardingStarted()
  {
    ShowableListMenu localShowableListMenu = getPopup();
    if ((localShowableListMenu != null) && (!localShowableListMenu.isShowing()))
      localShowableListMenu.show();
    return true;
  }

  protected boolean onForwardingStopped()
  {
    ShowableListMenu localShowableListMenu = getPopup();
    if ((localShowableListMenu != null) && (localShowableListMenu.isShowing()))
      localShowableListMenu.dismiss();
    return true;
  }

  void onLongPress()
  {
    clearCallbacks();
    View localView = this.mSrc;
    if ((!localView.isEnabled()) || (localView.isLongClickable()));
    while (true)
    {
      return;
      if (onForwardingStarted())
      {
        localView.getParent().requestDisallowInterceptTouchEvent(true);
        long l = SystemClock.uptimeMillis();
        MotionEvent localMotionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
        localView.onTouchEvent(localMotionEvent);
        localMotionEvent.recycle();
        this.mForwarding = true;
      }
    }
  }

  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    boolean bool1 = false;
    boolean bool2 = this.mForwarding;
    boolean bool3;
    if (bool2)
      if ((onTouchForwarded(paramMotionEvent)) || (!onForwardingStopped()))
        bool3 = true;
    label120: 
    while (true)
    {
      this.mForwarding = bool3;
      if ((bool3) || (bool2))
        bool1 = true;
      return bool1;
      bool3 = false;
      continue;
      if ((onTouchObserved(paramMotionEvent)) && (onForwardingStarted()));
      for (bool3 = true; ; bool3 = false)
      {
        if (!bool3)
          break label120;
        long l = SystemClock.uptimeMillis();
        MotionEvent localMotionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
        this.mSrc.onTouchEvent(localMotionEvent);
        localMotionEvent.recycle();
        break;
      }
    }
  }

  public void onViewAttachedToWindow(View paramView)
  {
  }

  public void onViewDetachedFromWindow(View paramView)
  {
    this.mForwarding = false;
    this.mActivePointerId = -1;
    if (this.mDisallowIntercept != null)
      this.mSrc.removeCallbacks(this.mDisallowIntercept);
  }

  private class DisallowIntercept
    implements Runnable
  {
    DisallowIntercept()
    {
    }

    public void run()
    {
      ViewParent localViewParent = ForwardingListener.this.mSrc.getParent();
      if (localViewParent != null)
        localViewParent.requestDisallowInterceptTouchEvent(true);
    }
  }

  private class TriggerLongPress
    implements Runnable
  {
    TriggerLongPress()
    {
    }

    public void run()
    {
      ForwardingListener.this.onLongPress();
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.ForwardingListener
 * JD-Core Version:    0.6.2
 */