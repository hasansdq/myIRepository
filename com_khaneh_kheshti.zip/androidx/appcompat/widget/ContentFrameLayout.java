package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View.MeasureSpec;
import android.widget.FrameLayout;
import androidx.annotation.RestrictTo;
import androidx.core.view.ViewCompat;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY})
public class ContentFrameLayout extends FrameLayout
{
  private OnAttachListener mAttachListener;
  private final Rect mDecorPadding = new Rect();
  private TypedValue mFixedHeightMajor;
  private TypedValue mFixedHeightMinor;
  private TypedValue mFixedWidthMajor;
  private TypedValue mFixedWidthMinor;
  private TypedValue mMinWidthMajor;
  private TypedValue mMinWidthMinor;

  public ContentFrameLayout(Context paramContext)
  {
    this(paramContext, null);
  }

  public ContentFrameLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public ContentFrameLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
  }

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public void dispatchFitSystemWindows(Rect paramRect)
  {
    fitSystemWindows(paramRect);
  }

  public TypedValue getFixedHeightMajor()
  {
    if (this.mFixedHeightMajor == null)
      this.mFixedHeightMajor = new TypedValue();
    return this.mFixedHeightMajor;
  }

  public TypedValue getFixedHeightMinor()
  {
    if (this.mFixedHeightMinor == null)
      this.mFixedHeightMinor = new TypedValue();
    return this.mFixedHeightMinor;
  }

  public TypedValue getFixedWidthMajor()
  {
    if (this.mFixedWidthMajor == null)
      this.mFixedWidthMajor = new TypedValue();
    return this.mFixedWidthMajor;
  }

  public TypedValue getFixedWidthMinor()
  {
    if (this.mFixedWidthMinor == null)
      this.mFixedWidthMinor = new TypedValue();
    return this.mFixedWidthMinor;
  }

  public TypedValue getMinWidthMajor()
  {
    if (this.mMinWidthMajor == null)
      this.mMinWidthMajor = new TypedValue();
    return this.mMinWidthMajor;
  }

  public TypedValue getMinWidthMinor()
  {
    if (this.mMinWidthMinor == null)
      this.mMinWidthMinor = new TypedValue();
    return this.mMinWidthMinor;
  }

  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    if (this.mAttachListener != null)
      this.mAttachListener.onAttachedFromWindow();
  }

  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    if (this.mAttachListener != null)
      this.mAttachListener.onDetachedFromWindow();
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    DisplayMetrics localDisplayMetrics = getContext().getResources().getDisplayMetrics();
    int i;
    TypedValue localTypedValue3;
    label58: int i5;
    label92: TypedValue localTypedValue2;
    label149: int i4;
    label183: int n;
    int i1;
    int i2;
    TypedValue localTypedValue1;
    label266: int i3;
    if (localDisplayMetrics.widthPixels < localDisplayMetrics.heightPixels)
    {
      i = 1;
      int j = View.MeasureSpec.getMode(paramInt1);
      int k = View.MeasureSpec.getMode(paramInt2);
      int m = 0;
      if (j == -2147483648)
      {
        if (i == 0)
          break label363;
        localTypedValue3 = this.mFixedWidthMinor;
        if ((localTypedValue3 != null) && (localTypedValue3.type != 0))
        {
          i5 = 0;
          if (localTypedValue3.type != 5)
            break label372;
          i5 = (int)localTypedValue3.getDimension(localDisplayMetrics);
          if (i5 > 0)
          {
            paramInt1 = View.MeasureSpec.makeMeasureSpec(Math.min(i5 - (this.mDecorPadding.left + this.mDecorPadding.right), View.MeasureSpec.getSize(paramInt1)), 1073741824);
            m = 1;
          }
        }
      }
      if (k == -2147483648)
      {
        if (i == 0)
          break label403;
        localTypedValue2 = this.mFixedHeightMajor;
        if ((localTypedValue2 != null) && (localTypedValue2.type != 0))
        {
          i4 = 0;
          if (localTypedValue2.type != 5)
            break label412;
          i4 = (int)localTypedValue2.getDimension(localDisplayMetrics);
          if (i4 > 0)
            paramInt2 = View.MeasureSpec.makeMeasureSpec(Math.min(i4 - (this.mDecorPadding.top + this.mDecorPadding.bottom), View.MeasureSpec.getSize(paramInt2)), 1073741824);
        }
      }
      super.onMeasure(paramInt1, paramInt2);
      n = getMeasuredWidth();
      i1 = 0;
      i2 = View.MeasureSpec.makeMeasureSpec(n, 1073741824);
      if ((m == 0) && (j == -2147483648))
      {
        if (i == 0)
          break label443;
        localTypedValue1 = this.mMinWidthMinor;
        if ((localTypedValue1 != null) && (localTypedValue1.type != 0))
        {
          i3 = 0;
          if (localTypedValue1.type != 5)
            break label452;
          i3 = (int)localTypedValue1.getDimension(localDisplayMetrics);
        }
      }
    }
    while (true)
    {
      if (i3 > 0)
        i3 -= this.mDecorPadding.left + this.mDecorPadding.right;
      if (n < i3)
      {
        i2 = View.MeasureSpec.makeMeasureSpec(i3, 1073741824);
        i1 = 1;
      }
      if (i1 != 0)
        super.onMeasure(i2, paramInt2);
      return;
      i = 0;
      break;
      label363: localTypedValue3 = this.mFixedWidthMajor;
      break label58;
      label372: if (localTypedValue3.type != 6)
        break label92;
      i5 = (int)localTypedValue3.getFraction(localDisplayMetrics.widthPixels, localDisplayMetrics.widthPixels);
      break label92;
      label403: localTypedValue2 = this.mFixedHeightMinor;
      break label149;
      label412: if (localTypedValue2.type != 6)
        break label183;
      i4 = (int)localTypedValue2.getFraction(localDisplayMetrics.heightPixels, localDisplayMetrics.heightPixels);
      break label183;
      label443: localTypedValue1 = this.mMinWidthMajor;
      break label266;
      label452: if (localTypedValue1.type == 6)
        i3 = (int)localTypedValue1.getFraction(localDisplayMetrics.widthPixels, localDisplayMetrics.widthPixels);
    }
  }

  public void setAttachListener(OnAttachListener paramOnAttachListener)
  {
    this.mAttachListener = paramOnAttachListener;
  }

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public void setDecorPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.mDecorPadding.set(paramInt1, paramInt2, paramInt3, paramInt4);
    if (ViewCompat.isLaidOut(this))
      requestLayout();
  }

  public static abstract interface OnAttachListener
  {
    public abstract void onAttachedFromWindow();

    public abstract void onDetachedFromWindow();
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.ContentFrameLayout
 * JD-Core Version:    0.6.2
 */