package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import androidx.annotation.DrawableRes;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R.attr;
import androidx.appcompat.R.layout;
import androidx.appcompat.R.styleable;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.appcompat.view.ContextThemeWrapper;
import androidx.appcompat.view.menu.ShowableListMenu;
import androidx.core.view.TintableBackgroundView;
import androidx.core.view.ViewCompat;

public class AppCompatSpinner extends Spinner
  implements TintableBackgroundView
{
  private static final int[] ATTRS_ANDROID_SPINNERMODE = { 16843505 };
  private static final int MAX_ITEMS_MEASURED = 15;
  private static final int MODE_DIALOG = 0;
  private static final int MODE_DROPDOWN = 1;
  private static final int MODE_THEME = -1;
  private static final String TAG = "AppCompatSpinner";
  private final AppCompatBackgroundHelper mBackgroundTintHelper;
  int mDropDownWidth;
  private ForwardingListener mForwardingListener;
  DropdownPopup mPopup;
  private final Context mPopupContext;
  private final boolean mPopupSet;
  private SpinnerAdapter mTempAdapter;
  final Rect mTempRect = new Rect();

  public AppCompatSpinner(Context paramContext)
  {
    this(paramContext, null);
  }

  public AppCompatSpinner(Context paramContext, int paramInt)
  {
    this(paramContext, null, R.attr.spinnerStyle, paramInt);
  }

  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, R.attr.spinnerStyle);
  }

  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    this(paramContext, paramAttributeSet, paramInt, -1);
  }

  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    this(paramContext, paramAttributeSet, paramInt1, paramInt2, null);
  }

  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2, Resources.Theme paramTheme)
  {
    super(paramContext, paramAttributeSet, paramInt1);
    TintTypedArray localTintTypedArray1 = TintTypedArray.obtainStyledAttributes(paramContext, paramAttributeSet, R.styleable.Spinner, paramInt1, 0);
    this.mBackgroundTintHelper = new AppCompatBackgroundHelper(this);
    if (paramTheme != null)
      this.mPopupContext = new ContextThemeWrapper(paramContext, paramTheme);
    while (true)
    {
      TypedArray localTypedArray;
      if (this.mPopupContext != null)
        if (paramInt2 == -1)
          localTypedArray = null;
      try
      {
        localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, ATTRS_ANDROID_SPINNERMODE, paramInt1, 0);
        if (localTypedArray.hasValue(0))
        {
          int j = localTypedArray.getInt(0, 0);
          paramInt2 = j;
        }
        if (localTypedArray != null)
          localTypedArray.recycle();
        if (paramInt2 == 1)
        {
          final DropdownPopup localDropdownPopup = new DropdownPopup(this.mPopupContext, paramAttributeSet, paramInt1);
          TintTypedArray localTintTypedArray2 = TintTypedArray.obtainStyledAttributes(this.mPopupContext, paramAttributeSet, R.styleable.Spinner, paramInt1, 0);
          this.mDropDownWidth = localTintTypedArray2.getLayoutDimension(R.styleable.Spinner_android_dropDownWidth, -2);
          localDropdownPopup.setBackgroundDrawable(localTintTypedArray2.getDrawable(R.styleable.Spinner_android_popupBackground));
          localDropdownPopup.setPromptText(localTintTypedArray1.getString(R.styleable.Spinner_android_prompt));
          localTintTypedArray2.recycle();
          this.mPopup = localDropdownPopup;
          this.mForwardingListener = new ForwardingListener(this)
          {
            public ShowableListMenu getPopup()
            {
              return localDropdownPopup;
            }

            public boolean onForwardingStarted()
            {
              if (!AppCompatSpinner.this.mPopup.isShowing())
                AppCompatSpinner.this.mPopup.show();
              return true;
            }
          };
        }
        CharSequence[] arrayOfCharSequence = localTintTypedArray1.getTextArray(R.styleable.Spinner_android_entries);
        if (arrayOfCharSequence != null)
        {
          ArrayAdapter localArrayAdapter = new ArrayAdapter(paramContext, 17367048, arrayOfCharSequence);
          localArrayAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
          setAdapter(localArrayAdapter);
        }
        localTintTypedArray1.recycle();
        this.mPopupSet = true;
        if (this.mTempAdapter != null)
        {
          setAdapter(this.mTempAdapter);
          this.mTempAdapter = null;
        }
        this.mBackgroundTintHelper.loadFromAttributes(paramAttributeSet, paramInt1);
        return;
        int i = localTintTypedArray1.getResourceId(R.styleable.Spinner_popupTheme, 0);
        if (i != 0)
        {
          this.mPopupContext = new ContextThemeWrapper(paramContext, i);
          continue;
        }
        if (Build.VERSION.SDK_INT < 23);
        for (Context localContext = paramContext; ; localContext = null)
        {
          this.mPopupContext = localContext;
          break;
        }
      }
      catch (Exception localException)
      {
        while (true)
        {
          Log.i("AppCompatSpinner", "Could not read android:spinnerMode", localException);
          if (localTypedArray != null)
            localTypedArray.recycle();
        }
      }
      finally
      {
        if (localTypedArray != null)
          localTypedArray.recycle();
      }
    }
  }

  int compatMeasureContentWidth(SpinnerAdapter paramSpinnerAdapter, Drawable paramDrawable)
  {
    int i;
    if (paramSpinnerAdapter == null)
      i = 0;
    while (true)
    {
      return i;
      i = 0;
      View localView = null;
      int j = 0;
      int k = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
      int m = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
      int n = Math.max(0, getSelectedItemPosition());
      int i1 = Math.min(paramSpinnerAdapter.getCount(), n + 15);
      for (int i2 = Math.max(0, n - (15 - (i1 - n))); i2 < i1; i2++)
      {
        int i3 = paramSpinnerAdapter.getItemViewType(i2);
        if (i3 != j)
        {
          j = i3;
          localView = null;
        }
        localView = paramSpinnerAdapter.getView(i2, localView, this);
        if (localView.getLayoutParams() == null)
          localView.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
        localView.measure(k, m);
        i = Math.max(i, localView.getMeasuredWidth());
      }
      if (paramDrawable != null)
      {
        paramDrawable.getPadding(this.mTempRect);
        i += this.mTempRect.left + this.mTempRect.right;
      }
    }
  }

  protected void drawableStateChanged()
  {
    super.drawableStateChanged();
    if (this.mBackgroundTintHelper != null)
      this.mBackgroundTintHelper.applySupportBackgroundTint();
  }

  public int getDropDownHorizontalOffset()
  {
    int i;
    if (this.mPopup != null)
      i = this.mPopup.getHorizontalOffset();
    while (true)
    {
      return i;
      if (Build.VERSION.SDK_INT >= 16)
        i = super.getDropDownHorizontalOffset();
      else
        i = 0;
    }
  }

  public int getDropDownVerticalOffset()
  {
    int i;
    if (this.mPopup != null)
      i = this.mPopup.getVerticalOffset();
    while (true)
    {
      return i;
      if (Build.VERSION.SDK_INT >= 16)
        i = super.getDropDownVerticalOffset();
      else
        i = 0;
    }
  }

  public int getDropDownWidth()
  {
    int i;
    if (this.mPopup != null)
      i = this.mDropDownWidth;
    while (true)
    {
      return i;
      if (Build.VERSION.SDK_INT >= 16)
        i = super.getDropDownWidth();
      else
        i = 0;
    }
  }

  public Drawable getPopupBackground()
  {
    Drawable localDrawable;
    if (this.mPopup != null)
      localDrawable = this.mPopup.getBackground();
    while (true)
    {
      return localDrawable;
      if (Build.VERSION.SDK_INT >= 16)
        localDrawable = super.getPopupBackground();
      else
        localDrawable = null;
    }
  }

  public Context getPopupContext()
  {
    Context localContext;
    if (this.mPopup != null)
      localContext = this.mPopupContext;
    while (true)
    {
      return localContext;
      if (Build.VERSION.SDK_INT >= 23)
        localContext = super.getPopupContext();
      else
        localContext = null;
    }
  }

  public CharSequence getPrompt()
  {
    if (this.mPopup != null);
    for (CharSequence localCharSequence = this.mPopup.getHintText(); ; localCharSequence = super.getPrompt())
      return localCharSequence;
  }

  @Nullable
  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public ColorStateList getSupportBackgroundTintList()
  {
    if (this.mBackgroundTintHelper != null);
    for (ColorStateList localColorStateList = this.mBackgroundTintHelper.getSupportBackgroundTintList(); ; localColorStateList = null)
      return localColorStateList;
  }

  @Nullable
  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public PorterDuff.Mode getSupportBackgroundTintMode()
  {
    if (this.mBackgroundTintHelper != null);
    for (PorterDuff.Mode localMode = this.mBackgroundTintHelper.getSupportBackgroundTintMode(); ; localMode = null)
      return localMode;
  }

  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    if ((this.mPopup != null) && (this.mPopup.isShowing()))
      this.mPopup.dismiss();
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    super.onMeasure(paramInt1, paramInt2);
    if ((this.mPopup != null) && (View.MeasureSpec.getMode(paramInt1) == -2147483648))
      setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), compatMeasureContentWidth(getAdapter(), getBackground())), View.MeasureSpec.getSize(paramInt1)), getMeasuredHeight());
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    if ((this.mForwardingListener != null) && (this.mForwardingListener.onTouch(this, paramMotionEvent)));
    for (boolean bool = true; ; bool = super.onTouchEvent(paramMotionEvent))
      return bool;
  }

  public boolean performClick()
  {
    if (this.mPopup != null)
      if (!this.mPopup.isShowing())
        this.mPopup.show();
    for (boolean bool = true; ; bool = super.performClick())
      return bool;
  }

  public void setAdapter(SpinnerAdapter paramSpinnerAdapter)
  {
    if (!this.mPopupSet)
      this.mTempAdapter = paramSpinnerAdapter;
    do
    {
      return;
      super.setAdapter(paramSpinnerAdapter);
    }
    while (this.mPopup == null);
    if (this.mPopupContext == null);
    for (Context localContext = getContext(); ; localContext = this.mPopupContext)
    {
      this.mPopup.setAdapter(new DropDownAdapter(paramSpinnerAdapter, localContext.getTheme()));
      break;
    }
  }

  public void setBackgroundDrawable(Drawable paramDrawable)
  {
    super.setBackgroundDrawable(paramDrawable);
    if (this.mBackgroundTintHelper != null)
      this.mBackgroundTintHelper.onSetBackgroundDrawable(paramDrawable);
  }

  public void setBackgroundResource(@DrawableRes int paramInt)
  {
    super.setBackgroundResource(paramInt);
    if (this.mBackgroundTintHelper != null)
      this.mBackgroundTintHelper.onSetBackgroundResource(paramInt);
  }

  public void setDropDownHorizontalOffset(int paramInt)
  {
    if (this.mPopup != null)
      this.mPopup.setHorizontalOffset(paramInt);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 16)
        super.setDropDownHorizontalOffset(paramInt);
    }
  }

  public void setDropDownVerticalOffset(int paramInt)
  {
    if (this.mPopup != null)
      this.mPopup.setVerticalOffset(paramInt);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 16)
        super.setDropDownVerticalOffset(paramInt);
    }
  }

  public void setDropDownWidth(int paramInt)
  {
    if (this.mPopup != null)
      this.mDropDownWidth = paramInt;
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 16)
        super.setDropDownWidth(paramInt);
    }
  }

  public void setPopupBackgroundDrawable(Drawable paramDrawable)
  {
    if (this.mPopup != null)
      this.mPopup.setBackgroundDrawable(paramDrawable);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 16)
        super.setPopupBackgroundDrawable(paramDrawable);
    }
  }

  public void setPopupBackgroundResource(@DrawableRes int paramInt)
  {
    setPopupBackgroundDrawable(AppCompatResources.getDrawable(getPopupContext(), paramInt));
  }

  public void setPrompt(CharSequence paramCharSequence)
  {
    if (this.mPopup != null)
      this.mPopup.setPromptText(paramCharSequence);
    while (true)
    {
      return;
      super.setPrompt(paramCharSequence);
    }
  }

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public void setSupportBackgroundTintList(@Nullable ColorStateList paramColorStateList)
  {
    if (this.mBackgroundTintHelper != null)
      this.mBackgroundTintHelper.setSupportBackgroundTintList(paramColorStateList);
  }

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public void setSupportBackgroundTintMode(@Nullable PorterDuff.Mode paramMode)
  {
    if (this.mBackgroundTintHelper != null)
      this.mBackgroundTintHelper.setSupportBackgroundTintMode(paramMode);
  }

  private static class DropDownAdapter
    implements ListAdapter, SpinnerAdapter
  {
    private SpinnerAdapter mAdapter;
    private ListAdapter mListAdapter;

    public DropDownAdapter(@Nullable SpinnerAdapter paramSpinnerAdapter, @Nullable Resources.Theme paramTheme)
    {
      this.mAdapter = paramSpinnerAdapter;
      if ((paramSpinnerAdapter instanceof SpinnerAdapter))
        this.mListAdapter = ((SpinnerAdapter)paramSpinnerAdapter);
      if (paramTheme != null)
      {
        if ((Build.VERSION.SDK_INT < 23) || (!(paramSpinnerAdapter instanceof android.widget.ThemedSpinnerAdapter)))
          break label69;
        android.widget.ThemedSpinnerAdapter localThemedSpinnerAdapter1 = (android.widget.ThemedSpinnerAdapter)paramSpinnerAdapter;
        if (localThemedSpinnerAdapter1.getDropDownViewTheme() != paramTheme)
          localThemedSpinnerAdapter1.setDropDownViewTheme(paramTheme);
      }
      while (true)
      {
        return;
        label69: if ((paramSpinnerAdapter instanceof ThemedSpinnerAdapter))
        {
          ThemedSpinnerAdapter localThemedSpinnerAdapter = (ThemedSpinnerAdapter)paramSpinnerAdapter;
          if (localThemedSpinnerAdapter.getDropDownViewTheme() == null)
            localThemedSpinnerAdapter.setDropDownViewTheme(paramTheme);
        }
      }
    }

    public boolean areAllItemsEnabled()
    {
      ListAdapter localListAdapter = this.mListAdapter;
      if (localListAdapter != null);
      for (boolean bool = localListAdapter.areAllItemsEnabled(); ; bool = true)
        return bool;
    }

    public int getCount()
    {
      if (this.mAdapter == null);
      for (int i = 0; ; i = this.mAdapter.getCount())
        return i;
    }

    public View getDropDownView(int paramInt, View paramView, ViewGroup paramViewGroup)
    {
      if (this.mAdapter == null);
      for (View localView = null; ; localView = this.mAdapter.getDropDownView(paramInt, paramView, paramViewGroup))
        return localView;
    }

    public Object getItem(int paramInt)
    {
      if (this.mAdapter == null);
      for (Object localObject = null; ; localObject = this.mAdapter.getItem(paramInt))
        return localObject;
    }

    public long getItemId(int paramInt)
    {
      if (this.mAdapter == null);
      for (long l = -1L; ; l = this.mAdapter.getItemId(paramInt))
        return l;
    }

    public int getItemViewType(int paramInt)
    {
      return 0;
    }

    public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
    {
      return getDropDownView(paramInt, paramView, paramViewGroup);
    }

    public int getViewTypeCount()
    {
      return 1;
    }

    public boolean hasStableIds()
    {
      if ((this.mAdapter != null) && (this.mAdapter.hasStableIds()));
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    public boolean isEmpty()
    {
      if (getCount() == 0);
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    public boolean isEnabled(int paramInt)
    {
      ListAdapter localListAdapter = this.mListAdapter;
      if (localListAdapter != null);
      for (boolean bool = localListAdapter.isEnabled(paramInt); ; bool = true)
        return bool;
    }

    public void registerDataSetObserver(DataSetObserver paramDataSetObserver)
    {
      if (this.mAdapter != null)
        this.mAdapter.registerDataSetObserver(paramDataSetObserver);
    }

    public void unregisterDataSetObserver(DataSetObserver paramDataSetObserver)
    {
      if (this.mAdapter != null)
        this.mAdapter.unregisterDataSetObserver(paramDataSetObserver);
    }
  }

  private class DropdownPopup extends ListPopupWindow
  {
    ListAdapter mAdapter;
    private CharSequence mHintText;
    private final Rect mVisibleRect = new Rect();

    public DropdownPopup(Context paramAttributeSet, AttributeSet paramInt, int arg4)
    {
      super(paramInt, i);
      setAnchorView(AppCompatSpinner.this);
      setModal(true);
      setPromptPosition(0);
      setOnItemClickListener(new AdapterView.OnItemClickListener()
      {
        public void onItemClick(AdapterView<?> paramAnonymousAdapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong)
        {
          AppCompatSpinner.this.setSelection(paramAnonymousInt);
          if (AppCompatSpinner.this.getOnItemClickListener() != null)
            AppCompatSpinner.this.performItemClick(paramAnonymousView, paramAnonymousInt, AppCompatSpinner.DropdownPopup.this.mAdapter.getItemId(paramAnonymousInt));
          AppCompatSpinner.DropdownPopup.this.dismiss();
        }
      });
    }

    void computeContentWidth()
    {
      Drawable localDrawable = getBackground();
      int i = 0;
      int j;
      int k;
      int m;
      if (localDrawable != null)
      {
        localDrawable.getPadding(AppCompatSpinner.this.mTempRect);
        if (ViewUtils.isLayoutRtl(AppCompatSpinner.this))
        {
          i = AppCompatSpinner.this.mTempRect.right;
          j = AppCompatSpinner.this.getPaddingLeft();
          k = AppCompatSpinner.this.getPaddingRight();
          m = AppCompatSpinner.this.getWidth();
          if (AppCompatSpinner.this.mDropDownWidth != -2)
            break label244;
          int i1 = AppCompatSpinner.this.compatMeasureContentWidth((SpinnerAdapter)this.mAdapter, getBackground());
          int i2 = AppCompatSpinner.this.getContext().getResources().getDisplayMetrics().widthPixels - AppCompatSpinner.this.mTempRect.left - AppCompatSpinner.this.mTempRect.right;
          if (i1 > i2)
            i1 = i2;
          setContentWidth(Math.max(i1, m - j - k));
          label171: if (!ViewUtils.isLayoutRtl(AppCompatSpinner.this))
            break label284;
        }
      }
      label284: for (int n = i + (m - k - getWidth()); ; n = i + j)
      {
        setHorizontalOffset(n);
        return;
        i = -AppCompatSpinner.this.mTempRect.left;
        break;
        Rect localRect = AppCompatSpinner.this.mTempRect;
        AppCompatSpinner.this.mTempRect.right = 0;
        localRect.left = 0;
        break;
        label244: if (AppCompatSpinner.this.mDropDownWidth == -1)
        {
          setContentWidth(m - j - k);
          break label171;
        }
        setContentWidth(AppCompatSpinner.this.mDropDownWidth);
        break label171;
      }
    }

    public CharSequence getHintText()
    {
      return this.mHintText;
    }

    boolean isVisibleToUser(View paramView)
    {
      if ((ViewCompat.isAttachedToWindow(paramView)) && (paramView.getGlobalVisibleRect(this.mVisibleRect)));
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    public void setAdapter(ListAdapter paramListAdapter)
    {
      super.setAdapter(paramListAdapter);
      this.mAdapter = paramListAdapter;
    }

    public void setPromptText(CharSequence paramCharSequence)
    {
      this.mHintText = paramCharSequence;
    }

    public void show()
    {
      boolean bool = isShowing();
      computeContentWidth();
      setInputMethodMode(2);
      super.show();
      getListView().setChoiceMode(1);
      setSelection(AppCompatSpinner.this.getSelectedItemPosition());
      if (bool);
      while (true)
      {
        return;
        ViewTreeObserver localViewTreeObserver = AppCompatSpinner.this.getViewTreeObserver();
        if (localViewTreeObserver != null)
        {
          final ViewTreeObserver.OnGlobalLayoutListener local2 = new ViewTreeObserver.OnGlobalLayoutListener()
          {
            public void onGlobalLayout()
            {
              if (!AppCompatSpinner.DropdownPopup.this.isVisibleToUser(AppCompatSpinner.this))
                AppCompatSpinner.DropdownPopup.this.dismiss();
              while (true)
              {
                return;
                AppCompatSpinner.DropdownPopup.this.computeContentWidth();
                AppCompatSpinner.DropdownPopup.this.show();
              }
            }
          };
          localViewTreeObserver.addOnGlobalLayoutListener(local2);
          setOnDismissListener(new PopupWindow.OnDismissListener()
          {
            public void onDismiss()
            {
              ViewTreeObserver localViewTreeObserver = AppCompatSpinner.this.getViewTreeObserver();
              if (localViewTreeObserver != null)
                localViewTreeObserver.removeGlobalOnLayoutListener(local2);
            }
          });
        }
      }
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.AppCompatSpinner
 * JD-Core Version:    0.6.2
 */