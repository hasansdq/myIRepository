package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.widget.AbsListView;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.appcompat.R.attr;
import androidx.appcompat.graphics.drawable.DrawableWrapper;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.core.view.ViewPropertyAnimatorCompat;
import androidx.core.widget.ListViewAutoScrollHelper;
import java.lang.reflect.Field;

class DropDownListView extends ListView
{
  public static final int INVALID_POSITION = -1;
  public static final int NO_POSITION = -1;
  private ViewPropertyAnimatorCompat mClickAnimation;
  private boolean mDrawsInPressedState;
  private boolean mHijackFocus;
  private Field mIsChildViewEnabled;
  private boolean mListSelectionHidden;
  private int mMotionPosition;
  ResolveHoverRunnable mResolveHoverRunnable;
  private ListViewAutoScrollHelper mScrollHelper;
  private int mSelectionBottomPadding = 0;
  private int mSelectionLeftPadding = 0;
  private int mSelectionRightPadding = 0;
  private int mSelectionTopPadding = 0;
  private GateKeeperDrawable mSelector;
  private final Rect mSelectorRect = new Rect();

  DropDownListView(Context paramContext, boolean paramBoolean)
  {
    super(paramContext, null, R.attr.dropDownListViewStyle);
    this.mHijackFocus = paramBoolean;
    setCacheColorHint(0);
    try
    {
      this.mIsChildViewEnabled = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
      this.mIsChildViewEnabled.setAccessible(true);
      return;
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      while (true)
        localNoSuchFieldException.printStackTrace();
    }
  }

  private void clearPressedItem()
  {
    this.mDrawsInPressedState = false;
    setPressed(false);
    drawableStateChanged();
    View localView = getChildAt(this.mMotionPosition - getFirstVisiblePosition());
    if (localView != null)
      localView.setPressed(false);
    if (this.mClickAnimation != null)
    {
      this.mClickAnimation.cancel();
      this.mClickAnimation = null;
    }
  }

  private void clickPressedItem(View paramView, int paramInt)
  {
    performItemClick(paramView, paramInt, getItemIdAtPosition(paramInt));
  }

  private void drawSelectorCompat(Canvas paramCanvas)
  {
    if (!this.mSelectorRect.isEmpty())
    {
      Drawable localDrawable = getSelector();
      if (localDrawable != null)
      {
        localDrawable.setBounds(this.mSelectorRect);
        localDrawable.draw(paramCanvas);
      }
    }
  }

  private void positionSelectorCompat(int paramInt, View paramView)
  {
    Rect localRect = this.mSelectorRect;
    localRect.set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
    localRect.left -= this.mSelectionLeftPadding;
    localRect.top -= this.mSelectionTopPadding;
    localRect.right += this.mSelectionRightPadding;
    localRect.bottom += this.mSelectionBottomPadding;
    try
    {
      boolean bool1 = this.mIsChildViewEnabled.getBoolean(this);
      Field localField;
      if (paramView.isEnabled() != bool1)
      {
        localField = this.mIsChildViewEnabled;
        if (bool1)
          break label131;
      }
      label131: for (boolean bool2 = true; ; bool2 = false)
      {
        localField.set(this, Boolean.valueOf(bool2));
        if (paramInt != -1)
          refreshDrawableState();
        return;
      }
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      while (true)
        localIllegalAccessException.printStackTrace();
    }
  }

  private void positionSelectorLikeFocusCompat(int paramInt, View paramView)
  {
    boolean bool1 = true;
    Drawable localDrawable = getSelector();
    boolean bool2;
    float f1;
    float f2;
    if ((localDrawable != null) && (paramInt != -1))
    {
      bool2 = bool1;
      if (bool2)
        localDrawable.setVisible(false, false);
      positionSelectorCompat(paramInt, paramView);
      if (bool2)
      {
        Rect localRect = this.mSelectorRect;
        f1 = localRect.exactCenterX();
        f2 = localRect.exactCenterY();
        if (getVisibility() != 0)
          break label96;
      }
    }
    while (true)
    {
      localDrawable.setVisible(bool1, false);
      DrawableCompat.setHotspot(localDrawable, f1, f2);
      return;
      bool2 = false;
      break;
      label96: bool1 = false;
    }
  }

  private void positionSelectorLikeTouchCompat(int paramInt, View paramView, float paramFloat1, float paramFloat2)
  {
    positionSelectorLikeFocusCompat(paramInt, paramView);
    Drawable localDrawable = getSelector();
    if ((localDrawable != null) && (paramInt != -1))
      DrawableCompat.setHotspot(localDrawable, paramFloat1, paramFloat2);
  }

  private void setPressedItem(View paramView, int paramInt, float paramFloat1, float paramFloat2)
  {
    this.mDrawsInPressedState = true;
    if (Build.VERSION.SDK_INT >= 21)
      drawableHotspotChanged(paramFloat1, paramFloat2);
    if (!isPressed())
      setPressed(true);
    layoutChildren();
    if (this.mMotionPosition != -1)
    {
      View localView = getChildAt(this.mMotionPosition - getFirstVisiblePosition());
      if ((localView != null) && (localView != paramView) && (localView.isPressed()))
        localView.setPressed(false);
    }
    this.mMotionPosition = paramInt;
    float f1 = paramFloat1 - paramView.getLeft();
    float f2 = paramFloat2 - paramView.getTop();
    if (Build.VERSION.SDK_INT >= 21)
      paramView.drawableHotspotChanged(f1, f2);
    if (!paramView.isPressed())
      paramView.setPressed(true);
    positionSelectorLikeTouchCompat(paramInt, paramView, paramFloat1, paramFloat2);
    setSelectorEnabled(false);
    refreshDrawableState();
  }

  private void setSelectorEnabled(boolean paramBoolean)
  {
    if (this.mSelector != null)
      this.mSelector.setEnabled(paramBoolean);
  }

  private boolean touchModeDrawsInPressedStateCompat()
  {
    return this.mDrawsInPressedState;
  }

  private void updateSelectorStateCompat()
  {
    Drawable localDrawable = getSelector();
    if ((localDrawable != null) && (touchModeDrawsInPressedStateCompat()) && (isPressed()))
      localDrawable.setState(getDrawableState());
  }

  protected void dispatchDraw(Canvas paramCanvas)
  {
    drawSelectorCompat(paramCanvas);
    super.dispatchDraw(paramCanvas);
  }

  protected void drawableStateChanged()
  {
    if (this.mResolveHoverRunnable != null);
    while (true)
    {
      return;
      super.drawableStateChanged();
      setSelectorEnabled(true);
      updateSelectorStateCompat();
    }
  }

  public boolean hasFocus()
  {
    if ((this.mHijackFocus) || (super.hasFocus()));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean hasWindowFocus()
  {
    if ((this.mHijackFocus) || (super.hasWindowFocus()));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isFocused()
  {
    if ((this.mHijackFocus) || (super.isFocused()));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isInTouchMode()
  {
    if (((this.mHijackFocus) && (this.mListSelectionHidden)) || (super.isInTouchMode()));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public int lookForSelectablePosition(int paramInt, boolean paramBoolean)
  {
    int i = -1;
    ListAdapter localListAdapter = getAdapter();
    if ((localListAdapter == null) || (isInTouchMode()));
    while (true)
    {
      return i;
      int j = localListAdapter.getCount();
      if (!getAdapter().areAllItemsEnabled())
      {
        if (paramBoolean)
          for (k = Math.max(0, paramInt); (k < j) && (!localListAdapter.isEnabled(k)); k++);
        for (int k = Math.min(paramInt, j - 1); (k >= 0) && (!localListAdapter.isEnabled(k)); k--);
        if ((k >= 0) && (k < j))
          i = k;
      }
      else if ((paramInt >= 0) && (paramInt < j))
      {
        i = paramInt;
      }
    }
  }

  public int measureHeightOfChildrenCompat(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    int i = getListPaddingTop();
    int j = getListPaddingBottom();
    getListPaddingLeft();
    getListPaddingRight();
    int k = getDividerHeight();
    Drawable localDrawable = getDivider();
    ListAdapter localListAdapter = getAdapter();
    int i1;
    if (localListAdapter == null)
      i1 = i + j;
    while (true)
    {
      return i1;
      int m = i + j;
      int n;
      label76: View localView;
      int i2;
      int i3;
      if ((k > 0) && (localDrawable != null))
      {
        n = k;
        i1 = 0;
        localView = null;
        i2 = 0;
        i3 = localListAdapter.getCount();
      }
      for (int i4 = 0; ; i4++)
      {
        if (i4 >= i3)
          break label300;
        int i5 = localListAdapter.getItemViewType(i4);
        if (i5 != i2)
        {
          localView = null;
          i2 = i5;
        }
        localView = localListAdapter.getView(i4, localView, this);
        ViewGroup.LayoutParams localLayoutParams = localView.getLayoutParams();
        if (localLayoutParams == null)
        {
          localLayoutParams = generateDefaultLayoutParams();
          localView.setLayoutParams(localLayoutParams);
        }
        if (localLayoutParams.height > 0);
        for (int i6 = View.MeasureSpec.makeMeasureSpec(localLayoutParams.height, 1073741824); ; i6 = View.MeasureSpec.makeMeasureSpec(0, 0))
        {
          localView.measure(paramInt1, i6);
          localView.forceLayout();
          if (i4 > 0)
            m += n;
          m += localView.getMeasuredHeight();
          if (m < paramInt4)
            break label278;
          if ((paramInt5 >= 0) && (i4 > paramInt5) && (i1 > 0) && (m != paramInt4))
            break;
          i1 = paramInt4;
          break;
          n = 0;
          break label76;
        }
        label278: if ((paramInt5 >= 0) && (i4 >= paramInt5))
          i1 = m;
      }
      label300: i1 = m;
    }
  }

  protected void onDetachedFromWindow()
  {
    this.mResolveHoverRunnable = null;
    super.onDetachedFromWindow();
  }

  public boolean onForwardedEvent(MotionEvent paramMotionEvent, int paramInt)
  {
    boolean bool = true;
    int i = 0;
    int j = paramMotionEvent.getActionMasked();
    switch (j)
    {
    default:
      if ((!bool) || (i != 0))
        clearPressedItem();
      if (bool)
      {
        if (this.mScrollHelper == null)
          this.mScrollHelper = new ListViewAutoScrollHelper(this);
        this.mScrollHelper.setEnabled(true);
        this.mScrollHelper.onTouch(this, paramMotionEvent);
      }
      break;
    case 3:
    case 1:
    case 2:
    }
    while (true)
    {
      return bool;
      bool = false;
      break;
      bool = false;
      int k = paramMotionEvent.findPointerIndex(paramInt);
      if (k < 0)
      {
        bool = false;
        break;
      }
      int m = (int)paramMotionEvent.getX(k);
      int n = (int)paramMotionEvent.getY(k);
      int i1 = pointToPosition(m, n);
      if (i1 == -1)
      {
        i = 1;
        break;
      }
      View localView = getChildAt(i1 - getFirstVisiblePosition());
      setPressedItem(localView, i1, m, n);
      bool = true;
      if (j != 1)
        break;
      clickPressedItem(localView, i1);
      break;
      if (this.mScrollHelper != null)
        this.mScrollHelper.setEnabled(false);
    }
  }

  public boolean onHoverEvent(@NonNull MotionEvent paramMotionEvent)
  {
    boolean bool;
    if (Build.VERSION.SDK_INT < 26)
      bool = super.onHoverEvent(paramMotionEvent);
    while (true)
    {
      return bool;
      int i = paramMotionEvent.getActionMasked();
      if ((i == 10) && (this.mResolveHoverRunnable == null))
      {
        this.mResolveHoverRunnable = new ResolveHoverRunnable();
        this.mResolveHoverRunnable.post();
      }
      bool = super.onHoverEvent(paramMotionEvent);
      if ((i == 9) || (i == 7))
      {
        int j = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY());
        if ((j != -1) && (j != getSelectedItemPosition()))
        {
          View localView = getChildAt(j - getFirstVisiblePosition());
          if (localView.isEnabled())
            setSelectionFromTop(j, localView.getTop() - getTop());
          updateSelectorStateCompat();
        }
      }
      else
      {
        setSelection(-1);
      }
    }
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    switch (paramMotionEvent.getAction())
    {
    default:
    case 0:
    }
    while (true)
    {
      if (this.mResolveHoverRunnable != null)
        this.mResolveHoverRunnable.cancel();
      return super.onTouchEvent(paramMotionEvent);
      this.mMotionPosition = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY());
    }
  }

  void setListSelectionHidden(boolean paramBoolean)
  {
    this.mListSelectionHidden = paramBoolean;
  }

  public void setSelector(Drawable paramDrawable)
  {
    if (paramDrawable != null);
    for (GateKeeperDrawable localGateKeeperDrawable = new GateKeeperDrawable(paramDrawable); ; localGateKeeperDrawable = null)
    {
      this.mSelector = localGateKeeperDrawable;
      super.setSelector(this.mSelector);
      Rect localRect = new Rect();
      if (paramDrawable != null)
        paramDrawable.getPadding(localRect);
      this.mSelectionLeftPadding = localRect.left;
      this.mSelectionTopPadding = localRect.top;
      this.mSelectionRightPadding = localRect.right;
      this.mSelectionBottomPadding = localRect.bottom;
      return;
    }
  }

  private static class GateKeeperDrawable extends DrawableWrapper
  {
    private boolean mEnabled = true;

    GateKeeperDrawable(Drawable paramDrawable)
    {
      super();
    }

    public void draw(Canvas paramCanvas)
    {
      if (this.mEnabled)
        super.draw(paramCanvas);
    }

    void setEnabled(boolean paramBoolean)
    {
      this.mEnabled = paramBoolean;
    }

    public void setHotspot(float paramFloat1, float paramFloat2)
    {
      if (this.mEnabled)
        super.setHotspot(paramFloat1, paramFloat2);
    }

    public void setHotspotBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      if (this.mEnabled)
        super.setHotspotBounds(paramInt1, paramInt2, paramInt3, paramInt4);
    }

    public boolean setState(int[] paramArrayOfInt)
    {
      if (this.mEnabled);
      for (boolean bool = super.setState(paramArrayOfInt); ; bool = false)
        return bool;
    }

    public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2)
    {
      if (this.mEnabled);
      for (boolean bool = super.setVisible(paramBoolean1, paramBoolean2); ; bool = false)
        return bool;
    }
  }

  private class ResolveHoverRunnable
    implements Runnable
  {
    ResolveHoverRunnable()
    {
    }

    public void cancel()
    {
      DropDownListView.this.mResolveHoverRunnable = null;
      DropDownListView.this.removeCallbacks(this);
    }

    public void post()
    {
      DropDownListView.this.post(this);
    }

    public void run()
    {
      DropDownListView.this.mResolveHoverRunnable = null;
      DropDownListView.this.drawableStateChanged();
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.DropDownListView
 * JD-Core Version:    0.6.2
 */