package androidx.appcompat.widget;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.DataSetObservable;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;
import android.util.Xml;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

class ActivityChooserModel extends DataSetObservable
{
  static final String ATTRIBUTE_ACTIVITY = "activity";
  static final String ATTRIBUTE_TIME = "time";
  static final String ATTRIBUTE_WEIGHT = "weight";
  static final boolean DEBUG = false;
  private static final int DEFAULT_ACTIVITY_INFLATION = 5;
  private static final float DEFAULT_HISTORICAL_RECORD_WEIGHT = 1.0F;
  public static final String DEFAULT_HISTORY_FILE_NAME = "activity_choser_model_history.xml";
  public static final int DEFAULT_HISTORY_MAX_LENGTH = 50;
  private static final String HISTORY_FILE_EXTENSION = ".xml";
  private static final int INVALID_INDEX = -1;
  static final String LOG_TAG = ActivityChooserModel.class.getSimpleName();
  static final String TAG_HISTORICAL_RECORD = "historical-record";
  static final String TAG_HISTORICAL_RECORDS = "historical-records";
  private static final Map<String, ActivityChooserModel> sDataModelRegistry = new HashMap();
  private static final Object sRegistryLock = new Object();
  private final List<ActivityResolveInfo> mActivities = new ArrayList();
  private OnChooseActivityListener mActivityChoserModelPolicy;
  private ActivitySorter mActivitySorter = new DefaultSorter();
  boolean mCanReadHistoricalData = true;
  final Context mContext;
  private final List<HistoricalRecord> mHistoricalRecords = new ArrayList();
  private boolean mHistoricalRecordsChanged = true;
  final String mHistoryFileName;
  private int mHistoryMaxSize = 50;
  private final Object mInstanceLock = new Object();
  private Intent mIntent;
  private boolean mReadShareHistoryCalled = false;
  private boolean mReloadActivities = false;

  private ActivityChooserModel(Context paramContext, String paramString)
  {
    this.mContext = paramContext.getApplicationContext();
    if ((!TextUtils.isEmpty(paramString)) && (!paramString.endsWith(".xml")));
    for (this.mHistoryFileName = (paramString + ".xml"); ; this.mHistoryFileName = paramString)
      return;
  }

  private boolean addHistoricalRecord(HistoricalRecord paramHistoricalRecord)
  {
    boolean bool = this.mHistoricalRecords.add(paramHistoricalRecord);
    if (bool)
    {
      this.mHistoricalRecordsChanged = true;
      pruneExcessiveHistoricalRecordsIfNeeded();
      persistHistoricalDataIfNeeded();
      sortActivitiesIfNeeded();
      notifyChanged();
    }
    return bool;
  }

  private void ensureConsistentState()
  {
    boolean bool = loadActivitiesIfNeeded() | readHistoricalDataIfNeeded();
    pruneExcessiveHistoricalRecordsIfNeeded();
    if (bool)
    {
      sortActivitiesIfNeeded();
      notifyChanged();
    }
  }

  public static ActivityChooserModel get(Context paramContext, String paramString)
  {
    synchronized (sRegistryLock)
    {
      ActivityChooserModel localActivityChooserModel = (ActivityChooserModel)sDataModelRegistry.get(paramString);
      if (localActivityChooserModel == null)
      {
        localActivityChooserModel = new ActivityChooserModel(paramContext, paramString);
        sDataModelRegistry.put(paramString, localActivityChooserModel);
      }
      return localActivityChooserModel;
    }
  }

  private boolean loadActivitiesIfNeeded()
  {
    boolean bool = false;
    if ((this.mReloadActivities) && (this.mIntent != null))
    {
      this.mReloadActivities = false;
      this.mActivities.clear();
      List localList = this.mContext.getPackageManager().queryIntentActivities(this.mIntent, 0);
      int i = localList.size();
      for (int j = 0; j < i; j++)
      {
        ResolveInfo localResolveInfo = (ResolveInfo)localList.get(j);
        this.mActivities.add(new ActivityResolveInfo(localResolveInfo));
      }
      bool = true;
    }
    return bool;
  }

  private void persistHistoricalDataIfNeeded()
  {
    if (!this.mReadShareHistoryCalled)
      throw new IllegalStateException("No preceding call to #readHistoricalData");
    if (!this.mHistoricalRecordsChanged);
    while (true)
    {
      return;
      this.mHistoricalRecordsChanged = false;
      if (!TextUtils.isEmpty(this.mHistoryFileName))
      {
        PersistHistoryAsyncTask localPersistHistoryAsyncTask = new PersistHistoryAsyncTask();
        Executor localExecutor = AsyncTask.THREAD_POOL_EXECUTOR;
        Object[] arrayOfObject = new Object[2];
        arrayOfObject[0] = new ArrayList(this.mHistoricalRecords);
        arrayOfObject[1] = this.mHistoryFileName;
        localPersistHistoryAsyncTask.executeOnExecutor(localExecutor, arrayOfObject);
      }
    }
  }

  private void pruneExcessiveHistoricalRecordsIfNeeded()
  {
    int i = this.mHistoricalRecords.size() - this.mHistoryMaxSize;
    if (i <= 0);
    while (true)
    {
      return;
      this.mHistoricalRecordsChanged = true;
      for (int j = 0; j < i; j++)
        ((HistoricalRecord)this.mHistoricalRecords.remove(0));
    }
  }

  private boolean readHistoricalDataIfNeeded()
  {
    boolean bool = true;
    if ((this.mCanReadHistoricalData) && (this.mHistoricalRecordsChanged) && (!TextUtils.isEmpty(this.mHistoryFileName)))
    {
      this.mCanReadHistoricalData = false;
      this.mReadShareHistoryCalled = bool;
      readHistoricalDataImpl();
    }
    while (true)
    {
      return bool;
      bool = false;
    }
  }

  private void readHistoricalDataImpl()
  {
    try
    {
      FileInputStream localFileInputStream = this.mContext.openFileInput(this.mHistoryFileName);
      try
      {
        localXmlPullParser = Xml.newPullParser();
        localXmlPullParser.setInput(localFileInputStream, "UTF-8");
        for (int i = 0; (i != 1) && (i != 2); i = localXmlPullParser.next());
        if (!"historical-records".equals(localXmlPullParser.getName()))
          throw new XmlPullParserException("Share records file does not start with historical-records tag.");
      }
      catch (XmlPullParserException localXmlPullParserException)
      {
        Log.e(LOG_TAG, "Error reading historical recrod file: " + this.mHistoryFileName, localXmlPullParserException);
        if (localFileInputStream != null)
        {
          try
          {
            localFileInputStream.close();
          }
          catch (IOException localIOException4)
          {
          }
          localList = this.mHistoricalRecords;
          localList.clear();
          int j;
          do
          {
            j = localXmlPullParser.next();
            if (j == 1)
            {
              if (localFileInputStream == null)
                break;
              try
              {
                localFileInputStream.close();
              }
              catch (IOException localIOException5)
              {
              }
            }
          }
          while ((j == 3) || (j == 4));
          if (!"historical-record".equals(localXmlPullParser.getName()))
            throw new XmlPullParserException("Share records file not well-formed.");
        }
      }
      catch (IOException localIOException2)
      {
        while (true)
        {
          XmlPullParser localXmlPullParser;
          List localList;
          Log.e(LOG_TAG, "Error reading historical recrod file: " + this.mHistoryFileName, localIOException2);
          if (localFileInputStream == null)
            break;
          try
          {
            localFileInputStream.close();
          }
          catch (IOException localIOException3)
          {
          }
          localList.add(new HistoricalRecord(localXmlPullParser.getAttributeValue(null, "activity"), Long.parseLong(localXmlPullParser.getAttributeValue(null, "time")), Float.parseFloat(localXmlPullParser.getAttributeValue(null, "weight"))));
        }
      }
      finally
      {
        if (localFileInputStream != null);
        try
        {
          localFileInputStream.close();
          label326: throw localObject;
        }
        catch (IOException localIOException1)
        {
          break label326;
        }
      }
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
    }
  }

  private boolean sortActivitiesIfNeeded()
  {
    if ((this.mActivitySorter != null) && (this.mIntent != null) && (!this.mActivities.isEmpty()) && (!this.mHistoricalRecords.isEmpty()))
      this.mActivitySorter.sort(this.mIntent, this.mActivities, Collections.unmodifiableList(this.mHistoricalRecords));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public Intent chooseActivity(int paramInt)
  {
    Intent localIntent1;
    synchronized (this.mInstanceLock)
    {
      if (this.mIntent == null)
      {
        localIntent1 = null;
      }
      else
      {
        ensureConsistentState();
        ActivityResolveInfo localActivityResolveInfo = (ActivityResolveInfo)this.mActivities.get(paramInt);
        ComponentName localComponentName = new ComponentName(localActivityResolveInfo.resolveInfo.activityInfo.packageName, localActivityResolveInfo.resolveInfo.activityInfo.name);
        localIntent1 = new Intent(this.mIntent);
        localIntent1.setComponent(localComponentName);
        if (this.mActivityChoserModelPolicy != null)
        {
          Intent localIntent2 = new Intent(localIntent1);
          if (this.mActivityChoserModelPolicy.onChooseActivity(this, localIntent2))
          {
            localIntent1 = null;
            break label162;
          }
        }
        addHistoricalRecord(new HistoricalRecord(localComponentName, System.currentTimeMillis(), 1.0F));
      }
    }
    label162: return localIntent1;
  }

  public ResolveInfo getActivity(int paramInt)
  {
    synchronized (this.mInstanceLock)
    {
      ensureConsistentState();
      ResolveInfo localResolveInfo = ((ActivityResolveInfo)this.mActivities.get(paramInt)).resolveInfo;
      return localResolveInfo;
    }
  }

  public int getActivityCount()
  {
    synchronized (this.mInstanceLock)
    {
      ensureConsistentState();
      int i = this.mActivities.size();
      return i;
    }
  }

  public int getActivityIndex(ResolveInfo paramResolveInfo)
  {
    while (true)
    {
      int j;
      synchronized (this.mInstanceLock)
      {
        ensureConsistentState();
        List localList = this.mActivities;
        int i = localList.size();
        j = 0;
        if (j < i)
          if (((ActivityResolveInfo)localList.get(j)).resolveInfo != paramResolveInfo)
            break label76;
        else
          j = -1;
      }
      return j;
      label76: j++;
    }
  }

  public ResolveInfo getDefaultActivity()
  {
    ResolveInfo localResolveInfo;
    synchronized (this.mInstanceLock)
    {
      ensureConsistentState();
      if (!this.mActivities.isEmpty())
        localResolveInfo = ((ActivityResolveInfo)this.mActivities.get(0)).resolveInfo;
      else
        localResolveInfo = null;
    }
    return localResolveInfo;
  }

  public int getHistoryMaxSize()
  {
    synchronized (this.mInstanceLock)
    {
      int i = this.mHistoryMaxSize;
      return i;
    }
  }

  public int getHistorySize()
  {
    synchronized (this.mInstanceLock)
    {
      ensureConsistentState();
      int i = this.mHistoricalRecords.size();
      return i;
    }
  }

  public Intent getIntent()
  {
    synchronized (this.mInstanceLock)
    {
      Intent localIntent = this.mIntent;
      return localIntent;
    }
  }

  public void setActivitySorter(ActivitySorter paramActivitySorter)
  {
    synchronized (this.mInstanceLock)
    {
      if (this.mActivitySorter != paramActivitySorter)
      {
        this.mActivitySorter = paramActivitySorter;
        if (sortActivitiesIfNeeded())
          notifyChanged();
      }
    }
  }

  public void setDefaultActivity(int paramInt)
  {
    while (true)
    {
      synchronized (this.mInstanceLock)
      {
        ensureConsistentState();
        ActivityResolveInfo localActivityResolveInfo1 = (ActivityResolveInfo)this.mActivities.get(paramInt);
        ActivityResolveInfo localActivityResolveInfo2 = (ActivityResolveInfo)this.mActivities.get(0);
        if (localActivityResolveInfo2 != null)
        {
          f = 5.0F + (localActivityResolveInfo2.weight - localActivityResolveInfo1.weight);
          addHistoricalRecord(new HistoricalRecord(new ComponentName(localActivityResolveInfo1.resolveInfo.activityInfo.packageName, localActivityResolveInfo1.resolveInfo.activityInfo.name), System.currentTimeMillis(), f));
          return;
        }
      }
      float f = 1.0F;
    }
  }

  public void setHistoryMaxSize(int paramInt)
  {
    synchronized (this.mInstanceLock)
    {
      if (this.mHistoryMaxSize != paramInt)
      {
        this.mHistoryMaxSize = paramInt;
        pruneExcessiveHistoricalRecordsIfNeeded();
        if (sortActivitiesIfNeeded())
          notifyChanged();
      }
    }
  }

  public void setIntent(Intent paramIntent)
  {
    synchronized (this.mInstanceLock)
    {
      if (this.mIntent != paramIntent)
      {
        this.mIntent = paramIntent;
        this.mReloadActivities = true;
        ensureConsistentState();
      }
    }
  }

  public void setOnChooseActivityListener(OnChooseActivityListener paramOnChooseActivityListener)
  {
    synchronized (this.mInstanceLock)
    {
      this.mActivityChoserModelPolicy = paramOnChooseActivityListener;
      return;
    }
  }

  public static abstract interface ActivityChooserModelClient
  {
    public abstract void setActivityChooserModel(ActivityChooserModel paramActivityChooserModel);
  }

  public static final class ActivityResolveInfo
    implements Comparable<ActivityResolveInfo>
  {
    public final ResolveInfo resolveInfo;
    public float weight;

    public ActivityResolveInfo(ResolveInfo paramResolveInfo)
    {
      this.resolveInfo = paramResolveInfo;
    }

    public int compareTo(ActivityResolveInfo paramActivityResolveInfo)
    {
      return Float.floatToIntBits(paramActivityResolveInfo.weight) - Float.floatToIntBits(this.weight);
    }

    public boolean equals(Object paramObject)
    {
      boolean bool = true;
      if (this == paramObject);
      while (true)
      {
        return bool;
        if (paramObject == null)
        {
          bool = false;
        }
        else if (getClass() != paramObject.getClass())
        {
          bool = false;
        }
        else
        {
          ActivityResolveInfo localActivityResolveInfo = (ActivityResolveInfo)paramObject;
          if (Float.floatToIntBits(this.weight) != Float.floatToIntBits(localActivityResolveInfo.weight))
            bool = false;
        }
      }
    }

    public int hashCode()
    {
      return 31 + Float.floatToIntBits(this.weight);
    }

    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("[");
      localStringBuilder.append("resolveInfo:").append(this.resolveInfo.toString());
      localStringBuilder.append("; weight:").append(new BigDecimal(this.weight));
      localStringBuilder.append("]");
      return localStringBuilder.toString();
    }
  }

  public static abstract interface ActivitySorter
  {
    public abstract void sort(Intent paramIntent, List<ActivityChooserModel.ActivityResolveInfo> paramList, List<ActivityChooserModel.HistoricalRecord> paramList1);
  }

  private static final class DefaultSorter
    implements ActivityChooserModel.ActivitySorter
  {
    private static final float WEIGHT_DECAY_COEFFICIENT = 0.95F;
    private final Map<ComponentName, ActivityChooserModel.ActivityResolveInfo> mPackageNameToActivityMap = new HashMap();

    public void sort(Intent paramIntent, List<ActivityChooserModel.ActivityResolveInfo> paramList, List<ActivityChooserModel.HistoricalRecord> paramList1)
    {
      Map localMap = this.mPackageNameToActivityMap;
      localMap.clear();
      int i = paramList.size();
      for (int j = 0; j < i; j++)
      {
        ActivityChooserModel.ActivityResolveInfo localActivityResolveInfo2 = (ActivityChooserModel.ActivityResolveInfo)paramList.get(j);
        localActivityResolveInfo2.weight = 0.0F;
        localMap.put(new ComponentName(localActivityResolveInfo2.resolveInfo.activityInfo.packageName, localActivityResolveInfo2.resolveInfo.activityInfo.name), localActivityResolveInfo2);
      }
      int k = -1 + paramList1.size();
      float f = 1.0F;
      for (int m = k; m >= 0; m--)
      {
        ActivityChooserModel.HistoricalRecord localHistoricalRecord = (ActivityChooserModel.HistoricalRecord)paramList1.get(m);
        ActivityChooserModel.ActivityResolveInfo localActivityResolveInfo1 = (ActivityChooserModel.ActivityResolveInfo)localMap.get(localHistoricalRecord.activity);
        if (localActivityResolveInfo1 != null)
        {
          localActivityResolveInfo1.weight += f * localHistoricalRecord.weight;
          f *= 0.95F;
        }
      }
      Collections.sort(paramList);
    }
  }

  public static final class HistoricalRecord
  {
    public final ComponentName activity;
    public final long time;
    public final float weight;

    public HistoricalRecord(ComponentName paramComponentName, long paramLong, float paramFloat)
    {
      this.activity = paramComponentName;
      this.time = paramLong;
      this.weight = paramFloat;
    }

    public HistoricalRecord(String paramString, long paramLong, float paramFloat)
    {
      this(ComponentName.unflattenFromString(paramString), paramLong, paramFloat);
    }

    public boolean equals(Object paramObject)
    {
      boolean bool = true;
      if (this == paramObject);
      while (true)
      {
        return bool;
        if (paramObject == null)
        {
          bool = false;
        }
        else if (getClass() != paramObject.getClass())
        {
          bool = false;
        }
        else
        {
          HistoricalRecord localHistoricalRecord = (HistoricalRecord)paramObject;
          if (this.activity == null)
          {
            if (localHistoricalRecord.activity != null)
              bool = false;
          }
          else if (!this.activity.equals(localHistoricalRecord.activity))
            bool = false;
          else if (this.time != localHistoricalRecord.time)
            bool = false;
          else if (Float.floatToIntBits(this.weight) != Float.floatToIntBits(localHistoricalRecord.weight))
            bool = false;
        }
      }
    }

    public int hashCode()
    {
      if (this.activity == null);
      for (int i = 0; ; i = this.activity.hashCode())
        return 31 * (31 * (i + 31) + (int)(this.time ^ this.time >>> 32)) + Float.floatToIntBits(this.weight);
    }

    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("[");
      localStringBuilder.append("; activity:").append(this.activity);
      localStringBuilder.append("; time:").append(this.time);
      localStringBuilder.append("; weight:").append(new BigDecimal(this.weight));
      localStringBuilder.append("]");
      return localStringBuilder.toString();
    }
  }

  public static abstract interface OnChooseActivityListener
  {
    public abstract boolean onChooseActivity(ActivityChooserModel paramActivityChooserModel, Intent paramIntent);
  }

  private final class PersistHistoryAsyncTask extends AsyncTask<Object, Void, Void>
  {
    PersistHistoryAsyncTask()
    {
    }

    // ERROR //
    public Void doInBackground(Object[] paramArrayOfObject)
    {
      // Byte code:
      //   0: aload_1
      //   1: iconst_0
      //   2: aaload
      //   3: checkcast 29	java/util/List
      //   6: astore_2
      //   7: aload_1
      //   8: iconst_1
      //   9: aaload
      //   10: checkcast 31	java/lang/String
      //   13: astore_3
      //   14: aload_0
      //   15: getfield 11	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   18: getfield 37	androidx/appcompat/widget/ActivityChooserModel:mContext	Landroid/content/Context;
      //   21: aload_3
      //   22: iconst_0
      //   23: invokevirtual 43	android/content/Context:openFileOutput	(Ljava/lang/String;I)Ljava/io/FileOutputStream;
      //   26: astore 6
      //   28: invokestatic 49	android/util/Xml:newSerializer	()Lorg/xmlpull/v1/XmlSerializer;
      //   31: astore 7
      //   33: aload 7
      //   35: aload 6
      //   37: aconst_null
      //   38: invokeinterface 55 3 0
      //   43: aload 7
      //   45: ldc 57
      //   47: iconst_1
      //   48: invokestatic 63	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
      //   51: invokeinterface 67 3 0
      //   56: aload 7
      //   58: aconst_null
      //   59: ldc 69
      //   61: invokeinterface 73 3 0
      //   66: pop
      //   67: aload_2
      //   68: invokeinterface 77 1 0
      //   73: istore 20
      //   75: iconst_0
      //   76: istore 21
      //   78: iload 21
      //   80: iload 20
      //   82: if_icmpge +132 -> 214
      //   85: aload_2
      //   86: iconst_0
      //   87: invokeinterface 81 2 0
      //   92: checkcast 83	androidx/appcompat/widget/ActivityChooserModel$HistoricalRecord
      //   95: astore 24
      //   97: aload 7
      //   99: aconst_null
      //   100: ldc 85
      //   102: invokeinterface 73 3 0
      //   107: pop
      //   108: aload 7
      //   110: aconst_null
      //   111: ldc 87
      //   113: aload 24
      //   115: getfield 90	androidx/appcompat/widget/ActivityChooserModel$HistoricalRecord:activity	Landroid/content/ComponentName;
      //   118: invokevirtual 96	android/content/ComponentName:flattenToString	()Ljava/lang/String;
      //   121: invokeinterface 100 4 0
      //   126: pop
      //   127: aload 7
      //   129: aconst_null
      //   130: ldc 102
      //   132: aload 24
      //   134: getfield 105	androidx/appcompat/widget/ActivityChooserModel$HistoricalRecord:time	J
      //   137: invokestatic 108	java/lang/String:valueOf	(J)Ljava/lang/String;
      //   140: invokeinterface 100 4 0
      //   145: pop
      //   146: aload 7
      //   148: aconst_null
      //   149: ldc 110
      //   151: aload 24
      //   153: getfield 113	androidx/appcompat/widget/ActivityChooserModel$HistoricalRecord:weight	F
      //   156: invokestatic 116	java/lang/String:valueOf	(F)Ljava/lang/String;
      //   159: invokeinterface 100 4 0
      //   164: pop
      //   165: aload 7
      //   167: aconst_null
      //   168: ldc 85
      //   170: invokeinterface 119 3 0
      //   175: pop
      //   176: iinc 21 1
      //   179: goto -101 -> 78
      //   182: astore 4
      //   184: getstatic 123	androidx/appcompat/widget/ActivityChooserModel:LOG_TAG	Ljava/lang/String;
      //   187: new 125	java/lang/StringBuilder
      //   190: dup
      //   191: invokespecial 126	java/lang/StringBuilder:<init>	()V
      //   194: ldc 128
      //   196: invokevirtual 132	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   199: aload_3
      //   200: invokevirtual 132	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   203: invokevirtual 135	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   206: aload 4
      //   208: invokestatic 141	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   211: pop
      //   212: aconst_null
      //   213: areturn
      //   214: aload 7
      //   216: aconst_null
      //   217: ldc 69
      //   219: invokeinterface 119 3 0
      //   224: pop
      //   225: aload 7
      //   227: invokeinterface 144 1 0
      //   232: aload_0
      //   233: getfield 11	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   236: iconst_1
      //   237: putfield 148	androidx/appcompat/widget/ActivityChooserModel:mCanReadHistoricalData	Z
      //   240: aload 6
      //   242: ifnull +8 -> 250
      //   245: aload 6
      //   247: invokevirtual 153	java/io/FileOutputStream:close	()V
      //   250: goto -38 -> 212
      //   253: astore 16
      //   255: getstatic 123	androidx/appcompat/widget/ActivityChooserModel:LOG_TAG	Ljava/lang/String;
      //   258: new 125	java/lang/StringBuilder
      //   261: dup
      //   262: invokespecial 126	java/lang/StringBuilder:<init>	()V
      //   265: ldc 128
      //   267: invokevirtual 132	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   270: aload_0
      //   271: getfield 11	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   274: getfield 156	androidx/appcompat/widget/ActivityChooserModel:mHistoryFileName	Ljava/lang/String;
      //   277: invokevirtual 132	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   280: invokevirtual 135	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   283: aload 16
      //   285: invokestatic 141	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   288: pop
      //   289: aload_0
      //   290: getfield 11	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   293: iconst_1
      //   294: putfield 148	androidx/appcompat/widget/ActivityChooserModel:mCanReadHistoricalData	Z
      //   297: aload 6
      //   299: ifnull -49 -> 250
      //   302: aload 6
      //   304: invokevirtual 153	java/io/FileOutputStream:close	()V
      //   307: goto -57 -> 250
      //   310: astore 18
      //   312: goto -62 -> 250
      //   315: astore 13
      //   317: getstatic 123	androidx/appcompat/widget/ActivityChooserModel:LOG_TAG	Ljava/lang/String;
      //   320: new 125	java/lang/StringBuilder
      //   323: dup
      //   324: invokespecial 126	java/lang/StringBuilder:<init>	()V
      //   327: ldc 128
      //   329: invokevirtual 132	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   332: aload_0
      //   333: getfield 11	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   336: getfield 156	androidx/appcompat/widget/ActivityChooserModel:mHistoryFileName	Ljava/lang/String;
      //   339: invokevirtual 132	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   342: invokevirtual 135	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   345: aload 13
      //   347: invokestatic 141	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   350: pop
      //   351: aload_0
      //   352: getfield 11	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   355: iconst_1
      //   356: putfield 148	androidx/appcompat/widget/ActivityChooserModel:mCanReadHistoricalData	Z
      //   359: aload 6
      //   361: ifnull -111 -> 250
      //   364: aload 6
      //   366: invokevirtual 153	java/io/FileOutputStream:close	()V
      //   369: goto -119 -> 250
      //   372: astore 15
      //   374: goto -124 -> 250
      //   377: astore 10
      //   379: getstatic 123	androidx/appcompat/widget/ActivityChooserModel:LOG_TAG	Ljava/lang/String;
      //   382: new 125	java/lang/StringBuilder
      //   385: dup
      //   386: invokespecial 126	java/lang/StringBuilder:<init>	()V
      //   389: ldc 128
      //   391: invokevirtual 132	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   394: aload_0
      //   395: getfield 11	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   398: getfield 156	androidx/appcompat/widget/ActivityChooserModel:mHistoryFileName	Ljava/lang/String;
      //   401: invokevirtual 132	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   404: invokevirtual 135	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   407: aload 10
      //   409: invokestatic 141	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   412: pop
      //   413: aload_0
      //   414: getfield 11	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   417: iconst_1
      //   418: putfield 148	androidx/appcompat/widget/ActivityChooserModel:mCanReadHistoricalData	Z
      //   421: aload 6
      //   423: ifnull -173 -> 250
      //   426: aload 6
      //   428: invokevirtual 153	java/io/FileOutputStream:close	()V
      //   431: goto -181 -> 250
      //   434: astore 12
      //   436: goto -186 -> 250
      //   439: astore 8
      //   441: aload_0
      //   442: getfield 11	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   445: iconst_1
      //   446: putfield 148	androidx/appcompat/widget/ActivityChooserModel:mCanReadHistoricalData	Z
      //   449: aload 6
      //   451: ifnull +8 -> 459
      //   454: aload 6
      //   456: invokevirtual 153	java/io/FileOutputStream:close	()V
      //   459: aload 8
      //   461: athrow
      //   462: astore 23
      //   464: goto -214 -> 250
      //   467: astore 9
      //   469: goto -10 -> 459
      //
      // Exception table:
      //   from	to	target	type
      //   14	28	182	java/io/FileNotFoundException
      //   33	176	253	java/lang/IllegalArgumentException
      //   214	232	253	java/lang/IllegalArgumentException
      //   302	307	310	java/io/IOException
      //   33	176	315	java/lang/IllegalStateException
      //   214	232	315	java/lang/IllegalStateException
      //   364	369	372	java/io/IOException
      //   33	176	377	java/io/IOException
      //   214	232	377	java/io/IOException
      //   426	431	434	java/io/IOException
      //   33	176	439	finally
      //   214	232	439	finally
      //   255	289	439	finally
      //   317	351	439	finally
      //   379	413	439	finally
      //   245	250	462	java/io/IOException
      //   454	459	467	java/io/IOException
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.ActivityChooserModel
 * JD-Core Version:    0.6.2
 */