package androidx.fragment.app;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.collection.ArrayMap;
import androidx.core.app.SharedElementCallback;
import androidx.core.view.ViewCompat;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

class FragmentTransition
{
  private static final int[] INVERSE_OPS = { 0, 3, 0, 1, 5, 4, 7, 6, 9, 8 };
  private static final FragmentTransitionImpl PLATFORM_IMPL;
  private static final FragmentTransitionImpl SUPPORT_IMPL;

  static
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (FragmentTransitionCompat21 localFragmentTransitionCompat21 = new FragmentTransitionCompat21(); ; localFragmentTransitionCompat21 = null)
    {
      PLATFORM_IMPL = localFragmentTransitionCompat21;
      SUPPORT_IMPL = resolveSupportImpl();
      return;
    }
  }

  private static void addSharedElementsWithMatchingNames(ArrayList<View> paramArrayList, ArrayMap<String, View> paramArrayMap, Collection<String> paramCollection)
  {
    for (int i = -1 + paramArrayMap.size(); i >= 0; i--)
    {
      View localView = (View)paramArrayMap.valueAt(i);
      if (paramCollection.contains(ViewCompat.getTransitionName(localView)))
        paramArrayList.add(localView);
    }
  }

  private static void addToFirstInLastOut(BackStackRecord paramBackStackRecord, BackStackRecord.Op paramOp, SparseArray<FragmentContainerTransition> paramSparseArray, boolean paramBoolean1, boolean paramBoolean2)
  {
    Fragment localFragment = paramOp.fragment;
    if (localFragment == null);
    int i;
    do
    {
      return;
      i = localFragment.mContainerId;
    }
    while (i == 0);
    int j;
    label38: boolean bool;
    int k;
    int n;
    if (paramBoolean1)
    {
      j = INVERSE_OPS[paramOp.cmd];
      bool = false;
      k = 0;
      m = 0;
      n = 0;
    }
    switch (j)
    {
    case 2:
    default:
    case 5:
    case 1:
    case 7:
      while (true)
      {
        FragmentContainerTransition localFragmentContainerTransition = (FragmentContainerTransition)paramSparseArray.get(i);
        if (bool)
        {
          localFragmentContainerTransition = ensureContainer(localFragmentContainerTransition, paramSparseArray, i);
          localFragmentContainerTransition.lastIn = localFragment;
          localFragmentContainerTransition.lastInIsPop = paramBoolean1;
          localFragmentContainerTransition.lastInTransaction = paramBackStackRecord;
        }
        if ((!paramBoolean2) && (n != 0))
        {
          if ((localFragmentContainerTransition != null) && (localFragmentContainerTransition.firstOut == localFragment))
            localFragmentContainerTransition.firstOut = null;
          FragmentManagerImpl localFragmentManagerImpl = paramBackStackRecord.mManager;
          if ((localFragment.mState < 1) && (localFragmentManagerImpl.mCurState >= 1) && (!paramBackStackRecord.mReorderingAllowed))
          {
            localFragmentManagerImpl.makeActive(localFragment);
            localFragmentManagerImpl.moveToState(localFragment, 1, 0, 0, false);
          }
        }
        if ((m != 0) && ((localFragmentContainerTransition == null) || (localFragmentContainerTransition.firstOut == null)))
        {
          localFragmentContainerTransition = ensureContainer(localFragmentContainerTransition, paramSparseArray, i);
          localFragmentContainerTransition.firstOut = localFragment;
          localFragmentContainerTransition.firstOutIsPop = paramBoolean1;
          localFragmentContainerTransition.firstOutTransaction = paramBackStackRecord;
        }
        if ((paramBoolean2) || (k == 0) || (localFragmentContainerTransition == null) || (localFragmentContainerTransition.lastIn != localFragment))
          break;
        localFragmentContainerTransition.lastIn = null;
        break;
        j = paramOp.cmd;
        break label38;
        if (paramBoolean2)
          if ((localFragment.mHiddenChanged) && (!localFragment.mHidden) && (localFragment.mAdded))
            bool = true;
        while (true)
        {
          n = 1;
          break;
          bool = false;
          continue;
          bool = localFragment.mHidden;
        }
        if (!paramBoolean2)
          break label383;
        bool = localFragment.mIsNewlyAdded;
        n = 1;
      }
      if ((!localFragment.mAdded) && (!localFragment.mHidden));
      for (bool = true; ; bool = false)
        break;
    case 4:
      label383: if (paramBoolean2)
      {
        if ((localFragment.mHiddenChanged) && (localFragment.mAdded) && (localFragment.mHidden));
        for (m = 1; ; m = 0)
        {
          k = 1;
          break;
        }
      }
      if ((localFragment.mAdded) && (!localFragment.mHidden));
      for (m = 1; ; m = 0)
        break;
    case 3:
    case 6:
    }
    if (paramBoolean2)
    {
      if ((!localFragment.mAdded) && (localFragment.mView != null) && (localFragment.mView.getVisibility() == 0) && (localFragment.mPostponedAlpha >= 0.0F));
      for (m = 1; ; m = 0)
      {
        k = 1;
        break;
      }
    }
    if ((localFragment.mAdded) && (!localFragment.mHidden));
    for (int m = 1; ; m = 0)
      break;
  }

  public static void calculateFragments(BackStackRecord paramBackStackRecord, SparseArray<FragmentContainerTransition> paramSparseArray, boolean paramBoolean)
  {
    int i = paramBackStackRecord.mOps.size();
    for (int j = 0; j < i; j++)
      addToFirstInLastOut(paramBackStackRecord, (BackStackRecord.Op)paramBackStackRecord.mOps.get(j), paramSparseArray, false, paramBoolean);
  }

  private static ArrayMap<String, String> calculateNameOverrides(int paramInt1, ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt2, int paramInt3)
  {
    ArrayMap localArrayMap = new ArrayMap();
    int i = paramInt3 - 1;
    if (i >= paramInt2)
    {
      BackStackRecord localBackStackRecord = (BackStackRecord)paramArrayList.get(i);
      if (!localBackStackRecord.interactsWith(paramInt1));
      boolean bool;
      do
      {
        i--;
        break;
        bool = ((Boolean)paramArrayList1.get(i)).booleanValue();
      }
      while (localBackStackRecord.mSharedElementSourceNames == null);
      int j = localBackStackRecord.mSharedElementSourceNames.size();
      ArrayList localArrayList2;
      ArrayList localArrayList1;
      label98: int k;
      label101: String str1;
      String str2;
      if (bool)
      {
        localArrayList2 = localBackStackRecord.mSharedElementSourceNames;
        localArrayList1 = localBackStackRecord.mSharedElementTargetNames;
        k = 0;
        if (k < j)
        {
          str1 = (String)localArrayList1.get(k);
          str2 = (String)localArrayList2.get(k);
          String str3 = (String)localArrayMap.remove(str2);
          if (str3 == null)
            break label182;
          localArrayMap.put(str1, str3);
        }
      }
      while (true)
      {
        k++;
        break label101;
        break;
        localArrayList1 = localBackStackRecord.mSharedElementSourceNames;
        localArrayList2 = localBackStackRecord.mSharedElementTargetNames;
        break label98;
        label182: localArrayMap.put(str1, str2);
      }
    }
    return localArrayMap;
  }

  public static void calculatePopFragments(BackStackRecord paramBackStackRecord, SparseArray<FragmentContainerTransition> paramSparseArray, boolean paramBoolean)
  {
    if (!paramBackStackRecord.mManager.mContainer.onHasView());
    while (true)
    {
      return;
      for (int i = -1 + paramBackStackRecord.mOps.size(); i >= 0; i--)
        addToFirstInLastOut(paramBackStackRecord, (BackStackRecord.Op)paramBackStackRecord.mOps.get(i), paramSparseArray, true, paramBoolean);
    }
  }

  static void callSharedElementStartEnd(Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean1, ArrayMap<String, View> paramArrayMap, boolean paramBoolean2)
  {
    SharedElementCallback localSharedElementCallback;
    ArrayList localArrayList1;
    ArrayList localArrayList2;
    if (paramBoolean1)
    {
      localSharedElementCallback = paramFragment2.getEnterTransitionCallback();
      if (localSharedElementCallback == null)
        break label113;
      localArrayList1 = new ArrayList();
      localArrayList2 = new ArrayList();
      if (paramArrayMap != null)
        break label89;
    }
    label89: for (int i = 0; ; i = paramArrayMap.size())
    {
      for (int j = 0; j < i; j++)
      {
        localArrayList2.add(paramArrayMap.keyAt(j));
        localArrayList1.add(paramArrayMap.valueAt(j));
      }
      localSharedElementCallback = paramFragment1.getEnterTransitionCallback();
      break;
    }
    if (paramBoolean2)
      localSharedElementCallback.onSharedElementStart(localArrayList2, localArrayList1, null);
    while (true)
    {
      label113: return;
      localSharedElementCallback.onSharedElementEnd(localArrayList2, localArrayList1, null);
    }
  }

  private static boolean canHandleAll(FragmentTransitionImpl paramFragmentTransitionImpl, List<Object> paramList)
  {
    int i = 0;
    int j = paramList.size();
    if (i < j)
      if (paramFragmentTransitionImpl.canHandle(paramList.get(i)));
    for (boolean bool = false; ; bool = true)
    {
      return bool;
      i++;
      break;
    }
  }

  static ArrayMap<String, View> captureInSharedElements(FragmentTransitionImpl paramFragmentTransitionImpl, ArrayMap<String, String> paramArrayMap, Object paramObject, FragmentContainerTransition paramFragmentContainerTransition)
  {
    Fragment localFragment = paramFragmentContainerTransition.lastIn;
    View localView1 = localFragment.getView();
    Object localObject;
    if ((paramArrayMap.isEmpty()) || (paramObject == null) || (localView1 == null))
    {
      paramArrayMap.clear();
      localObject = null;
    }
    while (true)
    {
      return localObject;
      localObject = new ArrayMap();
      paramFragmentTransitionImpl.findNamedViews((Map)localObject, localView1);
      BackStackRecord localBackStackRecord = paramFragmentContainerTransition.lastInTransaction;
      SharedElementCallback localSharedElementCallback;
      ArrayList localArrayList;
      label83: int i;
      label129: String str1;
      View localView2;
      if (paramFragmentContainerTransition.lastInIsPop)
      {
        localSharedElementCallback = localFragment.getExitTransitionCallback();
        localArrayList = localBackStackRecord.mSharedElementSourceNames;
        if (localArrayList != null)
        {
          ((ArrayMap)localObject).retainAll(localArrayList);
          ((ArrayMap)localObject).retainAll(paramArrayMap.values());
        }
        if (localSharedElementCallback == null)
          break label247;
        localSharedElementCallback.onMapSharedElements(localArrayList, (Map)localObject);
        i = -1 + localArrayList.size();
        if (i >= 0)
        {
          str1 = (String)localArrayList.get(i);
          localView2 = (View)((ArrayMap)localObject).get(str1);
          if (localView2 != null)
            break label206;
          String str3 = findKeyForValue(paramArrayMap, str1);
          if (str3 != null)
            paramArrayMap.remove(str3);
        }
      }
      while (true)
      {
        i--;
        break label129;
        break;
        localSharedElementCallback = localFragment.getEnterTransitionCallback();
        localArrayList = localBackStackRecord.mSharedElementTargetNames;
        break label83;
        label206: if (!str1.equals(ViewCompat.getTransitionName(localView2)))
        {
          String str2 = findKeyForValue(paramArrayMap, str1);
          if (str2 != null)
            paramArrayMap.put(str2, ViewCompat.getTransitionName(localView2));
        }
      }
      label247: retainValues(paramArrayMap, (ArrayMap)localObject);
    }
  }

  private static ArrayMap<String, View> captureOutSharedElements(FragmentTransitionImpl paramFragmentTransitionImpl, ArrayMap<String, String> paramArrayMap, Object paramObject, FragmentContainerTransition paramFragmentContainerTransition)
  {
    Object localObject;
    if ((paramArrayMap.isEmpty()) || (paramObject == null))
    {
      paramArrayMap.clear();
      localObject = null;
    }
    while (true)
    {
      return localObject;
      Fragment localFragment = paramFragmentContainerTransition.firstOut;
      localObject = new ArrayMap();
      paramFragmentTransitionImpl.findNamedViews((Map)localObject, localFragment.getView());
      BackStackRecord localBackStackRecord = paramFragmentContainerTransition.firstOutTransaction;
      SharedElementCallback localSharedElementCallback;
      ArrayList localArrayList;
      label74: int i;
      label105: String str1;
      View localView;
      if (paramFragmentContainerTransition.firstOutIsPop)
      {
        localSharedElementCallback = localFragment.getEnterTransitionCallback();
        localArrayList = localBackStackRecord.mSharedElementTargetNames;
        ((ArrayMap)localObject).retainAll(localArrayList);
        if (localSharedElementCallback == null)
          break label208;
        localSharedElementCallback.onMapSharedElements(localArrayList, (Map)localObject);
        i = -1 + localArrayList.size();
        if (i >= 0)
        {
          str1 = (String)localArrayList.get(i);
          localView = (View)((ArrayMap)localObject).get(str1);
          if (localView != null)
            break label169;
          paramArrayMap.remove(str1);
        }
      }
      while (true)
      {
        i--;
        break label105;
        break;
        localSharedElementCallback = localFragment.getExitTransitionCallback();
        localArrayList = localBackStackRecord.mSharedElementSourceNames;
        break label74;
        label169: if (!str1.equals(ViewCompat.getTransitionName(localView)))
        {
          String str2 = (String)paramArrayMap.remove(str1);
          paramArrayMap.put(ViewCompat.getTransitionName(localView), str2);
        }
      }
      label208: paramArrayMap.retainAll(((ArrayMap)localObject).keySet());
    }
  }

  private static FragmentTransitionImpl chooseImpl(Fragment paramFragment1, Fragment paramFragment2)
  {
    FragmentTransitionImpl localFragmentTransitionImpl = null;
    ArrayList localArrayList = new ArrayList();
    if (paramFragment1 != null)
    {
      Object localObject4 = paramFragment1.getExitTransition();
      if (localObject4 != null)
        localArrayList.add(localObject4);
      Object localObject5 = paramFragment1.getReturnTransition();
      if (localObject5 != null)
        localArrayList.add(localObject5);
      Object localObject6 = paramFragment1.getSharedElementReturnTransition();
      if (localObject6 != null)
        localArrayList.add(localObject6);
    }
    if (paramFragment2 != null)
    {
      Object localObject1 = paramFragment2.getEnterTransition();
      if (localObject1 != null)
        localArrayList.add(localObject1);
      Object localObject2 = paramFragment2.getReenterTransition();
      if (localObject2 != null)
        localArrayList.add(localObject2);
      Object localObject3 = paramFragment2.getSharedElementEnterTransition();
      if (localObject3 != null)
        localArrayList.add(localObject3);
    }
    if (localArrayList.isEmpty());
    do
      while (true)
      {
        return localFragmentTransitionImpl;
        if ((PLATFORM_IMPL != null) && (canHandleAll(PLATFORM_IMPL, localArrayList)))
        {
          localFragmentTransitionImpl = PLATFORM_IMPL;
        }
        else
        {
          if ((SUPPORT_IMPL == null) || (!canHandleAll(SUPPORT_IMPL, localArrayList)))
            break;
          localFragmentTransitionImpl = SUPPORT_IMPL;
        }
      }
    while ((PLATFORM_IMPL == null) && (SUPPORT_IMPL == null));
    throw new IllegalArgumentException("Invalid Transition types");
  }

  static ArrayList<View> configureEnteringExitingViews(FragmentTransitionImpl paramFragmentTransitionImpl, Object paramObject, Fragment paramFragment, ArrayList<View> paramArrayList, View paramView)
  {
    ArrayList localArrayList = null;
    if (paramObject != null)
    {
      localArrayList = new ArrayList();
      View localView = paramFragment.getView();
      if (localView != null)
        paramFragmentTransitionImpl.captureTransitioningViews(localArrayList, localView);
      if (paramArrayList != null)
        localArrayList.removeAll(paramArrayList);
      if (!localArrayList.isEmpty())
      {
        localArrayList.add(paramView);
        paramFragmentTransitionImpl.addTargets(paramObject, localArrayList);
      }
    }
    return localArrayList;
  }

  private static Object configureSharedElementsOrdered(FragmentTransitionImpl paramFragmentTransitionImpl, ViewGroup paramViewGroup, final View paramView, final ArrayMap<String, String> paramArrayMap, final FragmentContainerTransition paramFragmentContainerTransition, final ArrayList<View> paramArrayList1, final ArrayList<View> paramArrayList2, final Object paramObject1, Object paramObject2)
  {
    final Fragment localFragment1 = paramFragmentContainerTransition.lastIn;
    final Fragment localFragment2 = paramFragmentContainerTransition.firstOut;
    if ((localFragment1 == null) || (localFragment2 == null))
    {
      localObject1 = null;
      return localObject1;
    }
    final boolean bool = paramFragmentContainerTransition.lastInIsPop;
    Object localObject2;
    label47: ArrayMap localArrayMap;
    if (paramArrayMap.isEmpty())
    {
      localObject2 = null;
      localArrayMap = captureOutSharedElements(paramFragmentTransitionImpl, paramArrayMap, localObject2, paramFragmentContainerTransition);
      if (!paramArrayMap.isEmpty())
        break label104;
    }
    for (final Object localObject1 = null; ; localObject1 = localObject2)
    {
      if ((paramObject1 != null) || (paramObject2 != null) || (localObject1 != null))
        break label122;
      localObject1 = null;
      break;
      localObject2 = getSharedElementTransition(paramFragmentTransitionImpl, localFragment1, localFragment2, bool);
      break label47;
      label104: paramArrayList1.addAll(localArrayMap.values());
    }
    label122: callSharedElementStartEnd(localFragment1, localFragment2, bool, localArrayMap, true);
    final Rect localRect;
    if (localObject1 != null)
    {
      localRect = new Rect();
      paramFragmentTransitionImpl.setSharedElementTargets(localObject1, paramView, paramArrayList1);
      setOutEpicenter(paramFragmentTransitionImpl, localObject1, paramObject2, localArrayMap, paramFragmentContainerTransition.firstOutIsPop, paramFragmentContainerTransition.firstOutTransaction);
      if (paramObject1 != null)
        paramFragmentTransitionImpl.setEpicenter(paramObject1, localRect);
    }
    while (true)
    {
      OneShotPreDrawListener.add(paramViewGroup, new Runnable()
      {
        public void run()
        {
          ArrayMap localArrayMap = FragmentTransition.captureInSharedElements(this.val$impl, paramArrayMap, localObject1, paramFragmentContainerTransition);
          if (localArrayMap != null)
          {
            paramArrayList2.addAll(localArrayMap.values());
            paramArrayList2.add(paramView);
          }
          FragmentTransition.callSharedElementStartEnd(localFragment1, localFragment2, bool, localArrayMap, false);
          if (localObject1 != null)
          {
            this.val$impl.swapSharedElementTargets(localObject1, paramArrayList1, paramArrayList2);
            View localView = FragmentTransition.getInEpicenterView(localArrayMap, paramFragmentContainerTransition, paramObject1, bool);
            if (localView != null)
              this.val$impl.getBoundsOnScreen(localView, localRect);
          }
        }
      });
      break;
      localRect = null;
    }
  }

  private static Object configureSharedElementsReordered(final FragmentTransitionImpl paramFragmentTransitionImpl, ViewGroup paramViewGroup, View paramView, ArrayMap<String, String> paramArrayMap, FragmentContainerTransition paramFragmentContainerTransition, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2, Object paramObject1, Object paramObject2)
  {
    Fragment localFragment1 = paramFragmentContainerTransition.lastIn;
    final Fragment localFragment2 = paramFragmentContainerTransition.firstOut;
    if (localFragment1 != null)
      localFragment1.getView().setVisibility(0);
    Object localObject;
    if ((localFragment1 == null) || (localFragment2 == null))
    {
      localObject = null;
      return localObject;
    }
    final boolean bool = paramFragmentContainerTransition.lastInIsPop;
    label61: ArrayMap localArrayMap1;
    final ArrayMap localArrayMap2;
    if (paramArrayMap.isEmpty())
    {
      localObject = null;
      localArrayMap1 = captureOutSharedElements(paramFragmentTransitionImpl, paramArrayMap, localObject, paramFragmentContainerTransition);
      localArrayMap2 = captureInSharedElements(paramFragmentTransitionImpl, paramArrayMap, localObject, paramFragmentContainerTransition);
      if (!paramArrayMap.isEmpty())
        break label149;
      localObject = null;
      if (localArrayMap1 != null)
        localArrayMap1.clear();
      if (localArrayMap2 != null)
        localArrayMap2.clear();
    }
    while (true)
    {
      if ((paramObject1 != null) || (paramObject2 != null) || (localObject != null))
        break label174;
      localObject = null;
      break;
      localObject = getSharedElementTransition(paramFragmentTransitionImpl, localFragment1, localFragment2, bool);
      break label61;
      label149: addSharedElementsWithMatchingNames(paramArrayList1, localArrayMap1, paramArrayMap.keySet());
      addSharedElementsWithMatchingNames(paramArrayList2, localArrayMap2, paramArrayMap.values());
    }
    label174: callSharedElementStartEnd(localFragment1, localFragment2, bool, localArrayMap1, true);
    final Rect localRect;
    final View localView;
    if (localObject != null)
    {
      paramArrayList2.add(paramView);
      paramFragmentTransitionImpl.setSharedElementTargets(localObject, paramView, paramArrayList1);
      setOutEpicenter(paramFragmentTransitionImpl, localObject, paramObject2, localArrayMap1, paramFragmentContainerTransition.firstOutIsPop, paramFragmentContainerTransition.firstOutTransaction);
      localRect = new Rect();
      localView = getInEpicenterView(localArrayMap2, paramFragmentContainerTransition, paramObject1, bool);
      if (localView != null)
        paramFragmentTransitionImpl.setEpicenter(paramObject1, localRect);
    }
    while (true)
    {
      OneShotPreDrawListener.add(paramViewGroup, new Runnable()
      {
        public void run()
        {
          FragmentTransition.callSharedElementStartEnd(this.val$inFragment, localFragment2, bool, localArrayMap2, false);
          if (localView != null)
            paramFragmentTransitionImpl.getBoundsOnScreen(localView, localRect);
        }
      });
      break;
      localRect = null;
      localView = null;
    }
  }

  private static void configureTransitionsOrdered(FragmentManagerImpl paramFragmentManagerImpl, int paramInt, FragmentContainerTransition paramFragmentContainerTransition, View paramView, ArrayMap<String, String> paramArrayMap)
  {
    ViewGroup localViewGroup = null;
    if (paramFragmentManagerImpl.mContainer.onHasView())
      localViewGroup = (ViewGroup)paramFragmentManagerImpl.mContainer.onFindViewById(paramInt);
    if (localViewGroup == null);
    while (true)
    {
      return;
      Fragment localFragment1 = paramFragmentContainerTransition.lastIn;
      Fragment localFragment2 = paramFragmentContainerTransition.firstOut;
      FragmentTransitionImpl localFragmentTransitionImpl = chooseImpl(localFragment2, localFragment1);
      if (localFragmentTransitionImpl != null)
      {
        boolean bool1 = paramFragmentContainerTransition.lastInIsPop;
        boolean bool2 = paramFragmentContainerTransition.firstOutIsPop;
        Object localObject1 = getEnterTransition(localFragmentTransitionImpl, localFragment1, bool1);
        Object localObject2 = getExitTransition(localFragmentTransitionImpl, localFragment2, bool2);
        ArrayList localArrayList1 = new ArrayList();
        ArrayList localArrayList2 = new ArrayList();
        Object localObject3 = configureSharedElementsOrdered(localFragmentTransitionImpl, localViewGroup, paramView, paramArrayMap, paramFragmentContainerTransition, localArrayList1, localArrayList2, localObject1, localObject2);
        if ((localObject1 != null) || (localObject3 != null) || (localObject2 != null))
        {
          ArrayList localArrayList3 = configureEnteringExitingViews(localFragmentTransitionImpl, localObject2, localFragment2, localArrayList1, paramView);
          if ((localArrayList3 == null) || (localArrayList3.isEmpty()))
            localObject2 = null;
          localFragmentTransitionImpl.addTarget(localObject1, paramView);
          boolean bool3 = paramFragmentContainerTransition.lastInIsPop;
          Object localObject4 = mergeTransitions(localFragmentTransitionImpl, localObject1, localObject2, localObject3, localFragment1, bool3);
          if (localObject4 != null)
          {
            ArrayList localArrayList4 = new ArrayList();
            localFragmentTransitionImpl.scheduleRemoveTargets(localObject4, localObject1, localArrayList4, localObject2, localArrayList3, localObject3, localArrayList2);
            scheduleTargetChange(localFragmentTransitionImpl, localViewGroup, localFragment1, paramView, localArrayList2, localObject1, localArrayList4, localObject2, localArrayList3);
            localFragmentTransitionImpl.setNameOverridesOrdered(localViewGroup, localArrayList2, paramArrayMap);
            localFragmentTransitionImpl.beginDelayedTransition(localViewGroup, localObject4);
            localFragmentTransitionImpl.scheduleNameReset(localViewGroup, localArrayList2, paramArrayMap);
          }
        }
      }
    }
  }

  private static void configureTransitionsReordered(FragmentManagerImpl paramFragmentManagerImpl, int paramInt, FragmentContainerTransition paramFragmentContainerTransition, View paramView, ArrayMap<String, String> paramArrayMap)
  {
    ViewGroup localViewGroup = null;
    if (paramFragmentManagerImpl.mContainer.onHasView())
      localViewGroup = (ViewGroup)paramFragmentManagerImpl.mContainer.onFindViewById(paramInt);
    if (localViewGroup == null);
    while (true)
    {
      return;
      Fragment localFragment1 = paramFragmentContainerTransition.lastIn;
      Fragment localFragment2 = paramFragmentContainerTransition.firstOut;
      FragmentTransitionImpl localFragmentTransitionImpl = chooseImpl(localFragment2, localFragment1);
      if (localFragmentTransitionImpl != null)
      {
        boolean bool1 = paramFragmentContainerTransition.lastInIsPop;
        boolean bool2 = paramFragmentContainerTransition.firstOutIsPop;
        ArrayList localArrayList1 = new ArrayList();
        ArrayList localArrayList2 = new ArrayList();
        Object localObject1 = getEnterTransition(localFragmentTransitionImpl, localFragment1, bool1);
        Object localObject2 = getExitTransition(localFragmentTransitionImpl, localFragment2, bool2);
        Object localObject3 = configureSharedElementsReordered(localFragmentTransitionImpl, localViewGroup, paramView, paramArrayMap, paramFragmentContainerTransition, localArrayList2, localArrayList1, localObject1, localObject2);
        if ((localObject1 != null) || (localObject3 != null) || (localObject2 != null))
        {
          ArrayList localArrayList3 = configureEnteringExitingViews(localFragmentTransitionImpl, localObject2, localFragment2, localArrayList2, paramView);
          ArrayList localArrayList4 = configureEnteringExitingViews(localFragmentTransitionImpl, localObject1, localFragment1, localArrayList1, paramView);
          setViewVisibility(localArrayList4, 4);
          Object localObject4 = mergeTransitions(localFragmentTransitionImpl, localObject1, localObject2, localObject3, localFragment1, bool1);
          if (localObject4 != null)
          {
            replaceHide(localFragmentTransitionImpl, localObject2, localFragment2, localArrayList3);
            ArrayList localArrayList5 = localFragmentTransitionImpl.prepareSetNameOverridesReordered(localArrayList1);
            localFragmentTransitionImpl.scheduleRemoveTargets(localObject4, localObject1, localArrayList4, localObject2, localArrayList3, localObject3, localArrayList1);
            localFragmentTransitionImpl.beginDelayedTransition(localViewGroup, localObject4);
            localFragmentTransitionImpl.setNameOverridesReordered(localViewGroup, localArrayList2, localArrayList1, localArrayList5, paramArrayMap);
            setViewVisibility(localArrayList4, 0);
            localFragmentTransitionImpl.swapSharedElementTargets(localObject3, localArrayList2, localArrayList1);
          }
        }
      }
    }
  }

  private static FragmentContainerTransition ensureContainer(FragmentContainerTransition paramFragmentContainerTransition, SparseArray<FragmentContainerTransition> paramSparseArray, int paramInt)
  {
    if (paramFragmentContainerTransition == null)
    {
      paramFragmentContainerTransition = new FragmentContainerTransition();
      paramSparseArray.put(paramInt, paramFragmentContainerTransition);
    }
    return paramFragmentContainerTransition;
  }

  private static String findKeyForValue(ArrayMap<String, String> paramArrayMap, String paramString)
  {
    int i = paramArrayMap.size();
    int j = 0;
    if (j < i)
      if (!paramString.equals(paramArrayMap.valueAt(j)));
    for (String str = (String)paramArrayMap.keyAt(j); ; str = null)
    {
      return str;
      j++;
      break;
    }
  }

  private static Object getEnterTransition(FragmentTransitionImpl paramFragmentTransitionImpl, Fragment paramFragment, boolean paramBoolean)
  {
    Object localObject2;
    if (paramFragment == null)
    {
      localObject2 = null;
      return localObject2;
    }
    if (paramBoolean);
    for (Object localObject1 = paramFragment.getReenterTransition(); ; localObject1 = paramFragment.getEnterTransition())
    {
      localObject2 = paramFragmentTransitionImpl.cloneTransition(localObject1);
      break;
    }
  }

  private static Object getExitTransition(FragmentTransitionImpl paramFragmentTransitionImpl, Fragment paramFragment, boolean paramBoolean)
  {
    Object localObject2;
    if (paramFragment == null)
    {
      localObject2 = null;
      return localObject2;
    }
    if (paramBoolean);
    for (Object localObject1 = paramFragment.getReturnTransition(); ; localObject1 = paramFragment.getExitTransition())
    {
      localObject2 = paramFragmentTransitionImpl.cloneTransition(localObject1);
      break;
    }
  }

  static View getInEpicenterView(ArrayMap<String, View> paramArrayMap, FragmentContainerTransition paramFragmentContainerTransition, Object paramObject, boolean paramBoolean)
  {
    BackStackRecord localBackStackRecord = paramFragmentContainerTransition.lastInTransaction;
    String str;
    if ((paramObject != null) && (paramArrayMap != null) && (localBackStackRecord.mSharedElementSourceNames != null) && (!localBackStackRecord.mSharedElementSourceNames.isEmpty()))
      if (paramBoolean)
        str = (String)localBackStackRecord.mSharedElementSourceNames.get(0);
    for (View localView = (View)paramArrayMap.get(str); ; localView = null)
    {
      return localView;
      str = (String)localBackStackRecord.mSharedElementTargetNames.get(0);
      break;
    }
  }

  private static Object getSharedElementTransition(FragmentTransitionImpl paramFragmentTransitionImpl, Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean)
  {
    Object localObject1;
    if ((paramFragment1 == null) || (paramFragment2 == null))
    {
      localObject1 = null;
      return localObject1;
    }
    if (paramBoolean);
    for (Object localObject2 = paramFragment2.getSharedElementReturnTransition(); ; localObject2 = paramFragment1.getSharedElementEnterTransition())
    {
      localObject1 = paramFragmentTransitionImpl.wrapTransitionInSet(paramFragmentTransitionImpl.cloneTransition(localObject2));
      break;
    }
  }

  private static Object mergeTransitions(FragmentTransitionImpl paramFragmentTransitionImpl, Object paramObject1, Object paramObject2, Object paramObject3, Fragment paramFragment, boolean paramBoolean)
  {
    boolean bool = true;
    if ((paramObject1 != null) && (paramObject2 != null) && (paramFragment != null))
    {
      if (paramBoolean)
        bool = paramFragment.getAllowReturnTransitionOverlap();
    }
    else
      if (!bool)
        break label55;
    label55: for (Object localObject = paramFragmentTransitionImpl.mergeTransitionsTogether(paramObject2, paramObject1, paramObject3); ; localObject = paramFragmentTransitionImpl.mergeTransitionsInSequence(paramObject2, paramObject1, paramObject3))
    {
      return localObject;
      bool = paramFragment.getAllowEnterTransitionOverlap();
      break;
    }
  }

  private static void replaceHide(FragmentTransitionImpl paramFragmentTransitionImpl, Object paramObject, Fragment paramFragment, ArrayList<View> paramArrayList)
  {
    if ((paramFragment != null) && (paramObject != null) && (paramFragment.mAdded) && (paramFragment.mHidden) && (paramFragment.mHiddenChanged))
    {
      paramFragment.setHideReplaced(true);
      paramFragmentTransitionImpl.scheduleHideFragmentView(paramObject, paramFragment.getView(), paramArrayList);
      OneShotPreDrawListener.add(paramFragment.mContainer, new Runnable()
      {
        public void run()
        {
          FragmentTransition.setViewVisibility(this.val$exitingViews, 4);
        }
      });
    }
  }

  private static FragmentTransitionImpl resolveSupportImpl()
  {
    try
    {
      localFragmentTransitionImpl = (FragmentTransitionImpl)Class.forName("androidx.transition.FragmentTransitionSupport").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
      return localFragmentTransitionImpl;
    }
    catch (Exception localException)
    {
      while (true)
        FragmentTransitionImpl localFragmentTransitionImpl = null;
    }
  }

  private static void retainValues(ArrayMap<String, String> paramArrayMap, ArrayMap<String, View> paramArrayMap1)
  {
    for (int i = -1 + paramArrayMap.size(); i >= 0; i--)
      if (!paramArrayMap1.containsKey((String)paramArrayMap.valueAt(i)))
        paramArrayMap.removeAt(i);
  }

  private static void scheduleTargetChange(final FragmentTransitionImpl paramFragmentTransitionImpl, ViewGroup paramViewGroup, final Fragment paramFragment, final View paramView, final ArrayList<View> paramArrayList1, Object paramObject1, final ArrayList<View> paramArrayList2, final Object paramObject2, final ArrayList<View> paramArrayList3)
  {
    OneShotPreDrawListener.add(paramViewGroup, new Runnable()
    {
      public void run()
      {
        if (this.val$enterTransition != null)
        {
          paramFragmentTransitionImpl.removeTarget(this.val$enterTransition, paramView);
          ArrayList localArrayList2 = FragmentTransition.configureEnteringExitingViews(paramFragmentTransitionImpl, this.val$enterTransition, paramFragment, paramArrayList1, paramView);
          paramArrayList2.addAll(localArrayList2);
        }
        if (paramArrayList3 != null)
        {
          if (paramObject2 != null)
          {
            ArrayList localArrayList1 = new ArrayList();
            localArrayList1.add(paramView);
            paramFragmentTransitionImpl.replaceTargets(paramObject2, paramArrayList3, localArrayList1);
          }
          paramArrayList3.clear();
          paramArrayList3.add(paramView);
        }
      }
    });
  }

  private static void setOutEpicenter(FragmentTransitionImpl paramFragmentTransitionImpl, Object paramObject1, Object paramObject2, ArrayMap<String, View> paramArrayMap, boolean paramBoolean, BackStackRecord paramBackStackRecord)
  {
    if ((paramBackStackRecord.mSharedElementSourceNames != null) && (!paramBackStackRecord.mSharedElementSourceNames.isEmpty()))
      if (!paramBoolean)
        break label68;
    label68: for (String str = (String)paramBackStackRecord.mSharedElementTargetNames.get(0); ; str = (String)paramBackStackRecord.mSharedElementSourceNames.get(0))
    {
      View localView = (View)paramArrayMap.get(str);
      paramFragmentTransitionImpl.setEpicenter(paramObject1, localView);
      if (paramObject2 != null)
        paramFragmentTransitionImpl.setEpicenter(paramObject2, localView);
      return;
    }
  }

  static void setViewVisibility(ArrayList<View> paramArrayList, int paramInt)
  {
    if (paramArrayList == null);
    while (true)
    {
      return;
      for (int i = -1 + paramArrayList.size(); i >= 0; i--)
        ((View)paramArrayList.get(i)).setVisibility(paramInt);
    }
  }

  static void startTransitions(FragmentManagerImpl paramFragmentManagerImpl, ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    if (paramFragmentManagerImpl.mCurState < 1);
    SparseArray localSparseArray;
    do
    {
      return;
      localSparseArray = new SparseArray();
      int i = paramInt1;
      if (i < paramInt2)
      {
        BackStackRecord localBackStackRecord = (BackStackRecord)paramArrayList.get(i);
        if (((Boolean)paramArrayList1.get(i)).booleanValue())
          calculatePopFragments(localBackStackRecord, localSparseArray, paramBoolean);
        while (true)
        {
          i++;
          break;
          calculateFragments(localBackStackRecord, localSparseArray, paramBoolean);
        }
      }
    }
    while (localSparseArray.size() == 0);
    View localView = new View(paramFragmentManagerImpl.mHost.getContext());
    int j = localSparseArray.size();
    int k = 0;
    label115: int m;
    ArrayMap localArrayMap;
    FragmentContainerTransition localFragmentContainerTransition;
    if (k < j)
    {
      m = localSparseArray.keyAt(k);
      localArrayMap = calculateNameOverrides(m, paramArrayList, paramArrayList1, paramInt1, paramInt2);
      localFragmentContainerTransition = (FragmentContainerTransition)localSparseArray.valueAt(k);
      if (!paramBoolean)
        break label178;
      configureTransitionsReordered(paramFragmentManagerImpl, m, localFragmentContainerTransition, localView, localArrayMap);
    }
    while (true)
    {
      k++;
      break label115;
      break;
      label178: configureTransitionsOrdered(paramFragmentManagerImpl, m, localFragmentContainerTransition, localView, localArrayMap);
    }
  }

  static boolean supportsTransition()
  {
    if ((PLATFORM_IMPL != null) || (SUPPORT_IMPL != null));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  static class FragmentContainerTransition
  {
    public Fragment firstOut;
    public boolean firstOutIsPop;
    public BackStackRecord firstOutTransaction;
    public Fragment lastIn;
    public boolean lastInIsPop;
    public BackStackRecord lastInTransaction;
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.fragment.app.FragmentTransition
 * JD-Core Version:    0.6.2
 */