package androidx.fragment.app;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.Transition.EpicenterCallback;
import android.transition.Transition.TransitionListener;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.RequiresApi;
import java.util.ArrayList;
import java.util.List;

@RequiresApi(21)
class FragmentTransitionCompat21 extends FragmentTransitionImpl
{
  private static boolean hasSimpleTarget(Transition paramTransition)
  {
    if ((!isNullOrEmpty(paramTransition.getTargetIds())) || (!isNullOrEmpty(paramTransition.getTargetNames())) || (!isNullOrEmpty(paramTransition.getTargetTypes())));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public void addTarget(Object paramObject, View paramView)
  {
    if (paramObject != null)
      ((Transition)paramObject).addTarget(paramView);
  }

  public void addTargets(Object paramObject, ArrayList<View> paramArrayList)
  {
    Transition localTransition = (Transition)paramObject;
    if (localTransition == null);
    while (true)
    {
      return;
      if ((localTransition instanceof TransitionSet))
      {
        TransitionSet localTransitionSet = (TransitionSet)localTransition;
        int k = localTransitionSet.getTransitionCount();
        for (int m = 0; m < k; m++)
          addTargets(localTransitionSet.getTransitionAt(m), paramArrayList);
      }
      else if ((!hasSimpleTarget(localTransition)) && (isNullOrEmpty(localTransition.getTargets())))
      {
        int i = paramArrayList.size();
        for (int j = 0; j < i; j++)
          localTransition.addTarget((View)paramArrayList.get(j));
      }
    }
  }

  public void beginDelayedTransition(ViewGroup paramViewGroup, Object paramObject)
  {
    TransitionManager.beginDelayedTransition(paramViewGroup, (Transition)paramObject);
  }

  public boolean canHandle(Object paramObject)
  {
    return paramObject instanceof Transition;
  }

  public Object cloneTransition(Object paramObject)
  {
    Transition localTransition = null;
    if (paramObject != null)
      localTransition = ((Transition)paramObject).clone();
    return localTransition;
  }

  public Object mergeTransitionsInSequence(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    Object localObject1 = null;
    Transition localTransition1 = (Transition)paramObject1;
    Transition localTransition2 = (Transition)paramObject2;
    Transition localTransition3 = (Transition)paramObject3;
    Object localObject2;
    if ((localTransition1 != null) && (localTransition2 != null))
    {
      localObject1 = new TransitionSet().addTransition(localTransition1).addTransition(localTransition2).setOrdering(1);
      if (localTransition3 == null)
        break label116;
      localObject2 = new TransitionSet();
      if (localObject1 != null)
        ((TransitionSet)localObject2).addTransition((Transition)localObject1);
      ((TransitionSet)localObject2).addTransition(localTransition3);
    }
    while (true)
    {
      return localObject2;
      if (localTransition1 != null)
      {
        localObject1 = localTransition1;
        break;
      }
      if (localTransition2 == null)
        break;
      localObject1 = localTransition2;
      break;
      label116: localObject2 = localObject1;
    }
  }

  public Object mergeTransitionsTogether(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    TransitionSet localTransitionSet = new TransitionSet();
    if (paramObject1 != null)
      localTransitionSet.addTransition((Transition)paramObject1);
    if (paramObject2 != null)
      localTransitionSet.addTransition((Transition)paramObject2);
    if (paramObject3 != null)
      localTransitionSet.addTransition((Transition)paramObject3);
    return localTransitionSet;
  }

  public void removeTarget(Object paramObject, View paramView)
  {
    if (paramObject != null)
      ((Transition)paramObject).removeTarget(paramView);
  }

  public void replaceTargets(Object paramObject, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2)
  {
    Transition localTransition = (Transition)paramObject;
    if ((localTransition instanceof TransitionSet))
    {
      TransitionSet localTransitionSet = (TransitionSet)localTransition;
      int m = localTransitionSet.getTransitionCount();
      for (int n = 0; n < m; n++)
        replaceTargets(localTransitionSet.getTransitionAt(n), paramArrayList1, paramArrayList2);
    }
    if (!hasSimpleTarget(localTransition))
    {
      List localList = localTransition.getTargets();
      if ((localList != null) && (localList.size() == paramArrayList1.size()) && (localList.containsAll(paramArrayList1)))
      {
        if (paramArrayList2 == null);
        for (int i = 0; ; i = paramArrayList2.size())
          for (int j = 0; j < i; j++)
            localTransition.addTarget((View)paramArrayList2.get(j));
        for (int k = -1 + paramArrayList1.size(); k >= 0; k--)
          localTransition.removeTarget((View)paramArrayList1.get(k));
      }
    }
  }

  public void scheduleHideFragmentView(Object paramObject, final View paramView, final ArrayList<View> paramArrayList)
  {
    ((Transition)paramObject).addListener(new Transition.TransitionListener()
    {
      public void onTransitionCancel(Transition paramAnonymousTransition)
      {
      }

      public void onTransitionEnd(Transition paramAnonymousTransition)
      {
        paramAnonymousTransition.removeListener(this);
        paramView.setVisibility(8);
        int i = paramArrayList.size();
        for (int j = 0; j < i; j++)
          ((View)paramArrayList.get(j)).setVisibility(0);
      }

      public void onTransitionPause(Transition paramAnonymousTransition)
      {
      }

      public void onTransitionResume(Transition paramAnonymousTransition)
      {
      }

      public void onTransitionStart(Transition paramAnonymousTransition)
      {
      }
    });
  }

  public void scheduleRemoveTargets(Object paramObject1, final Object paramObject2, final ArrayList<View> paramArrayList1, final Object paramObject3, final ArrayList<View> paramArrayList2, final Object paramObject4, final ArrayList<View> paramArrayList3)
  {
    ((Transition)paramObject1).addListener(new Transition.TransitionListener()
    {
      public void onTransitionCancel(Transition paramAnonymousTransition)
      {
      }

      public void onTransitionEnd(Transition paramAnonymousTransition)
      {
      }

      public void onTransitionPause(Transition paramAnonymousTransition)
      {
      }

      public void onTransitionResume(Transition paramAnonymousTransition)
      {
      }

      public void onTransitionStart(Transition paramAnonymousTransition)
      {
        if (paramObject2 != null)
          FragmentTransitionCompat21.this.replaceTargets(paramObject2, paramArrayList1, null);
        if (paramObject3 != null)
          FragmentTransitionCompat21.this.replaceTargets(paramObject3, paramArrayList2, null);
        if (paramObject4 != null)
          FragmentTransitionCompat21.this.replaceTargets(paramObject4, paramArrayList3, null);
      }
    });
  }

  public void setEpicenter(Object paramObject, final Rect paramRect)
  {
    if (paramObject != null)
      ((Transition)paramObject).setEpicenterCallback(new Transition.EpicenterCallback()
      {
        public Rect onGetEpicenter(Transition paramAnonymousTransition)
        {
          if ((paramRect == null) || (paramRect.isEmpty()));
          for (Rect localRect = null; ; localRect = paramRect)
            return localRect;
        }
      });
  }

  public void setEpicenter(Object paramObject, View paramView)
  {
    if (paramView != null)
    {
      Transition localTransition = (Transition)paramObject;
      final Rect localRect = new Rect();
      getBoundsOnScreen(paramView, localRect);
      localTransition.setEpicenterCallback(new Transition.EpicenterCallback()
      {
        public Rect onGetEpicenter(Transition paramAnonymousTransition)
        {
          return localRect;
        }
      });
    }
  }

  public void setSharedElementTargets(Object paramObject, View paramView, ArrayList<View> paramArrayList)
  {
    TransitionSet localTransitionSet = (TransitionSet)paramObject;
    List localList = localTransitionSet.getTargets();
    localList.clear();
    int i = paramArrayList.size();
    for (int j = 0; j < i; j++)
      bfsAddViewChildren(localList, (View)paramArrayList.get(j));
    localList.add(paramView);
    paramArrayList.add(paramView);
    addTargets(localTransitionSet, paramArrayList);
  }

  public void swapSharedElementTargets(Object paramObject, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2)
  {
    TransitionSet localTransitionSet = (TransitionSet)paramObject;
    if (localTransitionSet != null)
    {
      localTransitionSet.getTargets().clear();
      localTransitionSet.getTargets().addAll(paramArrayList2);
      replaceTargets(localTransitionSet, paramArrayList1, paramArrayList2);
    }
  }

  public Object wrapTransitionInSet(Object paramObject)
  {
    Object localObject;
    if (paramObject == null)
      localObject = null;
    while (true)
    {
      return localObject;
      localObject = new TransitionSet();
      ((TransitionSet)localObject).addTransition((Transition)paramObject);
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.fragment.app.FragmentTransitionCompat21
 * JD-Core Version:    0.6.2
 */