package androidx.lifecycle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public class Lifecycling
{
  private static final int GENERATED_CALLBACK = 2;
  private static final int REFLECTIVE_CALLBACK = 1;
  private static Map<Class, Integer> sCallbackCache = new HashMap();
  private static Map<Class, List<Constructor<? extends GeneratedAdapter>>> sClassToAdapters = new HashMap();

  private static GeneratedAdapter createGeneratedAdapter(Constructor<? extends GeneratedAdapter> paramConstructor, Object paramObject)
  {
    try
    {
      GeneratedAdapter localGeneratedAdapter = (GeneratedAdapter)paramConstructor.newInstance(new Object[] { paramObject });
      return localGeneratedAdapter;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new RuntimeException(localIllegalAccessException);
    }
    catch (InstantiationException localInstantiationException)
    {
      throw new RuntimeException(localInstantiationException);
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      throw new RuntimeException(localInvocationTargetException);
    }
  }

  @Nullable
  private static Constructor<? extends GeneratedAdapter> generatedConstructor(Class<?> paramClass)
  {
    while (true)
    {
      Constructor localConstructor;
      try
      {
        Package localPackage = paramClass.getPackage();
        String str1 = paramClass.getCanonicalName();
        if (localPackage == null)
          break label148;
        str2 = localPackage.getName();
        if (str2.isEmpty())
        {
          localObject = getAdapterName(str1);
          if (str2.isEmpty())
          {
            localConstructor = Class.forName((String)localObject).getDeclaredConstructor(new Class[] { paramClass });
            if (localConstructor.isAccessible())
              break label146;
            localConstructor.setAccessible(true);
            break label146;
          }
        }
        else
        {
          str1 = str1.substring(1 + str2.length());
          continue;
        }
        String str3 = str2 + "." + (String)localObject;
        Object localObject = str3;
        continue;
      }
      catch (ClassNotFoundException localClassNotFoundException)
      {
        localConstructor = null;
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
        throw new RuntimeException(localNoSuchMethodException);
      }
      label146: return localConstructor;
      label148: String str2 = "";
    }
  }

  public static String getAdapterName(String paramString)
  {
    return paramString.replace(".", "_") + "_LifecycleAdapter";
  }

  @NonNull
  static GenericLifecycleObserver getCallback(Object paramObject)
  {
    Object localObject;
    if ((paramObject instanceof FullLifecycleObserver))
      localObject = new FullLifecycleObserverAdapter((FullLifecycleObserver)paramObject);
    while (true)
    {
      return localObject;
      if ((paramObject instanceof GenericLifecycleObserver))
      {
        localObject = (GenericLifecycleObserver)paramObject;
      }
      else
      {
        Class localClass = paramObject.getClass();
        if (getObserverConstructorType(localClass) == 2)
        {
          List localList = (List)sClassToAdapters.get(localClass);
          if (localList.size() == 1)
          {
            localObject = new SingleGeneratedAdapterObserver(createGeneratedAdapter((Constructor)localList.get(0), paramObject));
          }
          else
          {
            GeneratedAdapter[] arrayOfGeneratedAdapter = new GeneratedAdapter[localList.size()];
            for (int i = 0; i < localList.size(); i++)
              arrayOfGeneratedAdapter[i] = createGeneratedAdapter((Constructor)localList.get(i), paramObject);
            localObject = new CompositeGeneratedAdaptersObserver(arrayOfGeneratedAdapter);
          }
        }
        else
        {
          localObject = new ReflectiveGenericLifecycleObserver(paramObject);
        }
      }
    }
  }

  private static int getObserverConstructorType(Class<?> paramClass)
  {
    int i;
    if (sCallbackCache.containsKey(paramClass))
      i = ((Integer)sCallbackCache.get(paramClass)).intValue();
    while (true)
    {
      return i;
      i = resolveObserverCallbackType(paramClass);
      sCallbackCache.put(paramClass, Integer.valueOf(i));
    }
  }

  private static boolean isLifecycleParent(Class<?> paramClass)
  {
    if ((paramClass != null) && (LifecycleObserver.class.isAssignableFrom(paramClass)));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private static int resolveObserverCallbackType(Class<?> paramClass)
  {
    int k;
    if (paramClass.getCanonicalName() == null)
      k = 1;
    while (true)
    {
      return k;
      Constructor localConstructor = generatedConstructor(paramClass);
      if (localConstructor != null)
      {
        sClassToAdapters.put(paramClass, Collections.singletonList(localConstructor));
        k = 2;
      }
      else if (ClassesInfoCache.sInstance.hasLifecycleMethods(paramClass))
      {
        k = 1;
      }
      else
      {
        Class localClass1 = paramClass.getSuperclass();
        ArrayList localArrayList = null;
        if (isLifecycleParent(localClass1))
        {
          if (getObserverConstructorType(localClass1) == 1)
            k = 1;
          else
            localArrayList = new ArrayList((Collection)sClassToAdapters.get(localClass1));
        }
        else
        {
          Class[] arrayOfClass = paramClass.getInterfaces();
          int i = arrayOfClass.length;
          int j = 0;
          label120: if (j < i)
          {
            Class localClass2 = arrayOfClass[j];
            if (!isLifecycleParent(localClass2));
            while (true)
            {
              j++;
              break label120;
              if (getObserverConstructorType(localClass2) == 1)
              {
                k = 1;
                break;
              }
              if (localArrayList == null)
                localArrayList = new ArrayList();
              localArrayList.addAll((Collection)sClassToAdapters.get(localClass2));
            }
          }
          if (localArrayList != null)
          {
            sClassToAdapters.put(paramClass, localArrayList);
            k = 2;
          }
          else
          {
            k = 1;
          }
        }
      }
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.Lifecycling
 * JD-Core Version:    0.6.2
 */