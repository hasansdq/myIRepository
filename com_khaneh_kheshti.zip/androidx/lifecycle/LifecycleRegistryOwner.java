package androidx.lifecycle;

import androidx.annotation.NonNull;

@Deprecated
public abstract interface LifecycleRegistryOwner extends LifecycleOwner
{
  @NonNull
  public abstract LifecycleRegistry getLifecycle();
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.LifecycleRegistryOwner
 * JD-Core Version:    0.6.2
 */