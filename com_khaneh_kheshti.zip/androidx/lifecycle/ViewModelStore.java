package androidx.lifecycle;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

public class ViewModelStore
{
  private final HashMap<String, ViewModel> mMap = new HashMap();

  public final void clear()
  {
    Iterator localIterator = this.mMap.values().iterator();
    while (localIterator.hasNext())
      ((ViewModel)localIterator.next()).onCleared();
    this.mMap.clear();
  }

  final ViewModel get(String paramString)
  {
    return (ViewModel)this.mMap.get(paramString);
  }

  final void put(String paramString, ViewModel paramViewModel)
  {
    ViewModel localViewModel = (ViewModel)this.mMap.put(paramString, paramViewModel);
    if (localViewModel != null)
      localViewModel.onCleared();
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.ViewModelStore
 * JD-Core Version:    0.6.2
 */