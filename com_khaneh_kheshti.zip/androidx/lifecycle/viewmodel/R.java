package androidx.lifecycle.viewmodel;

public final class R
{
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.viewmodel.R
 * JD-Core Version:    0.6.2
 */