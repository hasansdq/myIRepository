package androidx.lifecycle;

public abstract class ViewModel
{
  protected void onCleared()
  {
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.ViewModel
 * JD-Core Version:    0.6.2
 */