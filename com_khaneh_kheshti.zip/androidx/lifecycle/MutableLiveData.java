package androidx.lifecycle;

public class MutableLiveData<T> extends LiveData<T>
{
  public void postValue(T paramT)
  {
    super.postValue(paramT);
  }

  public void setValue(T paramT)
  {
    super.setValue(paramT);
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.MutableLiveData
 * JD-Core Version:    0.6.2
 */