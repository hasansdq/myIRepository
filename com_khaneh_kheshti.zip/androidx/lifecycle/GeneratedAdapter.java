package androidx.lifecycle;

import androidx.annotation.RestrictTo;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public abstract interface GeneratedAdapter
{
  public abstract void callMethods(LifecycleOwner paramLifecycleOwner, Lifecycle.Event paramEvent, boolean paramBoolean, MethodCallsLogger paramMethodCallsLogger);
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.GeneratedAdapter
 * JD-Core Version:    0.6.2
 */