package androidx.lifecycle;

import androidx.annotation.RestrictTo;
import java.util.HashMap;
import java.util.Map;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public class MethodCallsLogger
{
  private Map<String, Integer> mCalledMethods = new HashMap();

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public boolean approveCall(String paramString, int paramInt)
  {
    boolean bool1 = true;
    Integer localInteger = (Integer)this.mCalledMethods.get(paramString);
    int i;
    boolean bool2;
    if (localInteger != null)
    {
      i = localInteger.intValue();
      if ((i & paramInt) == 0)
        break label70;
      bool2 = bool1;
      label39: this.mCalledMethods.put(paramString, Integer.valueOf(i | paramInt));
      if (bool2)
        break label76;
    }
    while (true)
    {
      return bool1;
      i = 0;
      break;
      label70: bool2 = false;
      break label39;
      label76: bool1 = false;
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.MethodCallsLogger
 * JD-Core Version:    0.6.2
 */