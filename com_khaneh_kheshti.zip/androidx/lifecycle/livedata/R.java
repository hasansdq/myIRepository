package androidx.lifecycle.livedata;

public final class R
{
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.livedata.R
 * JD-Core Version:    0.6.2
 */