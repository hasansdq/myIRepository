package androidx.lifecycle;

public abstract interface Observer<T>
{
  public abstract void onChanged(T paramT);
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.Observer
 * JD-Core Version:    0.6.2
 */