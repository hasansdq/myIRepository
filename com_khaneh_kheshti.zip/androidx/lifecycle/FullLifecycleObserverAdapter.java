package androidx.lifecycle;

class FullLifecycleObserverAdapter
  implements GenericLifecycleObserver
{
  private final FullLifecycleObserver mObserver;

  FullLifecycleObserverAdapter(FullLifecycleObserver paramFullLifecycleObserver)
  {
    this.mObserver = paramFullLifecycleObserver;
  }

  public void onStateChanged(LifecycleOwner paramLifecycleOwner, Lifecycle.Event paramEvent)
  {
    switch (1.$SwitchMap$androidx$lifecycle$Lifecycle$Event[paramEvent.ordinal()])
    {
    default:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
      while (true)
      {
        return;
        this.mObserver.onCreate(paramLifecycleOwner);
        continue;
        this.mObserver.onStart(paramLifecycleOwner);
        continue;
        this.mObserver.onResume(paramLifecycleOwner);
        continue;
        this.mObserver.onPause(paramLifecycleOwner);
        continue;
        this.mObserver.onStop(paramLifecycleOwner);
        continue;
        this.mObserver.onDestroy(paramLifecycleOwner);
      }
    case 7:
    }
    throw new IllegalArgumentException("ON_ANY must not been send by anybody");
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.FullLifecycleObserverAdapter
 * JD-Core Version:    0.6.2
 */