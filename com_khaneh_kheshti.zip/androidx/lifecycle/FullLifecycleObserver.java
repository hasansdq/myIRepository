package androidx.lifecycle;

abstract interface FullLifecycleObserver extends LifecycleObserver
{
  public abstract void onCreate(LifecycleOwner paramLifecycleOwner);

  public abstract void onDestroy(LifecycleOwner paramLifecycleOwner);

  public abstract void onPause(LifecycleOwner paramLifecycleOwner);

  public abstract void onResume(LifecycleOwner paramLifecycleOwner);

  public abstract void onStart(LifecycleOwner paramLifecycleOwner);

  public abstract void onStop(LifecycleOwner paramLifecycleOwner);
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.FullLifecycleObserver
 * JD-Core Version:    0.6.2
 */