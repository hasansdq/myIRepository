package androidx.lifecycle;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.arch.core.executor.ArchTaskExecutor;
import androidx.arch.core.internal.SafeIterableMap;
import androidx.arch.core.internal.SafeIterableMap.IteratorWithAdditions;
import java.util.Iterator;
import java.util.Map.Entry;

public abstract class LiveData<T>
{
  static final Object NOT_SET = new Object();
  static final int START_VERSION = -1;
  int mActiveCount = 0;
  private volatile Object mData = NOT_SET;
  final Object mDataLock = new Object();
  private boolean mDispatchInvalidated;
  private boolean mDispatchingValue;
  private SafeIterableMap<Observer<? super T>, LiveData<T>.ObserverWrapper> mObservers = new SafeIterableMap();
  volatile Object mPendingData = NOT_SET;
  private final Runnable mPostValueRunnable = new Runnable()
  {
    public void run()
    {
      synchronized (LiveData.this.mDataLock)
      {
        Object localObject3 = LiveData.this.mPendingData;
        LiveData.this.mPendingData = LiveData.NOT_SET;
        LiveData.this.setValue(localObject3);
        return;
      }
    }
  };
  private int mVersion = -1;

  private static void assertMainThread(String paramString)
  {
    if (!ArchTaskExecutor.getInstance().isMainThread())
      throw new IllegalStateException("Cannot invoke " + paramString + " on a background" + " thread");
  }

  private void considerNotify(LiveData<T>.ObserverWrapper paramLiveData)
  {
    if (!paramLiveData.mActive);
    while (true)
    {
      return;
      if (!paramLiveData.shouldBeActive())
      {
        paramLiveData.activeStateChanged(false);
      }
      else if (paramLiveData.mLastVersion < this.mVersion)
      {
        paramLiveData.mLastVersion = this.mVersion;
        paramLiveData.mObserver.onChanged(this.mData);
      }
    }
  }

  void dispatchingValue(@Nullable LiveData<T>.ObserverWrapper paramLiveData)
  {
    if (this.mDispatchingValue)
    {
      this.mDispatchInvalidated = true;
      return;
    }
    this.mDispatchingValue = true;
    label33: label95: 
    while (true)
    {
      this.mDispatchInvalidated = false;
      if (paramLiveData != null)
      {
        considerNotify(paramLiveData);
        paramLiveData = null;
      }
      while (true)
      {
        if (this.mDispatchInvalidated)
          break label95;
        this.mDispatchingValue = false;
        break;
        SafeIterableMap.IteratorWithAdditions localIteratorWithAdditions = this.mObservers.iteratorWithAdditions();
        if (localIteratorWithAdditions.hasNext())
        {
          considerNotify((ObserverWrapper)((Map.Entry)localIteratorWithAdditions.next()).getValue());
          if (!this.mDispatchInvalidated)
            break label33;
        }
      }
    }
  }

  @Nullable
  public T getValue()
  {
    Object localObject = this.mData;
    if (localObject != NOT_SET);
    while (true)
    {
      return localObject;
      localObject = null;
    }
  }

  int getVersion()
  {
    return this.mVersion;
  }

  public boolean hasActiveObservers()
  {
    if (this.mActiveCount > 0);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean hasObservers()
  {
    if (this.mObservers.size() > 0);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  @MainThread
  public void observe(@NonNull LifecycleOwner paramLifecycleOwner, @NonNull Observer<? super T> paramObserver)
  {
    assertMainThread("observe");
    if (paramLifecycleOwner.getLifecycle().getCurrentState() == Lifecycle.State.DESTROYED);
    while (true)
    {
      return;
      LifecycleBoundObserver localLifecycleBoundObserver = new LifecycleBoundObserver(paramLifecycleOwner, paramObserver);
      ObserverWrapper localObserverWrapper = (ObserverWrapper)this.mObservers.putIfAbsent(paramObserver, localLifecycleBoundObserver);
      if ((localObserverWrapper != null) && (!localObserverWrapper.isAttachedTo(paramLifecycleOwner)))
        throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
      if (localObserverWrapper == null)
        paramLifecycleOwner.getLifecycle().addObserver(localLifecycleBoundObserver);
    }
  }

  @MainThread
  public void observeForever(@NonNull Observer<? super T> paramObserver)
  {
    assertMainThread("observeForever");
    AlwaysActiveObserver localAlwaysActiveObserver = new AlwaysActiveObserver(paramObserver);
    ObserverWrapper localObserverWrapper = (ObserverWrapper)this.mObservers.putIfAbsent(paramObserver, localAlwaysActiveObserver);
    if ((localObserverWrapper != null) && ((localObserverWrapper instanceof LifecycleBoundObserver)))
      throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
    if (localObserverWrapper != null);
    while (true)
    {
      return;
      localAlwaysActiveObserver.activeStateChanged(true);
    }
  }

  protected void onActive()
  {
  }

  protected void onInactive()
  {
  }

  protected void postValue(T paramT)
  {
    while (true)
    {
      synchronized (this.mDataLock)
      {
        if (this.mPendingData != NOT_SET)
          break label51;
        i = 1;
        this.mPendingData = paramT;
        if (i != 0);
      }
      return;
      label51: int i = 0;
    }
  }

  @MainThread
  public void removeObserver(@NonNull Observer<? super T> paramObserver)
  {
    assertMainThread("removeObserver");
    ObserverWrapper localObserverWrapper = (ObserverWrapper)this.mObservers.remove(paramObserver);
    if (localObserverWrapper == null);
    while (true)
    {
      return;
      localObserverWrapper.detachObserver();
      localObserverWrapper.activeStateChanged(false);
    }
  }

  @MainThread
  public void removeObservers(@NonNull LifecycleOwner paramLifecycleOwner)
  {
    assertMainThread("removeObservers");
    Iterator localIterator = this.mObservers.iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      if (((ObserverWrapper)localEntry.getValue()).isAttachedTo(paramLifecycleOwner))
        removeObserver((Observer)localEntry.getKey());
    }
  }

  @MainThread
  protected void setValue(T paramT)
  {
    assertMainThread("setValue");
    this.mVersion = (1 + this.mVersion);
    this.mData = paramT;
    dispatchingValue(null);
  }

  private class AlwaysActiveObserver extends LiveData<T>.ObserverWrapper
  {
    AlwaysActiveObserver()
    {
      super(localObserver);
    }

    boolean shouldBeActive()
    {
      return true;
    }
  }

  class LifecycleBoundObserver extends LiveData<T>.ObserverWrapper
    implements GenericLifecycleObserver
  {

    @NonNull
    final LifecycleOwner mOwner;

    LifecycleBoundObserver(Observer<? super T> arg2)
    {
      super(localObserver);
      Object localObject;
      this.mOwner = localObject;
    }

    void detachObserver()
    {
      this.mOwner.getLifecycle().removeObserver(this);
    }

    boolean isAttachedTo(LifecycleOwner paramLifecycleOwner)
    {
      if (this.mOwner == paramLifecycleOwner);
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    public void onStateChanged(LifecycleOwner paramLifecycleOwner, Lifecycle.Event paramEvent)
    {
      if (this.mOwner.getLifecycle().getCurrentState() == Lifecycle.State.DESTROYED)
        LiveData.this.removeObserver(this.mObserver);
      while (true)
      {
        return;
        activeStateChanged(shouldBeActive());
      }
    }

    boolean shouldBeActive()
    {
      return this.mOwner.getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED);
    }
  }

  private abstract class ObserverWrapper
  {
    boolean mActive;
    int mLastVersion = -1;
    final Observer<? super T> mObserver;

    ObserverWrapper()
    {
      Object localObject;
      this.mObserver = localObject;
    }

    void activeStateChanged(boolean paramBoolean)
    {
      int i = 1;
      if (paramBoolean == this.mActive)
        return;
      this.mActive = paramBoolean;
      int j;
      label28: LiveData localLiveData;
      int k;
      if (LiveData.this.mActiveCount == 0)
      {
        j = i;
        localLiveData = LiveData.this;
        k = localLiveData.mActiveCount;
        if (!this.mActive)
          break label122;
      }
      while (true)
      {
        localLiveData.mActiveCount = (i + k);
        if ((j != 0) && (this.mActive))
          LiveData.this.onActive();
        if ((LiveData.this.mActiveCount == 0) && (!this.mActive))
          LiveData.this.onInactive();
        if (!this.mActive)
          break;
        LiveData.this.dispatchingValue(this);
        break;
        j = 0;
        break label28;
        label122: i = -1;
      }
    }

    void detachObserver()
    {
    }

    boolean isAttachedTo(LifecycleOwner paramLifecycleOwner)
    {
      return false;
    }

    abstract boolean shouldBeActive();
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.LiveData
 * JD-Core Version:    0.6.2
 */