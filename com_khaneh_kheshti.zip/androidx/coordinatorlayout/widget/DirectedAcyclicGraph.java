package androidx.coordinatorlayout.widget;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.collection.SimpleArrayMap;
import androidx.core.util.Pools.Pool;
import androidx.core.util.Pools.SimplePool;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY})
public final class DirectedAcyclicGraph<T>
{
  private final SimpleArrayMap<T, ArrayList<T>> mGraph = new SimpleArrayMap();
  private final Pools.Pool<ArrayList<T>> mListPool = new Pools.SimplePool(10);
  private final ArrayList<T> mSortResult = new ArrayList();
  private final HashSet<T> mSortTmpMarked = new HashSet();

  private void dfs(T paramT, ArrayList<T> paramArrayList, HashSet<T> paramHashSet)
  {
    if (paramArrayList.contains(paramT));
    while (true)
    {
      return;
      if (paramHashSet.contains(paramT))
        throw new RuntimeException("This graph contains cyclic dependencies");
      paramHashSet.add(paramT);
      ArrayList localArrayList = (ArrayList)this.mGraph.get(paramT);
      if (localArrayList != null)
      {
        int i = 0;
        int j = localArrayList.size();
        while (i < j)
        {
          dfs(localArrayList.get(i), paramArrayList, paramHashSet);
          i++;
        }
      }
      paramHashSet.remove(paramT);
      paramArrayList.add(paramT);
    }
  }

  @NonNull
  private ArrayList<T> getEmptyList()
  {
    ArrayList localArrayList = (ArrayList)this.mListPool.acquire();
    if (localArrayList == null)
      localArrayList = new ArrayList();
    return localArrayList;
  }

  private void poolList(@NonNull ArrayList<T> paramArrayList)
  {
    paramArrayList.clear();
    this.mListPool.release(paramArrayList);
  }

  public void addEdge(@NonNull T paramT1, @NonNull T paramT2)
  {
    if ((!this.mGraph.containsKey(paramT1)) || (!this.mGraph.containsKey(paramT2)))
      throw new IllegalArgumentException("All nodes must be present in the graph before being added as an edge");
    ArrayList localArrayList = (ArrayList)this.mGraph.get(paramT1);
    if (localArrayList == null)
    {
      localArrayList = getEmptyList();
      this.mGraph.put(paramT1, localArrayList);
    }
    localArrayList.add(paramT2);
  }

  public void addNode(@NonNull T paramT)
  {
    if (!this.mGraph.containsKey(paramT))
      this.mGraph.put(paramT, null);
  }

  public void clear()
  {
    int i = 0;
    int j = this.mGraph.size();
    while (i < j)
    {
      ArrayList localArrayList = (ArrayList)this.mGraph.valueAt(i);
      if (localArrayList != null)
        poolList(localArrayList);
      i++;
    }
    this.mGraph.clear();
  }

  public boolean contains(@NonNull T paramT)
  {
    return this.mGraph.containsKey(paramT);
  }

  @Nullable
  public List getIncomingEdges(@NonNull T paramT)
  {
    return (List)this.mGraph.get(paramT);
  }

  @Nullable
  public List<T> getOutgoingEdges(@NonNull T paramT)
  {
    ArrayList localArrayList1 = null;
    int i = 0;
    int j = this.mGraph.size();
    while (i < j)
    {
      ArrayList localArrayList2 = (ArrayList)this.mGraph.valueAt(i);
      if ((localArrayList2 != null) && (localArrayList2.contains(paramT)))
      {
        if (localArrayList1 == null)
          localArrayList1 = new ArrayList();
        localArrayList1.add(this.mGraph.keyAt(i));
      }
      i++;
    }
    return localArrayList1;
  }

  @NonNull
  public ArrayList<T> getSortedList()
  {
    this.mSortResult.clear();
    this.mSortTmpMarked.clear();
    int i = 0;
    int j = this.mGraph.size();
    while (i < j)
    {
      dfs(this.mGraph.keyAt(i), this.mSortResult, this.mSortTmpMarked);
      i++;
    }
    return this.mSortResult;
  }

  public boolean hasOutgoingEdges(@NonNull T paramT)
  {
    int i = 0;
    int j = this.mGraph.size();
    if (i < j)
    {
      ArrayList localArrayList = (ArrayList)this.mGraph.valueAt(i);
      if ((localArrayList == null) || (!localArrayList.contains(paramT)));
    }
    for (boolean bool = true; ; bool = false)
    {
      return bool;
      i++;
      break;
    }
  }

  int size()
  {
    return this.mGraph.size();
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.coordinatorlayout.widget.DirectedAcyclicGraph
 * JD-Core Version:    0.6.2
 */