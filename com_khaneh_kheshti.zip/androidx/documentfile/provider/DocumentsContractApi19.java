package androidx.documentfile.provider;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

@RequiresApi(19)
class DocumentsContractApi19
{
  private static final int FLAG_VIRTUAL_DOCUMENT = 512;
  private static final String TAG = "DocumentFile";

  public static boolean canRead(Context paramContext, Uri paramUri)
  {
    boolean bool = false;
    if (paramContext.checkCallingOrSelfUriPermission(paramUri, 1) != 0);
    while (true)
    {
      return bool;
      if (!TextUtils.isEmpty(getRawType(paramContext, paramUri)))
        bool = true;
    }
  }

  public static boolean canWrite(Context paramContext, Uri paramUri)
  {
    boolean bool = false;
    if (paramContext.checkCallingOrSelfUriPermission(paramUri, 2) != 0);
    while (true)
    {
      return bool;
      String str = getRawType(paramContext, paramUri);
      int i = queryForInt(paramContext, paramUri, "flags", 0);
      if (!TextUtils.isEmpty(str))
        if ((i & 0x4) != 0)
          bool = true;
        else if (("vnd.android.document/directory".equals(str)) && ((i & 0x8) != 0))
          bool = true;
        else if ((!TextUtils.isEmpty(str)) && ((i & 0x2) != 0))
          bool = true;
    }
  }

  private static void closeQuietly(@Nullable AutoCloseable paramAutoCloseable)
  {
    if (paramAutoCloseable != null);
    try
    {
      paramAutoCloseable.close();
      label10: return;
    }
    catch (RuntimeException localRuntimeException)
    {
      throw localRuntimeException;
    }
    catch (Exception localException)
    {
      break label10;
    }
  }

  public static boolean exists(Context paramContext, Uri paramUri)
  {
    ContentResolver localContentResolver = paramContext.getContentResolver();
    Cursor localCursor = null;
    try
    {
      localCursor = localContentResolver.query(paramUri, new String[] { "document_id" }, null, null, null);
      int i = localCursor.getCount();
      if (i > 0);
      for (bool = true; ; bool = false)
        return bool;
    }
    catch (Exception localException)
    {
      while (true)
      {
        Log.w("DocumentFile", "Failed query: " + localException);
        closeQuietly(localCursor);
        boolean bool = false;
      }
    }
    finally
    {
      closeQuietly(localCursor);
    }
  }

  public static long getFlags(Context paramContext, Uri paramUri)
  {
    return queryForLong(paramContext, paramUri, "flags", 0L);
  }

  @Nullable
  public static String getName(Context paramContext, Uri paramUri)
  {
    return queryForString(paramContext, paramUri, "_display_name", null);
  }

  @Nullable
  private static String getRawType(Context paramContext, Uri paramUri)
  {
    return queryForString(paramContext, paramUri, "mime_type", null);
  }

  @Nullable
  public static String getType(Context paramContext, Uri paramUri)
  {
    String str = getRawType(paramContext, paramUri);
    if ("vnd.android.document/directory".equals(str))
      str = null;
    return str;
  }

  public static boolean isDirectory(Context paramContext, Uri paramUri)
  {
    return "vnd.android.document/directory".equals(getRawType(paramContext, paramUri));
  }

  public static boolean isFile(Context paramContext, Uri paramUri)
  {
    String str = getRawType(paramContext, paramUri);
    if (("vnd.android.document/directory".equals(str)) || (TextUtils.isEmpty(str)));
    for (boolean bool = false; ; bool = true)
      return bool;
  }

  public static boolean isVirtual(Context paramContext, Uri paramUri)
  {
    boolean bool = false;
    if (!DocumentsContract.isDocumentUri(paramContext, paramUri));
    while (true)
    {
      return bool;
      if ((0x200 & getFlags(paramContext, paramUri)) != 0L)
        bool = true;
    }
  }

  public static long lastModified(Context paramContext, Uri paramUri)
  {
    return queryForLong(paramContext, paramUri, "last_modified", 0L);
  }

  public static long length(Context paramContext, Uri paramUri)
  {
    return queryForLong(paramContext, paramUri, "_size", 0L);
  }

  private static int queryForInt(Context paramContext, Uri paramUri, String paramString, int paramInt)
  {
    return (int)queryForLong(paramContext, paramUri, paramString, paramInt);
  }

  private static long queryForLong(Context paramContext, Uri paramUri, String paramString, long paramLong)
  {
    ContentResolver localContentResolver = paramContext.getContentResolver();
    Cursor localCursor = null;
    try
    {
      localCursor = localContentResolver.query(paramUri, new String[] { paramString }, null, null, null);
      if ((localCursor.moveToFirst()) && (!localCursor.isNull(0)))
      {
        long l = localCursor.getLong(0);
        paramLong = l;
      }
      while (true)
      {
        return paramLong;
        closeQuietly(localCursor);
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        Log.w("DocumentFile", "Failed query: " + localException);
        closeQuietly(localCursor);
      }
    }
    finally
    {
      closeQuietly(localCursor);
    }
  }

  @Nullable
  private static String queryForString(Context paramContext, Uri paramUri, String paramString1, @Nullable String paramString2)
  {
    ContentResolver localContentResolver = paramContext.getContentResolver();
    Cursor localCursor = null;
    try
    {
      localCursor = localContentResolver.query(paramUri, new String[] { paramString1 }, null, null, null);
      if ((localCursor.moveToFirst()) && (!localCursor.isNull(0)))
      {
        String str = localCursor.getString(0);
        paramString2 = str;
      }
      while (true)
      {
        return paramString2;
        closeQuietly(localCursor);
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        Log.w("DocumentFile", "Failed query: " + localException);
        closeQuietly(localCursor);
      }
    }
    finally
    {
      closeQuietly(localCursor);
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.documentfile.provider.DocumentsContractApi19
 * JD-Core Version:    0.6.2
 */