package androidx.documentfile.provider;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import java.util.ArrayList;

@RequiresApi(21)
class TreeDocumentFile extends DocumentFile
{
  private Context mContext;
  private Uri mUri;

  TreeDocumentFile(@Nullable DocumentFile paramDocumentFile, Context paramContext, Uri paramUri)
  {
    super(paramDocumentFile);
    this.mContext = paramContext;
    this.mUri = paramUri;
  }

  private static void closeQuietly(@Nullable AutoCloseable paramAutoCloseable)
  {
    if (paramAutoCloseable != null);
    try
    {
      paramAutoCloseable.close();
      label10: return;
    }
    catch (RuntimeException localRuntimeException)
    {
      throw localRuntimeException;
    }
    catch (Exception localException)
    {
      break label10;
    }
  }

  @Nullable
  private static Uri createFile(Context paramContext, Uri paramUri, String paramString1, String paramString2)
  {
    try
    {
      Uri localUri2 = DocumentsContract.createDocument(paramContext.getContentResolver(), paramUri, paramString1, paramString2);
      localUri1 = localUri2;
      return localUri1;
    }
    catch (Exception localException)
    {
      while (true)
        Uri localUri1 = null;
    }
  }

  public boolean canRead()
  {
    return DocumentsContractApi19.canRead(this.mContext, this.mUri);
  }

  public boolean canWrite()
  {
    return DocumentsContractApi19.canWrite(this.mContext, this.mUri);
  }

  @Nullable
  public DocumentFile createDirectory(String paramString)
  {
    Uri localUri = createFile(this.mContext, this.mUri, "vnd.android.document/directory", paramString);
    if (localUri != null);
    for (TreeDocumentFile localTreeDocumentFile = new TreeDocumentFile(this, this.mContext, localUri); ; localTreeDocumentFile = null)
      return localTreeDocumentFile;
  }

  @Nullable
  public DocumentFile createFile(String paramString1, String paramString2)
  {
    Uri localUri = createFile(this.mContext, this.mUri, paramString1, paramString2);
    if (localUri != null);
    for (TreeDocumentFile localTreeDocumentFile = new TreeDocumentFile(this, this.mContext, localUri); ; localTreeDocumentFile = null)
      return localTreeDocumentFile;
  }

  public boolean delete()
  {
    try
    {
      boolean bool2 = DocumentsContract.deleteDocument(this.mContext.getContentResolver(), this.mUri);
      bool1 = bool2;
      return bool1;
    }
    catch (Exception localException)
    {
      while (true)
        boolean bool1 = false;
    }
  }

  public boolean exists()
  {
    return DocumentsContractApi19.exists(this.mContext, this.mUri);
  }

  @Nullable
  public String getName()
  {
    return DocumentsContractApi19.getName(this.mContext, this.mUri);
  }

  @Nullable
  public String getType()
  {
    return DocumentsContractApi19.getType(this.mContext, this.mUri);
  }

  public Uri getUri()
  {
    return this.mUri;
  }

  public boolean isDirectory()
  {
    return DocumentsContractApi19.isDirectory(this.mContext, this.mUri);
  }

  public boolean isFile()
  {
    return DocumentsContractApi19.isFile(this.mContext, this.mUri);
  }

  public boolean isVirtual()
  {
    return DocumentsContractApi19.isVirtual(this.mContext, this.mUri);
  }

  public long lastModified()
  {
    return DocumentsContractApi19.lastModified(this.mContext, this.mUri);
  }

  public long length()
  {
    return DocumentsContractApi19.length(this.mContext, this.mUri);
  }

  public DocumentFile[] listFiles()
  {
    ContentResolver localContentResolver = this.mContext.getContentResolver();
    Uri localUri = DocumentsContract.buildChildDocumentsUriUsingTree(this.mUri, DocumentsContract.getDocumentId(this.mUri));
    ArrayList localArrayList = new ArrayList();
    Cursor localCursor = null;
    DocumentFile[] arrayOfDocumentFile;
    try
    {
      localCursor = localContentResolver.query(localUri, new String[] { "document_id" }, null, null, null);
      while (localCursor.moveToNext())
      {
        String str = localCursor.getString(0);
        localArrayList.add(DocumentsContract.buildDocumentUriUsingTree(this.mUri, str));
      }
    }
    catch (Exception localException)
    {
      Log.w("DocumentFile", "Failed query: " + localException);
      closeQuietly(localCursor);
      while (true)
      {
        Uri[] arrayOfUri = (Uri[])localArrayList.toArray(new Uri[localArrayList.size()]);
        arrayOfDocumentFile = new DocumentFile[arrayOfUri.length];
        for (int i = 0; i < arrayOfUri.length; i++)
          arrayOfDocumentFile[i] = new TreeDocumentFile(this, this.mContext, arrayOfUri[i]);
        closeQuietly(localCursor);
      }
    }
    finally
    {
      closeQuietly(localCursor);
    }
    return arrayOfDocumentFile;
  }

  public boolean renameTo(String paramString)
  {
    boolean bool = false;
    try
    {
      Uri localUri = DocumentsContract.renameDocument(this.mContext.getContentResolver(), this.mUri, paramString);
      if (localUri != null)
      {
        this.mUri = localUri;
        bool = true;
      }
      label32: return bool;
    }
    catch (Exception localException)
    {
      break label32;
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.documentfile.provider.TreeDocumentFile
 * JD-Core Version:    0.6.2
 */