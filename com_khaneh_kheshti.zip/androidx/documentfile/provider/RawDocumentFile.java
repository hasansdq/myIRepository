package androidx.documentfile.provider;

import android.net.Uri;
import android.util.Log;
import android.webkit.MimeTypeMap;
import androidx.annotation.Nullable;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

class RawDocumentFile extends DocumentFile
{
  private File mFile;

  RawDocumentFile(@Nullable DocumentFile paramDocumentFile, File paramFile)
  {
    super(paramDocumentFile);
    this.mFile = paramFile;
  }

  private static boolean deleteContents(File paramFile)
  {
    File[] arrayOfFile = paramFile.listFiles();
    boolean bool = true;
    if (arrayOfFile != null)
    {
      int i = arrayOfFile.length;
      for (int j = 0; j < i; j++)
      {
        File localFile = arrayOfFile[j];
        if (localFile.isDirectory())
          bool &= deleteContents(localFile);
        if (!localFile.delete())
        {
          Log.w("DocumentFile", "Failed to delete " + localFile);
          bool = false;
        }
      }
    }
    return bool;
  }

  private static String getTypeForName(String paramString)
  {
    int i = paramString.lastIndexOf('.');
    String str1;
    if (i >= 0)
    {
      String str2 = paramString.substring(i + 1).toLowerCase();
      str1 = MimeTypeMap.getSingleton().getMimeTypeFromExtension(str2);
      if (str1 == null);
    }
    while (true)
    {
      return str1;
      str1 = "application/octet-stream";
    }
  }

  public boolean canRead()
  {
    return this.mFile.canRead();
  }

  public boolean canWrite()
  {
    return this.mFile.canWrite();
  }

  @Nullable
  public DocumentFile createDirectory(String paramString)
  {
    File localFile = new File(this.mFile, paramString);
    if ((localFile.isDirectory()) || (localFile.mkdir()));
    for (RawDocumentFile localRawDocumentFile = new RawDocumentFile(this, localFile); ; localRawDocumentFile = null)
      return localRawDocumentFile;
  }

  @Nullable
  public DocumentFile createFile(String paramString1, String paramString2)
  {
    String str = MimeTypeMap.getSingleton().getExtensionFromMimeType(paramString1);
    if (str != null)
      paramString2 = paramString2 + "." + str;
    File localFile = new File(this.mFile, paramString2);
    try
    {
      localFile.createNewFile();
      localRawDocumentFile = new RawDocumentFile(this, localFile);
      return localRawDocumentFile;
    }
    catch (IOException localIOException)
    {
      while (true)
      {
        Log.w("DocumentFile", "Failed to createFile: " + localIOException);
        RawDocumentFile localRawDocumentFile = null;
      }
    }
  }

  public boolean delete()
  {
    deleteContents(this.mFile);
    return this.mFile.delete();
  }

  public boolean exists()
  {
    return this.mFile.exists();
  }

  public String getName()
  {
    return this.mFile.getName();
  }

  @Nullable
  public String getType()
  {
    if (this.mFile.isDirectory());
    for (String str = null; ; str = getTypeForName(this.mFile.getName()))
      return str;
  }

  public Uri getUri()
  {
    return Uri.fromFile(this.mFile);
  }

  public boolean isDirectory()
  {
    return this.mFile.isDirectory();
  }

  public boolean isFile()
  {
    return this.mFile.isFile();
  }

  public boolean isVirtual()
  {
    return false;
  }

  public long lastModified()
  {
    return this.mFile.lastModified();
  }

  public long length()
  {
    return this.mFile.length();
  }

  public DocumentFile[] listFiles()
  {
    ArrayList localArrayList = new ArrayList();
    File[] arrayOfFile = this.mFile.listFiles();
    if (arrayOfFile != null)
    {
      int i = arrayOfFile.length;
      for (int j = 0; j < i; j++)
        localArrayList.add(new RawDocumentFile(this, arrayOfFile[j]));
    }
    return (DocumentFile[])localArrayList.toArray(new DocumentFile[localArrayList.size()]);
  }

  public boolean renameTo(String paramString)
  {
    File localFile = new File(this.mFile.getParentFile(), paramString);
    if (this.mFile.renameTo(localFile))
      this.mFile = localFile;
    for (boolean bool = true; ; bool = false)
      return bool;
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.documentfile.provider.RawDocumentFile
 * JD-Core Version:    0.6.2
 */