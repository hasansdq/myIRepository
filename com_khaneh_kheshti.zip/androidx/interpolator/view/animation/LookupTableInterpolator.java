package androidx.interpolator.view.animation;

import android.view.animation.Interpolator;

abstract class LookupTableInterpolator
  implements Interpolator
{
  private final float mStepSize;
  private final float[] mValues;

  protected LookupTableInterpolator(float[] paramArrayOfFloat)
  {
    this.mValues = paramArrayOfFloat;
    this.mStepSize = (1.0F / (-1 + this.mValues.length));
  }

  public float getInterpolation(float paramFloat)
  {
    float f1 = 1.0F;
    if (paramFloat >= f1);
    while (true)
    {
      return f1;
      if (paramFloat <= 0.0F)
      {
        f1 = 0.0F;
      }
      else
      {
        int i = Math.min((int)(paramFloat * (-1 + this.mValues.length)), -2 + this.mValues.length);
        float f2 = (paramFloat - i * this.mStepSize) / this.mStepSize;
        f1 = this.mValues[i] + f2 * (this.mValues[(i + 1)] - this.mValues[i]);
      }
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.interpolator.view.animation.LookupTableInterpolator
 * JD-Core Version:    0.6.2
 */