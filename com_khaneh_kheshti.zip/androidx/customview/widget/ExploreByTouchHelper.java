package androidx.customview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.collection.SparseArrayCompat;
import androidx.core.view.AccessibilityDelegateCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.ViewParentCompat;
import androidx.core.view.accessibility.AccessibilityEventCompat;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import androidx.core.view.accessibility.AccessibilityNodeProviderCompat;
import androidx.core.view.accessibility.AccessibilityRecordCompat;
import java.util.ArrayList;
import java.util.List;

public abstract class ExploreByTouchHelper extends AccessibilityDelegateCompat
{
  private static final String DEFAULT_CLASS_NAME = "android.view.View";
  public static final int HOST_ID = -1;
  public static final int INVALID_ID = -2147483648;
  private static final Rect INVALID_PARENT_BOUNDS = new Rect(2147483647, 2147483647, -2147483648, -2147483648);
  private static final FocusStrategy.BoundsAdapter<AccessibilityNodeInfoCompat> NODE_ADAPTER = new FocusStrategy.BoundsAdapter()
  {
    public void obtainBounds(AccessibilityNodeInfoCompat paramAnonymousAccessibilityNodeInfoCompat, Rect paramAnonymousRect)
    {
      paramAnonymousAccessibilityNodeInfoCompat.getBoundsInParent(paramAnonymousRect);
    }
  };
  private static final FocusStrategy.CollectionAdapter<SparseArrayCompat<AccessibilityNodeInfoCompat>, AccessibilityNodeInfoCompat> SPARSE_VALUES_ADAPTER = new FocusStrategy.CollectionAdapter()
  {
    public AccessibilityNodeInfoCompat get(SparseArrayCompat<AccessibilityNodeInfoCompat> paramAnonymousSparseArrayCompat, int paramAnonymousInt)
    {
      return (AccessibilityNodeInfoCompat)paramAnonymousSparseArrayCompat.valueAt(paramAnonymousInt);
    }

    public int size(SparseArrayCompat<AccessibilityNodeInfoCompat> paramAnonymousSparseArrayCompat)
    {
      return paramAnonymousSparseArrayCompat.size();
    }
  };
  int mAccessibilityFocusedVirtualViewId = -2147483648;
  private final View mHost;
  private int mHoveredVirtualViewId = -2147483648;
  int mKeyboardFocusedVirtualViewId = -2147483648;
  private final AccessibilityManager mManager;
  private MyNodeProvider mNodeProvider;
  private final int[] mTempGlobalRect = new int[2];
  private final Rect mTempParentRect = new Rect();
  private final Rect mTempScreenRect = new Rect();
  private final Rect mTempVisibleRect = new Rect();

  public ExploreByTouchHelper(@NonNull View paramView)
  {
    if (paramView == null)
      throw new IllegalArgumentException("View may not be null");
    this.mHost = paramView;
    this.mManager = ((AccessibilityManager)paramView.getContext().getSystemService("accessibility"));
    paramView.setFocusable(true);
    if (ViewCompat.getImportantForAccessibility(paramView) == 0)
      ViewCompat.setImportantForAccessibility(paramView, 1);
  }

  private boolean clearAccessibilityFocus(int paramInt)
  {
    if (this.mAccessibilityFocusedVirtualViewId == paramInt)
    {
      this.mAccessibilityFocusedVirtualViewId = -2147483648;
      this.mHost.invalidate();
      sendEventForVirtualView(paramInt, 65536);
    }
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private boolean clickKeyboardFocusedVirtualView()
  {
    if ((this.mKeyboardFocusedVirtualViewId != -2147483648) && (onPerformActionForVirtualView(this.mKeyboardFocusedVirtualViewId, 16, null)));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private AccessibilityEvent createEvent(int paramInt1, int paramInt2)
  {
    switch (paramInt1)
    {
    default:
    case -1:
    }
    for (AccessibilityEvent localAccessibilityEvent = createEventForChild(paramInt1, paramInt2); ; localAccessibilityEvent = createEventForHost(paramInt2))
      return localAccessibilityEvent;
  }

  private AccessibilityEvent createEventForChild(int paramInt1, int paramInt2)
  {
    AccessibilityEvent localAccessibilityEvent = AccessibilityEvent.obtain(paramInt2);
    AccessibilityNodeInfoCompat localAccessibilityNodeInfoCompat = obtainAccessibilityNodeInfo(paramInt1);
    localAccessibilityEvent.getText().add(localAccessibilityNodeInfoCompat.getText());
    localAccessibilityEvent.setContentDescription(localAccessibilityNodeInfoCompat.getContentDescription());
    localAccessibilityEvent.setScrollable(localAccessibilityNodeInfoCompat.isScrollable());
    localAccessibilityEvent.setPassword(localAccessibilityNodeInfoCompat.isPassword());
    localAccessibilityEvent.setEnabled(localAccessibilityNodeInfoCompat.isEnabled());
    localAccessibilityEvent.setChecked(localAccessibilityNodeInfoCompat.isChecked());
    onPopulateEventForVirtualView(paramInt1, localAccessibilityEvent);
    if ((localAccessibilityEvent.getText().isEmpty()) && (localAccessibilityEvent.getContentDescription() == null))
      throw new RuntimeException("Callbacks must add text or a content description in populateEventForVirtualViewId()");
    localAccessibilityEvent.setClassName(localAccessibilityNodeInfoCompat.getClassName());
    AccessibilityRecordCompat.setSource(localAccessibilityEvent, this.mHost, paramInt1);
    localAccessibilityEvent.setPackageName(this.mHost.getContext().getPackageName());
    return localAccessibilityEvent;
  }

  private AccessibilityEvent createEventForHost(int paramInt)
  {
    AccessibilityEvent localAccessibilityEvent = AccessibilityEvent.obtain(paramInt);
    this.mHost.onInitializeAccessibilityEvent(localAccessibilityEvent);
    return localAccessibilityEvent;
  }

  @NonNull
  private AccessibilityNodeInfoCompat createNodeForChild(int paramInt)
  {
    AccessibilityNodeInfoCompat localAccessibilityNodeInfoCompat1 = AccessibilityNodeInfoCompat.obtain();
    localAccessibilityNodeInfoCompat1.setEnabled(true);
    localAccessibilityNodeInfoCompat1.setFocusable(true);
    localAccessibilityNodeInfoCompat1.setClassName("android.view.View");
    localAccessibilityNodeInfoCompat1.setBoundsInParent(INVALID_PARENT_BOUNDS);
    localAccessibilityNodeInfoCompat1.setBoundsInScreen(INVALID_PARENT_BOUNDS);
    localAccessibilityNodeInfoCompat1.setParent(this.mHost);
    onPopulateNodeForVirtualView(paramInt, localAccessibilityNodeInfoCompat1);
    if ((localAccessibilityNodeInfoCompat1.getText() == null) && (localAccessibilityNodeInfoCompat1.getContentDescription() == null))
      throw new RuntimeException("Callbacks must add text or a content description in populateNodeForVirtualViewId()");
    localAccessibilityNodeInfoCompat1.getBoundsInParent(this.mTempParentRect);
    if (this.mTempParentRect.equals(INVALID_PARENT_BOUNDS))
      throw new RuntimeException("Callbacks must set parent bounds in populateNodeForVirtualViewId()");
    int i = localAccessibilityNodeInfoCompat1.getActions();
    if ((i & 0x40) != 0)
      throw new RuntimeException("Callbacks must not add ACTION_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
    if ((i & 0x80) != 0)
      throw new RuntimeException("Callbacks must not add ACTION_CLEAR_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
    localAccessibilityNodeInfoCompat1.setPackageName(this.mHost.getContext().getPackageName());
    localAccessibilityNodeInfoCompat1.setSource(this.mHost, paramInt);
    boolean bool;
    if (this.mAccessibilityFocusedVirtualViewId == paramInt)
    {
      localAccessibilityNodeInfoCompat1.setAccessibilityFocused(true);
      localAccessibilityNodeInfoCompat1.addAction(128);
      if (this.mKeyboardFocusedVirtualViewId != paramInt)
        break label361;
      bool = true;
      label200: if (!bool)
        break label367;
      localAccessibilityNodeInfoCompat1.addAction(2);
    }
    AccessibilityNodeInfoCompat localAccessibilityNodeInfoCompat2;
    while (true)
    {
      localAccessibilityNodeInfoCompat1.setFocused(bool);
      this.mHost.getLocationOnScreen(this.mTempGlobalRect);
      localAccessibilityNodeInfoCompat1.getBoundsInScreen(this.mTempScreenRect);
      if (!this.mTempScreenRect.equals(INVALID_PARENT_BOUNDS))
        break label422;
      localAccessibilityNodeInfoCompat1.getBoundsInParent(this.mTempScreenRect);
      if (localAccessibilityNodeInfoCompat1.mParentVirtualDescendantId == -1)
        break label387;
      localAccessibilityNodeInfoCompat2 = AccessibilityNodeInfoCompat.obtain();
      for (int j = localAccessibilityNodeInfoCompat1.mParentVirtualDescendantId; j != -1; j = localAccessibilityNodeInfoCompat2.mParentVirtualDescendantId)
      {
        localAccessibilityNodeInfoCompat2.setParent(this.mHost, -1);
        localAccessibilityNodeInfoCompat2.setBoundsInParent(INVALID_PARENT_BOUNDS);
        onPopulateNodeForVirtualView(j, localAccessibilityNodeInfoCompat2);
        localAccessibilityNodeInfoCompat2.getBoundsInParent(this.mTempParentRect);
        this.mTempScreenRect.offset(this.mTempParentRect.left, this.mTempParentRect.top);
      }
      localAccessibilityNodeInfoCompat1.setAccessibilityFocused(false);
      localAccessibilityNodeInfoCompat1.addAction(64);
      break;
      label361: bool = false;
      break label200;
      label367: if (localAccessibilityNodeInfoCompat1.isFocusable())
        localAccessibilityNodeInfoCompat1.addAction(1);
    }
    localAccessibilityNodeInfoCompat2.recycle();
    label387: this.mTempScreenRect.offset(this.mTempGlobalRect[0] - this.mHost.getScrollX(), this.mTempGlobalRect[1] - this.mHost.getScrollY());
    label422: if (this.mHost.getLocalVisibleRect(this.mTempVisibleRect))
    {
      this.mTempVisibleRect.offset(this.mTempGlobalRect[0] - this.mHost.getScrollX(), this.mTempGlobalRect[1] - this.mHost.getScrollY());
      if (this.mTempScreenRect.intersect(this.mTempVisibleRect))
      {
        localAccessibilityNodeInfoCompat1.setBoundsInScreen(this.mTempScreenRect);
        if (isVisibleToUser(this.mTempScreenRect))
          localAccessibilityNodeInfoCompat1.setVisibleToUser(true);
      }
    }
    return localAccessibilityNodeInfoCompat1;
  }

  @NonNull
  private AccessibilityNodeInfoCompat createNodeForHost()
  {
    AccessibilityNodeInfoCompat localAccessibilityNodeInfoCompat = AccessibilityNodeInfoCompat.obtain(this.mHost);
    ViewCompat.onInitializeAccessibilityNodeInfo(this.mHost, localAccessibilityNodeInfoCompat);
    ArrayList localArrayList = new ArrayList();
    getVisibleVirtualViews(localArrayList);
    if ((localAccessibilityNodeInfoCompat.getChildCount() > 0) && (localArrayList.size() > 0))
      throw new RuntimeException("Views cannot have both real and virtual children");
    int i = 0;
    int j = localArrayList.size();
    while (i < j)
    {
      localAccessibilityNodeInfoCompat.addChild(this.mHost, ((Integer)localArrayList.get(i)).intValue());
      i++;
    }
    return localAccessibilityNodeInfoCompat;
  }

  private SparseArrayCompat<AccessibilityNodeInfoCompat> getAllNodes()
  {
    ArrayList localArrayList = new ArrayList();
    getVisibleVirtualViews(localArrayList);
    SparseArrayCompat localSparseArrayCompat = new SparseArrayCompat();
    for (int i = 0; i < localArrayList.size(); i++)
      localSparseArrayCompat.put(i, createNodeForChild(i));
    return localSparseArrayCompat;
  }

  private void getBoundsInParent(int paramInt, Rect paramRect)
  {
    obtainAccessibilityNodeInfo(paramInt).getBoundsInParent(paramRect);
  }

  private static Rect guessPreviouslyFocusedRect(@NonNull View paramView, int paramInt, @NonNull Rect paramRect)
  {
    int i = paramView.getWidth();
    int j = paramView.getHeight();
    switch (paramInt)
    {
    default:
      throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
    case 17:
      paramRect.set(i, 0, i, j);
    case 33:
    case 66:
    case 130:
    }
    while (true)
    {
      return paramRect;
      paramRect.set(0, j, i, j);
      continue;
      paramRect.set(-1, 0, -1, j);
      continue;
      paramRect.set(0, -1, i, -1);
    }
  }

  private boolean isVisibleToUser(Rect paramRect)
  {
    boolean bool = false;
    if ((paramRect == null) || (paramRect.isEmpty()));
    while (true)
    {
      return bool;
      if (this.mHost.getWindowVisibility() == 0)
      {
        View localView;
        for (ViewParent localViewParent = this.mHost.getParent(); ; localViewParent = localView.getParent())
        {
          if (!(localViewParent instanceof View))
            break label73;
          localView = (View)localViewParent;
          if ((localView.getAlpha() <= 0.0F) || (localView.getVisibility() != 0))
            break;
        }
        label73: if (localViewParent != null)
          bool = true;
      }
    }
  }

  private static int keyToDirection(int paramInt)
  {
    int i;
    switch (paramInt)
    {
    case 20:
    default:
      i = 130;
    case 21:
    case 19:
    case 22:
    }
    while (true)
    {
      return i;
      i = 17;
      continue;
      i = 33;
      continue;
      i = 66;
    }
  }

  private boolean moveFocus(int paramInt, @Nullable Rect paramRect)
  {
    SparseArrayCompat localSparseArrayCompat = getAllNodes();
    int i = this.mKeyboardFocusedVirtualViewId;
    if (i == -2147483648);
    for (AccessibilityNodeInfoCompat localAccessibilityNodeInfoCompat1 = null; ; localAccessibilityNodeInfoCompat1 = (AccessibilityNodeInfoCompat)localSparseArrayCompat.get(i))
      switch (paramInt)
      {
      default:
        throw new IllegalArgumentException("direction must be one of {FOCUS_FORWARD, FOCUS_BACKWARD, FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
      case 1:
      case 2:
      case 17:
      case 33:
      case 66:
      case 130:
      }
    boolean bool;
    AccessibilityNodeInfoCompat localAccessibilityNodeInfoCompat2;
    if (ViewCompat.getLayoutDirection(this.mHost) == 1)
    {
      bool = true;
      localAccessibilityNodeInfoCompat2 = (AccessibilityNodeInfoCompat)FocusStrategy.findNextFocusInRelativeDirection(localSparseArrayCompat, SPARSE_VALUES_ADAPTER, NODE_ADAPTER, localAccessibilityNodeInfoCompat1, paramInt, bool, false);
      if (localAccessibilityNodeInfoCompat2 != null)
        break label240;
    }
    label240: for (int j = -2147483648; ; j = localSparseArrayCompat.keyAt(localSparseArrayCompat.indexOfValue(localAccessibilityNodeInfoCompat2)))
    {
      return requestKeyboardFocusForVirtualView(j);
      bool = false;
      break;
      Rect localRect = new Rect();
      if (this.mKeyboardFocusedVirtualViewId != -2147483648)
        getBoundsInParent(this.mKeyboardFocusedVirtualViewId, localRect);
      while (true)
      {
        localAccessibilityNodeInfoCompat2 = (AccessibilityNodeInfoCompat)FocusStrategy.findNextFocusInAbsoluteDirection(localSparseArrayCompat, SPARSE_VALUES_ADAPTER, NODE_ADAPTER, localAccessibilityNodeInfoCompat1, localRect, paramInt);
        break;
        if (paramRect != null)
          localRect.set(paramRect);
        else
          guessPreviouslyFocusedRect(this.mHost, paramInt, localRect);
      }
    }
  }

  private boolean performActionForChild(int paramInt1, int paramInt2, Bundle paramBundle)
  {
    boolean bool;
    switch (paramInt2)
    {
    default:
      bool = onPerformActionForVirtualView(paramInt1, paramInt2, paramBundle);
    case 64:
    case 128:
    case 1:
    case 2:
    }
    while (true)
    {
      return bool;
      bool = requestAccessibilityFocus(paramInt1);
      continue;
      bool = clearAccessibilityFocus(paramInt1);
      continue;
      bool = requestKeyboardFocusForVirtualView(paramInt1);
      continue;
      bool = clearKeyboardFocusForVirtualView(paramInt1);
    }
  }

  private boolean performActionForHost(int paramInt, Bundle paramBundle)
  {
    return ViewCompat.performAccessibilityAction(this.mHost, paramInt, paramBundle);
  }

  private boolean requestAccessibilityFocus(int paramInt)
  {
    boolean bool = false;
    if ((!this.mManager.isEnabled()) || (!this.mManager.isTouchExplorationEnabled()));
    while (true)
    {
      return bool;
      if (this.mAccessibilityFocusedVirtualViewId != paramInt)
      {
        if (this.mAccessibilityFocusedVirtualViewId != -2147483648)
          clearAccessibilityFocus(this.mAccessibilityFocusedVirtualViewId);
        this.mAccessibilityFocusedVirtualViewId = paramInt;
        this.mHost.invalidate();
        sendEventForVirtualView(paramInt, 32768);
        bool = true;
      }
    }
  }

  private void updateHoveredVirtualView(int paramInt)
  {
    if (this.mHoveredVirtualViewId == paramInt);
    while (true)
    {
      return;
      int i = this.mHoveredVirtualViewId;
      this.mHoveredVirtualViewId = paramInt;
      sendEventForVirtualView(paramInt, 128);
      sendEventForVirtualView(i, 256);
    }
  }

  public final boolean clearKeyboardFocusForVirtualView(int paramInt)
  {
    boolean bool = false;
    if (this.mKeyboardFocusedVirtualViewId != paramInt);
    while (true)
    {
      return bool;
      this.mKeyboardFocusedVirtualViewId = -2147483648;
      onVirtualViewKeyboardFocusChanged(paramInt, false);
      sendEventForVirtualView(paramInt, 8);
      bool = true;
    }
  }

  public final boolean dispatchHoverEvent(@NonNull MotionEvent paramMotionEvent)
  {
    boolean bool1 = true;
    boolean bool2 = false;
    if ((!this.mManager.isEnabled()) || (!this.mManager.isTouchExplorationEnabled()));
    while (true)
    {
      return bool2;
      switch (paramMotionEvent.getAction())
      {
      case 8:
      default:
        break;
      case 7:
      case 9:
        int i = getVirtualViewAt(paramMotionEvent.getX(), paramMotionEvent.getY());
        updateHoveredVirtualView(i);
        if (i != -2147483648);
        while (true)
        {
          bool2 = bool1;
          break;
          bool1 = false;
        }
      case 10:
        if (this.mHoveredVirtualViewId != -2147483648)
        {
          updateHoveredVirtualView(-2147483648);
          bool2 = bool1;
        }
        break;
      }
    }
  }

  public final boolean dispatchKeyEvent(@NonNull KeyEvent paramKeyEvent)
  {
    boolean bool = false;
    int i;
    if (paramKeyEvent.getAction() != 1)
    {
      i = paramKeyEvent.getKeyCode();
      switch (i)
      {
      default:
      case 19:
      case 20:
      case 21:
      case 22:
      case 23:
      case 66:
      case 61:
      }
    }
    while (true)
    {
      return bool;
      if (paramKeyEvent.hasNoModifiers())
      {
        int j = keyToDirection(i);
        int k = 1 + paramKeyEvent.getRepeatCount();
        for (int m = 0; (m < k) && (moveFocus(j, null)); m++)
          bool = true;
        if ((paramKeyEvent.hasNoModifiers()) && (paramKeyEvent.getRepeatCount() == 0))
        {
          clickKeyboardFocusedVirtualView();
          bool = true;
          continue;
          if (paramKeyEvent.hasNoModifiers())
            bool = moveFocus(2, null);
          else if (paramKeyEvent.hasModifiers(1))
            bool = moveFocus(1, null);
        }
      }
    }
  }

  public final int getAccessibilityFocusedVirtualViewId()
  {
    return this.mAccessibilityFocusedVirtualViewId;
  }

  public AccessibilityNodeProviderCompat getAccessibilityNodeProvider(View paramView)
  {
    if (this.mNodeProvider == null)
      this.mNodeProvider = new MyNodeProvider();
    return this.mNodeProvider;
  }

  @Deprecated
  public int getFocusedVirtualView()
  {
    return getAccessibilityFocusedVirtualViewId();
  }

  public final int getKeyboardFocusedVirtualViewId()
  {
    return this.mKeyboardFocusedVirtualViewId;
  }

  protected abstract int getVirtualViewAt(float paramFloat1, float paramFloat2);

  protected abstract void getVisibleVirtualViews(List<Integer> paramList);

  public final void invalidateRoot()
  {
    invalidateVirtualView(-1, 1);
  }

  public final void invalidateVirtualView(int paramInt)
  {
    invalidateVirtualView(paramInt, 0);
  }

  public final void invalidateVirtualView(int paramInt1, int paramInt2)
  {
    if ((paramInt1 != -2147483648) && (this.mManager.isEnabled()))
    {
      ViewParent localViewParent = this.mHost.getParent();
      if (localViewParent != null)
      {
        AccessibilityEvent localAccessibilityEvent = createEvent(paramInt1, 2048);
        AccessibilityEventCompat.setContentChangeTypes(localAccessibilityEvent, paramInt2);
        ViewParentCompat.requestSendAccessibilityEvent(localViewParent, this.mHost, localAccessibilityEvent);
      }
    }
  }

  @NonNull
  AccessibilityNodeInfoCompat obtainAccessibilityNodeInfo(int paramInt)
  {
    if (paramInt == -1);
    for (AccessibilityNodeInfoCompat localAccessibilityNodeInfoCompat = createNodeForHost(); ; localAccessibilityNodeInfoCompat = createNodeForChild(paramInt))
      return localAccessibilityNodeInfoCompat;
  }

  public final void onFocusChanged(boolean paramBoolean, int paramInt, @Nullable Rect paramRect)
  {
    if (this.mKeyboardFocusedVirtualViewId != -2147483648)
      clearKeyboardFocusForVirtualView(this.mKeyboardFocusedVirtualViewId);
    if (paramBoolean)
      moveFocus(paramInt, paramRect);
  }

  public void onInitializeAccessibilityEvent(View paramView, AccessibilityEvent paramAccessibilityEvent)
  {
    super.onInitializeAccessibilityEvent(paramView, paramAccessibilityEvent);
    onPopulateEventForHost(paramAccessibilityEvent);
  }

  public void onInitializeAccessibilityNodeInfo(View paramView, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat)
  {
    super.onInitializeAccessibilityNodeInfo(paramView, paramAccessibilityNodeInfoCompat);
    onPopulateNodeForHost(paramAccessibilityNodeInfoCompat);
  }

  protected abstract boolean onPerformActionForVirtualView(int paramInt1, int paramInt2, @Nullable Bundle paramBundle);

  protected void onPopulateEventForHost(@NonNull AccessibilityEvent paramAccessibilityEvent)
  {
  }

  protected void onPopulateEventForVirtualView(int paramInt, @NonNull AccessibilityEvent paramAccessibilityEvent)
  {
  }

  protected void onPopulateNodeForHost(@NonNull AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat)
  {
  }

  protected abstract void onPopulateNodeForVirtualView(int paramInt, @NonNull AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat);

  protected void onVirtualViewKeyboardFocusChanged(int paramInt, boolean paramBoolean)
  {
  }

  boolean performAction(int paramInt1, int paramInt2, Bundle paramBundle)
  {
    switch (paramInt1)
    {
    default:
    case -1:
    }
    for (boolean bool = performActionForChild(paramInt1, paramInt2, paramBundle); ; bool = performActionForHost(paramInt2, paramBundle))
      return bool;
  }

  public final boolean requestKeyboardFocusForVirtualView(int paramInt)
  {
    boolean bool = false;
    if ((!this.mHost.isFocused()) && (!this.mHost.requestFocus()));
    while (true)
    {
      return bool;
      if (this.mKeyboardFocusedVirtualViewId != paramInt)
      {
        if (this.mKeyboardFocusedVirtualViewId != -2147483648)
          clearKeyboardFocusForVirtualView(this.mKeyboardFocusedVirtualViewId);
        this.mKeyboardFocusedVirtualViewId = paramInt;
        onVirtualViewKeyboardFocusChanged(paramInt, true);
        sendEventForVirtualView(paramInt, 8);
        bool = true;
      }
    }
  }

  public final boolean sendEventForVirtualView(int paramInt1, int paramInt2)
  {
    boolean bool = false;
    if ((paramInt1 == -2147483648) || (!this.mManager.isEnabled()));
    while (true)
    {
      return bool;
      ViewParent localViewParent = this.mHost.getParent();
      if (localViewParent != null)
      {
        AccessibilityEvent localAccessibilityEvent = createEvent(paramInt1, paramInt2);
        bool = ViewParentCompat.requestSendAccessibilityEvent(localViewParent, this.mHost, localAccessibilityEvent);
      }
    }
  }

  private class MyNodeProvider extends AccessibilityNodeProviderCompat
  {
    MyNodeProvider()
    {
    }

    public AccessibilityNodeInfoCompat createAccessibilityNodeInfo(int paramInt)
    {
      return AccessibilityNodeInfoCompat.obtain(ExploreByTouchHelper.this.obtainAccessibilityNodeInfo(paramInt));
    }

    public AccessibilityNodeInfoCompat findFocus(int paramInt)
    {
      int i;
      if (paramInt == 2)
      {
        i = ExploreByTouchHelper.this.mAccessibilityFocusedVirtualViewId;
        if (i != -2147483648)
          break label34;
      }
      label34: for (AccessibilityNodeInfoCompat localAccessibilityNodeInfoCompat = null; ; localAccessibilityNodeInfoCompat = createAccessibilityNodeInfo(i))
      {
        return localAccessibilityNodeInfoCompat;
        i = ExploreByTouchHelper.this.mKeyboardFocusedVirtualViewId;
        break;
      }
    }

    public boolean performAction(int paramInt1, int paramInt2, Bundle paramBundle)
    {
      return ExploreByTouchHelper.this.performAction(paramInt1, paramInt2, paramBundle);
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.customview.widget.ExploreByTouchHelper
 * JD-Core Version:    0.6.2
 */