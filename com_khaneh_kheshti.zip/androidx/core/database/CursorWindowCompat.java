package androidx.core.database;

import android.database.CursorWindow;
import android.os.Build.VERSION;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public final class CursorWindowCompat
{
  @NonNull
  public static CursorWindow create(@Nullable String paramString, long paramLong)
  {
    CursorWindow localCursorWindow;
    if (Build.VERSION.SDK_INT >= 28)
      localCursorWindow = new CursorWindow(paramString, paramLong);
    while (true)
    {
      return localCursorWindow;
      if (Build.VERSION.SDK_INT >= 15)
        localCursorWindow = new CursorWindow(paramString);
      else
        localCursorWindow = new CursorWindow(false);
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.database.CursorWindowCompat
 * JD-Core Version:    0.6.2
 */