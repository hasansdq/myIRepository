package androidx.core.content.pm;

@Deprecated
public final class ActivityInfoCompat
{

  @Deprecated
  public static final int CONFIG_UI_MODE = 512;
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.content.pm.ActivityInfoCompat
 * JD-Core Version:    0.6.2
 */