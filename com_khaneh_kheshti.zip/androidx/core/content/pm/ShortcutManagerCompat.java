package androidx.core.content.pm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.IntentSender.SendIntentException;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ShortcutManager;
import android.os.Build.VERSION;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import androidx.core.content.ContextCompat;
import java.util.Iterator;
import java.util.List;

public class ShortcutManagerCompat
{

  @VisibleForTesting
  static final String ACTION_INSTALL_SHORTCUT = "com.android.launcher.action.INSTALL_SHORTCUT";

  @VisibleForTesting
  static final String INSTALL_SHORTCUT_PERMISSION = "com.android.launcher.permission.INSTALL_SHORTCUT";

  @NonNull
  public static Intent createShortcutResultIntent(@NonNull Context paramContext, @NonNull ShortcutInfoCompat paramShortcutInfoCompat)
  {
    Intent localIntent = null;
    if (Build.VERSION.SDK_INT >= 26)
      localIntent = ((ShortcutManager)paramContext.getSystemService(ShortcutManager.class)).createShortcutResultIntent(paramShortcutInfoCompat.toShortcutInfo());
    if (localIntent == null)
      localIntent = new Intent();
    return paramShortcutInfoCompat.addToIntent(localIntent);
  }

  public static boolean isRequestPinShortcutSupported(@NonNull Context paramContext)
  {
    boolean bool = false;
    if (Build.VERSION.SDK_INT >= 26)
      bool = ((ShortcutManager)paramContext.getSystemService(ShortcutManager.class)).isRequestPinShortcutSupported();
    while (true)
    {
      return bool;
      if (ContextCompat.checkSelfPermission(paramContext, "com.android.launcher.permission.INSTALL_SHORTCUT") == 0)
      {
        Iterator localIterator = paramContext.getPackageManager().queryBroadcastReceivers(new Intent("com.android.launcher.action.INSTALL_SHORTCUT"), 0).iterator();
        if (localIterator.hasNext())
        {
          String str = ((ResolveInfo)localIterator.next()).activityInfo.permission;
          if ((!TextUtils.isEmpty(str)) && (!"com.android.launcher.permission.INSTALL_SHORTCUT".equals(str)))
            break;
          bool = true;
        }
      }
    }
  }

  public static boolean requestPinShortcut(@NonNull Context paramContext, @NonNull ShortcutInfoCompat paramShortcutInfoCompat, @Nullable IntentSender paramIntentSender)
  {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 26)
      bool = ((ShortcutManager)paramContext.getSystemService(ShortcutManager.class)).requestPinShortcut(paramShortcutInfoCompat.toShortcutInfo(), paramIntentSender);
    while (true)
    {
      return bool;
      if (!isRequestPinShortcutSupported(paramContext))
      {
        bool = false;
      }
      else
      {
        Intent localIntent = paramShortcutInfoCompat.addToIntent(new Intent("com.android.launcher.action.INSTALL_SHORTCUT"));
        if (paramIntentSender == null)
        {
          paramContext.sendBroadcast(localIntent);
          bool = true;
        }
        else
        {
          paramContext.sendOrderedBroadcast(localIntent, null, new BroadcastReceiver()
          {
            public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
            {
              try
              {
                this.val$callback.sendIntent(paramAnonymousContext, 0, null, null, null);
                label12: return;
              }
              catch (IntentSender.SendIntentException localSendIntentException)
              {
                break label12;
              }
            }
          }
          , null, -1, null, null);
          bool = true;
        }
      }
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.content.pm.ShortcutManagerCompat
 * JD-Core Version:    0.6.2
 */