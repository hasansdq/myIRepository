package androidx.core.content.pm;

import android.content.pm.PackageInfo;
import android.os.Build.VERSION;
import androidx.annotation.NonNull;

public final class PackageInfoCompat
{
  public static long getLongVersionCode(@NonNull PackageInfo paramPackageInfo)
  {
    if (Build.VERSION.SDK_INT >= 28);
    for (long l = paramPackageInfo.getLongVersionCode(); ; l = paramPackageInfo.versionCode)
      return l;
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.content.pm.PackageInfoCompat
 * JD-Core Version:    0.6.2
 */