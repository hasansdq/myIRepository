package androidx.core.content;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;

public final class MimeTypeFilter
{
  @Nullable
  public static String matches(@Nullable String paramString, @NonNull String[] paramArrayOfString)
  {
    String str;
    if (paramString == null)
      str = null;
    while (true)
    {
      return str;
      String[] arrayOfString = paramString.split("/");
      int i = paramArrayOfString.length;
      for (int j = 0; ; j++)
      {
        if (j >= i)
          break label55;
        str = paramArrayOfString[j];
        if (mimeTypeAgainstFilter(arrayOfString, str.split("/")))
          break;
      }
      label55: str = null;
    }
  }

  @Nullable
  public static String matches(@Nullable String[] paramArrayOfString, @NonNull String paramString)
  {
    String str;
    if (paramArrayOfString == null)
      str = null;
    while (true)
    {
      return str;
      String[] arrayOfString = paramString.split("/");
      int i = paramArrayOfString.length;
      for (int j = 0; ; j++)
      {
        if (j >= i)
          break label55;
        str = paramArrayOfString[j];
        if (mimeTypeAgainstFilter(str.split("/"), arrayOfString))
          break;
      }
      label55: str = null;
    }
  }

  public static boolean matches(@Nullable String paramString1, @NonNull String paramString2)
  {
    if (paramString1 == null);
    for (boolean bool = false; ; bool = mimeTypeAgainstFilter(paramString1.split("/"), paramString2.split("/")))
      return bool;
  }

  @NonNull
  public static String[] matchesMany(@Nullable String[] paramArrayOfString, @NonNull String paramString)
  {
    int i = 0;
    if (paramArrayOfString == null);
    ArrayList localArrayList;
    for (String[] arrayOfString1 = new String[0]; ; arrayOfString1 = (String[])localArrayList.toArray(new String[localArrayList.size()]))
    {
      return arrayOfString1;
      localArrayList = new ArrayList();
      String[] arrayOfString2 = paramString.split("/");
      int j = paramArrayOfString.length;
      while (i < j)
      {
        String str = paramArrayOfString[i];
        if (mimeTypeAgainstFilter(str.split("/"), arrayOfString2))
          localArrayList.add(str);
        i++;
      }
    }
  }

  private static boolean mimeTypeAgainstFilter(@NonNull String[] paramArrayOfString1, @NonNull String[] paramArrayOfString2)
  {
    boolean bool = false;
    if (paramArrayOfString2.length != 2)
      throw new IllegalArgumentException("Ill-formatted MIME type filter. Must be type/subtype.");
    if ((paramArrayOfString2[0].isEmpty()) || (paramArrayOfString2[1].isEmpty()))
      throw new IllegalArgumentException("Ill-formatted MIME type filter. Type or subtype empty.");
    if (paramArrayOfString1.length != 2);
    while (true)
    {
      return bool;
      if ((("*".equals(paramArrayOfString2[0])) || (paramArrayOfString2[0].equals(paramArrayOfString1[0]))) && (("*".equals(paramArrayOfString2[1])) || (paramArrayOfString2[1].equals(paramArrayOfString1[1]))))
        bool = true;
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.content.MimeTypeFilter
 * JD-Core Version:    0.6.2
 */