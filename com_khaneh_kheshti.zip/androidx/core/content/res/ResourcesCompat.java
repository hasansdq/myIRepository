package androidx.core.content.res;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.Resources.Theme;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.TypedValue;
import androidx.annotation.ColorInt;
import androidx.annotation.ColorRes;
import androidx.annotation.DrawableRes;
import androidx.annotation.FontRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.core.graphics.TypefaceCompat;
import androidx.core.util.Preconditions;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParserException;

public final class ResourcesCompat
{
  private static final String TAG = "ResourcesCompat";

  @ColorInt
  public static int getColor(@NonNull Resources paramResources, @ColorRes int paramInt, @Nullable Resources.Theme paramTheme)
    throws Resources.NotFoundException
  {
    if (Build.VERSION.SDK_INT >= 23);
    for (int i = paramResources.getColor(paramInt, paramTheme); ; i = paramResources.getColor(paramInt))
      return i;
  }

  @Nullable
  public static ColorStateList getColorStateList(@NonNull Resources paramResources, @ColorRes int paramInt, @Nullable Resources.Theme paramTheme)
    throws Resources.NotFoundException
  {
    if (Build.VERSION.SDK_INT >= 23);
    for (ColorStateList localColorStateList = paramResources.getColorStateList(paramInt, paramTheme); ; localColorStateList = paramResources.getColorStateList(paramInt))
      return localColorStateList;
  }

  @Nullable
  public static Drawable getDrawable(@NonNull Resources paramResources, @DrawableRes int paramInt, @Nullable Resources.Theme paramTheme)
    throws Resources.NotFoundException
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (Drawable localDrawable = paramResources.getDrawable(paramInt, paramTheme); ; localDrawable = paramResources.getDrawable(paramInt))
      return localDrawable;
  }

  @Nullable
  public static Drawable getDrawableForDensity(@NonNull Resources paramResources, @DrawableRes int paramInt1, int paramInt2, @Nullable Resources.Theme paramTheme)
    throws Resources.NotFoundException
  {
    Drawable localDrawable;
    if (Build.VERSION.SDK_INT >= 21)
      localDrawable = paramResources.getDrawableForDensity(paramInt1, paramInt2, paramTheme);
    while (true)
    {
      return localDrawable;
      if (Build.VERSION.SDK_INT >= 15)
        localDrawable = paramResources.getDrawableForDensity(paramInt1, paramInt2);
      else
        localDrawable = paramResources.getDrawable(paramInt1);
    }
  }

  @Nullable
  public static Typeface getFont(@NonNull Context paramContext, @FontRes int paramInt)
    throws Resources.NotFoundException
  {
    Typeface localTypeface = null;
    if (paramContext.isRestricted());
    while (true)
    {
      return localTypeface;
      localTypeface = loadFont(paramContext, paramInt, new TypedValue(), 0, null, null, false);
    }
  }

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public static Typeface getFont(@NonNull Context paramContext, @FontRes int paramInt1, TypedValue paramTypedValue, int paramInt2, @Nullable FontCallback paramFontCallback)
    throws Resources.NotFoundException
  {
    Typeface localTypeface = null;
    if (paramContext.isRestricted());
    while (true)
    {
      return localTypeface;
      localTypeface = loadFont(paramContext, paramInt1, paramTypedValue, paramInt2, paramFontCallback, null, true);
    }
  }

  public static void getFont(@NonNull Context paramContext, @FontRes int paramInt, @NonNull FontCallback paramFontCallback, @Nullable Handler paramHandler)
    throws Resources.NotFoundException
  {
    Preconditions.checkNotNull(paramFontCallback);
    if (paramContext.isRestricted())
      paramFontCallback.callbackFailAsync(-4, paramHandler);
    while (true)
    {
      return;
      loadFont(paramContext, paramInt, new TypedValue(), 0, paramFontCallback, paramHandler, false);
    }
  }

  private static Typeface loadFont(@NonNull Context paramContext, int paramInt1, TypedValue paramTypedValue, int paramInt2, @Nullable FontCallback paramFontCallback, @Nullable Handler paramHandler, boolean paramBoolean)
  {
    Resources localResources = paramContext.getResources();
    localResources.getValue(paramInt1, paramTypedValue, true);
    Typeface localTypeface = loadFont(paramContext, localResources, paramTypedValue, paramInt1, paramInt2, paramFontCallback, paramHandler, paramBoolean);
    if ((localTypeface == null) && (paramFontCallback == null))
      throw new Resources.NotFoundException("Font resource ID #0x" + Integer.toHexString(paramInt1) + " could not be retrieved.");
    return localTypeface;
  }

  private static Typeface loadFont(@NonNull Context paramContext, Resources paramResources, TypedValue paramTypedValue, int paramInt1, int paramInt2, @Nullable FontCallback paramFontCallback, @Nullable Handler paramHandler, boolean paramBoolean)
  {
    if (paramTypedValue.string == null)
      throw new Resources.NotFoundException("Resource \"" + paramResources.getResourceName(paramInt1) + "\" (" + Integer.toHexString(paramInt1) + ") is not a Font: " + paramTypedValue);
    String str = paramTypedValue.string.toString();
    Typeface localTypeface;
    if (!str.startsWith("res/"))
    {
      if (paramFontCallback != null)
        paramFontCallback.callbackFailAsync(-3, paramHandler);
      localTypeface = null;
    }
    while (true)
    {
      return localTypeface;
      localTypeface = TypefaceCompat.findFromCache(paramResources, paramInt1, paramInt2);
      if (localTypeface != null)
      {
        if (paramFontCallback != null)
          paramFontCallback.callbackSuccessAsync(localTypeface, paramHandler);
      }
      else
        try
        {
          if (str.toLowerCase().endsWith(".xml"))
          {
            FontResourcesParserCompat.FamilyResourceEntry localFamilyResourceEntry = FontResourcesParserCompat.parse(paramResources.getXml(paramInt1), paramResources);
            if (localFamilyResourceEntry == null)
            {
              Log.e("ResourcesCompat", "Failed to find font-family tag");
              if (paramFontCallback != null)
                paramFontCallback.callbackFailAsync(-3, paramHandler);
            }
            else
            {
              localTypeface = TypefaceCompat.createFromResourcesFamilyXml(paramContext, localFamilyResourceEntry, paramResources, paramInt1, paramInt2, paramFontCallback, paramHandler, paramBoolean);
            }
          }
          else
          {
            localTypeface = TypefaceCompat.createFromResourcesFontFile(paramContext, paramResources, paramInt1, str, paramInt2);
            if (paramFontCallback != null)
              if (localTypeface != null)
                paramFontCallback.callbackSuccessAsync(localTypeface, paramHandler);
          }
        }
        catch (XmlPullParserException localXmlPullParserException)
        {
          Log.e("ResourcesCompat", "Failed to parse xml resource " + str, localXmlPullParserException);
          if (paramFontCallback != null)
            paramFontCallback.callbackFailAsync(-3, paramHandler);
          localTypeface = null;
          continue;
          paramFontCallback.callbackFailAsync(-3, paramHandler);
        }
        catch (IOException localIOException)
        {
          while (true)
            Log.e("ResourcesCompat", "Failed to read xml resource " + str, localIOException);
          localTypeface = null;
        }
    }
  }

  public static abstract class FontCallback
  {
    @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
    public final void callbackFailAsync(final int paramInt, @Nullable Handler paramHandler)
    {
      if (paramHandler == null)
        paramHandler = new Handler(Looper.getMainLooper());
      paramHandler.post(new Runnable()
      {
        public void run()
        {
          ResourcesCompat.FontCallback.this.onFontRetrievalFailed(paramInt);
        }
      });
    }

    @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
    public final void callbackSuccessAsync(final Typeface paramTypeface, @Nullable Handler paramHandler)
    {
      if (paramHandler == null)
        paramHandler = new Handler(Looper.getMainLooper());
      paramHandler.post(new Runnable()
      {
        public void run()
        {
          ResourcesCompat.FontCallback.this.onFontRetrieved(paramTypeface);
        }
      });
    }

    public abstract void onFontRetrievalFailed(int paramInt);

    public abstract void onFontRetrieved(@NonNull Typeface paramTypeface);
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.content.res.ResourcesCompat
 * JD-Core Version:    0.6.2
 */