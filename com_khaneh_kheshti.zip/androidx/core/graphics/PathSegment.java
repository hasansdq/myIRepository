package androidx.core.graphics;

import android.graphics.PointF;
import androidx.annotation.NonNull;
import androidx.core.util.Preconditions;

public final class PathSegment
{
  private final PointF mEnd;
  private final float mEndFraction;
  private final PointF mStart;
  private final float mStartFraction;

  public PathSegment(@NonNull PointF paramPointF1, float paramFloat1, @NonNull PointF paramPointF2, float paramFloat2)
  {
    this.mStart = ((PointF)Preconditions.checkNotNull(paramPointF1, "start == null"));
    this.mStartFraction = paramFloat1;
    this.mEnd = ((PointF)Preconditions.checkNotNull(paramPointF2, "end == null"));
    this.mEndFraction = paramFloat2;
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = true;
    if (this == paramObject);
    while (true)
    {
      return bool;
      if (!(paramObject instanceof PathSegment))
      {
        bool = false;
      }
      else
      {
        PathSegment localPathSegment = (PathSegment)paramObject;
        if ((Float.compare(this.mStartFraction, localPathSegment.mStartFraction) != 0) || (Float.compare(this.mEndFraction, localPathSegment.mEndFraction) != 0) || (!this.mStart.equals(localPathSegment.mStart)) || (!this.mEnd.equals(localPathSegment.mEnd)))
          bool = false;
      }
    }
  }

  @NonNull
  public PointF getEnd()
  {
    return this.mEnd;
  }

  public float getEndFraction()
  {
    return this.mEndFraction;
  }

  @NonNull
  public PointF getStart()
  {
    return this.mStart;
  }

  public float getStartFraction()
  {
    return this.mStartFraction;
  }

  public int hashCode()
  {
    int i = 0;
    int j = 31 * this.mStart.hashCode();
    if (this.mStartFraction != 0.0F);
    for (int k = Float.floatToIntBits(this.mStartFraction); ; k = 0)
    {
      int m = 31 * (31 * (j + k) + this.mEnd.hashCode());
      if (this.mEndFraction != 0.0F)
        i = Float.floatToIntBits(this.mEndFraction);
      return m + i;
    }
  }

  public String toString()
  {
    return "PathSegment{start=" + this.mStart + ", startFraction=" + this.mStartFraction + ", end=" + this.mEnd + ", endFraction=" + this.mEndFraction + '}';
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.graphics.PathSegment
 * JD-Core Version:    0.6.2
 */