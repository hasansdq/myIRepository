package androidx.core.graphics;

import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.system.StructStat;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import java.io.File;

@RequiresApi(21)
@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
class TypefaceCompatApi21Impl extends TypefaceCompatBaseImpl
{
  private static final String TAG = "TypefaceCompatApi21Impl";

  private File getFile(ParcelFileDescriptor paramParcelFileDescriptor)
  {
    try
    {
      String str = Os.readlink("/proc/self/fd/" + paramParcelFileDescriptor.getFd());
      if (OsConstants.S_ISREG(Os.stat(str).st_mode));
      for (localFile = new File(str); ; localFile = null)
        return localFile;
    }
    catch (ErrnoException localErrnoException)
    {
      while (true)
        File localFile = null;
    }
  }

  // ERROR //
  public android.graphics.Typeface createFromFontInfo(android.content.Context paramContext, android.os.CancellationSignal paramCancellationSignal, @androidx.annotation.NonNull androidx.core.provider.FontsContractCompat.FontInfo[] paramArrayOfFontInfo, int paramInt)
  {
    // Byte code:
    //   0: aload_3
    //   1: arraylength
    //   2: iconst_1
    //   3: if_icmpge +9 -> 12
    //   6: aconst_null
    //   7: astore 8
    //   9: aload 8
    //   11: areturn
    //   12: aload_0
    //   13: aload_3
    //   14: iload 4
    //   16: invokevirtual 82	androidx/core/graphics/TypefaceCompatApi21Impl:findBestInfo	([Landroidx/core/provider/FontsContractCompat$FontInfo;I)Landroidx/core/provider/FontsContractCompat$FontInfo;
    //   19: astore 5
    //   21: aload_1
    //   22: invokevirtual 88	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   25: astore 6
    //   27: aload 6
    //   29: aload 5
    //   31: invokevirtual 94	androidx/core/provider/FontsContractCompat$FontInfo:getUri	()Landroid/net/Uri;
    //   34: ldc 96
    //   36: aload_2
    //   37: invokevirtual 102	android/content/ContentResolver:openFileDescriptor	(Landroid/net/Uri;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/os/ParcelFileDescriptor;
    //   40: astore 9
    //   42: aload_0
    //   43: aload 9
    //   45: invokespecial 104	androidx/core/graphics/TypefaceCompatApi21Impl:getFile	(Landroid/os/ParcelFileDescriptor;)Ljava/io/File;
    //   48: astore 15
    //   50: aload 15
    //   52: ifnull +11 -> 63
    //   55: aload 15
    //   57: invokevirtual 108	java/io/File:canRead	()Z
    //   60: ifne +196 -> 256
    //   63: new 110	java/io/FileInputStream
    //   66: dup
    //   67: aload 9
    //   69: invokevirtual 114	android/os/ParcelFileDescriptor:getFileDescriptor	()Ljava/io/FileDescriptor;
    //   72: invokespecial 117	java/io/FileInputStream:<init>	(Ljava/io/FileDescriptor;)V
    //   75: astore 16
    //   77: aconst_null
    //   78: astore 17
    //   80: aload_0
    //   81: aload_1
    //   82: aload 16
    //   84: invokespecial 121	androidx/core/graphics/TypefaceCompatBaseImpl:createFromInputStream	(Landroid/content/Context;Ljava/io/InputStream;)Landroid/graphics/Typeface;
    //   87: astore 20
    //   89: aload 20
    //   91: astore 8
    //   93: aload 16
    //   95: ifnull +12 -> 107
    //   98: iconst_0
    //   99: ifeq +88 -> 187
    //   102: aload 16
    //   104: invokevirtual 124	java/io/FileInputStream:close	()V
    //   107: aload 9
    //   109: ifnull -100 -> 9
    //   112: iconst_0
    //   113: ifeq +90 -> 203
    //   116: aload 9
    //   118: invokevirtual 125	android/os/ParcelFileDescriptor:close	()V
    //   121: goto -112 -> 9
    //   124: astore 21
    //   126: aconst_null
    //   127: aload 21
    //   129: invokevirtual 129	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
    //   132: goto -123 -> 9
    //   135: astore 7
    //   137: aconst_null
    //   138: astore 8
    //   140: goto -131 -> 9
    //   143: astore 22
    //   145: aconst_null
    //   146: aload 22
    //   148: invokevirtual 129	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
    //   151: goto -44 -> 107
    //   154: astore 13
    //   156: aload 13
    //   158: athrow
    //   159: astore 14
    //   161: aload 13
    //   163: astore 11
    //   165: aload 14
    //   167: astore 10
    //   169: aload 9
    //   171: ifnull +13 -> 184
    //   174: aload 11
    //   176: ifnull +139 -> 315
    //   179: aload 9
    //   181: invokevirtual 125	android/os/ParcelFileDescriptor:close	()V
    //   184: aload 10
    //   186: athrow
    //   187: aload 16
    //   189: invokevirtual 124	java/io/FileInputStream:close	()V
    //   192: goto -85 -> 107
    //   195: astore 10
    //   197: aconst_null
    //   198: astore 11
    //   200: goto -31 -> 169
    //   203: aload 9
    //   205: invokevirtual 125	android/os/ParcelFileDescriptor:close	()V
    //   208: goto -199 -> 9
    //   211: astore 17
    //   213: aload 17
    //   215: athrow
    //   216: astore 18
    //   218: aload 16
    //   220: ifnull +13 -> 233
    //   223: aload 17
    //   225: ifnull +23 -> 248
    //   228: aload 16
    //   230: invokevirtual 124	java/io/FileInputStream:close	()V
    //   233: aload 18
    //   235: athrow
    //   236: astore 19
    //   238: aload 17
    //   240: aload 19
    //   242: invokevirtual 129	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
    //   245: goto -12 -> 233
    //   248: aload 16
    //   250: invokevirtual 124	java/io/FileInputStream:close	()V
    //   253: goto -20 -> 233
    //   256: aload 15
    //   258: invokestatic 135	android/graphics/Typeface:createFromFile	(Ljava/io/File;)Landroid/graphics/Typeface;
    //   261: astore 23
    //   263: aload 23
    //   265: astore 8
    //   267: aload 9
    //   269: ifnull -260 -> 9
    //   272: iconst_0
    //   273: ifeq +22 -> 295
    //   276: aload 9
    //   278: invokevirtual 125	android/os/ParcelFileDescriptor:close	()V
    //   281: goto -272 -> 9
    //   284: astore 24
    //   286: aconst_null
    //   287: aload 24
    //   289: invokevirtual 129	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
    //   292: goto -283 -> 9
    //   295: aload 9
    //   297: invokevirtual 125	android/os/ParcelFileDescriptor:close	()V
    //   300: goto -291 -> 9
    //   303: astore 12
    //   305: aload 11
    //   307: aload 12
    //   309: invokevirtual 129	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
    //   312: goto -128 -> 184
    //   315: aload 9
    //   317: invokevirtual 125	android/os/ParcelFileDescriptor:close	()V
    //   320: goto -136 -> 184
    //
    // Exception table:
    //   from	to	target	type
    //   116	121	124	java/lang/Throwable
    //   27	42	135	java/io/IOException
    //   116	121	135	java/io/IOException
    //   126	132	135	java/io/IOException
    //   179	184	135	java/io/IOException
    //   184	187	135	java/io/IOException
    //   203	208	135	java/io/IOException
    //   276	281	135	java/io/IOException
    //   286	320	135	java/io/IOException
    //   102	107	143	java/lang/Throwable
    //   42	77	154	java/lang/Throwable
    //   145	151	154	java/lang/Throwable
    //   187	192	154	java/lang/Throwable
    //   233	263	154	java/lang/Throwable
    //   156	159	159	finally
    //   42	77	195	finally
    //   102	107	195	finally
    //   145	151	195	finally
    //   187	192	195	finally
    //   228	233	195	finally
    //   233	263	195	finally
    //   80	89	211	java/lang/Throwable
    //   80	89	216	finally
    //   213	216	216	finally
    //   228	233	236	java/lang/Throwable
    //   276	281	284	java/lang/Throwable
    //   179	184	303	java/lang/Throwable
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.graphics.TypefaceCompatApi21Impl
 * JD-Core Version:    0.6.2
 */