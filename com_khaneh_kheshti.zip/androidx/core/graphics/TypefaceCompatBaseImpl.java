package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.core.content.res.FontResourcesParserCompat.FontFamilyFilesResourceEntry;
import androidx.core.content.res.FontResourcesParserCompat.FontFileResourceEntry;
import androidx.core.provider.FontsContractCompat.FontInfo;
import java.io.File;
import java.io.InputStream;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
class TypefaceCompatBaseImpl
{
  private static final String CACHE_FILE_PREFIX = "cached_font_";
  private static final String TAG = "TypefaceCompatBaseImpl";

  private FontResourcesParserCompat.FontFileResourceEntry findBestEntry(FontResourcesParserCompat.FontFamilyFilesResourceEntry paramFontFamilyFilesResourceEntry, int paramInt)
  {
    return (FontResourcesParserCompat.FontFileResourceEntry)findBestFont(paramFontFamilyFilesResourceEntry.getEntries(), paramInt, new StyleExtractor()
    {
      public int getWeight(FontResourcesParserCompat.FontFileResourceEntry paramAnonymousFontFileResourceEntry)
      {
        return paramAnonymousFontFileResourceEntry.getWeight();
      }

      public boolean isItalic(FontResourcesParserCompat.FontFileResourceEntry paramAnonymousFontFileResourceEntry)
      {
        return paramAnonymousFontFileResourceEntry.isItalic();
      }
    });
  }

  private static <T> T findBestFont(T[] paramArrayOfT, int paramInt, StyleExtractor<T> paramStyleExtractor)
  {
    int i;
    int j;
    label19: Object localObject;
    int k;
    int n;
    label33: T ?;
    int i1;
    if ((paramInt & 0x1) == 0)
    {
      i = 400;
      if ((paramInt & 0x2) == 0)
        break label119;
      j = 1;
      localObject = null;
      k = 2147483647;
      int m = paramArrayOfT.length;
      n = 0;
      if (n >= m)
        break label131;
      ? = paramArrayOfT[n];
      i1 = 2 * Math.abs(paramStyleExtractor.getWeight(?) - i);
      if (paramStyleExtractor.isItalic(?) != j)
        break label125;
    }
    label119: label125: for (int i2 = 0; ; i2 = 1)
    {
      int i3 = i1 + i2;
      if ((localObject == null) || (k > i3))
      {
        localObject = ?;
        k = i3;
      }
      n++;
      break label33;
      i = 700;
      break;
      j = 0;
      break label19;
    }
    label131: return localObject;
  }

  @Nullable
  public Typeface createFromFontFamilyFilesResourceEntry(Context paramContext, FontResourcesParserCompat.FontFamilyFilesResourceEntry paramFontFamilyFilesResourceEntry, Resources paramResources, int paramInt)
  {
    FontResourcesParserCompat.FontFileResourceEntry localFontFileResourceEntry = findBestEntry(paramFontFamilyFilesResourceEntry, paramInt);
    if (localFontFileResourceEntry == null);
    for (Typeface localTypeface = null; ; localTypeface = TypefaceCompat.createFromResourcesFontFile(paramContext, paramResources, localFontFileResourceEntry.getResourceId(), localFontFileResourceEntry.getFileName(), paramInt))
      return localTypeface;
  }

  // ERROR //
  public Typeface createFromFontInfo(Context paramContext, @Nullable android.os.CancellationSignal paramCancellationSignal, @androidx.annotation.NonNull FontsContractCompat.FontInfo[] paramArrayOfFontInfo, int paramInt)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 5
    //   3: aload_3
    //   4: arraylength
    //   5: iconst_1
    //   6: if_icmpge +6 -> 12
    //   9: aload 5
    //   11: areturn
    //   12: aload_0
    //   13: aload_3
    //   14: iload 4
    //   16: invokevirtual 83	androidx/core/graphics/TypefaceCompatBaseImpl:findBestInfo	([Landroidx/core/provider/FontsContractCompat$FontInfo;I)Landroidx/core/provider/FontsContractCompat$FontInfo;
    //   19: astore 6
    //   21: aconst_null
    //   22: astore 7
    //   24: aload_1
    //   25: invokevirtual 89	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   28: aload 6
    //   30: invokevirtual 95	androidx/core/provider/FontsContractCompat$FontInfo:getUri	()Landroid/net/Uri;
    //   33: invokevirtual 101	android/content/ContentResolver:openInputStream	(Landroid/net/Uri;)Ljava/io/InputStream;
    //   36: astore 7
    //   38: aload_0
    //   39: aload_1
    //   40: aload 7
    //   42: invokevirtual 105	androidx/core/graphics/TypefaceCompatBaseImpl:createFromInputStream	(Landroid/content/Context;Ljava/io/InputStream;)Landroid/graphics/Typeface;
    //   45: astore 10
    //   47: aload 10
    //   49: astore 5
    //   51: aload 7
    //   53: invokestatic 111	androidx/core/graphics/TypefaceCompatUtil:closeQuietly	(Ljava/io/Closeable;)V
    //   56: goto -47 -> 9
    //   59: astore 9
    //   61: aload 7
    //   63: invokestatic 111	androidx/core/graphics/TypefaceCompatUtil:closeQuietly	(Ljava/io/Closeable;)V
    //   66: goto -57 -> 9
    //   69: astore 8
    //   71: aload 7
    //   73: invokestatic 111	androidx/core/graphics/TypefaceCompatUtil:closeQuietly	(Ljava/io/Closeable;)V
    //   76: aload 8
    //   78: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   24	47	59	java/io/IOException
    //   24	47	69	finally
  }

  protected Typeface createFromInputStream(Context paramContext, InputStream paramInputStream)
  {
    Object localObject1 = null;
    File localFile = TypefaceCompatUtil.getTempFile(paramContext);
    if (localFile == null);
    while (true)
    {
      return localObject1;
      try
      {
        boolean bool = TypefaceCompatUtil.copyToFile(localFile, paramInputStream);
        if (!bool)
        {
          localFile.delete();
          continue;
        }
        Typeface localTypeface = Typeface.createFromFile(localFile.getPath());
        localObject1 = localTypeface;
        localFile.delete();
      }
      catch (RuntimeException localRuntimeException)
      {
        localFile.delete();
      }
      finally
      {
        localFile.delete();
      }
    }
  }

  @Nullable
  public Typeface createFromResourcesFontFile(Context paramContext, Resources paramResources, int paramInt1, String paramString, int paramInt2)
  {
    Object localObject1 = null;
    File localFile = TypefaceCompatUtil.getTempFile(paramContext);
    if (localFile == null);
    while (true)
    {
      return localObject1;
      try
      {
        boolean bool = TypefaceCompatUtil.copyToFile(localFile, paramResources, paramInt1);
        if (!bool)
        {
          localFile.delete();
          continue;
        }
        Typeface localTypeface = Typeface.createFromFile(localFile.getPath());
        localObject1 = localTypeface;
        localFile.delete();
      }
      catch (RuntimeException localRuntimeException)
      {
        localFile.delete();
      }
      finally
      {
        localFile.delete();
      }
    }
  }

  protected FontsContractCompat.FontInfo findBestInfo(FontsContractCompat.FontInfo[] paramArrayOfFontInfo, int paramInt)
  {
    return (FontsContractCompat.FontInfo)findBestFont(paramArrayOfFontInfo, paramInt, new StyleExtractor()
    {
      public int getWeight(FontsContractCompat.FontInfo paramAnonymousFontInfo)
      {
        return paramAnonymousFontInfo.getWeight();
      }

      public boolean isItalic(FontsContractCompat.FontInfo paramAnonymousFontInfo)
      {
        return paramAnonymousFontInfo.isItalic();
      }
    });
  }

  private static abstract interface StyleExtractor<T>
  {
    public abstract int getWeight(T paramT);

    public abstract boolean isItalic(T paramT);
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.graphics.TypefaceCompatBaseImpl
 * JD-Core Version:    0.6.2
 */