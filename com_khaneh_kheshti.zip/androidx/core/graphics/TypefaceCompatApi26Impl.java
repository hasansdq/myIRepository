package androidx.core.graphics;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.FontVariationAxis;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.core.content.res.FontResourcesParserCompat.FontFamilyFilesResourceEntry;
import androidx.core.content.res.FontResourcesParserCompat.FontFileResourceEntry;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;

@RequiresApi(26)
@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public class TypefaceCompatApi26Impl extends TypefaceCompatApi21Impl
{
  private static final String ABORT_CREATION_METHOD = "abortCreation";
  private static final String ADD_FONT_FROM_ASSET_MANAGER_METHOD = "addFontFromAssetManager";
  private static final String ADD_FONT_FROM_BUFFER_METHOD = "addFontFromBuffer";
  private static final String CREATE_FROM_FAMILIES_WITH_DEFAULT_METHOD = "createFromFamiliesWithDefault";
  private static final String DEFAULT_FAMILY = "sans-serif";
  private static final String FONT_FAMILY_CLASS = "android.graphics.FontFamily";
  private static final String FREEZE_METHOD = "freeze";
  private static final int RESOLVE_BY_FONT_TABLE = -1;
  private static final String TAG = "TypefaceCompatApi26Impl";
  protected final Method mAbortCreation;
  protected final Method mAddFontFromAssetManager;
  protected final Method mAddFontFromBuffer;
  protected final Method mCreateFromFamiliesWithDefault;
  protected final Class mFontFamily;
  protected final Constructor mFontFamilyCtor;
  protected final Method mFreeze;

  public TypefaceCompatApi26Impl()
  {
    try
    {
      localClass = obtainFontFamily();
      localConstructor = obtainFontFamilyCtor(localClass);
      localMethod1 = obtainAddFontFromAssetManagerMethod(localClass);
      localMethod2 = obtainAddFontFromBufferMethod(localClass);
      localMethod3 = obtainFreezeMethod(localClass);
      localMethod4 = obtainAbortCreationMethod(localClass);
      Method localMethod6 = obtainCreateFromFamiliesWithDefaultMethod(localClass);
      localMethod5 = localMethod6;
      this.mFontFamily = localClass;
      this.mFontFamilyCtor = localConstructor;
      this.mAddFontFromAssetManager = localMethod1;
      this.mAddFontFromBuffer = localMethod2;
      this.mFreeze = localMethod3;
      this.mAbortCreation = localMethod4;
      this.mCreateFromFamiliesWithDefault = localMethod5;
      return;
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      while (true)
      {
        Log.e("TypefaceCompatApi26Impl", "Unable to collect necessary methods for class " + localClassNotFoundException.getClass().getName(), localClassNotFoundException);
        Class localClass = null;
        Constructor localConstructor = null;
        Method localMethod1 = null;
        Method localMethod2 = null;
        Method localMethod3 = null;
        Method localMethod4 = null;
        Method localMethod5 = null;
      }
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      label98: break label98;
    }
  }

  private void abortCreation(Object paramObject)
  {
    try
    {
      this.mAbortCreation.invoke(paramObject, new Object[0]);
      return;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new RuntimeException(localIllegalAccessException);
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      label15: break label15;
    }
  }

  private boolean addFontFromAssetManager(Context paramContext, Object paramObject, String paramString, int paramInt1, int paramInt2, int paramInt3, @Nullable FontVariationAxis[] paramArrayOfFontVariationAxis)
  {
    try
    {
      Method localMethod = this.mAddFontFromAssetManager;
      Object[] arrayOfObject = new Object[8];
      arrayOfObject[0] = paramContext.getAssets();
      arrayOfObject[1] = paramString;
      arrayOfObject[2] = Integer.valueOf(0);
      arrayOfObject[3] = Boolean.valueOf(false);
      arrayOfObject[4] = Integer.valueOf(paramInt1);
      arrayOfObject[5] = Integer.valueOf(paramInt2);
      arrayOfObject[6] = Integer.valueOf(paramInt3);
      arrayOfObject[7] = paramArrayOfFontVariationAxis;
      boolean bool = ((Boolean)localMethod.invoke(paramObject, arrayOfObject)).booleanValue();
      return bool;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new RuntimeException(localIllegalAccessException);
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      label98: break label98;
    }
  }

  private boolean addFontFromBuffer(Object paramObject, ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, int paramInt3)
  {
    try
    {
      Method localMethod = this.mAddFontFromBuffer;
      Object[] arrayOfObject = new Object[5];
      arrayOfObject[0] = paramByteBuffer;
      arrayOfObject[1] = Integer.valueOf(paramInt1);
      arrayOfObject[2] = null;
      arrayOfObject[3] = Integer.valueOf(paramInt2);
      arrayOfObject[4] = Integer.valueOf(paramInt3);
      boolean bool = ((Boolean)localMethod.invoke(paramObject, arrayOfObject)).booleanValue();
      return bool;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new RuntimeException(localIllegalAccessException);
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      label69: break label69;
    }
  }

  private boolean freeze(Object paramObject)
  {
    try
    {
      boolean bool = ((Boolean)this.mFreeze.invoke(paramObject, new Object[0])).booleanValue();
      return bool;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new RuntimeException(localIllegalAccessException);
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      label22: break label22;
    }
  }

  private boolean isFontFamilyPrivateAPIAvailable()
  {
    if (this.mAddFontFromAssetManager == null)
      Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
    if (this.mAddFontFromAssetManager != null);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private Object newFamily()
  {
    try
    {
      Object localObject = this.mFontFamilyCtor.newInstance(new Object[0]);
      return localObject;
    }
    catch (InstantiationException localInstantiationException)
    {
      throw new RuntimeException(localInstantiationException);
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      break label15;
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      label15: break label15;
    }
  }

  protected Typeface createFromFamiliesWithDefault(Object paramObject)
  {
    try
    {
      Object localObject = Array.newInstance(this.mFontFamily, 1);
      Array.set(localObject, 0, paramObject);
      Method localMethod = this.mCreateFromFamiliesWithDefault;
      Object[] arrayOfObject = new Object[3];
      arrayOfObject[0] = localObject;
      arrayOfObject[1] = Integer.valueOf(-1);
      arrayOfObject[2] = Integer.valueOf(-1);
      Typeface localTypeface = (Typeface)localMethod.invoke(null, arrayOfObject);
      return localTypeface;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new RuntimeException(localIllegalAccessException);
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      label65: break label65;
    }
  }

  public Typeface createFromFontFamilyFilesResourceEntry(Context paramContext, FontResourcesParserCompat.FontFamilyFilesResourceEntry paramFontFamilyFilesResourceEntry, Resources paramResources, int paramInt)
  {
    Typeface localTypeface;
    if (!isFontFamilyPrivateAPIAvailable())
      localTypeface = super.createFromFontFamilyFilesResourceEntry(paramContext, paramFontFamilyFilesResourceEntry, paramResources, paramInt);
    while (true)
    {
      return localTypeface;
      Object localObject = newFamily();
      FontResourcesParserCompat.FontFileResourceEntry[] arrayOfFontFileResourceEntry = paramFontFamilyFilesResourceEntry.getEntries();
      int i = arrayOfFontFileResourceEntry.length;
      label131: for (int j = 0; ; j++)
      {
        if (j >= i)
          break label137;
        FontResourcesParserCompat.FontFileResourceEntry localFontFileResourceEntry = arrayOfFontFileResourceEntry[j];
        String str = localFontFileResourceEntry.getFileName();
        int k = localFontFileResourceEntry.getTtcIndex();
        int m = localFontFileResourceEntry.getWeight();
        if (localFontFileResourceEntry.isItalic());
        for (int n = 1; ; n = 0)
        {
          if (addFontFromAssetManager(paramContext, localObject, str, k, m, n, FontVariationAxis.fromFontVariationSettings(localFontFileResourceEntry.getVariationSettings())))
            break label131;
          abortCreation(localObject);
          localTypeface = null;
          break;
        }
      }
      label137: if (!freeze(localObject))
        localTypeface = null;
      else
        localTypeface = createFromFamiliesWithDefault(localObject);
    }
  }

  // ERROR //
  public Typeface createFromFontInfo(Context paramContext, @Nullable android.os.CancellationSignal paramCancellationSignal, @androidx.annotation.NonNull androidx.core.provider.FontsContractCompat.FontInfo[] paramArrayOfFontInfo, int paramInt)
  {
    // Byte code:
    //   0: aload_3
    //   1: arraylength
    //   2: iconst_1
    //   3: if_icmpge +9 -> 12
    //   6: aconst_null
    //   7: astore 10
    //   9: aload 10
    //   11: areturn
    //   12: aload_0
    //   13: invokespecial 197	androidx/core/graphics/TypefaceCompatApi26Impl:isFontFamilyPrivateAPIAvailable	()Z
    //   16: ifne +207 -> 223
    //   19: aload_0
    //   20: aload_3
    //   21: iload 4
    //   23: invokevirtual 250	androidx/core/graphics/TypefaceCompatApi26Impl:findBestInfo	([Landroidx/core/provider/FontsContractCompat$FontInfo;I)Landroidx/core/provider/FontsContractCompat$FontInfo;
    //   26: astore 16
    //   28: aload_1
    //   29: invokevirtual 254	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   32: astore 17
    //   34: aload 17
    //   36: aload 16
    //   38: invokevirtual 260	androidx/core/provider/FontsContractCompat$FontInfo:getUri	()Landroid/net/Uri;
    //   41: ldc_w 262
    //   44: aload_2
    //   45: invokevirtual 268	android/content/ContentResolver:openFileDescriptor	(Landroid/net/Uri;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/os/ParcelFileDescriptor;
    //   48: astore 19
    //   50: aconst_null
    //   51: astore 20
    //   53: aload 19
    //   55: ifnonnull +42 -> 97
    //   58: aconst_null
    //   59: astore 10
    //   61: aload 19
    //   63: ifnull -54 -> 9
    //   66: iconst_0
    //   67: ifeq +22 -> 89
    //   70: aload 19
    //   72: invokevirtual 273	android/os/ParcelFileDescriptor:close	()V
    //   75: goto -66 -> 9
    //   78: astore 27
    //   80: aconst_null
    //   81: aload 27
    //   83: invokevirtual 276	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
    //   86: goto -77 -> 9
    //   89: aload 19
    //   91: invokevirtual 273	android/os/ParcelFileDescriptor:close	()V
    //   94: goto -85 -> 9
    //   97: new 278	android/graphics/Typeface$Builder
    //   100: dup
    //   101: aload 19
    //   103: invokevirtual 282	android/os/ParcelFileDescriptor:getFileDescriptor	()Ljava/io/FileDescriptor;
    //   106: invokespecial 285	android/graphics/Typeface$Builder:<init>	(Ljava/io/FileDescriptor;)V
    //   109: aload 16
    //   111: invokevirtual 286	androidx/core/provider/FontsContractCompat$FontInfo:getWeight	()I
    //   114: invokevirtual 290	android/graphics/Typeface$Builder:setWeight	(I)Landroid/graphics/Typeface$Builder;
    //   117: aload 16
    //   119: invokevirtual 291	androidx/core/provider/FontsContractCompat$FontInfo:isItalic	()Z
    //   122: invokevirtual 295	android/graphics/Typeface$Builder:setItalic	(Z)Landroid/graphics/Typeface$Builder;
    //   125: invokevirtual 299	android/graphics/Typeface$Builder:build	()Landroid/graphics/Typeface;
    //   128: astore 25
    //   130: aload 25
    //   132: astore 10
    //   134: aload 19
    //   136: ifnull -127 -> 9
    //   139: iconst_0
    //   140: ifeq +22 -> 162
    //   143: aload 19
    //   145: invokevirtual 273	android/os/ParcelFileDescriptor:close	()V
    //   148: goto -139 -> 9
    //   151: astore 26
    //   153: aconst_null
    //   154: aload 26
    //   156: invokevirtual 276	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
    //   159: goto -150 -> 9
    //   162: aload 19
    //   164: invokevirtual 273	android/os/ParcelFileDescriptor:close	()V
    //   167: goto -158 -> 9
    //   170: astore 23
    //   172: aload 23
    //   174: athrow
    //   175: astore 24
    //   177: aload 23
    //   179: astore 20
    //   181: aload 24
    //   183: astore 21
    //   185: aload 19
    //   187: ifnull +13 -> 200
    //   190: aload 20
    //   192: ifnull +23 -> 215
    //   195: aload 19
    //   197: invokevirtual 273	android/os/ParcelFileDescriptor:close	()V
    //   200: aload 21
    //   202: athrow
    //   203: astore 22
    //   205: aload 20
    //   207: aload 22
    //   209: invokevirtual 276	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
    //   212: goto -12 -> 200
    //   215: aload 19
    //   217: invokevirtual 273	android/os/ParcelFileDescriptor:close	()V
    //   220: goto -20 -> 200
    //   223: aload_1
    //   224: aload_3
    //   225: aload_2
    //   226: invokestatic 305	androidx/core/provider/FontsContractCompat:prepareFontData	(Landroid/content/Context;[Landroidx/core/provider/FontsContractCompat$FontInfo;Landroid/os/CancellationSignal;)Ljava/util/Map;
    //   229: astore 5
    //   231: aload_0
    //   232: invokespecial 201	androidx/core/graphics/TypefaceCompatApi26Impl:newFamily	()Ljava/lang/Object;
    //   235: astore 6
    //   237: iconst_0
    //   238: istore 7
    //   240: aload_3
    //   241: arraylength
    //   242: istore 8
    //   244: iconst_0
    //   245: istore 9
    //   247: iload 9
    //   249: iload 8
    //   251: if_icmpge +103 -> 354
    //   254: aload_3
    //   255: iload 9
    //   257: aaload
    //   258: astore 11
    //   260: aload 5
    //   262: aload 11
    //   264: invokevirtual 260	androidx/core/provider/FontsContractCompat$FontInfo:getUri	()Landroid/net/Uri;
    //   267: invokeinterface 311 2 0
    //   272: checkcast 313	java/nio/ByteBuffer
    //   275: astore 12
    //   277: aload 12
    //   279: ifnonnull +9 -> 288
    //   282: iinc 9 1
    //   285: goto -38 -> 247
    //   288: aload 11
    //   290: invokevirtual 314	androidx/core/provider/FontsContractCompat$FontInfo:getTtcIndex	()I
    //   293: istore 13
    //   295: aload 11
    //   297: invokevirtual 286	androidx/core/provider/FontsContractCompat$FontInfo:getWeight	()I
    //   300: istore 14
    //   302: aload 11
    //   304: invokevirtual 291	androidx/core/provider/FontsContractCompat$FontInfo:isItalic	()Z
    //   307: ifeq +35 -> 342
    //   310: iconst_1
    //   311: istore 15
    //   313: aload_0
    //   314: aload 6
    //   316: aload 12
    //   318: iload 13
    //   320: iload 14
    //   322: iload 15
    //   324: invokespecial 316	androidx/core/graphics/TypefaceCompatApi26Impl:addFontFromBuffer	(Ljava/lang/Object;Ljava/nio/ByteBuffer;III)Z
    //   327: ifne +21 -> 348
    //   330: aload_0
    //   331: aload 6
    //   333: invokespecial 235	androidx/core/graphics/TypefaceCompatApi26Impl:abortCreation	(Ljava/lang/Object;)V
    //   336: aconst_null
    //   337: astore 10
    //   339: goto -330 -> 9
    //   342: iconst_0
    //   343: istore 15
    //   345: goto -32 -> 313
    //   348: iconst_1
    //   349: istore 7
    //   351: goto -69 -> 282
    //   354: iload 7
    //   356: ifne +15 -> 371
    //   359: aload_0
    //   360: aload 6
    //   362: invokespecial 235	androidx/core/graphics/TypefaceCompatApi26Impl:abortCreation	(Ljava/lang/Object;)V
    //   365: aconst_null
    //   366: astore 10
    //   368: goto -359 -> 9
    //   371: aload_0
    //   372: aload 6
    //   374: invokespecial 237	androidx/core/graphics/TypefaceCompatApi26Impl:freeze	(Ljava/lang/Object;)Z
    //   377: ifne +9 -> 386
    //   380: aconst_null
    //   381: astore 10
    //   383: goto -374 -> 9
    //   386: aload_0
    //   387: aload 6
    //   389: invokevirtual 239	androidx/core/graphics/TypefaceCompatApi26Impl:createFromFamiliesWithDefault	(Ljava/lang/Object;)Landroid/graphics/Typeface;
    //   392: iload 4
    //   394: invokestatic 320	android/graphics/Typeface:create	(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;
    //   397: astore 10
    //   399: goto -390 -> 9
    //   402: astore 21
    //   404: goto -219 -> 185
    //   407: astore 18
    //   409: aconst_null
    //   410: astore 10
    //   412: goto -403 -> 9
    //
    // Exception table:
    //   from	to	target	type
    //   70	75	78	java/lang/Throwable
    //   143	148	151	java/lang/Throwable
    //   97	130	170	java/lang/Throwable
    //   172	175	175	finally
    //   195	200	203	java/lang/Throwable
    //   97	130	402	finally
    //   34	50	407	java/io/IOException
    //   70	75	407	java/io/IOException
    //   80	94	407	java/io/IOException
    //   143	148	407	java/io/IOException
    //   153	167	407	java/io/IOException
    //   195	200	407	java/io/IOException
    //   200	220	407	java/io/IOException
  }

  @Nullable
  public Typeface createFromResourcesFontFile(Context paramContext, Resources paramResources, int paramInt1, String paramString, int paramInt2)
  {
    Typeface localTypeface = null;
    if (!isFontFamilyPrivateAPIAvailable())
      localTypeface = super.createFromResourcesFontFile(paramContext, paramResources, paramInt1, paramString, paramInt2);
    while (true)
    {
      return localTypeface;
      Object localObject = newFamily();
      if (!addFontFromAssetManager(paramContext, localObject, paramString, 0, -1, -1, null))
        abortCreation(localObject);
      else if (freeze(localObject))
        localTypeface = createFromFamiliesWithDefault(localObject);
    }
  }

  protected Method obtainAbortCreationMethod(Class paramClass)
    throws NoSuchMethodException
  {
    return paramClass.getMethod("abortCreation", new Class[0]);
  }

  protected Method obtainAddFontFromAssetManagerMethod(Class paramClass)
    throws NoSuchMethodException
  {
    Class[] arrayOfClass = new Class[8];
    arrayOfClass[0] = AssetManager.class;
    arrayOfClass[1] = String.class;
    arrayOfClass[2] = Integer.TYPE;
    arrayOfClass[3] = Boolean.TYPE;
    arrayOfClass[4] = Integer.TYPE;
    arrayOfClass[5] = Integer.TYPE;
    arrayOfClass[6] = Integer.TYPE;
    arrayOfClass[7] = [Landroid.graphics.fonts.FontVariationAxis.class;
    return paramClass.getMethod("addFontFromAssetManager", arrayOfClass);
  }

  protected Method obtainAddFontFromBufferMethod(Class paramClass)
    throws NoSuchMethodException
  {
    Class[] arrayOfClass = new Class[5];
    arrayOfClass[0] = ByteBuffer.class;
    arrayOfClass[1] = Integer.TYPE;
    arrayOfClass[2] = [Landroid.graphics.fonts.FontVariationAxis.class;
    arrayOfClass[3] = Integer.TYPE;
    arrayOfClass[4] = Integer.TYPE;
    return paramClass.getMethod("addFontFromBuffer", arrayOfClass);
  }

  protected Method obtainCreateFromFamiliesWithDefaultMethod(Class paramClass)
    throws NoSuchMethodException
  {
    Object localObject = Array.newInstance(paramClass, 1);
    Class[] arrayOfClass = new Class[3];
    arrayOfClass[0] = localObject.getClass();
    arrayOfClass[1] = Integer.TYPE;
    arrayOfClass[2] = Integer.TYPE;
    Method localMethod = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", arrayOfClass);
    localMethod.setAccessible(true);
    return localMethod;
  }

  protected Class obtainFontFamily()
    throws ClassNotFoundException
  {
    return Class.forName("android.graphics.FontFamily");
  }

  protected Constructor obtainFontFamilyCtor(Class paramClass)
    throws NoSuchMethodException
  {
    return paramClass.getConstructor(new Class[0]);
  }

  protected Method obtainFreezeMethod(Class paramClass)
    throws NoSuchMethodException
  {
    return paramClass.getMethod("freeze", new Class[0]);
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.graphics.TypefaceCompatApi26Impl
 * JD-Core Version:    0.6.2
 */