package androidx.core.graphics.drawable;

import android.app.ActivityManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.Intent.ShortcutIconResource;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.ColorInt;
import androidx.annotation.DrawableRes;
import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.util.Preconditions;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.Charset;

public class IconCompat extends CustomVersionedParcelable
{
  private static final float ADAPTIVE_ICON_INSET_FACTOR = 0.25F;
  private static final int AMBIENT_SHADOW_ALPHA = 30;
  private static final float BLUR_FACTOR = 0.01041667F;
  static final PorterDuff.Mode DEFAULT_TINT_MODE = PorterDuff.Mode.SRC_IN;
  private static final float DEFAULT_VIEW_PORT_SCALE = 0.6666667F;
  private static final String EXTRA_INT1 = "int1";
  private static final String EXTRA_INT2 = "int2";
  private static final String EXTRA_OBJ = "obj";
  private static final String EXTRA_TINT_LIST = "tint_list";
  private static final String EXTRA_TINT_MODE = "tint_mode";
  private static final String EXTRA_TYPE = "type";
  private static final float ICON_DIAMETER_FACTOR = 0.9166667F;
  private static final int KEY_SHADOW_ALPHA = 61;
  private static final float KEY_SHADOW_OFFSET_FACTOR = 0.02083333F;
  private static final String TAG = "IconCompat";
  public static final int TYPE_UNKNOWN = -1;

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY})
  public byte[] mData;

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY})
  public int mInt1;

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY})
  public int mInt2;
  Object mObj1;

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY})
  public Parcelable mParcelable;

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY})
  public ColorStateList mTintList = null;
  PorterDuff.Mode mTintMode = DEFAULT_TINT_MODE;

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY})
  public String mTintModeStr;

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY})
  public int mType;

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY})
  public IconCompat()
  {
  }

  private IconCompat(int paramInt)
  {
    this.mType = paramInt;
  }

  @Nullable
  public static IconCompat createFromBundle(@NonNull Bundle paramBundle)
  {
    int i = paramBundle.getInt("type");
    IconCompat localIconCompat = new IconCompat(i);
    localIconCompat.mInt1 = paramBundle.getInt("int1");
    localIconCompat.mInt2 = paramBundle.getInt("int2");
    if (paramBundle.containsKey("tint_list"))
      localIconCompat.mTintList = ((ColorStateList)paramBundle.getParcelable("tint_list"));
    if (paramBundle.containsKey("tint_mode"))
      localIconCompat.mTintMode = PorterDuff.Mode.valueOf(paramBundle.getString("tint_mode"));
    switch (i)
    {
    case 0:
    default:
      Log.w("IconCompat", "Unknown type " + i);
      localIconCompat = null;
    case -1:
    case 1:
    case 5:
    case 2:
    case 4:
    case 3:
    }
    while (true)
    {
      return localIconCompat;
      localIconCompat.mObj1 = paramBundle.getParcelable("obj");
      continue;
      localIconCompat.mObj1 = paramBundle.getString("obj");
      continue;
      localIconCompat.mObj1 = paramBundle.getByteArray("obj");
    }
  }

  @Nullable
  @RequiresApi(23)
  public static IconCompat createFromIcon(@NonNull Context paramContext, @NonNull Icon paramIcon)
  {
    Preconditions.checkNotNull(paramIcon);
    Object localObject;
    switch (getType(paramIcon))
    {
    case 3:
    default:
      localObject = new IconCompat(-1);
      ((IconCompat)localObject).mObj1 = paramIcon;
    case 2:
    case 4:
    }
    while (true)
    {
      return localObject;
      String str = getResPackage(paramIcon);
      try
      {
        IconCompat localIconCompat = createWithResource(getResources(paramContext, str), str, getResId(paramIcon));
        localObject = localIconCompat;
      }
      catch (Resources.NotFoundException localNotFoundException)
      {
        throw new IllegalArgumentException("Icon resource cannot be found");
      }
      localObject = createWithContentUri(getUri(paramIcon));
    }
  }

  @Nullable
  @RequiresApi(23)
  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public static IconCompat createFromIcon(@NonNull Icon paramIcon)
  {
    Preconditions.checkNotNull(paramIcon);
    IconCompat localIconCompat;
    switch (getType(paramIcon))
    {
    case 3:
    default:
      localIconCompat = new IconCompat(-1);
      localIconCompat.mObj1 = paramIcon;
    case 2:
    case 4:
    }
    while (true)
    {
      return localIconCompat;
      localIconCompat = createWithResource(null, getResPackage(paramIcon), getResId(paramIcon));
      continue;
      localIconCompat = createWithContentUri(getUri(paramIcon));
    }
  }

  @VisibleForTesting
  static Bitmap createLegacyIconFromAdaptiveIcon(Bitmap paramBitmap, boolean paramBoolean)
  {
    int i = (int)(0.6666667F * Math.min(paramBitmap.getWidth(), paramBitmap.getHeight()));
    Bitmap localBitmap = Bitmap.createBitmap(i, i, Bitmap.Config.ARGB_8888);
    Canvas localCanvas = new Canvas(localBitmap);
    Paint localPaint = new Paint(3);
    float f1 = 0.5F * i;
    float f2 = f1 * 0.9166667F;
    if (paramBoolean)
    {
      float f3 = 0.01041667F * i;
      localPaint.setColor(0);
      localPaint.setShadowLayer(f3, 0.0F, 0.02083333F * i, 1023410176);
      localCanvas.drawCircle(f1, f1, f2, localPaint);
      localPaint.setShadowLayer(f3, 0.0F, 0.0F, 503316480);
      localCanvas.drawCircle(f1, f1, f2, localPaint);
      localPaint.clearShadowLayer();
    }
    localPaint.setColor(-16777216);
    BitmapShader localBitmapShader = new BitmapShader(paramBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
    Matrix localMatrix = new Matrix();
    localMatrix.setTranslate(-(paramBitmap.getWidth() - i) / 2, -(paramBitmap.getHeight() - i) / 2);
    localBitmapShader.setLocalMatrix(localMatrix);
    localPaint.setShader(localBitmapShader);
    localCanvas.drawCircle(f1, f1, f2, localPaint);
    localCanvas.setBitmap(null);
    return localBitmap;
  }

  public static IconCompat createWithAdaptiveBitmap(Bitmap paramBitmap)
  {
    if (paramBitmap == null)
      throw new IllegalArgumentException("Bitmap must not be null.");
    IconCompat localIconCompat = new IconCompat(5);
    localIconCompat.mObj1 = paramBitmap;
    return localIconCompat;
  }

  public static IconCompat createWithBitmap(Bitmap paramBitmap)
  {
    if (paramBitmap == null)
      throw new IllegalArgumentException("Bitmap must not be null.");
    IconCompat localIconCompat = new IconCompat(1);
    localIconCompat.mObj1 = paramBitmap;
    return localIconCompat;
  }

  public static IconCompat createWithContentUri(Uri paramUri)
  {
    if (paramUri == null)
      throw new IllegalArgumentException("Uri must not be null.");
    return createWithContentUri(paramUri.toString());
  }

  public static IconCompat createWithContentUri(String paramString)
  {
    if (paramString == null)
      throw new IllegalArgumentException("Uri must not be null.");
    IconCompat localIconCompat = new IconCompat(4);
    localIconCompat.mObj1 = paramString;
    return localIconCompat;
  }

  public static IconCompat createWithData(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if (paramArrayOfByte == null)
      throw new IllegalArgumentException("Data must not be null.");
    IconCompat localIconCompat = new IconCompat(3);
    localIconCompat.mObj1 = paramArrayOfByte;
    localIconCompat.mInt1 = paramInt1;
    localIconCompat.mInt2 = paramInt2;
    return localIconCompat;
  }

  public static IconCompat createWithResource(Context paramContext, @DrawableRes int paramInt)
  {
    if (paramContext == null)
      throw new IllegalArgumentException("Context must not be null.");
    return createWithResource(paramContext.getResources(), paramContext.getPackageName(), paramInt);
  }

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY})
  public static IconCompat createWithResource(Resources paramResources, String paramString, @DrawableRes int paramInt)
  {
    if (paramString == null)
      throw new IllegalArgumentException("Package must not be null.");
    if (paramInt == 0)
      throw new IllegalArgumentException("Drawable resource ID must not be 0");
    IconCompat localIconCompat = new IconCompat(2);
    localIconCompat.mInt1 = paramInt;
    if (paramResources != null);
    while (true)
    {
      try
      {
        localIconCompat.mObj1 = paramResources.getResourceName(paramInt);
        return localIconCompat;
      }
      catch (Resources.NotFoundException localNotFoundException)
      {
        throw new IllegalArgumentException("Icon resource cannot be found");
      }
      localIconCompat.mObj1 = paramString;
    }
  }

  @DrawableRes
  @IdRes
  @RequiresApi(23)
  private static int getResId(@NonNull Icon paramIcon)
  {
    int i;
    if (Build.VERSION.SDK_INT >= 28)
      i = paramIcon.getResId();
    while (true)
    {
      return i;
      try
      {
        int j = ((Integer)paramIcon.getClass().getMethod("getResId", new Class[0]).invoke(paramIcon, new Object[0])).intValue();
        i = j;
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        Log.e("IconCompat", "Unable to get icon resource", localIllegalAccessException);
        i = 0;
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        Log.e("IconCompat", "Unable to get icon resource", localInvocationTargetException);
        i = 0;
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
        Log.e("IconCompat", "Unable to get icon resource", localNoSuchMethodException);
        i = 0;
      }
    }
  }

  @Nullable
  @RequiresApi(23)
  private static String getResPackage(@NonNull Icon paramIcon)
  {
    String str;
    if (Build.VERSION.SDK_INT >= 28)
      str = paramIcon.getResPackage();
    while (true)
    {
      return str;
      try
      {
        str = (String)paramIcon.getClass().getMethod("getResPackage", new Class[0]).invoke(paramIcon, new Object[0]);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        Log.e("IconCompat", "Unable to get icon package", localIllegalAccessException);
        str = null;
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        Log.e("IconCompat", "Unable to get icon package", localInvocationTargetException);
        str = null;
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
        Log.e("IconCompat", "Unable to get icon package", localNoSuchMethodException);
        str = null;
      }
    }
  }

  private static Resources getResources(Context paramContext, String paramString)
  {
    Object localObject = null;
    if ("android".equals(paramString))
      localObject = Resources.getSystem();
    while (true)
    {
      return localObject;
      PackageManager localPackageManager = paramContext.getPackageManager();
      try
      {
        ApplicationInfo localApplicationInfo = localPackageManager.getApplicationInfo(paramString, 8192);
        if (localApplicationInfo != null)
        {
          Resources localResources = localPackageManager.getResourcesForApplication(localApplicationInfo);
          localObject = localResources;
        }
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        Log.e("IconCompat", String.format("Unable to find pkg=%s for icon", new Object[] { paramString }), localNameNotFoundException);
      }
    }
  }

  @RequiresApi(23)
  private static int getType(@NonNull Icon paramIcon)
  {
    int i;
    if (Build.VERSION.SDK_INT >= 28)
      i = paramIcon.getType();
    while (true)
    {
      return i;
      try
      {
        int j = ((Integer)paramIcon.getClass().getMethod("getType", new Class[0]).invoke(paramIcon, new Object[0])).intValue();
        i = j;
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        Log.e("IconCompat", "Unable to get icon type " + paramIcon, localIllegalAccessException);
        i = -1;
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        Log.e("IconCompat", "Unable to get icon type " + paramIcon, localInvocationTargetException);
        i = -1;
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
        Log.e("IconCompat", "Unable to get icon type " + paramIcon, localNoSuchMethodException);
        i = -1;
      }
    }
  }

  @Nullable
  @RequiresApi(23)
  private static Uri getUri(@NonNull Icon paramIcon)
  {
    Uri localUri;
    if (Build.VERSION.SDK_INT >= 28)
      localUri = paramIcon.getUri();
    while (true)
    {
      return localUri;
      try
      {
        localUri = (Uri)paramIcon.getClass().getMethod("getUri", new Class[0]).invoke(paramIcon, new Object[0]);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        Log.e("IconCompat", "Unable to get icon uri", localIllegalAccessException);
        localUri = null;
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        Log.e("IconCompat", "Unable to get icon uri", localInvocationTargetException);
        localUri = null;
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
        Log.e("IconCompat", "Unable to get icon uri", localNoSuchMethodException);
        localUri = null;
      }
    }
  }

  private Drawable loadDrawableInner(Context paramContext)
  {
    Object localObject2;
    switch (this.mType)
    {
    default:
      localObject2 = null;
    case 1:
    case 5:
    case 2:
    case 3:
      while (true)
      {
        return localObject2;
        localObject2 = new BitmapDrawable(paramContext.getResources(), (Bitmap)this.mObj1);
        continue;
        localObject2 = new BitmapDrawable(paramContext.getResources(), createLegacyIconFromAdaptiveIcon((Bitmap)this.mObj1, false));
        continue;
        String str2 = getResPackage();
        if (TextUtils.isEmpty(str2))
          str2 = paramContext.getPackageName();
        Resources localResources = getResources(paramContext, str2);
        try
        {
          Drawable localDrawable = ResourcesCompat.getDrawable(localResources, this.mInt1, paramContext.getTheme());
          localObject2 = localDrawable;
        }
        catch (RuntimeException localRuntimeException)
        {
          Object[] arrayOfObject = new Object[2];
          arrayOfObject[0] = Integer.valueOf(this.mInt1);
          arrayOfObject[1] = this.mObj1;
          Log.e("IconCompat", String.format("Unable to load resource 0x%08x from pkg=%s", arrayOfObject), localRuntimeException);
        }
        break;
        localObject2 = new BitmapDrawable(paramContext.getResources(), BitmapFactory.decodeByteArray((byte[])this.mObj1, this.mInt1, this.mInt2));
      }
    case 4:
    }
    Uri localUri = Uri.parse((String)this.mObj1);
    String str1 = localUri.getScheme();
    Object localObject1 = null;
    if (("content".equals(str1)) || ("file".equals(str1)));
    while (true)
    {
      try
      {
        InputStream localInputStream = paramContext.getContentResolver().openInputStream(localUri);
        localObject1 = localInputStream;
        if (localObject1 == null)
          break;
        localObject2 = new BitmapDrawable(paramContext.getResources(), BitmapFactory.decodeStream(localObject1));
      }
      catch (Exception localException)
      {
        Log.w("IconCompat", "Unable to load image from URI: " + localUri, localException);
        continue;
      }
      try
      {
        FileInputStream localFileInputStream = new FileInputStream(new File((String)this.mObj1));
        localObject1 = localFileInputStream;
      }
      catch (FileNotFoundException localFileNotFoundException)
      {
        Log.w("IconCompat", "Unable to load image from path: " + localUri, localFileNotFoundException);
      }
    }
  }

  private static String typeToString(int paramInt)
  {
    String str;
    switch (paramInt)
    {
    default:
      str = "UNKNOWN";
    case 1:
    case 5:
    case 3:
    case 2:
    case 4:
    }
    while (true)
    {
      return str;
      str = "BITMAP";
      continue;
      str = "BITMAP_MASKABLE";
      continue;
      str = "DATA";
      continue;
      str = "RESOURCE";
      continue;
      str = "URI";
    }
  }

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public void addToShortcutIntent(@NonNull Intent paramIntent, @Nullable Drawable paramDrawable, @NonNull Context paramContext)
  {
    checkResource(paramContext);
    switch (this.mType)
    {
    case 3:
    case 4:
    default:
      throw new IllegalArgumentException("Icon type not supported for intent shortcuts");
    case 1:
      localObject = (Bitmap)this.mObj1;
      if (paramDrawable != null)
        localObject = ((Bitmap)localObject).copy(((Bitmap)localObject).getConfig(), true);
      if (paramDrawable != null)
      {
        int j = ((Bitmap)localObject).getWidth();
        int k = ((Bitmap)localObject).getHeight();
        paramDrawable.setBounds(j / 2, k / 2, j, k);
        paramDrawable.draw(new Canvas((Bitmap)localObject));
      }
      paramIntent.putExtra("android.intent.extra.shortcut.ICON", (Parcelable)localObject);
    case 5:
    case 2:
    }
    Context localContext;
    while (true)
    {
      return;
      localObject = createLegacyIconFromAdaptiveIcon((Bitmap)this.mObj1, true);
      break;
      try
      {
        localContext = paramContext.createPackageContext(getResPackage(), 0);
        if (paramDrawable == null)
          paramIntent.putExtra("android.intent.extra.shortcut.ICON_RESOURCE", Intent.ShortcutIconResource.fromContext(localContext, this.mInt1));
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        throw new IllegalArgumentException("Can't find package " + this.mObj1, localNameNotFoundException);
      }
    }
    Drawable localDrawable = ContextCompat.getDrawable(localContext, this.mInt1);
    int i;
    if ((localDrawable.getIntrinsicWidth() <= 0) || (localDrawable.getIntrinsicHeight() <= 0))
      i = ((ActivityManager)localContext.getSystemService("activity")).getLauncherLargeIconSize();
    Bitmap localBitmap;
    for (Object localObject = Bitmap.createBitmap(i, i, Bitmap.Config.ARGB_8888); ; localObject = localBitmap)
    {
      localDrawable.setBounds(0, 0, ((Bitmap)localObject).getWidth(), ((Bitmap)localObject).getHeight());
      localDrawable.draw(new Canvas((Bitmap)localObject));
      break;
      localBitmap = Bitmap.createBitmap(localDrawable.getIntrinsicWidth(), localDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
    }
  }

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public void checkResource(Context paramContext)
  {
    String str1;
    if (this.mType == 2)
    {
      str1 = (String)this.mObj1;
      if (str1.contains(":"))
        break label27;
    }
    while (true)
    {
      return;
      label27: String str2 = str1.split(":", -1)[1];
      String str3 = str2.split("/", -1)[0];
      String str4 = str2.split("/", -1)[1];
      String str5 = str1.split(":", -1)[0];
      int i = getResources(paramContext, str5).getIdentifier(str4, str3, str5);
      if (this.mInt1 != i)
      {
        Log.i("IconCompat", "Id has changed for " + str5 + "/" + str4);
        this.mInt1 = i;
      }
    }
  }

  @IdRes
  public int getResId()
  {
    if ((this.mType == -1) && (Build.VERSION.SDK_INT >= 23));
    for (int i = getResId((Icon)this.mObj1); ; i = this.mInt1)
    {
      return i;
      if (this.mType != 2)
        throw new IllegalStateException("called getResId() on " + this);
    }
  }

  @NonNull
  public String getResPackage()
  {
    if ((this.mType == -1) && (Build.VERSION.SDK_INT >= 23));
    for (String str = getResPackage((Icon)this.mObj1); ; str = ((String)this.mObj1).split(":", -1)[0])
    {
      return str;
      if (this.mType != 2)
        throw new IllegalStateException("called getResPackage() on " + this);
    }
  }

  public int getType()
  {
    if ((this.mType == -1) && (Build.VERSION.SDK_INT >= 23));
    for (int i = getType((Icon)this.mObj1); ; i = this.mType)
      return i;
  }

  @NonNull
  public Uri getUri()
  {
    if ((this.mType == -1) && (Build.VERSION.SDK_INT >= 23));
    for (Uri localUri = getUri((Icon)this.mObj1); ; localUri = Uri.parse((String)this.mObj1))
      return localUri;
  }

  public Drawable loadDrawable(Context paramContext)
  {
    checkResource(paramContext);
    Drawable localDrawable;
    if (Build.VERSION.SDK_INT >= 23)
      localDrawable = toIcon().loadDrawable(paramContext);
    while (true)
    {
      return localDrawable;
      localDrawable = loadDrawableInner(paramContext);
      if ((localDrawable != null) && ((this.mTintList != null) || (this.mTintMode != DEFAULT_TINT_MODE)))
      {
        localDrawable.mutate();
        DrawableCompat.setTintList(localDrawable, this.mTintList);
        DrawableCompat.setTintMode(localDrawable, this.mTintMode);
      }
    }
  }

  public void onPostParceling()
  {
    this.mTintMode = PorterDuff.Mode.valueOf(this.mTintModeStr);
    switch (this.mType)
    {
    case 0:
    default:
    case -1:
    case 1:
    case 5:
    case 2:
    case 4:
    case 3:
    }
    while (true)
    {
      return;
      if (this.mParcelable != null)
      {
        this.mObj1 = this.mParcelable;
      }
      else
      {
        throw new IllegalArgumentException("Invalid icon");
        if (this.mParcelable != null)
        {
          this.mObj1 = this.mParcelable;
        }
        else
        {
          this.mObj1 = this.mData;
          this.mType = 3;
          this.mInt1 = 0;
          this.mInt2 = this.mData.length;
          continue;
          this.mObj1 = new String(this.mData, Charset.forName("UTF-16"));
          continue;
          this.mObj1 = this.mData;
        }
      }
    }
  }

  public void onPreParceling(boolean paramBoolean)
  {
    this.mTintModeStr = this.mTintMode.name();
    switch (this.mType)
    {
    case 0:
    default:
    case -1:
    case 1:
    case 5:
    case 4:
    case 2:
    case 3:
    }
    while (true)
    {
      return;
      if (paramBoolean)
        throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
      this.mParcelable = ((Parcelable)this.mObj1);
      continue;
      if (paramBoolean)
      {
        Bitmap localBitmap = (Bitmap)this.mObj1;
        ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
        localBitmap.compress(Bitmap.CompressFormat.PNG, 90, localByteArrayOutputStream);
        this.mData = localByteArrayOutputStream.toByteArray();
      }
      else
      {
        this.mParcelable = ((Parcelable)this.mObj1);
        continue;
        this.mData = this.mObj1.toString().getBytes(Charset.forName("UTF-16"));
        continue;
        this.mData = ((String)this.mObj1).getBytes(Charset.forName("UTF-16"));
        continue;
        this.mData = ((byte[])this.mObj1);
      }
    }
  }

  public IconCompat setTint(@ColorInt int paramInt)
  {
    return setTintList(ColorStateList.valueOf(paramInt));
  }

  public IconCompat setTintList(ColorStateList paramColorStateList)
  {
    this.mTintList = paramColorStateList;
    return this;
  }

  public IconCompat setTintMode(PorterDuff.Mode paramMode)
  {
    this.mTintMode = paramMode;
    return this;
  }

  public Bundle toBundle()
  {
    Bundle localBundle = new Bundle();
    switch (this.mType)
    {
    case 0:
    default:
      throw new IllegalArgumentException("Invalid icon");
    case 1:
    case 5:
      localBundle.putParcelable("obj", (Bitmap)this.mObj1);
    case -1:
    case 2:
    case 4:
    case 3:
    }
    while (true)
    {
      localBundle.putInt("type", this.mType);
      localBundle.putInt("int1", this.mInt1);
      localBundle.putInt("int2", this.mInt2);
      if (this.mTintList != null)
        localBundle.putParcelable("tint_list", this.mTintList);
      if (this.mTintMode != DEFAULT_TINT_MODE)
        localBundle.putString("tint_mode", this.mTintMode.name());
      return localBundle;
      localBundle.putParcelable("obj", (Parcelable)this.mObj1);
      continue;
      localBundle.putString("obj", (String)this.mObj1);
      continue;
      localBundle.putByteArray("obj", (byte[])this.mObj1);
    }
  }

  @RequiresApi(23)
  public Icon toIcon()
  {
    Object localObject;
    Icon localIcon;
    switch (this.mType)
    {
    case 0:
    default:
      throw new IllegalArgumentException("Unknown type");
    case -1:
      localObject = (Icon)this.mObj1;
      return localObject;
    case 1:
      localIcon = Icon.createWithBitmap((Bitmap)this.mObj1);
    case 5:
    case 2:
    case 3:
    case 4:
    }
    while (true)
    {
      if (this.mTintList != null)
        localIcon.setTintList(this.mTintList);
      if (this.mTintMode != DEFAULT_TINT_MODE)
        localIcon.setTintMode(this.mTintMode);
      localObject = localIcon;
      break;
      if (Build.VERSION.SDK_INT >= 26)
      {
        localIcon = Icon.createWithAdaptiveBitmap((Bitmap)this.mObj1);
      }
      else
      {
        localIcon = Icon.createWithBitmap(createLegacyIconFromAdaptiveIcon((Bitmap)this.mObj1, false));
        continue;
        localIcon = Icon.createWithResource(getResPackage(), this.mInt1);
        continue;
        localIcon = Icon.createWithData((byte[])this.mObj1, this.mInt1, this.mInt2);
        continue;
        localIcon = Icon.createWithContentUri((String)this.mObj1);
      }
    }
  }

  public String toString()
  {
    String str;
    if (this.mType == -1)
    {
      str = String.valueOf(this.mObj1);
      return str;
    }
    StringBuilder localStringBuilder1 = new StringBuilder("Icon(typ=").append(typeToString(this.mType));
    switch (this.mType)
    {
    default:
    case 1:
    case 5:
    case 2:
    case 3:
    case 4:
    }
    while (true)
    {
      if (this.mTintList != null)
      {
        localStringBuilder1.append(" tint=");
        localStringBuilder1.append(this.mTintList);
      }
      if (this.mTintMode != DEFAULT_TINT_MODE)
        localStringBuilder1.append(" mode=").append(this.mTintMode);
      localStringBuilder1.append(")");
      str = localStringBuilder1.toString();
      break;
      localStringBuilder1.append(" size=").append(((Bitmap)this.mObj1).getWidth()).append("x").append(((Bitmap)this.mObj1).getHeight());
      continue;
      StringBuilder localStringBuilder2 = localStringBuilder1.append(" pkg=").append(getResPackage()).append(" id=");
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = Integer.valueOf(getResId());
      localStringBuilder2.append(String.format("0x%08x", arrayOfObject));
      continue;
      localStringBuilder1.append(" len=").append(this.mInt1);
      if (this.mInt2 != 0)
      {
        localStringBuilder1.append(" off=").append(this.mInt2);
        continue;
        localStringBuilder1.append(" uri=").append(this.mObj1);
      }
    }
  }

  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY})
  public static @interface IconType
  {
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.graphics.drawable.IconCompat
 * JD-Core Version:    0.6.2
 */