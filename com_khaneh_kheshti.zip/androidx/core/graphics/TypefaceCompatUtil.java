package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.os.Process;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public class TypefaceCompatUtil
{
  private static final String CACHE_FILE_PREFIX = ".font";
  private static final String TAG = "TypefaceCompatUtil";

  public static void closeQuietly(Closeable paramCloseable)
  {
    if (paramCloseable != null);
    try
    {
      paramCloseable.close();
      label10: return;
    }
    catch (IOException localIOException)
    {
      break label10;
    }
  }

  @Nullable
  @RequiresApi(19)
  public static ByteBuffer copyToDirectBuffer(Context paramContext, Resources paramResources, int paramInt)
  {
    Object localObject1 = null;
    File localFile = getTempFile(paramContext);
    if (localFile == null);
    while (true)
    {
      return localObject1;
      try
      {
        boolean bool = copyToFile(localFile, paramResources, paramInt);
        if (!bool)
        {
          localFile.delete();
          continue;
        }
        ByteBuffer localByteBuffer = mmap(localFile);
        localObject1 = localByteBuffer;
        localFile.delete();
      }
      finally
      {
        localFile.delete();
      }
    }
  }

  public static boolean copyToFile(File paramFile, Resources paramResources, int paramInt)
  {
    InputStream localInputStream = null;
    try
    {
      localInputStream = paramResources.openRawResource(paramInt);
      boolean bool = copyToFile(paramFile, localInputStream);
      return bool;
    }
    finally
    {
      closeQuietly(localInputStream);
    }
  }

  // ERROR //
  public static boolean copyToFile(File paramFile, InputStream paramInputStream)
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aconst_null
    //   3: astore_3
    //   4: invokestatic 68	android/os/StrictMode:allowThreadDiskWrites	()Landroid/os/StrictMode$ThreadPolicy;
    //   7: astore 4
    //   9: new 70	java/io/FileOutputStream
    //   12: dup
    //   13: aload_0
    //   14: iconst_0
    //   15: invokespecial 73	java/io/FileOutputStream:<init>	(Ljava/io/File;Z)V
    //   18: astore 5
    //   20: sipush 1024
    //   23: newarray byte
    //   25: astore 9
    //   27: aload_1
    //   28: aload 9
    //   30: invokevirtual 79	java/io/InputStream:read	([B)I
    //   33: istore 10
    //   35: iload 10
    //   37: iconst_m1
    //   38: if_icmpeq +61 -> 99
    //   41: aload 5
    //   43: aload 9
    //   45: iconst_0
    //   46: iload 10
    //   48: invokevirtual 83	java/io/FileOutputStream:write	([BII)V
    //   51: goto -24 -> 27
    //   54: astore 7
    //   56: aload 5
    //   58: astore_3
    //   59: ldc 15
    //   61: new 85	java/lang/StringBuilder
    //   64: dup
    //   65: invokespecial 86	java/lang/StringBuilder:<init>	()V
    //   68: ldc 88
    //   70: invokevirtual 92	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   73: aload 7
    //   75: invokevirtual 96	java/io/IOException:getMessage	()Ljava/lang/String;
    //   78: invokevirtual 92	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   81: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   84: invokestatic 105	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   87: pop
    //   88: aload_3
    //   89: invokestatic 62	androidx/core/graphics/TypefaceCompatUtil:closeQuietly	(Ljava/io/Closeable;)V
    //   92: aload 4
    //   94: invokestatic 109	android/os/StrictMode:setThreadPolicy	(Landroid/os/StrictMode$ThreadPolicy;)V
    //   97: iload_2
    //   98: ireturn
    //   99: iconst_1
    //   100: istore_2
    //   101: aload 5
    //   103: invokestatic 62	androidx/core/graphics/TypefaceCompatUtil:closeQuietly	(Ljava/io/Closeable;)V
    //   106: aload 4
    //   108: invokestatic 109	android/os/StrictMode:setThreadPolicy	(Landroid/os/StrictMode$ThreadPolicy;)V
    //   111: goto -14 -> 97
    //   114: astore 6
    //   116: aload_3
    //   117: invokestatic 62	androidx/core/graphics/TypefaceCompatUtil:closeQuietly	(Ljava/io/Closeable;)V
    //   120: aload 4
    //   122: invokestatic 109	android/os/StrictMode:setThreadPolicy	(Landroid/os/StrictMode$ThreadPolicy;)V
    //   125: aload 6
    //   127: athrow
    //   128: astore 6
    //   130: aload 5
    //   132: astore_3
    //   133: goto -17 -> 116
    //   136: astore 7
    //   138: goto -79 -> 59
    //
    // Exception table:
    //   from	to	target	type
    //   20	51	54	java/io/IOException
    //   9	20	114	finally
    //   59	88	114	finally
    //   20	51	128	finally
    //   9	20	136	java/io/IOException
  }

  @Nullable
  public static File getTempFile(Context paramContext)
  {
    String str = ".font" + Process.myPid() + "-" + Process.myTid() + "-";
    int i = 0;
    if (i < 100);
    for (File localFile = new File(paramContext.getCacheDir(), str + i); ; localFile = null)
    {
      try
      {
        boolean bool = localFile.createNewFile();
        if (bool)
          return localFile;
      }
      catch (IOException localIOException)
      {
        i++;
      }
      break;
    }
  }

  // ERROR //
  @Nullable
  @RequiresApi(19)
  public static ByteBuffer mmap(Context paramContext, android.os.CancellationSignal paramCancellationSignal, android.net.Uri paramUri)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 142	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   4: astore_3
    //   5: aload_3
    //   6: aload_2
    //   7: ldc 144
    //   9: aload_1
    //   10: invokevirtual 150	android/content/ContentResolver:openFileDescriptor	(Landroid/net/Uri;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/os/ParcelFileDescriptor;
    //   13: astore 6
    //   15: aload 6
    //   17: ifnonnull +42 -> 59
    //   20: aconst_null
    //   21: astore 5
    //   23: aload 6
    //   25: ifnull +12 -> 37
    //   28: iconst_0
    //   29: ifeq +22 -> 51
    //   32: aload 6
    //   34: invokevirtual 153	android/os/ParcelFileDescriptor:close	()V
    //   37: aload 5
    //   39: areturn
    //   40: astore 24
    //   42: aconst_null
    //   43: aload 24
    //   45: invokevirtual 157	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
    //   48: goto -11 -> 37
    //   51: aload 6
    //   53: invokevirtual 153	android/os/ParcelFileDescriptor:close	()V
    //   56: goto -19 -> 37
    //   59: new 159	java/io/FileInputStream
    //   62: dup
    //   63: aload 6
    //   65: invokevirtual 163	android/os/ParcelFileDescriptor:getFileDescriptor	()Ljava/io/FileDescriptor;
    //   68: invokespecial 166	java/io/FileInputStream:<init>	(Ljava/io/FileDescriptor;)V
    //   71: astore 7
    //   73: aload 7
    //   75: invokevirtual 170	java/io/FileInputStream:getChannel	()Ljava/nio/channels/FileChannel;
    //   78: astore 18
    //   80: aload 18
    //   82: invokevirtual 176	java/nio/channels/FileChannel:size	()J
    //   85: lstore 19
    //   87: aload 18
    //   89: getstatic 182	java/nio/channels/FileChannel$MapMode:READ_ONLY	Ljava/nio/channels/FileChannel$MapMode;
    //   92: lconst_0
    //   93: lload 19
    //   95: invokevirtual 186	java/nio/channels/FileChannel:map	(Ljava/nio/channels/FileChannel$MapMode;JJ)Ljava/nio/MappedByteBuffer;
    //   98: astore 21
    //   100: aload 21
    //   102: astore 5
    //   104: aload 7
    //   106: ifnull +12 -> 118
    //   109: iconst_0
    //   110: ifeq +80 -> 190
    //   113: aload 7
    //   115: invokevirtual 187	java/io/FileInputStream:close	()V
    //   118: aload 6
    //   120: ifnull -83 -> 37
    //   123: iconst_0
    //   124: ifeq +82 -> 206
    //   127: aload 6
    //   129: invokevirtual 153	android/os/ParcelFileDescriptor:close	()V
    //   132: goto -95 -> 37
    //   135: astore 22
    //   137: aconst_null
    //   138: aload 22
    //   140: invokevirtual 157	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
    //   143: goto -106 -> 37
    //   146: astore 23
    //   148: aconst_null
    //   149: aload 23
    //   151: invokevirtual 157	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
    //   154: goto -36 -> 118
    //   157: astore 13
    //   159: aload 13
    //   161: athrow
    //   162: astore 14
    //   164: aload 13
    //   166: astore 11
    //   168: aload 14
    //   170: astore 10
    //   172: aload 6
    //   174: ifnull +13 -> 187
    //   177: aload 11
    //   179: ifnull +100 -> 279
    //   182: aload 6
    //   184: invokevirtual 153	android/os/ParcelFileDescriptor:close	()V
    //   187: aload 10
    //   189: athrow
    //   190: aload 7
    //   192: invokevirtual 187	java/io/FileInputStream:close	()V
    //   195: goto -77 -> 118
    //   198: astore 10
    //   200: aconst_null
    //   201: astore 11
    //   203: goto -31 -> 172
    //   206: aload 6
    //   208: invokevirtual 153	android/os/ParcelFileDescriptor:close	()V
    //   211: goto -174 -> 37
    //   214: astore 16
    //   216: aload 16
    //   218: athrow
    //   219: astore 17
    //   221: aload 16
    //   223: astore 9
    //   225: aload 17
    //   227: astore 8
    //   229: aload 7
    //   231: ifnull +13 -> 244
    //   234: aload 9
    //   236: ifnull +23 -> 259
    //   239: aload 7
    //   241: invokevirtual 187	java/io/FileInputStream:close	()V
    //   244: aload 8
    //   246: athrow
    //   247: astore 15
    //   249: aload 9
    //   251: aload 15
    //   253: invokevirtual 157	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
    //   256: goto -12 -> 244
    //   259: aload 7
    //   261: invokevirtual 187	java/io/FileInputStream:close	()V
    //   264: goto -20 -> 244
    //   267: astore 12
    //   269: aload 11
    //   271: aload 12
    //   273: invokevirtual 157	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
    //   276: goto -89 -> 187
    //   279: aload 6
    //   281: invokevirtual 153	android/os/ParcelFileDescriptor:close	()V
    //   284: goto -97 -> 187
    //   287: astore 8
    //   289: aconst_null
    //   290: astore 9
    //   292: goto -63 -> 229
    //   295: astore 4
    //   297: aconst_null
    //   298: astore 5
    //   300: goto -263 -> 37
    //
    // Exception table:
    //   from	to	target	type
    //   32	37	40	java/lang/Throwable
    //   127	132	135	java/lang/Throwable
    //   113	118	146	java/lang/Throwable
    //   59	73	157	java/lang/Throwable
    //   148	154	157	java/lang/Throwable
    //   190	195	157	java/lang/Throwable
    //   244	264	157	java/lang/Throwable
    //   159	162	162	finally
    //   59	73	198	finally
    //   113	118	198	finally
    //   148	154	198	finally
    //   190	195	198	finally
    //   239	244	198	finally
    //   244	264	198	finally
    //   73	100	214	java/lang/Throwable
    //   216	219	219	finally
    //   239	244	247	java/lang/Throwable
    //   182	187	267	java/lang/Throwable
    //   73	100	287	finally
    //   5	15	295	java/io/IOException
    //   32	37	295	java/io/IOException
    //   42	56	295	java/io/IOException
    //   127	132	295	java/io/IOException
    //   137	143	295	java/io/IOException
    //   182	187	295	java/io/IOException
    //   187	190	295	java/io/IOException
    //   206	211	295	java/io/IOException
    //   269	284	295	java/io/IOException
  }

  // ERROR //
  @Nullable
  @RequiresApi(19)
  private static ByteBuffer mmap(File paramFile)
  {
    // Byte code:
    //   0: new 159	java/io/FileInputStream
    //   3: dup
    //   4: aload_0
    //   5: invokespecial 190	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   8: astore_1
    //   9: aload_1
    //   10: invokevirtual 170	java/io/FileInputStream:getChannel	()Ljava/nio/channels/FileChannel;
    //   13: astore 9
    //   15: aload 9
    //   17: invokevirtual 176	java/nio/channels/FileChannel:size	()J
    //   20: lstore 10
    //   22: aload 9
    //   24: getstatic 182	java/nio/channels/FileChannel$MapMode:READ_ONLY	Ljava/nio/channels/FileChannel$MapMode;
    //   27: lconst_0
    //   28: lload 10
    //   30: invokevirtual 186	java/nio/channels/FileChannel:map	(Ljava/nio/channels/FileChannel$MapMode;JJ)Ljava/nio/MappedByteBuffer;
    //   33: astore 12
    //   35: aload 12
    //   37: astore 5
    //   39: aload_1
    //   40: ifnull +11 -> 51
    //   43: iconst_0
    //   44: ifeq +21 -> 65
    //   47: aload_1
    //   48: invokevirtual 187	java/io/FileInputStream:close	()V
    //   51: aload 5
    //   53: areturn
    //   54: astore 13
    //   56: aconst_null
    //   57: aload 13
    //   59: invokevirtual 157	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
    //   62: goto -11 -> 51
    //   65: aload_1
    //   66: invokevirtual 187	java/io/FileInputStream:close	()V
    //   69: goto -18 -> 51
    //   72: astore 7
    //   74: aload 7
    //   76: athrow
    //   77: astore 8
    //   79: aload 7
    //   81: astore_3
    //   82: aload 8
    //   84: astore_2
    //   85: aload_1
    //   86: ifnull +11 -> 97
    //   89: aload_3
    //   90: ifnull +20 -> 110
    //   93: aload_1
    //   94: invokevirtual 187	java/io/FileInputStream:close	()V
    //   97: aload_2
    //   98: athrow
    //   99: astore 6
    //   101: aload_3
    //   102: aload 6
    //   104: invokevirtual 157	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
    //   107: goto -10 -> 97
    //   110: aload_1
    //   111: invokevirtual 187	java/io/FileInputStream:close	()V
    //   114: goto -17 -> 97
    //   117: astore_2
    //   118: aconst_null
    //   119: astore_3
    //   120: goto -35 -> 85
    //   123: astore 4
    //   125: aconst_null
    //   126: astore 5
    //   128: goto -77 -> 51
    //
    // Exception table:
    //   from	to	target	type
    //   47	51	54	java/lang/Throwable
    //   9	35	72	java/lang/Throwable
    //   74	77	77	finally
    //   93	97	99	java/lang/Throwable
    //   9	35	117	finally
    //   0	9	123	java/io/IOException
    //   47	51	123	java/io/IOException
    //   56	69	123	java/io/IOException
    //   93	97	123	java/io/IOException
    //   97	114	123	java/io/IOException
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.graphics.TypefaceCompatUtil
 * JD-Core Version:    0.6.2
 */