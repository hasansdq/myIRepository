package androidx.core.accessibilityservice;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.pm.PackageManager;
import android.os.Build.VERSION;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public final class AccessibilityServiceInfoCompat
{
  public static final int CAPABILITY_CAN_FILTER_KEY_EVENTS = 8;
  public static final int CAPABILITY_CAN_REQUEST_ENHANCED_WEB_ACCESSIBILITY = 4;
  public static final int CAPABILITY_CAN_REQUEST_TOUCH_EXPLORATION = 2;
  public static final int CAPABILITY_CAN_RETRIEVE_WINDOW_CONTENT = 1;
  public static final int FEEDBACK_ALL_MASK = -1;
  public static final int FEEDBACK_BRAILLE = 32;
  public static final int FLAG_INCLUDE_NOT_IMPORTANT_VIEWS = 2;
  public static final int FLAG_REPORT_VIEW_IDS = 16;
  public static final int FLAG_REQUEST_ENHANCED_WEB_ACCESSIBILITY = 8;
  public static final int FLAG_REQUEST_FILTER_KEY_EVENTS = 32;
  public static final int FLAG_REQUEST_TOUCH_EXPLORATION_MODE = 4;

  @NonNull
  public static String capabilityToString(int paramInt)
  {
    String str;
    switch (paramInt)
    {
    case 3:
    case 5:
    case 6:
    case 7:
    default:
      str = "UNKNOWN";
    case 1:
    case 2:
    case 4:
    case 8:
    }
    while (true)
    {
      return str;
      str = "CAPABILITY_CAN_RETRIEVE_WINDOW_CONTENT";
      continue;
      str = "CAPABILITY_CAN_REQUEST_TOUCH_EXPLORATION";
      continue;
      str = "CAPABILITY_CAN_REQUEST_ENHANCED_WEB_ACCESSIBILITY";
      continue;
      str = "CAPABILITY_CAN_FILTER_KEY_EVENTS";
    }
  }

  @NonNull
  public static String feedbackTypeToString(int paramInt)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("[");
    while (paramInt > 0)
    {
      int i = 1 << Integer.numberOfTrailingZeros(paramInt);
      paramInt &= (i ^ 0xFFFFFFFF);
      if (localStringBuilder.length() > 1)
        localStringBuilder.append(", ");
      switch (i)
      {
      default:
        break;
      case 1:
        localStringBuilder.append("FEEDBACK_SPOKEN");
        break;
      case 4:
        localStringBuilder.append("FEEDBACK_AUDIBLE");
        break;
      case 2:
        localStringBuilder.append("FEEDBACK_HAPTIC");
        break;
      case 16:
        localStringBuilder.append("FEEDBACK_GENERIC");
        break;
      case 8:
        localStringBuilder.append("FEEDBACK_VISUAL");
      }
    }
    localStringBuilder.append("]");
    return localStringBuilder.toString();
  }

  @Nullable
  public static String flagToString(int paramInt)
  {
    String str;
    switch (paramInt)
    {
    default:
      str = null;
    case 1:
    case 2:
    case 4:
    case 8:
    case 16:
    case 32:
    }
    while (true)
    {
      return str;
      str = "DEFAULT";
      continue;
      str = "FLAG_INCLUDE_NOT_IMPORTANT_VIEWS";
      continue;
      str = "FLAG_REQUEST_TOUCH_EXPLORATION_MODE";
      continue;
      str = "FLAG_REQUEST_ENHANCED_WEB_ACCESSIBILITY";
      continue;
      str = "FLAG_REPORT_VIEW_IDS";
      continue;
      str = "FLAG_REQUEST_FILTER_KEY_EVENTS";
    }
  }

  public static int getCapabilities(@NonNull AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    int i;
    if (Build.VERSION.SDK_INT >= 18)
      i = paramAccessibilityServiceInfo.getCapabilities();
    while (true)
    {
      return i;
      if (paramAccessibilityServiceInfo.getCanRetrieveWindowContent())
        i = 1;
      else
        i = 0;
    }
  }

  @Nullable
  public static String loadDescription(@NonNull AccessibilityServiceInfo paramAccessibilityServiceInfo, @NonNull PackageManager paramPackageManager)
  {
    if (Build.VERSION.SDK_INT >= 16);
    for (String str = paramAccessibilityServiceInfo.loadDescription(paramPackageManager); ; str = paramAccessibilityServiceInfo.getDescription())
      return str;
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.accessibilityservice.AccessibilityServiceInfoCompat
 * JD-Core Version:    0.6.2
 */