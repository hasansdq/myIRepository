package androidx.core.view;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.os.Build.VERSION;
import android.util.Log;
import android.util.TypedValue;
import android.view.ViewConfiguration;
import androidx.annotation.NonNull;
import java.lang.reflect.Method;

public final class ViewConfigurationCompat
{
  private static final String TAG = "ViewConfigCompat";
  private static Method sGetScaledScrollFactorMethod;

  static
  {
    if (Build.VERSION.SDK_INT == 25);
    try
    {
      sGetScaledScrollFactorMethod = ViewConfiguration.class.getDeclaredMethod("getScaledScrollFactor", new Class[0]);
      return;
    }
    catch (Exception localException)
    {
      while (true)
        Log.i("ViewConfigCompat", "Could not find method getScaledScrollFactor() on ViewConfiguration");
    }
  }

  private static float getLegacyScrollFactor(ViewConfiguration paramViewConfiguration, Context paramContext)
  {
    if ((Build.VERSION.SDK_INT >= 25) && (sGetScaledScrollFactorMethod != null));
    while (true)
    {
      float f;
      try
      {
        int i = ((Integer)sGetScaledScrollFactorMethod.invoke(paramViewConfiguration, new Object[0])).intValue();
        f = i;
        return f;
      }
      catch (Exception localException)
      {
        Log.i("ViewConfigCompat", "Could not find method getScaledScrollFactor() on ViewConfiguration");
      }
      TypedValue localTypedValue = new TypedValue();
      if (paramContext.getTheme().resolveAttribute(16842829, localTypedValue, true))
        f = localTypedValue.getDimension(paramContext.getResources().getDisplayMetrics());
      else
        f = 0.0F;
    }
  }

  public static float getScaledHorizontalScrollFactor(@NonNull ViewConfiguration paramViewConfiguration, @NonNull Context paramContext)
  {
    if (Build.VERSION.SDK_INT >= 26);
    for (float f = paramViewConfiguration.getScaledHorizontalScrollFactor(); ; f = getLegacyScrollFactor(paramViewConfiguration, paramContext))
      return f;
  }

  public static int getScaledHoverSlop(ViewConfiguration paramViewConfiguration)
  {
    if (Build.VERSION.SDK_INT >= 28);
    for (int i = paramViewConfiguration.getScaledHoverSlop(); ; i = paramViewConfiguration.getScaledTouchSlop() / 2)
      return i;
  }

  @Deprecated
  public static int getScaledPagingTouchSlop(ViewConfiguration paramViewConfiguration)
  {
    return paramViewConfiguration.getScaledPagingTouchSlop();
  }

  public static float getScaledVerticalScrollFactor(@NonNull ViewConfiguration paramViewConfiguration, @NonNull Context paramContext)
  {
    if (Build.VERSION.SDK_INT >= 26);
    for (float f = paramViewConfiguration.getScaledVerticalScrollFactor(); ; f = getLegacyScrollFactor(paramViewConfiguration, paramContext))
      return f;
  }

  @Deprecated
  public static boolean hasPermanentMenuKey(ViewConfiguration paramViewConfiguration)
  {
    return paramViewConfiguration.hasPermanentMenuKey();
  }

  public static boolean shouldShowMenuShortcutsWhenKeyboardPresent(ViewConfiguration paramViewConfiguration, @NonNull Context paramContext)
  {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 28)
      bool = paramViewConfiguration.shouldShowMenuShortcutsWhenKeyboardPresent();
    while (true)
    {
      return bool;
      Resources localResources = paramContext.getResources();
      int i = localResources.getIdentifier("config_showMenuShortcutsWhenKeyboardPresent", "bool", "android");
      if ((i != 0) && (localResources.getBoolean(i)))
        bool = true;
      else
        bool = false;
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.view.ViewConfigurationCompat
 * JD-Core Version:    0.6.2
 */