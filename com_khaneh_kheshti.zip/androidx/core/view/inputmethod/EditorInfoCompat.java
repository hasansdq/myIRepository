package androidx.core.view.inputmethod;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.inputmethod.EditorInfo;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public final class EditorInfoCompat
{
  private static final String CONTENT_MIME_TYPES_KEY = "androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES";
  private static final String[] EMPTY_STRING_ARRAY = new String[0];
  public static final int IME_FLAG_FORCE_ASCII = -2147483648;
  public static final int IME_FLAG_NO_PERSONALIZED_LEARNING = 16777216;

  @NonNull
  public static String[] getContentMimeTypes(EditorInfo paramEditorInfo)
  {
    String[] arrayOfString;
    if (Build.VERSION.SDK_INT >= 25)
    {
      arrayOfString = paramEditorInfo.contentMimeTypes;
      if (arrayOfString == null);
    }
    while (true)
    {
      return arrayOfString;
      arrayOfString = EMPTY_STRING_ARRAY;
      continue;
      if (paramEditorInfo.extras == null)
      {
        arrayOfString = EMPTY_STRING_ARRAY;
      }
      else
      {
        arrayOfString = paramEditorInfo.extras.getStringArray("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES");
        if (arrayOfString == null)
          arrayOfString = EMPTY_STRING_ARRAY;
      }
    }
  }

  public static void setContentMimeTypes(@NonNull EditorInfo paramEditorInfo, @Nullable String[] paramArrayOfString)
  {
    if (Build.VERSION.SDK_INT >= 25)
      paramEditorInfo.contentMimeTypes = paramArrayOfString;
    while (true)
    {
      return;
      if (paramEditorInfo.extras == null)
        paramEditorInfo.extras = new Bundle();
      paramEditorInfo.extras.putStringArray("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES", paramArrayOfString);
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.view.inputmethod.EditorInfoCompat
 * JD-Core Version:    0.6.2
 */