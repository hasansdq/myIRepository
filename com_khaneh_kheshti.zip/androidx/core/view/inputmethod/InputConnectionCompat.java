package androidx.core.view.inputmethod;

import android.content.ClipDescription;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.text.TextUtils;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputConnectionWrapper;
import android.view.inputmethod.InputContentInfo;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public final class InputConnectionCompat
{
  private static final String COMMIT_CONTENT_ACTION = "androidx.core.view.inputmethod.InputConnectionCompat.COMMIT_CONTENT";
  private static final String COMMIT_CONTENT_CONTENT_URI_KEY = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_URI";
  private static final String COMMIT_CONTENT_DESCRIPTION_KEY = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_DESCRIPTION";
  private static final String COMMIT_CONTENT_FLAGS_KEY = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_FLAGS";
  private static final String COMMIT_CONTENT_LINK_URI_KEY = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_LINK_URI";
  private static final String COMMIT_CONTENT_OPTS_KEY = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_OPTS";
  private static final String COMMIT_CONTENT_RESULT_RECEIVER = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_RESULT_RECEIVER";
  public static final int INPUT_CONTENT_GRANT_READ_URI_PERMISSION = 1;

  public static boolean commitContent(@NonNull InputConnection paramInputConnection, @NonNull EditorInfo paramEditorInfo, @NonNull InputContentInfoCompat paramInputContentInfoCompat, int paramInt, @Nullable Bundle paramBundle)
  {
    boolean bool = false;
    ClipDescription localClipDescription = paramInputContentInfoCompat.getDescription();
    int i = 0;
    String[] arrayOfString = EditorInfoCompat.getContentMimeTypes(paramEditorInfo);
    int j = arrayOfString.length;
    int k = 0;
    if (k < j)
    {
      if (localClipDescription.hasMimeType(arrayOfString[k]))
        i = 1;
    }
    else
      if (i != 0)
        break label63;
    while (true)
    {
      return bool;
      k++;
      break;
      label63: if (Build.VERSION.SDK_INT >= 25)
      {
        bool = paramInputConnection.commitContent((InputContentInfo)paramInputContentInfoCompat.unwrap(), paramInt, paramBundle);
      }
      else
      {
        Bundle localBundle = new Bundle();
        localBundle.putParcelable("androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_URI", paramInputContentInfoCompat.getContentUri());
        localBundle.putParcelable("androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_DESCRIPTION", paramInputContentInfoCompat.getDescription());
        localBundle.putParcelable("androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_LINK_URI", paramInputContentInfoCompat.getLinkUri());
        localBundle.putInt("androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_FLAGS", paramInt);
        localBundle.putParcelable("androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_OPTS", paramBundle);
        bool = paramInputConnection.performPrivateCommand("androidx.core.view.inputmethod.InputConnectionCompat.COMMIT_CONTENT", localBundle);
      }
    }
  }

  @NonNull
  public static InputConnection createWrapper(@NonNull InputConnection paramInputConnection, @NonNull EditorInfo paramEditorInfo, @NonNull final OnCommitContentListener paramOnCommitContentListener)
  {
    if (paramInputConnection == null)
      throw new IllegalArgumentException("inputConnection must be non-null");
    if (paramEditorInfo == null)
      throw new IllegalArgumentException("editorInfo must be non-null");
    if (paramOnCommitContentListener == null)
      throw new IllegalArgumentException("onCommitContentListener must be non-null");
    if (Build.VERSION.SDK_INT >= 25)
      paramInputConnection = new InputConnectionWrapper(paramInputConnection, false)
      {
        public boolean commitContent(InputContentInfo paramAnonymousInputContentInfo, int paramAnonymousInt, Bundle paramAnonymousBundle)
        {
          if (paramOnCommitContentListener.onCommitContent(InputContentInfoCompat.wrap(paramAnonymousInputContentInfo), paramAnonymousInt, paramAnonymousBundle));
          for (boolean bool = true; ; bool = super.commitContent(paramAnonymousInputContentInfo, paramAnonymousInt, paramAnonymousBundle))
            return bool;
        }
      };
    while (true)
    {
      return paramInputConnection;
      if (EditorInfoCompat.getContentMimeTypes(paramEditorInfo).length != 0)
        paramInputConnection = new InputConnectionWrapper(paramInputConnection, false)
        {
          public boolean performPrivateCommand(String paramAnonymousString, Bundle paramAnonymousBundle)
          {
            if (InputConnectionCompat.handlePerformPrivateCommand(paramAnonymousString, paramAnonymousBundle, paramOnCommitContentListener));
            for (boolean bool = true; ; bool = super.performPrivateCommand(paramAnonymousString, paramAnonymousBundle))
              return bool;
          }
        };
    }
  }

  static boolean handlePerformPrivateCommand(@Nullable String paramString, @NonNull Bundle paramBundle, @NonNull OnCommitContentListener paramOnCommitContentListener)
  {
    int i = 1;
    boolean bool1 = false;
    if (!TextUtils.equals("androidx.core.view.inputmethod.InputConnectionCompat.COMMIT_CONTENT", paramString));
    while (true)
    {
      return bool1;
      if (paramBundle == null)
        continue;
      ResultReceiver localResultReceiver = null;
      label167: 
      try
      {
        localResultReceiver = (ResultReceiver)paramBundle.getParcelable("androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_RESULT_RECEIVER");
        Uri localUri1 = (Uri)paramBundle.getParcelable("androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_URI");
        ClipDescription localClipDescription = (ClipDescription)paramBundle.getParcelable("androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_DESCRIPTION");
        Uri localUri2 = (Uri)paramBundle.getParcelable("androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_LINK_URI");
        int j = paramBundle.getInt("androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_FLAGS");
        Bundle localBundle = (Bundle)paramBundle.getParcelable("androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_OPTS");
        boolean bool2 = paramOnCommitContentListener.onCommitContent(new InputContentInfoCompat(localUri1, localClipDescription, localUri2), j, localBundle);
        if (localResultReceiver != null)
        {
          if (bool2)
          {
            k = i;
            localResultReceiver.send(k, null);
          }
        }
        else
        {
          bool1 = bool2;
          continue;
        }
        int k = 0;
      }
      finally
      {
        if (localResultReceiver != null)
        {
          if (0 == 0)
            break label167;
          localResultReceiver.send(i, null);
        }
      }
    }
  }

  public static abstract interface OnCommitContentListener
  {
    public abstract boolean onCommitContent(InputContentInfoCompat paramInputContentInfoCompat, int paramInt, Bundle paramBundle);
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.view.inputmethod.InputConnectionCompat
 * JD-Core Version:    0.6.2
 */