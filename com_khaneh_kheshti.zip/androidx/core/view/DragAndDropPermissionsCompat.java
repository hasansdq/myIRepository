package androidx.core.view;

import android.app.Activity;
import android.os.Build.VERSION;
import android.view.DragAndDropPermissions;
import android.view.DragEvent;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

public final class DragAndDropPermissionsCompat
{
  private Object mDragAndDropPermissions;

  private DragAndDropPermissionsCompat(Object paramObject)
  {
    this.mDragAndDropPermissions = paramObject;
  }

  @Nullable
  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public static DragAndDropPermissionsCompat request(Activity paramActivity, DragEvent paramDragEvent)
  {
    DragAndDropPermissions localDragAndDropPermissions;
    if (Build.VERSION.SDK_INT >= 24)
    {
      localDragAndDropPermissions = paramActivity.requestDragAndDropPermissions(paramDragEvent);
      if (localDragAndDropPermissions == null);
    }
    for (DragAndDropPermissionsCompat localDragAndDropPermissionsCompat = new DragAndDropPermissionsCompat(localDragAndDropPermissions); ; localDragAndDropPermissionsCompat = null)
      return localDragAndDropPermissionsCompat;
  }

  public void release()
  {
    if (Build.VERSION.SDK_INT >= 24)
      ((DragAndDropPermissions)this.mDragAndDropPermissions).release();
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.view.DragAndDropPermissionsCompat
 * JD-Core Version:    0.6.2
 */