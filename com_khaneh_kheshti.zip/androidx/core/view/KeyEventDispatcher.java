package androidx.core.view;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface.OnKeyListener;
import android.os.Build.VERSION;
import android.view.KeyEvent;
import android.view.KeyEvent.DispatcherState;
import android.view.View;
import android.view.Window;
import android.view.Window.Callback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public class KeyEventDispatcher
{
  private static boolean sActionBarFieldsFetched = false;
  private static Method sActionBarOnMenuKeyMethod = null;
  private static boolean sDialogFieldsFetched = false;
  private static Field sDialogKeyListenerField = null;

  private static boolean actionBarOnMenuKeyEventPre28(ActionBar paramActionBar, KeyEvent paramKeyEvent)
  {
    if (!sActionBarFieldsFetched);
    try
    {
      sActionBarOnMenuKeyMethod = paramActionBar.getClass().getMethod("onMenuKeyEvent", new Class[] { KeyEvent.class });
      label27: sActionBarFieldsFetched = true;
      if (sActionBarOnMenuKeyMethod != null);
      try
      {
        boolean bool2 = ((Boolean)sActionBarOnMenuKeyMethod.invoke(paramActionBar, new Object[] { paramKeyEvent })).booleanValue();
        bool1 = bool2;
        return bool1;
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        while (true)
          boolean bool1 = false;
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        label67: break label67;
      }
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      break label27;
    }
  }

  private static boolean activitySuperDispatchKeyEventPre28(Activity paramActivity, KeyEvent paramKeyEvent)
  {
    boolean bool = true;
    paramActivity.onUserInteraction();
    Window localWindow = paramActivity.getWindow();
    if (localWindow.hasFeature(8))
    {
      ActionBar localActionBar = paramActivity.getActionBar();
      if ((paramKeyEvent.getKeyCode() != 82) || (localActionBar == null) || (!actionBarOnMenuKeyEventPre28(localActionBar, paramKeyEvent)));
    }
    View localView;
    do
    {
      do
        return bool;
      while (localWindow.superDispatchKeyEvent(paramKeyEvent));
      localView = localWindow.getDecorView();
    }
    while (ViewCompat.dispatchUnhandledKeyEventBeforeCallback(localView, paramKeyEvent));
    if (localView != null);
    for (KeyEvent.DispatcherState localDispatcherState = localView.getKeyDispatcherState(); ; localDispatcherState = null)
    {
      bool = paramKeyEvent.dispatch(paramActivity, localDispatcherState, paramActivity);
      break;
    }
  }

  private static boolean dialogSuperDispatchKeyEventPre28(Dialog paramDialog, KeyEvent paramKeyEvent)
  {
    boolean bool = true;
    DialogInterface.OnKeyListener localOnKeyListener = getDialogKeyListenerPre28(paramDialog);
    if ((localOnKeyListener != null) && (localOnKeyListener.onKey(paramDialog, paramKeyEvent.getKeyCode(), paramKeyEvent)));
    View localView;
    do
    {
      Window localWindow;
      do
      {
        return bool;
        localWindow = paramDialog.getWindow();
      }
      while (localWindow.superDispatchKeyEvent(paramKeyEvent));
      localView = localWindow.getDecorView();
    }
    while (ViewCompat.dispatchUnhandledKeyEventBeforeCallback(localView, paramKeyEvent));
    if (localView != null);
    for (KeyEvent.DispatcherState localDispatcherState = localView.getKeyDispatcherState(); ; localDispatcherState = null)
    {
      bool = paramKeyEvent.dispatch(paramDialog, localDispatcherState, paramDialog);
      break;
    }
  }

  public static boolean dispatchBeforeHierarchy(@NonNull View paramView, @NonNull KeyEvent paramKeyEvent)
  {
    return ViewCompat.dispatchUnhandledKeyEventBeforeHierarchy(paramView, paramKeyEvent);
  }

  public static boolean dispatchKeyEvent(@NonNull Component paramComponent, @Nullable View paramView, @Nullable Window.Callback paramCallback, @NonNull KeyEvent paramKeyEvent)
  {
    boolean bool = false;
    if (paramComponent == null);
    while (true)
    {
      return bool;
      if (Build.VERSION.SDK_INT >= 28)
        bool = paramComponent.superDispatchKeyEvent(paramKeyEvent);
      else if ((paramCallback instanceof Activity))
        bool = activitySuperDispatchKeyEventPre28((Activity)paramCallback, paramKeyEvent);
      else if ((paramCallback instanceof Dialog))
        bool = dialogSuperDispatchKeyEventPre28((Dialog)paramCallback, paramKeyEvent);
      else if (((paramView != null) && (ViewCompat.dispatchUnhandledKeyEventBeforeCallback(paramView, paramKeyEvent))) || (paramComponent.superDispatchKeyEvent(paramKeyEvent)))
        bool = true;
    }
  }

  private static DialogInterface.OnKeyListener getDialogKeyListenerPre28(Dialog paramDialog)
  {
    if (!sDialogFieldsFetched);
    try
    {
      sDialogKeyListenerField = Dialog.class.getDeclaredField("mOnKeyListener");
      sDialogKeyListenerField.setAccessible(true);
      label23: sDialogFieldsFetched = true;
      if (sDialogKeyListenerField != null);
      while (true)
      {
        try
        {
          localOnKeyListener = (DialogInterface.OnKeyListener)sDialogKeyListenerField.get(paramDialog);
          return localOnKeyListener;
        }
        catch (IllegalAccessException localIllegalAccessException)
        {
        }
        DialogInterface.OnKeyListener localOnKeyListener = null;
      }
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      break label23;
    }
  }

  public static abstract interface Component
  {
    public abstract boolean superDispatchKeyEvent(KeyEvent paramKeyEvent);
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.view.KeyEventDispatcher
 * JD-Core Version:    0.6.2
 */