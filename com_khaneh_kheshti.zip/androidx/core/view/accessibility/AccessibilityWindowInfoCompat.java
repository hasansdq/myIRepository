package androidx.core.view.accessibility;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.view.accessibility.AccessibilityWindowInfo;

public class AccessibilityWindowInfoCompat
{
  public static final int TYPE_ACCESSIBILITY_OVERLAY = 4;
  public static final int TYPE_APPLICATION = 1;
  public static final int TYPE_INPUT_METHOD = 2;
  public static final int TYPE_SPLIT_SCREEN_DIVIDER = 5;
  public static final int TYPE_SYSTEM = 3;
  private static final int UNDEFINED = -1;
  private Object mInfo;

  private AccessibilityWindowInfoCompat(Object paramObject)
  {
    this.mInfo = paramObject;
  }

  public static AccessibilityWindowInfoCompat obtain()
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (AccessibilityWindowInfoCompat localAccessibilityWindowInfoCompat = wrapNonNullInstance(AccessibilityWindowInfo.obtain()); ; localAccessibilityWindowInfoCompat = null)
      return localAccessibilityWindowInfoCompat;
  }

  public static AccessibilityWindowInfoCompat obtain(AccessibilityWindowInfoCompat paramAccessibilityWindowInfoCompat)
  {
    AccessibilityWindowInfoCompat localAccessibilityWindowInfoCompat = null;
    if ((Build.VERSION.SDK_INT < 21) || (paramAccessibilityWindowInfoCompat == null));
    while (true)
    {
      return localAccessibilityWindowInfoCompat;
      localAccessibilityWindowInfoCompat = wrapNonNullInstance(AccessibilityWindowInfo.obtain((AccessibilityWindowInfo)paramAccessibilityWindowInfoCompat.mInfo));
    }
  }

  private static String typeToString(int paramInt)
  {
    String str;
    switch (paramInt)
    {
    default:
      str = "<UNKNOWN>";
    case 1:
    case 2:
    case 3:
    case 4:
    }
    while (true)
    {
      return str;
      str = "TYPE_APPLICATION";
      continue;
      str = "TYPE_INPUT_METHOD";
      continue;
      str = "TYPE_SYSTEM";
      continue;
      str = "TYPE_ACCESSIBILITY_OVERLAY";
    }
  }

  static AccessibilityWindowInfoCompat wrapNonNullInstance(Object paramObject)
  {
    if (paramObject != null);
    for (AccessibilityWindowInfoCompat localAccessibilityWindowInfoCompat = new AccessibilityWindowInfoCompat(paramObject); ; localAccessibilityWindowInfoCompat = null)
      return localAccessibilityWindowInfoCompat;
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = true;
    if (this == paramObject);
    while (true)
    {
      return bool;
      if (paramObject == null)
      {
        bool = false;
      }
      else if (getClass() != paramObject.getClass())
      {
        bool = false;
      }
      else
      {
        AccessibilityWindowInfoCompat localAccessibilityWindowInfoCompat = (AccessibilityWindowInfoCompat)paramObject;
        if (this.mInfo == null)
        {
          if (localAccessibilityWindowInfoCompat.mInfo != null)
            bool = false;
        }
        else if (!this.mInfo.equals(localAccessibilityWindowInfoCompat.mInfo))
          bool = false;
      }
    }
  }

  public AccessibilityNodeInfoCompat getAnchor()
  {
    if (Build.VERSION.SDK_INT >= 24);
    for (AccessibilityNodeInfoCompat localAccessibilityNodeInfoCompat = AccessibilityNodeInfoCompat.wrapNonNullInstance(((AccessibilityWindowInfo)this.mInfo).getAnchor()); ; localAccessibilityNodeInfoCompat = null)
      return localAccessibilityNodeInfoCompat;
  }

  public void getBoundsInScreen(Rect paramRect)
  {
    if (Build.VERSION.SDK_INT >= 21)
      ((AccessibilityWindowInfo)this.mInfo).getBoundsInScreen(paramRect);
  }

  public AccessibilityWindowInfoCompat getChild(int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (AccessibilityWindowInfoCompat localAccessibilityWindowInfoCompat = wrapNonNullInstance(((AccessibilityWindowInfo)this.mInfo).getChild(paramInt)); ; localAccessibilityWindowInfoCompat = null)
      return localAccessibilityWindowInfoCompat;
  }

  public int getChildCount()
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (int i = ((AccessibilityWindowInfo)this.mInfo).getChildCount(); ; i = 0)
      return i;
  }

  public int getId()
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (int i = ((AccessibilityWindowInfo)this.mInfo).getId(); ; i = -1)
      return i;
  }

  public int getLayer()
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (int i = ((AccessibilityWindowInfo)this.mInfo).getLayer(); ; i = -1)
      return i;
  }

  public AccessibilityWindowInfoCompat getParent()
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (AccessibilityWindowInfoCompat localAccessibilityWindowInfoCompat = wrapNonNullInstance(((AccessibilityWindowInfo)this.mInfo).getParent()); ; localAccessibilityWindowInfoCompat = null)
      return localAccessibilityWindowInfoCompat;
  }

  public AccessibilityNodeInfoCompat getRoot()
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (AccessibilityNodeInfoCompat localAccessibilityNodeInfoCompat = AccessibilityNodeInfoCompat.wrapNonNullInstance(((AccessibilityWindowInfo)this.mInfo).getRoot()); ; localAccessibilityNodeInfoCompat = null)
      return localAccessibilityNodeInfoCompat;
  }

  public CharSequence getTitle()
  {
    if (Build.VERSION.SDK_INT >= 24);
    for (CharSequence localCharSequence = ((AccessibilityWindowInfo)this.mInfo).getTitle(); ; localCharSequence = null)
      return localCharSequence;
  }

  public int getType()
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (int i = ((AccessibilityWindowInfo)this.mInfo).getType(); ; i = -1)
      return i;
  }

  public int hashCode()
  {
    if (this.mInfo == null);
    for (int i = 0; ; i = this.mInfo.hashCode())
      return i;
  }

  public boolean isAccessibilityFocused()
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (boolean bool = ((AccessibilityWindowInfo)this.mInfo).isAccessibilityFocused(); ; bool = true)
      return bool;
  }

  public boolean isActive()
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (boolean bool = ((AccessibilityWindowInfo)this.mInfo).isActive(); ; bool = true)
      return bool;
  }

  public boolean isFocused()
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (boolean bool = ((AccessibilityWindowInfo)this.mInfo).isFocused(); ; bool = true)
      return bool;
  }

  public void recycle()
  {
    if (Build.VERSION.SDK_INT >= 21)
      ((AccessibilityWindowInfo)this.mInfo).recycle();
  }

  public String toString()
  {
    boolean bool1 = true;
    StringBuilder localStringBuilder1 = new StringBuilder();
    Rect localRect = new Rect();
    getBoundsInScreen(localRect);
    localStringBuilder1.append("AccessibilityWindowInfo[");
    localStringBuilder1.append("id=").append(getId());
    localStringBuilder1.append(", type=").append(typeToString(getType()));
    localStringBuilder1.append(", layer=").append(getLayer());
    localStringBuilder1.append(", bounds=").append(localRect);
    localStringBuilder1.append(", focused=").append(isFocused());
    localStringBuilder1.append(", active=").append(isActive());
    StringBuilder localStringBuilder2 = localStringBuilder1.append(", hasParent=");
    boolean bool2;
    StringBuilder localStringBuilder3;
    if (getParent() != null)
    {
      bool2 = bool1;
      localStringBuilder2.append(bool2);
      localStringBuilder3 = localStringBuilder1.append(", hasChildren=");
      if (getChildCount() <= 0)
        break label180;
    }
    while (true)
    {
      localStringBuilder3.append(bool1);
      localStringBuilder1.append(']');
      return localStringBuilder1.toString();
      bool2 = false;
      break;
      label180: bool1 = false;
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.view.accessibility.AccessibilityWindowInfoCompat
 * JD-Core Version:    0.6.2
 */