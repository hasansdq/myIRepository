package androidx.core.view;

import android.os.Build.VERSION;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.annotation.NonNull;
import androidx.core.R.id;

public final class ViewGroupCompat
{
  public static final int LAYOUT_MODE_CLIP_BOUNDS = 0;
  public static final int LAYOUT_MODE_OPTICAL_BOUNDS = 1;

  public static int getLayoutMode(@NonNull ViewGroup paramViewGroup)
  {
    if (Build.VERSION.SDK_INT >= 18);
    for (int i = paramViewGroup.getLayoutMode(); ; i = 0)
      return i;
  }

  public static int getNestedScrollAxes(@NonNull ViewGroup paramViewGroup)
  {
    int i;
    if (Build.VERSION.SDK_INT >= 21)
      i = paramViewGroup.getNestedScrollAxes();
    while (true)
    {
      return i;
      if ((paramViewGroup instanceof NestedScrollingParent))
        i = ((NestedScrollingParent)paramViewGroup).getNestedScrollAxes();
      else
        i = 0;
    }
  }

  public static boolean isTransitionGroup(@NonNull ViewGroup paramViewGroup)
  {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 21)
      bool = paramViewGroup.isTransitionGroup();
    while (true)
    {
      return bool;
      Boolean localBoolean = (Boolean)paramViewGroup.getTag(R.id.tag_transition_group);
      if (((localBoolean != null) && (localBoolean.booleanValue())) || (paramViewGroup.getBackground() != null) || (ViewCompat.getTransitionName(paramViewGroup) != null))
        bool = true;
      else
        bool = false;
    }
  }

  @Deprecated
  public static boolean onRequestSendAccessibilityEvent(ViewGroup paramViewGroup, View paramView, AccessibilityEvent paramAccessibilityEvent)
  {
    return paramViewGroup.onRequestSendAccessibilityEvent(paramView, paramAccessibilityEvent);
  }

  public static void setLayoutMode(@NonNull ViewGroup paramViewGroup, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 18)
      paramViewGroup.setLayoutMode(paramInt);
  }

  @Deprecated
  public static void setMotionEventSplittingEnabled(ViewGroup paramViewGroup, boolean paramBoolean)
  {
    paramViewGroup.setMotionEventSplittingEnabled(paramBoolean);
  }

  public static void setTransitionGroup(@NonNull ViewGroup paramViewGroup, boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT >= 21)
      paramViewGroup.setTransitionGroup(paramBoolean);
    while (true)
    {
      return;
      paramViewGroup.setTag(R.id.tag_transition_group, Boolean.valueOf(paramBoolean));
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.view.ViewGroupCompat
 * JD-Core Version:    0.6.2
 */