package androidx.core.view.animation;

import android.graphics.Path;
import android.os.Build.VERSION;
import android.view.animation.Interpolator;
import android.view.animation.PathInterpolator;

public final class PathInterpolatorCompat
{
  public static Interpolator create(float paramFloat1, float paramFloat2)
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (Object localObject = new PathInterpolator(paramFloat1, paramFloat2); ; localObject = new PathInterpolatorApi14(paramFloat1, paramFloat2))
      return localObject;
  }

  public static Interpolator create(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (Object localObject = new PathInterpolator(paramFloat1, paramFloat2, paramFloat3, paramFloat4); ; localObject = new PathInterpolatorApi14(paramFloat1, paramFloat2, paramFloat3, paramFloat4))
      return localObject;
  }

  public static Interpolator create(Path paramPath)
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (Object localObject = new PathInterpolator(paramPath); ; localObject = new PathInterpolatorApi14(paramPath))
      return localObject;
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.view.animation.PathInterpolatorCompat
 * JD-Core Version:    0.6.2
 */