package androidx.core.view;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.view.DisplayCutout;
import java.util.List;

public final class DisplayCutoutCompat
{
  private final Object mDisplayCutout;

  public DisplayCutoutCompat(Rect paramRect, List<Rect> paramList)
  {
  }

  private DisplayCutoutCompat(Object paramObject)
  {
    this.mDisplayCutout = paramObject;
  }

  static DisplayCutoutCompat wrap(Object paramObject)
  {
    if (paramObject == null);
    for (DisplayCutoutCompat localDisplayCutoutCompat = null; ; localDisplayCutoutCompat = new DisplayCutoutCompat(paramObject))
      return localDisplayCutoutCompat;
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = true;
    if (this == paramObject);
    while (true)
    {
      return bool;
      if ((paramObject == null) || (getClass() != paramObject.getClass()))
      {
        bool = false;
      }
      else
      {
        DisplayCutoutCompat localDisplayCutoutCompat = (DisplayCutoutCompat)paramObject;
        if (this.mDisplayCutout == null)
        {
          if (localDisplayCutoutCompat.mDisplayCutout != null)
            bool = false;
        }
        else
          bool = this.mDisplayCutout.equals(localDisplayCutoutCompat.mDisplayCutout);
      }
    }
  }

  public List<Rect> getBoundingRects()
  {
    if (Build.VERSION.SDK_INT >= 28);
    for (List localList = ((DisplayCutout)this.mDisplayCutout).getBoundingRects(); ; localList = null)
      return localList;
  }

  public int getSafeInsetBottom()
  {
    if (Build.VERSION.SDK_INT >= 28);
    for (int i = ((DisplayCutout)this.mDisplayCutout).getSafeInsetBottom(); ; i = 0)
      return i;
  }

  public int getSafeInsetLeft()
  {
    if (Build.VERSION.SDK_INT >= 28);
    for (int i = ((DisplayCutout)this.mDisplayCutout).getSafeInsetLeft(); ; i = 0)
      return i;
  }

  public int getSafeInsetRight()
  {
    if (Build.VERSION.SDK_INT >= 28);
    for (int i = ((DisplayCutout)this.mDisplayCutout).getSafeInsetRight(); ; i = 0)
      return i;
  }

  public int getSafeInsetTop()
  {
    if (Build.VERSION.SDK_INT >= 28);
    for (int i = ((DisplayCutout)this.mDisplayCutout).getSafeInsetTop(); ; i = 0)
      return i;
  }

  public int hashCode()
  {
    if (this.mDisplayCutout == null);
    for (int i = 0; ; i = this.mDisplayCutout.hashCode())
      return i;
  }

  public String toString()
  {
    return "DisplayCutoutCompat{" + this.mDisplayCutout + "}";
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.view.DisplayCutoutCompat
 * JD-Core Version:    0.6.2
 */