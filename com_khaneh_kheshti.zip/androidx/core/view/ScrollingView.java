package androidx.core.view;

public abstract interface ScrollingView
{
  public abstract int computeHorizontalScrollExtent();

  public abstract int computeHorizontalScrollOffset();

  public abstract int computeHorizontalScrollRange();

  public abstract int computeVerticalScrollExtent();

  public abstract int computeVerticalScrollOffset();

  public abstract int computeVerticalScrollRange();
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.view.ScrollingView
 * JD-Core Version:    0.6.2
 */