package androidx.core.view;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.view.WindowInsets;
import androidx.annotation.Nullable;

public class WindowInsetsCompat
{
  private final Object mInsets;

  public WindowInsetsCompat(WindowInsetsCompat paramWindowInsetsCompat)
  {
    if (Build.VERSION.SDK_INT >= 20)
      if (paramWindowInsetsCompat != null);
    for (this.mInsets = localWindowInsets; ; this.mInsets = null)
    {
      return;
      localWindowInsets = new WindowInsets((WindowInsets)paramWindowInsetsCompat.mInsets);
      break;
    }
  }

  private WindowInsetsCompat(Object paramObject)
  {
    this.mInsets = paramObject;
  }

  static Object unwrap(WindowInsetsCompat paramWindowInsetsCompat)
  {
    if (paramWindowInsetsCompat == null);
    for (Object localObject = null; ; localObject = paramWindowInsetsCompat.mInsets)
      return localObject;
  }

  static WindowInsetsCompat wrap(Object paramObject)
  {
    if (paramObject == null);
    for (WindowInsetsCompat localWindowInsetsCompat = null; ; localWindowInsetsCompat = new WindowInsetsCompat(paramObject))
      return localWindowInsetsCompat;
  }

  public WindowInsetsCompat consumeDisplayCutout()
  {
    if (Build.VERSION.SDK_INT >= 28)
      this = new WindowInsetsCompat(((WindowInsets)this.mInsets).consumeDisplayCutout());
    return this;
  }

  public WindowInsetsCompat consumeStableInsets()
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (WindowInsetsCompat localWindowInsetsCompat = new WindowInsetsCompat(((WindowInsets)this.mInsets).consumeStableInsets()); ; localWindowInsetsCompat = null)
      return localWindowInsetsCompat;
  }

  public WindowInsetsCompat consumeSystemWindowInsets()
  {
    if (Build.VERSION.SDK_INT >= 20);
    for (WindowInsetsCompat localWindowInsetsCompat = new WindowInsetsCompat(((WindowInsets)this.mInsets).consumeSystemWindowInsets()); ; localWindowInsetsCompat = null)
      return localWindowInsetsCompat;
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = true;
    if (this == paramObject);
    while (true)
    {
      return bool;
      if ((paramObject == null) || (getClass() != paramObject.getClass()))
      {
        bool = false;
      }
      else
      {
        WindowInsetsCompat localWindowInsetsCompat = (WindowInsetsCompat)paramObject;
        if (this.mInsets == null)
        {
          if (localWindowInsetsCompat.mInsets != null)
            bool = false;
        }
        else
          bool = this.mInsets.equals(localWindowInsetsCompat.mInsets);
      }
    }
  }

  @Nullable
  public DisplayCutoutCompat getDisplayCutout()
  {
    if (Build.VERSION.SDK_INT >= 28);
    for (DisplayCutoutCompat localDisplayCutoutCompat = DisplayCutoutCompat.wrap(((WindowInsets)this.mInsets).getDisplayCutout()); ; localDisplayCutoutCompat = null)
      return localDisplayCutoutCompat;
  }

  public int getStableInsetBottom()
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (int i = ((WindowInsets)this.mInsets).getStableInsetBottom(); ; i = 0)
      return i;
  }

  public int getStableInsetLeft()
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (int i = ((WindowInsets)this.mInsets).getStableInsetLeft(); ; i = 0)
      return i;
  }

  public int getStableInsetRight()
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (int i = ((WindowInsets)this.mInsets).getStableInsetRight(); ; i = 0)
      return i;
  }

  public int getStableInsetTop()
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (int i = ((WindowInsets)this.mInsets).getStableInsetTop(); ; i = 0)
      return i;
  }

  public int getSystemWindowInsetBottom()
  {
    if (Build.VERSION.SDK_INT >= 20);
    for (int i = ((WindowInsets)this.mInsets).getSystemWindowInsetBottom(); ; i = 0)
      return i;
  }

  public int getSystemWindowInsetLeft()
  {
    if (Build.VERSION.SDK_INT >= 20);
    for (int i = ((WindowInsets)this.mInsets).getSystemWindowInsetLeft(); ; i = 0)
      return i;
  }

  public int getSystemWindowInsetRight()
  {
    if (Build.VERSION.SDK_INT >= 20);
    for (int i = ((WindowInsets)this.mInsets).getSystemWindowInsetRight(); ; i = 0)
      return i;
  }

  public int getSystemWindowInsetTop()
  {
    if (Build.VERSION.SDK_INT >= 20);
    for (int i = ((WindowInsets)this.mInsets).getSystemWindowInsetTop(); ; i = 0)
      return i;
  }

  public boolean hasInsets()
  {
    if (Build.VERSION.SDK_INT >= 20);
    for (boolean bool = ((WindowInsets)this.mInsets).hasInsets(); ; bool = false)
      return bool;
  }

  public boolean hasStableInsets()
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (boolean bool = ((WindowInsets)this.mInsets).hasStableInsets(); ; bool = false)
      return bool;
  }

  public boolean hasSystemWindowInsets()
  {
    if (Build.VERSION.SDK_INT >= 20);
    for (boolean bool = ((WindowInsets)this.mInsets).hasSystemWindowInsets(); ; bool = false)
      return bool;
  }

  public int hashCode()
  {
    if (this.mInsets == null);
    for (int i = 0; ; i = this.mInsets.hashCode())
      return i;
  }

  public boolean isConsumed()
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (boolean bool = ((WindowInsets)this.mInsets).isConsumed(); ; bool = false)
      return bool;
  }

  public boolean isRound()
  {
    if (Build.VERSION.SDK_INT >= 20);
    for (boolean bool = ((WindowInsets)this.mInsets).isRound(); ; bool = false)
      return bool;
  }

  public WindowInsetsCompat replaceSystemWindowInsets(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (Build.VERSION.SDK_INT >= 20);
    for (WindowInsetsCompat localWindowInsetsCompat = new WindowInsetsCompat(((WindowInsets)this.mInsets).replaceSystemWindowInsets(paramInt1, paramInt2, paramInt3, paramInt4)); ; localWindowInsetsCompat = null)
      return localWindowInsetsCompat;
  }

  public WindowInsetsCompat replaceSystemWindowInsets(Rect paramRect)
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (WindowInsetsCompat localWindowInsetsCompat = new WindowInsetsCompat(((WindowInsets)this.mInsets).replaceSystemWindowInsets(paramRect)); ; localWindowInsetsCompat = null)
      return localWindowInsetsCompat;
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.view.WindowInsetsCompat
 * JD-Core Version:    0.6.2
 */