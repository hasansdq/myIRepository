package androidx.core.view;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.KeyEvent;
import android.view.PointerIcon;
import android.view.View;
import android.view.View.AccessibilityDelegate;
import android.view.View.DragShadowBuilder;
import android.view.View.OnApplyWindowInsetsListener;
import android.view.View.OnUnhandledKeyEventListener;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeProvider;
import androidx.annotation.FloatRange;
import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.Px;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.annotation.UiThread;
import androidx.collection.ArrayMap;
import androidx.core.R.id;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import androidx.core.view.accessibility.AccessibilityNodeProviderCompat;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class ViewCompat
{
  public static final int ACCESSIBILITY_LIVE_REGION_ASSERTIVE = 2;
  public static final int ACCESSIBILITY_LIVE_REGION_NONE = 0;
  public static final int ACCESSIBILITY_LIVE_REGION_POLITE = 1;
  public static final int IMPORTANT_FOR_ACCESSIBILITY_AUTO = 0;
  public static final int IMPORTANT_FOR_ACCESSIBILITY_NO = 2;
  public static final int IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS = 4;
  public static final int IMPORTANT_FOR_ACCESSIBILITY_YES = 1;

  @Deprecated
  public static final int LAYER_TYPE_HARDWARE = 2;

  @Deprecated
  public static final int LAYER_TYPE_NONE = 0;

  @Deprecated
  public static final int LAYER_TYPE_SOFTWARE = 1;
  public static final int LAYOUT_DIRECTION_INHERIT = 2;
  public static final int LAYOUT_DIRECTION_LOCALE = 3;
  public static final int LAYOUT_DIRECTION_LTR = 0;
  public static final int LAYOUT_DIRECTION_RTL = 1;

  @Deprecated
  public static final int MEASURED_HEIGHT_STATE_SHIFT = 16;

  @Deprecated
  public static final int MEASURED_SIZE_MASK = 16777215;

  @Deprecated
  public static final int MEASURED_STATE_MASK = -16777216;

  @Deprecated
  public static final int MEASURED_STATE_TOO_SMALL = 16777216;

  @Deprecated
  public static final int OVER_SCROLL_ALWAYS = 0;

  @Deprecated
  public static final int OVER_SCROLL_IF_CONTENT_SCROLLS = 1;

  @Deprecated
  public static final int OVER_SCROLL_NEVER = 2;
  public static final int SCROLL_AXIS_HORIZONTAL = 1;
  public static final int SCROLL_AXIS_NONE = 0;
  public static final int SCROLL_AXIS_VERTICAL = 2;
  public static final int SCROLL_INDICATOR_BOTTOM = 2;
  public static final int SCROLL_INDICATOR_END = 32;
  public static final int SCROLL_INDICATOR_LEFT = 4;
  public static final int SCROLL_INDICATOR_RIGHT = 8;
  public static final int SCROLL_INDICATOR_START = 16;
  public static final int SCROLL_INDICATOR_TOP = 1;
  private static final String TAG = "ViewCompat";
  public static final int TYPE_NON_TOUCH = 1;
  public static final int TYPE_TOUCH;
  private static boolean sAccessibilityDelegateCheckFailed = false;
  private static Field sAccessibilityDelegateField;
  private static Method sChildrenDrawingOrderMethod;
  private static Method sDispatchFinishTemporaryDetach;
  private static Method sDispatchStartTemporaryDetach;
  private static Field sMinHeightField;
  private static boolean sMinHeightFieldFetched;
  private static Field sMinWidthField;
  private static boolean sMinWidthFieldFetched;
  private static final AtomicInteger sNextGeneratedId = new AtomicInteger(1);
  private static boolean sTempDetachBound;
  private static ThreadLocal<Rect> sThreadLocalRect;
  private static WeakHashMap<View, String> sTransitionNameMap;
  private static WeakHashMap<View, ViewPropertyAnimatorCompat> sViewPropertyAnimatorMap = null;

  public static void addKeyboardNavigationClusters(@NonNull View paramView, @NonNull Collection<View> paramCollection, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 26)
      paramView.addKeyboardNavigationClusters(paramCollection, paramInt);
  }

  public static void addOnUnhandledKeyEventListener(@NonNull View paramView, @NonNull OnUnhandledKeyEventListenerCompat paramOnUnhandledKeyEventListenerCompat)
  {
    if (Build.VERSION.SDK_INT >= 28)
    {
      Object localObject = (Map)paramView.getTag(R.id.tag_unhandled_key_listeners);
      if (localObject == null)
      {
        localObject = new ArrayMap();
        paramView.setTag(R.id.tag_unhandled_key_listeners, localObject);
      }
      OnUnhandledKeyEventListenerWrapper localOnUnhandledKeyEventListenerWrapper = new OnUnhandledKeyEventListenerWrapper(paramOnUnhandledKeyEventListenerCompat);
      ((Map)localObject).put(paramOnUnhandledKeyEventListenerCompat, localOnUnhandledKeyEventListenerWrapper);
      paramView.addOnUnhandledKeyEventListener(localOnUnhandledKeyEventListenerWrapper);
    }
    while (true)
    {
      return;
      ArrayList localArrayList = (ArrayList)paramView.getTag(R.id.tag_unhandled_key_listeners);
      if (localArrayList == null)
      {
        localArrayList = new ArrayList();
        paramView.setTag(R.id.tag_unhandled_key_listeners, localArrayList);
      }
      localArrayList.add(paramOnUnhandledKeyEventListenerCompat);
      if (localArrayList.size() == 1)
        UnhandledKeyEventManager.registerListeningView(paramView);
    }
  }

  @NonNull
  public static ViewPropertyAnimatorCompat animate(@NonNull View paramView)
  {
    if (sViewPropertyAnimatorMap == null)
      sViewPropertyAnimatorMap = new WeakHashMap();
    ViewPropertyAnimatorCompat localViewPropertyAnimatorCompat = (ViewPropertyAnimatorCompat)sViewPropertyAnimatorMap.get(paramView);
    if (localViewPropertyAnimatorCompat == null)
    {
      localViewPropertyAnimatorCompat = new ViewPropertyAnimatorCompat(paramView);
      sViewPropertyAnimatorMap.put(paramView, localViewPropertyAnimatorCompat);
    }
    return localViewPropertyAnimatorCompat;
  }

  private static void bindTempDetach()
  {
    try
    {
      sDispatchStartTemporaryDetach = View.class.getDeclaredMethod("dispatchStartTemporaryDetach", new Class[0]);
      sDispatchFinishTemporaryDetach = View.class.getDeclaredMethod("dispatchFinishTemporaryDetach", new Class[0]);
      sTempDetachBound = true;
      return;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      while (true)
        Log.e("ViewCompat", "Couldn't find method", localNoSuchMethodException);
    }
  }

  @Deprecated
  public static boolean canScrollHorizontally(View paramView, int paramInt)
  {
    return paramView.canScrollHorizontally(paramInt);
  }

  @Deprecated
  public static boolean canScrollVertically(View paramView, int paramInt)
  {
    return paramView.canScrollVertically(paramInt);
  }

  public static void cancelDragAndDrop(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 24)
      paramView.cancelDragAndDrop();
  }

  @Deprecated
  public static int combineMeasuredStates(int paramInt1, int paramInt2)
  {
    return View.combineMeasuredStates(paramInt1, paramInt2);
  }

  private static void compatOffsetLeftAndRight(View paramView, int paramInt)
  {
    paramView.offsetLeftAndRight(paramInt);
    if (paramView.getVisibility() == 0)
    {
      tickleInvalidationFlag(paramView);
      ViewParent localViewParent = paramView.getParent();
      if ((localViewParent instanceof View))
        tickleInvalidationFlag((View)localViewParent);
    }
  }

  private static void compatOffsetTopAndBottom(View paramView, int paramInt)
  {
    paramView.offsetTopAndBottom(paramInt);
    if (paramView.getVisibility() == 0)
    {
      tickleInvalidationFlag(paramView);
      ViewParent localViewParent = paramView.getParent();
      if ((localViewParent instanceof View))
        tickleInvalidationFlag((View)localViewParent);
    }
  }

  public static WindowInsetsCompat dispatchApplyWindowInsets(@NonNull View paramView, WindowInsetsCompat paramWindowInsetsCompat)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      WindowInsets localWindowInsets1 = (WindowInsets)WindowInsetsCompat.unwrap(paramWindowInsetsCompat);
      WindowInsets localWindowInsets2 = paramView.dispatchApplyWindowInsets(localWindowInsets1);
      if (localWindowInsets2 != localWindowInsets1)
        localWindowInsets1 = new WindowInsets(localWindowInsets2);
      paramWindowInsetsCompat = WindowInsetsCompat.wrap(localWindowInsets1);
    }
    return paramWindowInsetsCompat;
  }

  public static void dispatchFinishTemporaryDetach(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 24)
      paramView.dispatchFinishTemporaryDetach();
    while (true)
    {
      return;
      if (!sTempDetachBound)
        bindTempDetach();
      if (sDispatchFinishTemporaryDetach != null)
        try
        {
          sDispatchFinishTemporaryDetach.invoke(paramView, new Object[0]);
        }
        catch (Exception localException)
        {
          Log.d("ViewCompat", "Error calling dispatchFinishTemporaryDetach", localException);
        }
      else
        paramView.onFinishTemporaryDetach();
    }
  }

  public static boolean dispatchNestedFling(@NonNull View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean)
  {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 21)
      bool = paramView.dispatchNestedFling(paramFloat1, paramFloat2, paramBoolean);
    while (true)
    {
      return bool;
      if ((paramView instanceof NestedScrollingChild))
        bool = ((NestedScrollingChild)paramView).dispatchNestedFling(paramFloat1, paramFloat2, paramBoolean);
      else
        bool = false;
    }
  }

  public static boolean dispatchNestedPreFling(@NonNull View paramView, float paramFloat1, float paramFloat2)
  {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 21)
      bool = paramView.dispatchNestedPreFling(paramFloat1, paramFloat2);
    while (true)
    {
      return bool;
      if ((paramView instanceof NestedScrollingChild))
        bool = ((NestedScrollingChild)paramView).dispatchNestedPreFling(paramFloat1, paramFloat2);
      else
        bool = false;
    }
  }

  public static boolean dispatchNestedPreScroll(@NonNull View paramView, int paramInt1, int paramInt2, @Nullable int[] paramArrayOfInt1, @Nullable int[] paramArrayOfInt2)
  {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 21)
      bool = paramView.dispatchNestedPreScroll(paramInt1, paramInt2, paramArrayOfInt1, paramArrayOfInt2);
    while (true)
    {
      return bool;
      if ((paramView instanceof NestedScrollingChild))
        bool = ((NestedScrollingChild)paramView).dispatchNestedPreScroll(paramInt1, paramInt2, paramArrayOfInt1, paramArrayOfInt2);
      else
        bool = false;
    }
  }

  public static boolean dispatchNestedPreScroll(@NonNull View paramView, int paramInt1, int paramInt2, @Nullable int[] paramArrayOfInt1, @Nullable int[] paramArrayOfInt2, int paramInt3)
  {
    boolean bool;
    if ((paramView instanceof NestedScrollingChild2))
      bool = ((NestedScrollingChild2)paramView).dispatchNestedPreScroll(paramInt1, paramInt2, paramArrayOfInt1, paramArrayOfInt2, paramInt3);
    while (true)
    {
      return bool;
      if (paramInt3 == 0)
        bool = dispatchNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfInt1, paramArrayOfInt2);
      else
        bool = false;
    }
  }

  public static boolean dispatchNestedScroll(@NonNull View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, @Nullable int[] paramArrayOfInt)
  {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 21)
      bool = paramView.dispatchNestedScroll(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfInt);
    while (true)
    {
      return bool;
      if ((paramView instanceof NestedScrollingChild))
        bool = ((NestedScrollingChild)paramView).dispatchNestedScroll(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfInt);
      else
        bool = false;
    }
  }

  public static boolean dispatchNestedScroll(@NonNull View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, @Nullable int[] paramArrayOfInt, int paramInt5)
  {
    boolean bool;
    if ((paramView instanceof NestedScrollingChild2))
      bool = ((NestedScrollingChild2)paramView).dispatchNestedScroll(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfInt, paramInt5);
    while (true)
    {
      return bool;
      if (paramInt5 == 0)
        bool = dispatchNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfInt);
      else
        bool = false;
    }
  }

  public static void dispatchStartTemporaryDetach(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 24)
      paramView.dispatchStartTemporaryDetach();
    while (true)
    {
      return;
      if (!sTempDetachBound)
        bindTempDetach();
      if (sDispatchStartTemporaryDetach != null)
        try
        {
          sDispatchStartTemporaryDetach.invoke(paramView, new Object[0]);
        }
        catch (Exception localException)
        {
          Log.d("ViewCompat", "Error calling dispatchStartTemporaryDetach", localException);
        }
      else
        paramView.onStartTemporaryDetach();
    }
  }

  @UiThread
  static boolean dispatchUnhandledKeyEventBeforeCallback(View paramView, KeyEvent paramKeyEvent)
  {
    if (Build.VERSION.SDK_INT >= 28);
    for (boolean bool = false; ; bool = UnhandledKeyEventManager.at(paramView).dispatch(paramView, paramKeyEvent))
      return bool;
  }

  @UiThread
  static boolean dispatchUnhandledKeyEventBeforeHierarchy(View paramView, KeyEvent paramKeyEvent)
  {
    if (Build.VERSION.SDK_INT >= 28);
    for (boolean bool = false; ; bool = UnhandledKeyEventManager.at(paramView).preDispatch(paramKeyEvent))
      return bool;
  }

  public static int generateViewId()
  {
    int i;
    if (Build.VERSION.SDK_INT >= 17)
      i = View.generateViewId();
    while (true)
    {
      return i;
      int j;
      do
      {
        i = sNextGeneratedId.get();
        j = i + 1;
        if (j > 16777215)
          j = 1;
      }
      while (!sNextGeneratedId.compareAndSet(i, j));
    }
  }

  public static int getAccessibilityLiveRegion(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 19);
    for (int i = paramView.getAccessibilityLiveRegion(); ; i = 0)
      return i;
  }

  public static AccessibilityNodeProviderCompat getAccessibilityNodeProvider(@NonNull View paramView)
  {
    AccessibilityNodeProvider localAccessibilityNodeProvider;
    if (Build.VERSION.SDK_INT >= 16)
    {
      localAccessibilityNodeProvider = paramView.getAccessibilityNodeProvider();
      if (localAccessibilityNodeProvider == null);
    }
    for (AccessibilityNodeProviderCompat localAccessibilityNodeProviderCompat = new AccessibilityNodeProviderCompat(localAccessibilityNodeProvider); ; localAccessibilityNodeProviderCompat = null)
      return localAccessibilityNodeProviderCompat;
  }

  @Deprecated
  public static float getAlpha(View paramView)
  {
    return paramView.getAlpha();
  }

  public static ColorStateList getBackgroundTintList(@NonNull View paramView)
  {
    ColorStateList localColorStateList;
    if (Build.VERSION.SDK_INT >= 21)
      localColorStateList = paramView.getBackgroundTintList();
    while (true)
    {
      return localColorStateList;
      if ((paramView instanceof TintableBackgroundView))
        localColorStateList = ((TintableBackgroundView)paramView).getSupportBackgroundTintList();
      else
        localColorStateList = null;
    }
  }

  public static PorterDuff.Mode getBackgroundTintMode(@NonNull View paramView)
  {
    PorterDuff.Mode localMode;
    if (Build.VERSION.SDK_INT >= 21)
      localMode = paramView.getBackgroundTintMode();
    while (true)
    {
      return localMode;
      if ((paramView instanceof TintableBackgroundView))
        localMode = ((TintableBackgroundView)paramView).getSupportBackgroundTintMode();
      else
        localMode = null;
    }
  }

  @Nullable
  public static Rect getClipBounds(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 18);
    for (Rect localRect = paramView.getClipBounds(); ; localRect = null)
      return localRect;
  }

  @Nullable
  public static Display getDisplay(@NonNull View paramView)
  {
    Display localDisplay;
    if (Build.VERSION.SDK_INT >= 17)
      localDisplay = paramView.getDisplay();
    while (true)
    {
      return localDisplay;
      if (isAttachedToWindow(paramView))
        localDisplay = ((WindowManager)paramView.getContext().getSystemService("window")).getDefaultDisplay();
      else
        localDisplay = null;
    }
  }

  public static float getElevation(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (float f = paramView.getElevation(); ; f = 0.0F)
      return f;
  }

  private static Rect getEmptyTempRect()
  {
    if (sThreadLocalRect == null)
      sThreadLocalRect = new ThreadLocal();
    Rect localRect = (Rect)sThreadLocalRect.get();
    if (localRect == null)
    {
      localRect = new Rect();
      sThreadLocalRect.set(localRect);
    }
    localRect.setEmpty();
    return localRect;
  }

  public static boolean getFitsSystemWindows(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 16);
    for (boolean bool = paramView.getFitsSystemWindows(); ; bool = false)
      return bool;
  }

  public static int getImportantForAccessibility(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 16);
    for (int i = paramView.getImportantForAccessibility(); ; i = 0)
      return i;
  }

  @SuppressLint({"InlinedApi"})
  public static int getImportantForAutofill(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 26);
    for (int i = paramView.getImportantForAutofill(); ; i = 0)
      return i;
  }

  public static int getLabelFor(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 17);
    for (int i = paramView.getLabelFor(); ; i = 0)
      return i;
  }

  @Deprecated
  public static int getLayerType(View paramView)
  {
    return paramView.getLayerType();
  }

  public static int getLayoutDirection(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 17);
    for (int i = paramView.getLayoutDirection(); ; i = 0)
      return i;
  }

  @Deprecated
  @Nullable
  public static Matrix getMatrix(View paramView)
  {
    return paramView.getMatrix();
  }

  @Deprecated
  public static int getMeasuredHeightAndState(View paramView)
  {
    return paramView.getMeasuredHeightAndState();
  }

  @Deprecated
  public static int getMeasuredState(View paramView)
  {
    return paramView.getMeasuredState();
  }

  @Deprecated
  public static int getMeasuredWidthAndState(View paramView)
  {
    return paramView.getMeasuredWidthAndState();
  }

  public static int getMinimumHeight(@NonNull View paramView)
  {
    int i;
    if (Build.VERSION.SDK_INT >= 16)
      i = paramView.getMinimumHeight();
    while (true)
    {
      return i;
      if (!sMinHeightFieldFetched);
      try
      {
        sMinHeightField = View.class.getDeclaredField("mMinHeight");
        sMinHeightField.setAccessible(true);
        label39: sMinHeightFieldFetched = true;
        if (sMinHeightField != null)
          try
          {
            int j = ((Integer)sMinHeightField.get(paramView)).intValue();
            i = j;
          }
          catch (Exception localException)
          {
          }
        i = 0;
      }
      catch (NoSuchFieldException localNoSuchFieldException)
      {
        break label39;
      }
    }
  }

  public static int getMinimumWidth(@NonNull View paramView)
  {
    int i;
    if (Build.VERSION.SDK_INT >= 16)
      i = paramView.getMinimumWidth();
    while (true)
    {
      return i;
      if (!sMinWidthFieldFetched);
      try
      {
        sMinWidthField = View.class.getDeclaredField("mMinWidth");
        sMinWidthField.setAccessible(true);
        label39: sMinWidthFieldFetched = true;
        if (sMinWidthField != null)
          try
          {
            int j = ((Integer)sMinWidthField.get(paramView)).intValue();
            i = j;
          }
          catch (Exception localException)
          {
          }
        i = 0;
      }
      catch (NoSuchFieldException localNoSuchFieldException)
      {
        break label39;
      }
    }
  }

  public static int getNextClusterForwardId(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 26);
    for (int i = paramView.getNextClusterForwardId(); ; i = -1)
      return i;
  }

  @Deprecated
  public static int getOverScrollMode(View paramView)
  {
    return paramView.getOverScrollMode();
  }

  @Px
  public static int getPaddingEnd(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 17);
    for (int i = paramView.getPaddingEnd(); ; i = paramView.getPaddingRight())
      return i;
  }

  @Px
  public static int getPaddingStart(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 17);
    for (int i = paramView.getPaddingStart(); ; i = paramView.getPaddingLeft())
      return i;
  }

  public static ViewParent getParentForAccessibility(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 16);
    for (ViewParent localViewParent = paramView.getParentForAccessibility(); ; localViewParent = paramView.getParent())
      return localViewParent;
  }

  @Deprecated
  public static float getPivotX(View paramView)
  {
    return paramView.getPivotX();
  }

  @Deprecated
  public static float getPivotY(View paramView)
  {
    return paramView.getPivotY();
  }

  @Deprecated
  public static float getRotation(View paramView)
  {
    return paramView.getRotation();
  }

  @Deprecated
  public static float getRotationX(View paramView)
  {
    return paramView.getRotationX();
  }

  @Deprecated
  public static float getRotationY(View paramView)
  {
    return paramView.getRotationY();
  }

  @Deprecated
  public static float getScaleX(View paramView)
  {
    return paramView.getScaleX();
  }

  @Deprecated
  public static float getScaleY(View paramView)
  {
    return paramView.getScaleY();
  }

  public static int getScrollIndicators(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 23);
    for (int i = paramView.getScrollIndicators(); ; i = 0)
      return i;
  }

  @Nullable
  public static String getTransitionName(@NonNull View paramView)
  {
    String str;
    if (Build.VERSION.SDK_INT >= 21)
      str = paramView.getTransitionName();
    while (true)
    {
      return str;
      if (sTransitionNameMap == null)
        str = null;
      else
        str = (String)sTransitionNameMap.get(paramView);
    }
  }

  @Deprecated
  public static float getTranslationX(View paramView)
  {
    return paramView.getTranslationX();
  }

  @Deprecated
  public static float getTranslationY(View paramView)
  {
    return paramView.getTranslationY();
  }

  public static float getTranslationZ(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (float f = paramView.getTranslationZ(); ; f = 0.0F)
      return f;
  }

  public static int getWindowSystemUiVisibility(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 16);
    for (int i = paramView.getWindowSystemUiVisibility(); ; i = 0)
      return i;
  }

  @Deprecated
  public static float getX(View paramView)
  {
    return paramView.getX();
  }

  @Deprecated
  public static float getY(View paramView)
  {
    return paramView.getY();
  }

  public static float getZ(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (float f = paramView.getZ(); ; f = 0.0F)
      return f;
  }

  // ERROR //
  public static boolean hasAccessibilityDelegate(@NonNull View paramView)
  {
    // Byte code:
    //   0: iconst_1
    //   1: istore_1
    //   2: iconst_0
    //   3: istore_2
    //   4: getstatic 90	androidx/core/view/ViewCompat:sAccessibilityDelegateCheckFailed	Z
    //   7: ifeq +5 -> 12
    //   10: iload_2
    //   11: ireturn
    //   12: getstatic 584	androidx/core/view/ViewCompat:sAccessibilityDelegateField	Ljava/lang/reflect/Field;
    //   15: ifnonnull +21 -> 36
    //   18: ldc 102
    //   20: ldc_w 586
    //   23: invokevirtual 479	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   26: putstatic 584	androidx/core/view/ViewCompat:sAccessibilityDelegateField	Ljava/lang/reflect/Field;
    //   29: getstatic 584	androidx/core/view/ViewCompat:sAccessibilityDelegateField	Ljava/lang/reflect/Field;
    //   32: iconst_1
    //   33: invokevirtual 487	java/lang/reflect/Field:setAccessible	(Z)V
    //   36: getstatic 584	androidx/core/view/ViewCompat:sAccessibilityDelegateField	Ljava/lang/reflect/Field;
    //   39: aload_0
    //   40: invokevirtual 488	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   43: astore 4
    //   45: aload 4
    //   47: ifnull +17 -> 64
    //   50: iload_1
    //   51: istore_2
    //   52: goto -42 -> 10
    //   55: astore 5
    //   57: iload_1
    //   58: putstatic 90	androidx/core/view/ViewCompat:sAccessibilityDelegateCheckFailed	Z
    //   61: goto -51 -> 10
    //   64: iconst_0
    //   65: istore_1
    //   66: goto -16 -> 50
    //   69: astore_3
    //   70: iload_1
    //   71: putstatic 90	androidx/core/view/ViewCompat:sAccessibilityDelegateCheckFailed	Z
    //   74: goto -64 -> 10
    //
    // Exception table:
    //   from	to	target	type
    //   18	36	55	java/lang/Throwable
    //   36	45	69	java/lang/Throwable
  }

  public static boolean hasExplicitFocusable(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 26);
    for (boolean bool = paramView.hasExplicitFocusable(); ; bool = paramView.hasFocusable())
      return bool;
  }

  public static boolean hasNestedScrollingParent(@NonNull View paramView)
  {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 21)
      bool = paramView.hasNestedScrollingParent();
    while (true)
    {
      return bool;
      if ((paramView instanceof NestedScrollingChild))
        bool = ((NestedScrollingChild)paramView).hasNestedScrollingParent();
      else
        bool = false;
    }
  }

  public static boolean hasNestedScrollingParent(@NonNull View paramView, int paramInt)
  {
    if ((paramView instanceof NestedScrollingChild2))
      ((NestedScrollingChild2)paramView).hasNestedScrollingParent(paramInt);
    for (boolean bool = false; ; bool = hasNestedScrollingParent(paramView))
    {
      return bool;
      if (paramInt != 0)
        break;
    }
  }

  public static boolean hasOnClickListeners(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 15);
    for (boolean bool = paramView.hasOnClickListeners(); ; bool = false)
      return bool;
  }

  public static boolean hasOverlappingRendering(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 16);
    for (boolean bool = paramView.hasOverlappingRendering(); ; bool = true)
      return bool;
  }

  public static boolean hasTransientState(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 16);
    for (boolean bool = paramView.hasTransientState(); ; bool = false)
      return bool;
  }

  public static boolean isAttachedToWindow(@NonNull View paramView)
  {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 19)
      bool = paramView.isAttachedToWindow();
    while (true)
    {
      return bool;
      if (paramView.getWindowToken() != null)
        bool = true;
      else
        bool = false;
    }
  }

  public static boolean isFocusedByDefault(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 26);
    for (boolean bool = paramView.isFocusedByDefault(); ; bool = false)
      return bool;
  }

  public static boolean isImportantForAccessibility(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (boolean bool = paramView.isImportantForAccessibility(); ; bool = true)
      return bool;
  }

  public static boolean isImportantForAutofill(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 26);
    for (boolean bool = paramView.isImportantForAutofill(); ; bool = true)
      return bool;
  }

  public static boolean isInLayout(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 18);
    for (boolean bool = paramView.isInLayout(); ; bool = false)
      return bool;
  }

  public static boolean isKeyboardNavigationCluster(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 26);
    for (boolean bool = paramView.isKeyboardNavigationCluster(); ; bool = false)
      return bool;
  }

  public static boolean isLaidOut(@NonNull View paramView)
  {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 19)
      bool = paramView.isLaidOut();
    while (true)
    {
      return bool;
      if ((paramView.getWidth() > 0) && (paramView.getHeight() > 0))
        bool = true;
      else
        bool = false;
    }
  }

  public static boolean isLayoutDirectionResolved(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 19);
    for (boolean bool = paramView.isLayoutDirectionResolved(); ; bool = false)
      return bool;
  }

  public static boolean isNestedScrollingEnabled(@NonNull View paramView)
  {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 21)
      bool = paramView.isNestedScrollingEnabled();
    while (true)
    {
      return bool;
      if ((paramView instanceof NestedScrollingChild))
        bool = ((NestedScrollingChild)paramView).isNestedScrollingEnabled();
      else
        bool = false;
    }
  }

  @Deprecated
  public static boolean isOpaque(View paramView)
  {
    return paramView.isOpaque();
  }

  public static boolean isPaddingRelative(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 17);
    for (boolean bool = paramView.isPaddingRelative(); ; bool = false)
      return bool;
  }

  @Deprecated
  public static void jumpDrawablesToCurrentState(View paramView)
  {
    paramView.jumpDrawablesToCurrentState();
  }

  public static View keyboardNavigationClusterSearch(@NonNull View paramView1, View paramView2, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 26);
    for (View localView = paramView1.keyboardNavigationClusterSearch(paramView2, paramInt); ; localView = null)
      return localView;
  }

  public static void offsetLeftAndRight(@NonNull View paramView, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 23)
      paramView.offsetLeftAndRight(paramInt);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 21)
      {
        Rect localRect = getEmptyTempRect();
        int i = 0;
        ViewParent localViewParent = paramView.getParent();
        if ((localViewParent instanceof View))
        {
          View localView = (View)localViewParent;
          localRect.set(localView.getLeft(), localView.getTop(), localView.getRight(), localView.getBottom());
          if (localRect.intersects(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()))
            break label142;
        }
        label142: for (i = 1; ; i = 0)
        {
          compatOffsetLeftAndRight(paramView, paramInt);
          if ((i == 0) || (!localRect.intersect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom())))
            break;
          ((View)localViewParent).invalidate(localRect);
          break;
        }
      }
      compatOffsetLeftAndRight(paramView, paramInt);
    }
  }

  public static void offsetTopAndBottom(@NonNull View paramView, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 23)
      paramView.offsetTopAndBottom(paramInt);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 21)
      {
        Rect localRect = getEmptyTempRect();
        int i = 0;
        ViewParent localViewParent = paramView.getParent();
        if ((localViewParent instanceof View))
        {
          View localView = (View)localViewParent;
          localRect.set(localView.getLeft(), localView.getTop(), localView.getRight(), localView.getBottom());
          if (localRect.intersects(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()))
            break label142;
        }
        label142: for (i = 1; ; i = 0)
        {
          compatOffsetTopAndBottom(paramView, paramInt);
          if ((i == 0) || (!localRect.intersect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom())))
            break;
          ((View)localViewParent).invalidate(localRect);
          break;
        }
      }
      compatOffsetTopAndBottom(paramView, paramInt);
    }
  }

  public static WindowInsetsCompat onApplyWindowInsets(@NonNull View paramView, WindowInsetsCompat paramWindowInsetsCompat)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      WindowInsets localWindowInsets1 = (WindowInsets)WindowInsetsCompat.unwrap(paramWindowInsetsCompat);
      WindowInsets localWindowInsets2 = paramView.onApplyWindowInsets(localWindowInsets1);
      if (localWindowInsets2 != localWindowInsets1)
        localWindowInsets1 = new WindowInsets(localWindowInsets2);
      paramWindowInsetsCompat = WindowInsetsCompat.wrap(localWindowInsets1);
    }
    return paramWindowInsetsCompat;
  }

  @Deprecated
  public static void onInitializeAccessibilityEvent(View paramView, AccessibilityEvent paramAccessibilityEvent)
  {
    paramView.onInitializeAccessibilityEvent(paramAccessibilityEvent);
  }

  public static void onInitializeAccessibilityNodeInfo(@NonNull View paramView, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat)
  {
    paramView.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfoCompat.unwrap());
  }

  @Deprecated
  public static void onPopulateAccessibilityEvent(View paramView, AccessibilityEvent paramAccessibilityEvent)
  {
    paramView.onPopulateAccessibilityEvent(paramAccessibilityEvent);
  }

  public static boolean performAccessibilityAction(@NonNull View paramView, int paramInt, Bundle paramBundle)
  {
    if (Build.VERSION.SDK_INT >= 16);
    for (boolean bool = paramView.performAccessibilityAction(paramInt, paramBundle); ; bool = false)
      return bool;
  }

  public static void postInvalidateOnAnimation(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 16)
      paramView.postInvalidateOnAnimation();
    while (true)
    {
      return;
      paramView.postInvalidate();
    }
  }

  public static void postInvalidateOnAnimation(@NonNull View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (Build.VERSION.SDK_INT >= 16)
      paramView.postInvalidateOnAnimation(paramInt1, paramInt2, paramInt3, paramInt4);
    while (true)
    {
      return;
      paramView.postInvalidate(paramInt1, paramInt2, paramInt3, paramInt4);
    }
  }

  public static void postOnAnimation(@NonNull View paramView, Runnable paramRunnable)
  {
    if (Build.VERSION.SDK_INT >= 16)
      paramView.postOnAnimation(paramRunnable);
    while (true)
    {
      return;
      paramView.postDelayed(paramRunnable, ValueAnimator.getFrameDelay());
    }
  }

  public static void postOnAnimationDelayed(@NonNull View paramView, Runnable paramRunnable, long paramLong)
  {
    if (Build.VERSION.SDK_INT >= 16)
      paramView.postOnAnimationDelayed(paramRunnable, paramLong);
    while (true)
    {
      return;
      paramView.postDelayed(paramRunnable, paramLong + ValueAnimator.getFrameDelay());
    }
  }

  public static void removeOnUnhandledKeyEventListener(@NonNull View paramView, @NonNull OnUnhandledKeyEventListenerCompat paramOnUnhandledKeyEventListenerCompat)
  {
    Map localMap;
    if (Build.VERSION.SDK_INT >= 28)
    {
      localMap = (Map)paramView.getTag(R.id.tag_unhandled_key_listeners);
      if (localMap != null);
    }
    while (true)
    {
      return;
      View.OnUnhandledKeyEventListener localOnUnhandledKeyEventListener = (View.OnUnhandledKeyEventListener)localMap.get(paramOnUnhandledKeyEventListenerCompat);
      if (localOnUnhandledKeyEventListener != null)
      {
        paramView.removeOnUnhandledKeyEventListener(localOnUnhandledKeyEventListener);
        continue;
        ArrayList localArrayList = (ArrayList)paramView.getTag(R.id.tag_unhandled_key_listeners);
        if (localArrayList != null)
        {
          localArrayList.remove(paramOnUnhandledKeyEventListenerCompat);
          if (localArrayList.size() == 0)
            UnhandledKeyEventManager.unregisterListeningView(paramView);
        }
      }
    }
  }

  public static void requestApplyInsets(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 20)
      paramView.requestApplyInsets();
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 16)
        paramView.requestFitSystemWindows();
    }
  }

  @NonNull
  public static <T extends View> T requireViewById(@NonNull View paramView, @IdRes int paramInt)
  {
    View localView;
    if (Build.VERSION.SDK_INT >= 28)
      localView = paramView.requireViewById(paramInt);
    do
    {
      return localView;
      localView = paramView.findViewById(paramInt);
    }
    while (localView != null);
    throw new IllegalArgumentException("ID does not reference a View inside this View");
  }

  @Deprecated
  public static int resolveSizeAndState(int paramInt1, int paramInt2, int paramInt3)
  {
    return View.resolveSizeAndState(paramInt1, paramInt2, paramInt3);
  }

  public static boolean restoreDefaultFocus(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 26);
    for (boolean bool = paramView.restoreDefaultFocus(); ; bool = paramView.requestFocus())
      return bool;
  }

  public static void setAccessibilityDelegate(@NonNull View paramView, AccessibilityDelegateCompat paramAccessibilityDelegateCompat)
  {
    if (paramAccessibilityDelegateCompat == null);
    for (View.AccessibilityDelegate localAccessibilityDelegate = null; ; localAccessibilityDelegate = paramAccessibilityDelegateCompat.getBridge())
    {
      paramView.setAccessibilityDelegate(localAccessibilityDelegate);
      return;
    }
  }

  public static void setAccessibilityLiveRegion(@NonNull View paramView, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 19)
      paramView.setAccessibilityLiveRegion(paramInt);
  }

  @Deprecated
  public static void setActivated(View paramView, boolean paramBoolean)
  {
    paramView.setActivated(paramBoolean);
  }

  @Deprecated
  public static void setAlpha(View paramView, @FloatRange(from=0.0D, to=1.0D) float paramFloat)
  {
    paramView.setAlpha(paramFloat);
  }

  public static void setAutofillHints(@NonNull View paramView, @Nullable String[] paramArrayOfString)
  {
    if (Build.VERSION.SDK_INT >= 26)
      paramView.setAutofillHints(paramArrayOfString);
  }

  public static void setBackground(@NonNull View paramView, @Nullable Drawable paramDrawable)
  {
    if (Build.VERSION.SDK_INT >= 16)
      paramView.setBackground(paramDrawable);
    while (true)
    {
      return;
      paramView.setBackgroundDrawable(paramDrawable);
    }
  }

  public static void setBackgroundTintList(@NonNull View paramView, ColorStateList paramColorStateList)
  {
    int i;
    if (Build.VERSION.SDK_INT >= 21)
    {
      paramView.setBackgroundTintList(paramColorStateList);
      if (Build.VERSION.SDK_INT == 21)
      {
        Drawable localDrawable = paramView.getBackground();
        if ((paramView.getBackgroundTintList() == null) && (paramView.getBackgroundTintMode() == null))
          break label72;
        i = 1;
        if ((localDrawable != null) && (i != 0))
        {
          if (localDrawable.isStateful())
            localDrawable.setState(paramView.getDrawableState());
          paramView.setBackground(localDrawable);
        }
      }
    }
    while (true)
    {
      return;
      label72: i = 0;
      break;
      if ((paramView instanceof TintableBackgroundView))
        ((TintableBackgroundView)paramView).setSupportBackgroundTintList(paramColorStateList);
    }
  }

  public static void setBackgroundTintMode(@NonNull View paramView, PorterDuff.Mode paramMode)
  {
    int i;
    if (Build.VERSION.SDK_INT >= 21)
    {
      paramView.setBackgroundTintMode(paramMode);
      if (Build.VERSION.SDK_INT == 21)
      {
        Drawable localDrawable = paramView.getBackground();
        if ((paramView.getBackgroundTintList() == null) && (paramView.getBackgroundTintMode() == null))
          break label72;
        i = 1;
        if ((localDrawable != null) && (i != 0))
        {
          if (localDrawable.isStateful())
            localDrawable.setState(paramView.getDrawableState());
          paramView.setBackground(localDrawable);
        }
      }
    }
    while (true)
    {
      return;
      label72: i = 0;
      break;
      if ((paramView instanceof TintableBackgroundView))
        ((TintableBackgroundView)paramView).setSupportBackgroundTintMode(paramMode);
    }
  }

  @Deprecated
  public static void setChildrenDrawingOrderEnabled(ViewGroup paramViewGroup, boolean paramBoolean)
  {
    if (sChildrenDrawingOrderMethod == null);
    try
    {
      Class[] arrayOfClass = new Class[1];
      arrayOfClass[0] = Boolean.TYPE;
      sChildrenDrawingOrderMethod = ViewGroup.class.getDeclaredMethod("setChildrenDrawingOrderEnabled", arrayOfClass);
      sChildrenDrawingOrderMethod.setAccessible(true);
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      try
      {
        Method localMethod = sChildrenDrawingOrderMethod;
        Object[] arrayOfObject = new Object[1];
        arrayOfObject[0] = Boolean.valueOf(paramBoolean);
        localMethod.invoke(paramViewGroup, arrayOfObject);
        return;
        localNoSuchMethodException = localNoSuchMethodException;
        Log.e("ViewCompat", "Unable to find childrenDrawingOrderEnabled", localNoSuchMethodException);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        while (true)
          Log.e("ViewCompat", "Unable to invoke childrenDrawingOrderEnabled", localIllegalAccessException);
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
        while (true)
          Log.e("ViewCompat", "Unable to invoke childrenDrawingOrderEnabled", localIllegalArgumentException);
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        while (true)
          Log.e("ViewCompat", "Unable to invoke childrenDrawingOrderEnabled", localInvocationTargetException);
      }
    }
  }

  public static void setClipBounds(@NonNull View paramView, Rect paramRect)
  {
    if (Build.VERSION.SDK_INT >= 18)
      paramView.setClipBounds(paramRect);
  }

  public static void setElevation(@NonNull View paramView, float paramFloat)
  {
    if (Build.VERSION.SDK_INT >= 21)
      paramView.setElevation(paramFloat);
  }

  @Deprecated
  public static void setFitsSystemWindows(View paramView, boolean paramBoolean)
  {
    paramView.setFitsSystemWindows(paramBoolean);
  }

  public static void setFocusedByDefault(@NonNull View paramView, boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT >= 26)
      paramView.setFocusedByDefault(paramBoolean);
  }

  public static void setHasTransientState(@NonNull View paramView, boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT >= 16)
      paramView.setHasTransientState(paramBoolean);
  }

  public static void setImportantForAccessibility(@NonNull View paramView, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 19)
      paramView.setImportantForAccessibility(paramInt);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 16)
      {
        if (paramInt == 4)
          paramInt = 2;
        paramView.setImportantForAccessibility(paramInt);
      }
    }
  }

  public static void setImportantForAutofill(@NonNull View paramView, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 26)
      paramView.setImportantForAutofill(paramInt);
  }

  public static void setKeyboardNavigationCluster(@NonNull View paramView, boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT >= 26)
      paramView.setKeyboardNavigationCluster(paramBoolean);
  }

  public static void setLabelFor(@NonNull View paramView, @IdRes int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 17)
      paramView.setLabelFor(paramInt);
  }

  public static void setLayerPaint(@NonNull View paramView, Paint paramPaint)
  {
    if (Build.VERSION.SDK_INT >= 17)
      paramView.setLayerPaint(paramPaint);
    while (true)
    {
      return;
      paramView.setLayerType(paramView.getLayerType(), paramPaint);
      paramView.invalidate();
    }
  }

  @Deprecated
  public static void setLayerType(View paramView, int paramInt, Paint paramPaint)
  {
    paramView.setLayerType(paramInt, paramPaint);
  }

  public static void setLayoutDirection(@NonNull View paramView, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 17)
      paramView.setLayoutDirection(paramInt);
  }

  public static void setNestedScrollingEnabled(@NonNull View paramView, boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT >= 21)
      paramView.setNestedScrollingEnabled(paramBoolean);
    while (true)
    {
      return;
      if ((paramView instanceof NestedScrollingChild))
        ((NestedScrollingChild)paramView).setNestedScrollingEnabled(paramBoolean);
    }
  }

  public static void setNextClusterForwardId(@NonNull View paramView, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 26)
      paramView.setNextClusterForwardId(paramInt);
  }

  public static void setOnApplyWindowInsetsListener(@NonNull View paramView, OnApplyWindowInsetsListener paramOnApplyWindowInsetsListener)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      if (paramOnApplyWindowInsetsListener != null)
        break label18;
      paramView.setOnApplyWindowInsetsListener(null);
    }
    while (true)
    {
      return;
      label18: paramView.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener()
      {
        public WindowInsets onApplyWindowInsets(View paramAnonymousView, WindowInsets paramAnonymousWindowInsets)
        {
          WindowInsetsCompat localWindowInsetsCompat = WindowInsetsCompat.wrap(paramAnonymousWindowInsets);
          return (WindowInsets)WindowInsetsCompat.unwrap(this.val$listener.onApplyWindowInsets(paramAnonymousView, localWindowInsetsCompat));
        }
      });
    }
  }

  @Deprecated
  public static void setOverScrollMode(View paramView, int paramInt)
  {
    paramView.setOverScrollMode(paramInt);
  }

  public static void setPaddingRelative(@NonNull View paramView, @Px int paramInt1, @Px int paramInt2, @Px int paramInt3, @Px int paramInt4)
  {
    if (Build.VERSION.SDK_INT >= 17)
      paramView.setPaddingRelative(paramInt1, paramInt2, paramInt3, paramInt4);
    while (true)
    {
      return;
      paramView.setPadding(paramInt1, paramInt2, paramInt3, paramInt4);
    }
  }

  @Deprecated
  public static void setPivotX(View paramView, float paramFloat)
  {
    paramView.setPivotX(paramFloat);
  }

  @Deprecated
  public static void setPivotY(View paramView, float paramFloat)
  {
    paramView.setPivotY(paramFloat);
  }

  public static void setPointerIcon(@NonNull View paramView, PointerIconCompat paramPointerIconCompat)
  {
    if (Build.VERSION.SDK_INT >= 24)
      if (paramPointerIconCompat == null)
        break label29;
    label29: for (Object localObject = paramPointerIconCompat.getPointerIcon(); ; localObject = null)
    {
      paramView.setPointerIcon((PointerIcon)localObject);
      return;
    }
  }

  @Deprecated
  public static void setRotation(View paramView, float paramFloat)
  {
    paramView.setRotation(paramFloat);
  }

  @Deprecated
  public static void setRotationX(View paramView, float paramFloat)
  {
    paramView.setRotationX(paramFloat);
  }

  @Deprecated
  public static void setRotationY(View paramView, float paramFloat)
  {
    paramView.setRotationY(paramFloat);
  }

  @Deprecated
  public static void setSaveFromParentEnabled(View paramView, boolean paramBoolean)
  {
    paramView.setSaveFromParentEnabled(paramBoolean);
  }

  @Deprecated
  public static void setScaleX(View paramView, float paramFloat)
  {
    paramView.setScaleX(paramFloat);
  }

  @Deprecated
  public static void setScaleY(View paramView, float paramFloat)
  {
    paramView.setScaleY(paramFloat);
  }

  public static void setScrollIndicators(@NonNull View paramView, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 23)
      paramView.setScrollIndicators(paramInt);
  }

  public static void setScrollIndicators(@NonNull View paramView, int paramInt1, int paramInt2)
  {
    if (Build.VERSION.SDK_INT >= 23)
      paramView.setScrollIndicators(paramInt1, paramInt2);
  }

  public static void setTooltipText(@NonNull View paramView, @Nullable CharSequence paramCharSequence)
  {
    if (Build.VERSION.SDK_INT >= 26)
      paramView.setTooltipText(paramCharSequence);
  }

  public static void setTransitionName(@NonNull View paramView, String paramString)
  {
    if (Build.VERSION.SDK_INT >= 21)
      paramView.setTransitionName(paramString);
    while (true)
    {
      return;
      if (sTransitionNameMap == null)
        sTransitionNameMap = new WeakHashMap();
      sTransitionNameMap.put(paramView, paramString);
    }
  }

  @Deprecated
  public static void setTranslationX(View paramView, float paramFloat)
  {
    paramView.setTranslationX(paramFloat);
  }

  @Deprecated
  public static void setTranslationY(View paramView, float paramFloat)
  {
    paramView.setTranslationY(paramFloat);
  }

  public static void setTranslationZ(@NonNull View paramView, float paramFloat)
  {
    if (Build.VERSION.SDK_INT >= 21)
      paramView.setTranslationZ(paramFloat);
  }

  @Deprecated
  public static void setX(View paramView, float paramFloat)
  {
    paramView.setX(paramFloat);
  }

  @Deprecated
  public static void setY(View paramView, float paramFloat)
  {
    paramView.setY(paramFloat);
  }

  public static void setZ(@NonNull View paramView, float paramFloat)
  {
    if (Build.VERSION.SDK_INT >= 21)
      paramView.setZ(paramFloat);
  }

  public static boolean startDragAndDrop(@NonNull View paramView, ClipData paramClipData, View.DragShadowBuilder paramDragShadowBuilder, Object paramObject, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 24);
    for (boolean bool = paramView.startDragAndDrop(paramClipData, paramDragShadowBuilder, paramObject, paramInt); ; bool = paramView.startDrag(paramClipData, paramDragShadowBuilder, paramObject, paramInt))
      return bool;
  }

  public static boolean startNestedScroll(@NonNull View paramView, int paramInt)
  {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 21)
      bool = paramView.startNestedScroll(paramInt);
    while (true)
    {
      return bool;
      if ((paramView instanceof NestedScrollingChild))
        bool = ((NestedScrollingChild)paramView).startNestedScroll(paramInt);
      else
        bool = false;
    }
  }

  public static boolean startNestedScroll(@NonNull View paramView, int paramInt1, int paramInt2)
  {
    boolean bool;
    if ((paramView instanceof NestedScrollingChild2))
      bool = ((NestedScrollingChild2)paramView).startNestedScroll(paramInt1, paramInt2);
    while (true)
    {
      return bool;
      if (paramInt2 == 0)
        bool = startNestedScroll(paramView, paramInt1);
      else
        bool = false;
    }
  }

  public static void stopNestedScroll(@NonNull View paramView)
  {
    if (Build.VERSION.SDK_INT >= 21)
      paramView.stopNestedScroll();
    while (true)
    {
      return;
      if ((paramView instanceof NestedScrollingChild))
        ((NestedScrollingChild)paramView).stopNestedScroll();
    }
  }

  public static void stopNestedScroll(@NonNull View paramView, int paramInt)
  {
    if ((paramView instanceof NestedScrollingChild2))
      ((NestedScrollingChild2)paramView).stopNestedScroll(paramInt);
    while (true)
    {
      return;
      if (paramInt == 0)
        stopNestedScroll(paramView);
    }
  }

  private static void tickleInvalidationFlag(View paramView)
  {
    float f = paramView.getTranslationY();
    paramView.setTranslationY(1.0F + f);
    paramView.setTranslationY(f);
  }

  public static void updateDragShadow(@NonNull View paramView, View.DragShadowBuilder paramDragShadowBuilder)
  {
    if (Build.VERSION.SDK_INT >= 24)
      paramView.updateDragShadow(paramDragShadowBuilder);
  }

  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface FocusDirection
  {
  }

  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface FocusRealDirection
  {
  }

  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface FocusRelativeDirection
  {
  }

  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface NestedScrollType
  {
  }

  public static abstract interface OnUnhandledKeyEventListenerCompat
  {
    public abstract boolean onUnhandledKeyEvent(View paramView, KeyEvent paramKeyEvent);
  }

  @RequiresApi(28)
  private static class OnUnhandledKeyEventListenerWrapper
    implements View.OnUnhandledKeyEventListener
  {
    private ViewCompat.OnUnhandledKeyEventListenerCompat mCompatListener;

    OnUnhandledKeyEventListenerWrapper(ViewCompat.OnUnhandledKeyEventListenerCompat paramOnUnhandledKeyEventListenerCompat)
    {
      this.mCompatListener = paramOnUnhandledKeyEventListenerCompat;
    }

    public boolean onUnhandledKeyEvent(View paramView, KeyEvent paramKeyEvent)
    {
      return this.mCompatListener.onUnhandledKeyEvent(paramView, paramKeyEvent);
    }
  }

  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface ScrollAxis
  {
  }

  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface ScrollIndicators
  {
  }

  static class UnhandledKeyEventManager
  {
    private static final ArrayList<WeakReference<View>> sViewsWithListeners = new ArrayList();
    private SparseArray<WeakReference<View>> mCapturedKeys = null;
    private WeakReference<KeyEvent> mLastDispatchedPreViewKeyEvent = null;

    @Nullable
    private WeakHashMap<View, Boolean> mViewsContainingListeners = null;

    static UnhandledKeyEventManager at(View paramView)
    {
      UnhandledKeyEventManager localUnhandledKeyEventManager = (UnhandledKeyEventManager)paramView.getTag(R.id.tag_unhandled_key_event_manager);
      if (localUnhandledKeyEventManager == null)
      {
        localUnhandledKeyEventManager = new UnhandledKeyEventManager();
        paramView.setTag(R.id.tag_unhandled_key_event_manager, localUnhandledKeyEventManager);
      }
      return localUnhandledKeyEventManager;
    }

    @Nullable
    private View dispatchInOrder(View paramView, KeyEvent paramKeyEvent)
    {
      View localView;
      if ((this.mViewsContainingListeners == null) || (!this.mViewsContainingListeners.containsKey(paramView)))
        localView = null;
      while (true)
      {
        return localView;
        if ((paramView instanceof ViewGroup))
        {
          ViewGroup localViewGroup = (ViewGroup)paramView;
          for (int i = -1 + localViewGroup.getChildCount(); ; i--)
          {
            if (i < 0)
              break label72;
            localView = dispatchInOrder(localViewGroup.getChildAt(i), paramKeyEvent);
            if (localView != null)
              break;
          }
        }
        label72: if (onUnhandledKeyEvent(paramView, paramKeyEvent))
          localView = paramView;
        else
          localView = null;
      }
    }

    private SparseArray<WeakReference<View>> getCapturedKeys()
    {
      if (this.mCapturedKeys == null)
        this.mCapturedKeys = new SparseArray();
      return this.mCapturedKeys;
    }

    private boolean onUnhandledKeyEvent(@NonNull View paramView, @NonNull KeyEvent paramKeyEvent)
    {
      ArrayList localArrayList = (ArrayList)paramView.getTag(R.id.tag_unhandled_key_listeners);
      int i;
      if (localArrayList != null)
      {
        i = -1 + localArrayList.size();
        if (i >= 0)
          if (!((ViewCompat.OnUnhandledKeyEventListenerCompat)localArrayList.get(i)).onUnhandledKeyEvent(paramView, paramKeyEvent));
      }
      for (boolean bool = true; ; bool = false)
      {
        return bool;
        i--;
        break;
      }
    }

    private void recalcViewsWithUnhandled()
    {
      if (this.mViewsContainingListeners != null)
        this.mViewsContainingListeners.clear();
      if (sViewsWithListeners.isEmpty())
        return;
      while (true)
      {
        int i;
        synchronized (sViewsWithListeners)
        {
          if (this.mViewsContainingListeners == null)
            this.mViewsContainingListeners = new WeakHashMap();
          i = -1 + sViewsWithListeners.size();
          if (i >= 0)
          {
            View localView = (View)((WeakReference)sViewsWithListeners.get(i)).get();
            if (localView == null)
            {
              sViewsWithListeners.remove(i);
              break label161;
            }
            this.mViewsContainingListeners.put(localView, Boolean.TRUE);
            ViewParent localViewParent = localView.getParent();
            if (!(localViewParent instanceof View))
              break label161;
            this.mViewsContainingListeners.put((View)localViewParent, Boolean.TRUE);
            localViewParent = localViewParent.getParent();
            continue;
          }
        }
        label161: i--;
      }
    }

    static void registerListeningView(View paramView)
    {
      synchronized (sViewsWithListeners)
      {
        Iterator localIterator = sViewsWithListeners.iterator();
        while (localIterator.hasNext())
          if (((WeakReference)localIterator.next()).get() == paramView)
            return;
        sViewsWithListeners.add(new WeakReference(paramView));
      }
    }

    static void unregisterListeningView(View paramView)
    {
      ArrayList localArrayList = sViewsWithListeners;
      for (int i = 0; ; i++)
      {
        try
        {
          if (i < sViewsWithListeners.size())
          {
            if (((WeakReference)sViewsWithListeners.get(i)).get() != paramView)
              continue;
            sViewsWithListeners.remove(i);
          }
          else;
        }
        finally
        {
          localObject = finally;
          throw localObject;
        }
        return;
      }
    }

    boolean dispatch(View paramView, KeyEvent paramKeyEvent)
    {
      if (paramKeyEvent.getAction() == 0)
        recalcViewsWithUnhandled();
      View localView = dispatchInOrder(paramView, paramKeyEvent);
      if (paramKeyEvent.getAction() == 0)
      {
        int i = paramKeyEvent.getKeyCode();
        if ((localView != null) && (!KeyEvent.isModifierKey(i)))
          getCapturedKeys().put(i, new WeakReference(localView));
      }
      if (localView != null);
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    boolean preDispatch(KeyEvent paramKeyEvent)
    {
      boolean bool = false;
      if ((this.mLastDispatchedPreViewKeyEvent != null) && (this.mLastDispatchedPreViewKeyEvent.get() == paramKeyEvent));
      while (true)
      {
        return bool;
        this.mLastDispatchedPreViewKeyEvent = new WeakReference(paramKeyEvent);
        WeakReference localWeakReference = null;
        SparseArray localSparseArray = getCapturedKeys();
        if (paramKeyEvent.getAction() == 1)
        {
          int i = localSparseArray.indexOfKey(paramKeyEvent.getKeyCode());
          if (i >= 0)
          {
            localWeakReference = (WeakReference)localSparseArray.valueAt(i);
            localSparseArray.removeAt(i);
          }
        }
        if (localWeakReference == null)
          localWeakReference = (WeakReference)localSparseArray.get(paramKeyEvent.getKeyCode());
        if (localWeakReference != null)
        {
          View localView = (View)localWeakReference.get();
          if ((localView != null) && (ViewCompat.isAttachedToWindow(localView)))
            onUnhandledKeyEvent(localView, paramKeyEvent);
          bool = true;
        }
      }
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.view.ViewCompat
 * JD-Core Version:    0.6.2
 */