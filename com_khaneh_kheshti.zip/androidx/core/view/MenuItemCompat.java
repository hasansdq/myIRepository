package androidx.core.view;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.os.Build.VERSION;
import android.util.Log;
import android.view.MenuItem;
import android.view.MenuItem.OnActionExpandListener;
import android.view.View;
import androidx.core.internal.view.SupportMenuItem;

public final class MenuItemCompat
{

  @Deprecated
  public static final int SHOW_AS_ACTION_ALWAYS = 2;

  @Deprecated
  public static final int SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW = 8;

  @Deprecated
  public static final int SHOW_AS_ACTION_IF_ROOM = 1;

  @Deprecated
  public static final int SHOW_AS_ACTION_NEVER = 0;

  @Deprecated
  public static final int SHOW_AS_ACTION_WITH_TEXT = 4;
  private static final String TAG = "MenuItemCompat";

  @Deprecated
  public static boolean collapseActionView(MenuItem paramMenuItem)
  {
    return paramMenuItem.collapseActionView();
  }

  @Deprecated
  public static boolean expandActionView(MenuItem paramMenuItem)
  {
    return paramMenuItem.expandActionView();
  }

  public static ActionProvider getActionProvider(MenuItem paramMenuItem)
  {
    if ((paramMenuItem instanceof SupportMenuItem));
    for (ActionProvider localActionProvider = ((SupportMenuItem)paramMenuItem).getSupportActionProvider(); ; localActionProvider = null)
    {
      return localActionProvider;
      Log.w("MenuItemCompat", "getActionProvider: item does not implement SupportMenuItem; returning null");
    }
  }

  @Deprecated
  public static View getActionView(MenuItem paramMenuItem)
  {
    return paramMenuItem.getActionView();
  }

  public static int getAlphabeticModifiers(MenuItem paramMenuItem)
  {
    int i;
    if ((paramMenuItem instanceof SupportMenuItem))
      i = ((SupportMenuItem)paramMenuItem).getAlphabeticModifiers();
    while (true)
    {
      return i;
      if (Build.VERSION.SDK_INT >= 26)
        i = paramMenuItem.getAlphabeticModifiers();
      else
        i = 0;
    }
  }

  public static CharSequence getContentDescription(MenuItem paramMenuItem)
  {
    CharSequence localCharSequence;
    if ((paramMenuItem instanceof SupportMenuItem))
      localCharSequence = ((SupportMenuItem)paramMenuItem).getContentDescription();
    while (true)
    {
      return localCharSequence;
      if (Build.VERSION.SDK_INT >= 26)
        localCharSequence = paramMenuItem.getContentDescription();
      else
        localCharSequence = null;
    }
  }

  public static ColorStateList getIconTintList(MenuItem paramMenuItem)
  {
    ColorStateList localColorStateList;
    if ((paramMenuItem instanceof SupportMenuItem))
      localColorStateList = ((SupportMenuItem)paramMenuItem).getIconTintList();
    while (true)
    {
      return localColorStateList;
      if (Build.VERSION.SDK_INT >= 26)
        localColorStateList = paramMenuItem.getIconTintList();
      else
        localColorStateList = null;
    }
  }

  public static PorterDuff.Mode getIconTintMode(MenuItem paramMenuItem)
  {
    PorterDuff.Mode localMode;
    if ((paramMenuItem instanceof SupportMenuItem))
      localMode = ((SupportMenuItem)paramMenuItem).getIconTintMode();
    while (true)
    {
      return localMode;
      if (Build.VERSION.SDK_INT >= 26)
        localMode = paramMenuItem.getIconTintMode();
      else
        localMode = null;
    }
  }

  public static int getNumericModifiers(MenuItem paramMenuItem)
  {
    int i;
    if ((paramMenuItem instanceof SupportMenuItem))
      i = ((SupportMenuItem)paramMenuItem).getNumericModifiers();
    while (true)
    {
      return i;
      if (Build.VERSION.SDK_INT >= 26)
        i = paramMenuItem.getNumericModifiers();
      else
        i = 0;
    }
  }

  public static CharSequence getTooltipText(MenuItem paramMenuItem)
  {
    CharSequence localCharSequence;
    if ((paramMenuItem instanceof SupportMenuItem))
      localCharSequence = ((SupportMenuItem)paramMenuItem).getTooltipText();
    while (true)
    {
      return localCharSequence;
      if (Build.VERSION.SDK_INT >= 26)
        localCharSequence = paramMenuItem.getTooltipText();
      else
        localCharSequence = null;
    }
  }

  @Deprecated
  public static boolean isActionViewExpanded(MenuItem paramMenuItem)
  {
    return paramMenuItem.isActionViewExpanded();
  }

  public static MenuItem setActionProvider(MenuItem paramMenuItem, ActionProvider paramActionProvider)
  {
    if ((paramMenuItem instanceof SupportMenuItem))
      paramMenuItem = ((SupportMenuItem)paramMenuItem).setSupportActionProvider(paramActionProvider);
    while (true)
    {
      return paramMenuItem;
      Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
    }
  }

  @Deprecated
  public static MenuItem setActionView(MenuItem paramMenuItem, int paramInt)
  {
    return paramMenuItem.setActionView(paramInt);
  }

  @Deprecated
  public static MenuItem setActionView(MenuItem paramMenuItem, View paramView)
  {
    return paramMenuItem.setActionView(paramView);
  }

  public static void setAlphabeticShortcut(MenuItem paramMenuItem, char paramChar, int paramInt)
  {
    if ((paramMenuItem instanceof SupportMenuItem))
      ((SupportMenuItem)paramMenuItem).setAlphabeticShortcut(paramChar, paramInt);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 26)
        paramMenuItem.setAlphabeticShortcut(paramChar, paramInt);
    }
  }

  public static void setContentDescription(MenuItem paramMenuItem, CharSequence paramCharSequence)
  {
    if ((paramMenuItem instanceof SupportMenuItem))
      ((SupportMenuItem)paramMenuItem).setContentDescription(paramCharSequence);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 26)
        paramMenuItem.setContentDescription(paramCharSequence);
    }
  }

  public static void setIconTintList(MenuItem paramMenuItem, ColorStateList paramColorStateList)
  {
    if ((paramMenuItem instanceof SupportMenuItem))
      ((SupportMenuItem)paramMenuItem).setIconTintList(paramColorStateList);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 26)
        paramMenuItem.setIconTintList(paramColorStateList);
    }
  }

  public static void setIconTintMode(MenuItem paramMenuItem, PorterDuff.Mode paramMode)
  {
    if ((paramMenuItem instanceof SupportMenuItem))
      ((SupportMenuItem)paramMenuItem).setIconTintMode(paramMode);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 26)
        paramMenuItem.setIconTintMode(paramMode);
    }
  }

  public static void setNumericShortcut(MenuItem paramMenuItem, char paramChar, int paramInt)
  {
    if ((paramMenuItem instanceof SupportMenuItem))
      ((SupportMenuItem)paramMenuItem).setNumericShortcut(paramChar, paramInt);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 26)
        paramMenuItem.setNumericShortcut(paramChar, paramInt);
    }
  }

  @Deprecated
  public static MenuItem setOnActionExpandListener(MenuItem paramMenuItem, OnActionExpandListener paramOnActionExpandListener)
  {
    return paramMenuItem.setOnActionExpandListener(new MenuItem.OnActionExpandListener()
    {
      public boolean onMenuItemActionCollapse(MenuItem paramAnonymousMenuItem)
      {
        return this.val$listener.onMenuItemActionCollapse(paramAnonymousMenuItem);
      }

      public boolean onMenuItemActionExpand(MenuItem paramAnonymousMenuItem)
      {
        return this.val$listener.onMenuItemActionExpand(paramAnonymousMenuItem);
      }
    });
  }

  public static void setShortcut(MenuItem paramMenuItem, char paramChar1, char paramChar2, int paramInt1, int paramInt2)
  {
    if ((paramMenuItem instanceof SupportMenuItem))
      ((SupportMenuItem)paramMenuItem).setShortcut(paramChar1, paramChar2, paramInt1, paramInt2);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 26)
        paramMenuItem.setShortcut(paramChar1, paramChar2, paramInt1, paramInt2);
    }
  }

  @Deprecated
  public static void setShowAsAction(MenuItem paramMenuItem, int paramInt)
  {
    paramMenuItem.setShowAsAction(paramInt);
  }

  public static void setTooltipText(MenuItem paramMenuItem, CharSequence paramCharSequence)
  {
    if ((paramMenuItem instanceof SupportMenuItem))
      ((SupportMenuItem)paramMenuItem).setTooltipText(paramCharSequence);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 26)
        paramMenuItem.setTooltipText(paramCharSequence);
    }
  }

  @Deprecated
  public static abstract interface OnActionExpandListener
  {
    public abstract boolean onMenuItemActionCollapse(MenuItem paramMenuItem);

    public abstract boolean onMenuItemActionExpand(MenuItem paramMenuItem);
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.view.MenuItemCompat
 * JD-Core Version:    0.6.2
 */