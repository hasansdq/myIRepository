package androidx.core.view;

import android.os.Build.VERSION;
import android.view.ViewGroup.MarginLayoutParams;

public final class MarginLayoutParamsCompat
{
  public static int getLayoutDirection(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
  {
    if (Build.VERSION.SDK_INT >= 17);
    for (int i = paramMarginLayoutParams.getLayoutDirection(); ; i = 0)
    {
      if ((i != 0) && (i != 1))
        i = 0;
      return i;
    }
  }

  public static int getMarginEnd(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
  {
    if (Build.VERSION.SDK_INT >= 17);
    for (int i = paramMarginLayoutParams.getMarginEnd(); ; i = paramMarginLayoutParams.rightMargin)
      return i;
  }

  public static int getMarginStart(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
  {
    if (Build.VERSION.SDK_INT >= 17);
    for (int i = paramMarginLayoutParams.getMarginStart(); ; i = paramMarginLayoutParams.leftMargin)
      return i;
  }

  public static boolean isMarginRelative(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
  {
    if (Build.VERSION.SDK_INT >= 17);
    for (boolean bool = paramMarginLayoutParams.isMarginRelative(); ; bool = false)
      return bool;
  }

  public static void resolveLayoutDirection(ViewGroup.MarginLayoutParams paramMarginLayoutParams, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 17)
      paramMarginLayoutParams.resolveLayoutDirection(paramInt);
  }

  public static void setLayoutDirection(ViewGroup.MarginLayoutParams paramMarginLayoutParams, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 17)
      paramMarginLayoutParams.setLayoutDirection(paramInt);
  }

  public static void setMarginEnd(ViewGroup.MarginLayoutParams paramMarginLayoutParams, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 17)
      paramMarginLayoutParams.setMarginEnd(paramInt);
    while (true)
    {
      return;
      paramMarginLayoutParams.rightMargin = paramInt;
    }
  }

  public static void setMarginStart(ViewGroup.MarginLayoutParams paramMarginLayoutParams, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 17)
      paramMarginLayoutParams.setMarginStart(paramInt);
    while (true)
    {
      return;
      paramMarginLayoutParams.leftMargin = paramInt;
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.view.MarginLayoutParamsCompat
 * JD-Core Version:    0.6.2
 */