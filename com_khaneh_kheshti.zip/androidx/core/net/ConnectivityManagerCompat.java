package androidx.core.net;

import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build.VERSION;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresPermission;
import androidx.annotation.RestrictTo;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public final class ConnectivityManagerCompat
{
  public static final int RESTRICT_BACKGROUND_STATUS_DISABLED = 1;
  public static final int RESTRICT_BACKGROUND_STATUS_ENABLED = 3;
  public static final int RESTRICT_BACKGROUND_STATUS_WHITELISTED = 2;

  @Nullable
  @RequiresPermission("android.permission.ACCESS_NETWORK_STATE")
  public static NetworkInfo getNetworkInfoFromBroadcast(@NonNull ConnectivityManager paramConnectivityManager, @NonNull Intent paramIntent)
  {
    NetworkInfo localNetworkInfo1 = (NetworkInfo)paramIntent.getParcelableExtra("networkInfo");
    if (localNetworkInfo1 != null);
    for (NetworkInfo localNetworkInfo2 = paramConnectivityManager.getNetworkInfo(localNetworkInfo1.getType()); ; localNetworkInfo2 = null)
      return localNetworkInfo2;
  }

  public static int getRestrictBackgroundStatus(@NonNull ConnectivityManager paramConnectivityManager)
  {
    if (Build.VERSION.SDK_INT >= 24);
    for (int i = paramConnectivityManager.getRestrictBackgroundStatus(); ; i = 3)
      return i;
  }

  @RequiresPermission("android.permission.ACCESS_NETWORK_STATE")
  public static boolean isActiveNetworkMetered(@NonNull ConnectivityManager paramConnectivityManager)
  {
    boolean bool = true;
    if (Build.VERSION.SDK_INT >= 16)
      bool = paramConnectivityManager.isActiveNetworkMetered();
    while (true)
    {
      return bool;
      NetworkInfo localNetworkInfo = paramConnectivityManager.getActiveNetworkInfo();
      if (localNetworkInfo != null)
        switch (localNetworkInfo.getType())
        {
        case 0:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 8:
        default:
          break;
        case 1:
        case 7:
        case 9:
          bool = false;
        }
    }
  }

  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface RestrictBackgroundStatus
  {
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.net.ConnectivityManagerCompat
 * JD-Core Version:    0.6.2
 */