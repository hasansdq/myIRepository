package androidx.core.internal;

import androidx.annotation.RestrictTo;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
abstract interface package-info
{
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.internal.package-info
 * JD-Core Version:    0.6.2
 */