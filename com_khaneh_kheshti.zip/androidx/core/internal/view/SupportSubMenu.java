package androidx.core.internal.view;

import android.view.SubMenu;
import androidx.annotation.RestrictTo;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public abstract interface SupportSubMenu extends SupportMenu, SubMenu
{
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.internal.view.SupportSubMenu
 * JD-Core Version:    0.6.2
 */