package androidx.core.hardware.display;

import android.content.Context;
import android.hardware.display.DisplayManager;
import android.os.Build.VERSION;
import android.view.Display;
import android.view.WindowManager;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.WeakHashMap;

public final class DisplayManagerCompat
{
  public static final String DISPLAY_CATEGORY_PRESENTATION = "android.hardware.display.category.PRESENTATION";
  private static final WeakHashMap<Context, DisplayManagerCompat> sInstances = new WeakHashMap();
  private final Context mContext;

  private DisplayManagerCompat(Context paramContext)
  {
    this.mContext = paramContext;
  }

  @NonNull
  public static DisplayManagerCompat getInstance(@NonNull Context paramContext)
  {
    synchronized (sInstances)
    {
      DisplayManagerCompat localDisplayManagerCompat = (DisplayManagerCompat)sInstances.get(paramContext);
      if (localDisplayManagerCompat == null)
      {
        localDisplayManagerCompat = new DisplayManagerCompat(paramContext);
        sInstances.put(paramContext, localDisplayManagerCompat);
      }
      return localDisplayManagerCompat;
    }
  }

  @Nullable
  public Display getDisplay(int paramInt)
  {
    Display localDisplay;
    if (Build.VERSION.SDK_INT >= 17)
      localDisplay = ((DisplayManager)this.mContext.getSystemService("display")).getDisplay(paramInt);
    while (true)
    {
      return localDisplay;
      localDisplay = ((WindowManager)this.mContext.getSystemService("window")).getDefaultDisplay();
      if (localDisplay.getDisplayId() != paramInt)
        localDisplay = null;
    }
  }

  @NonNull
  public Display[] getDisplays()
  {
    if (Build.VERSION.SDK_INT >= 17);
    for (Display[] arrayOfDisplay = ((DisplayManager)this.mContext.getSystemService("display")).getDisplays(); ; arrayOfDisplay = new Display[] { ((WindowManager)this.mContext.getSystemService("window")).getDefaultDisplay() })
      return arrayOfDisplay;
  }

  @NonNull
  public Display[] getDisplays(@Nullable String paramString)
  {
    Display[] arrayOfDisplay;
    if (Build.VERSION.SDK_INT >= 17)
      arrayOfDisplay = ((DisplayManager)this.mContext.getSystemService("display")).getDisplays(paramString);
    while (true)
    {
      return arrayOfDisplay;
      if (paramString == null)
        arrayOfDisplay = new Display[0];
      else
        arrayOfDisplay = new Display[] { ((WindowManager)this.mContext.getSystemService("window")).getDefaultDisplay() };
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.hardware.display.DisplayManagerCompat
 * JD-Core Version:    0.6.2
 */