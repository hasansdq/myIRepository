package androidx.core.math;

public class MathUtils
{
  public static double clamp(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    if (paramDouble1 < paramDouble2);
    while (true)
    {
      return paramDouble2;
      if (paramDouble1 > paramDouble3)
        paramDouble2 = paramDouble3;
      else
        paramDouble2 = paramDouble1;
    }
  }

  public static float clamp(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    if (paramFloat1 < paramFloat2);
    while (true)
    {
      return paramFloat2;
      if (paramFloat1 > paramFloat3)
        paramFloat2 = paramFloat3;
      else
        paramFloat2 = paramFloat1;
    }
  }

  public static int clamp(int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt1 < paramInt2);
    while (true)
    {
      return paramInt2;
      if (paramInt1 > paramInt3)
        paramInt2 = paramInt3;
      else
        paramInt2 = paramInt1;
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.math.MathUtils
 * JD-Core Version:    0.6.2
 */