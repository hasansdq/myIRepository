package androidx.core.util;

import android.os.Build.VERSION;
import androidx.annotation.Nullable;
import java.util.Arrays;
import java.util.Objects;

public class ObjectsCompat
{
  public static boolean equals(@Nullable Object paramObject1, @Nullable Object paramObject2)
  {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 19)
      bool = Objects.equals(paramObject1, paramObject2);
    while (true)
    {
      return bool;
      if ((paramObject1 == paramObject2) || ((paramObject1 != null) && (paramObject1.equals(paramObject2))))
        bool = true;
      else
        bool = false;
    }
  }

  public static int hash(@Nullable Object[] paramArrayOfObject)
  {
    if (Build.VERSION.SDK_INT >= 19);
    for (int i = Objects.hash(paramArrayOfObject); ; i = Arrays.hashCode(paramArrayOfObject))
      return i;
  }

  public static int hashCode(@Nullable Object paramObject)
  {
    if (paramObject != null);
    for (int i = paramObject.hashCode(); ; i = 0)
      return i;
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.util.ObjectsCompat
 * JD-Core Version:    0.6.2
 */