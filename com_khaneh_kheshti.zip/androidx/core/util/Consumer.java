package androidx.core.util;

public abstract interface Consumer<T>
{
  public abstract void accept(T paramT);
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.util.Consumer
 * JD-Core Version:    0.6.2
 */