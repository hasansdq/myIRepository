package androidx.core.util;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class Pair<F, S>
{

  @Nullable
  public final F first;

  @Nullable
  public final S second;

  public Pair(@Nullable F paramF, @Nullable S paramS)
  {
    this.first = paramF;
    this.second = paramS;
  }

  @NonNull
  public static <A, B> Pair<A, B> create(@Nullable A paramA, @Nullable B paramB)
  {
    return new Pair(paramA, paramB);
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = false;
    if (!(paramObject instanceof Pair));
    while (true)
    {
      return bool;
      Pair localPair = (Pair)paramObject;
      if ((ObjectsCompat.equals(localPair.first, this.first)) && (ObjectsCompat.equals(localPair.second, this.second)))
        bool = true;
    }
  }

  public int hashCode()
  {
    int i = 0;
    int j;
    if (this.first == null)
    {
      j = 0;
      if (this.second != null)
        break label33;
    }
    while (true)
    {
      return j ^ i;
      j = this.first.hashCode();
      break;
      label33: i = this.second.hashCode();
    }
  }

  public String toString()
  {
    return "Pair{" + String.valueOf(this.first) + " " + String.valueOf(this.second) + "}";
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.util.Pair
 * JD-Core Version:    0.6.2
 */