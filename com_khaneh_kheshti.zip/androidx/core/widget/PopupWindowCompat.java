package androidx.core.widget;

import android.os.Build.VERSION;
import android.util.Log;
import android.view.View;
import android.widget.PopupWindow;
import androidx.annotation.NonNull;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public final class PopupWindowCompat
{
  private static final String TAG = "PopupWindowCompatApi21";
  private static Method sGetWindowLayoutTypeMethod;
  private static boolean sGetWindowLayoutTypeMethodAttempted;
  private static Field sOverlapAnchorField;
  private static boolean sOverlapAnchorFieldAttempted;
  private static Method sSetWindowLayoutTypeMethod;
  private static boolean sSetWindowLayoutTypeMethodAttempted;

  public static boolean getOverlapAnchor(@NonNull PopupWindow paramPopupWindow)
  {
    if (Build.VERSION.SDK_INT >= 23);
    for (boolean bool1 = paramPopupWindow.getOverlapAnchor(); ; bool1 = false)
      while (true)
      {
        return bool1;
        if (Build.VERSION.SDK_INT >= 21)
        {
          if (!sOverlapAnchorFieldAttempted);
          try
          {
            sOverlapAnchorField = PopupWindow.class.getDeclaredField("mOverlapAnchor");
            sOverlapAnchorField.setAccessible(true);
            sOverlapAnchorFieldAttempted = true;
            if (sOverlapAnchorField == null)
              break;
          }
          catch (NoSuchFieldException localNoSuchFieldException)
          {
            try
            {
              boolean bool2 = ((Boolean)sOverlapAnchorField.get(paramPopupWindow)).booleanValue();
              bool1 = bool2;
              continue;
              localNoSuchFieldException = localNoSuchFieldException;
              Log.i("PopupWindowCompatApi21", "Could not fetch mOverlapAnchor field from PopupWindow", localNoSuchFieldException);
            }
            catch (IllegalAccessException localIllegalAccessException)
            {
              Log.i("PopupWindowCompatApi21", "Could not get overlap anchor field in PopupWindow", localIllegalAccessException);
            }
          }
        }
      }
  }

  public static int getWindowLayoutType(@NonNull PopupWindow paramPopupWindow)
  {
    int i;
    if (Build.VERSION.SDK_INT >= 23)
      i = paramPopupWindow.getWindowLayoutType();
    while (true)
    {
      return i;
      if (!sGetWindowLayoutTypeMethodAttempted);
      try
      {
        sGetWindowLayoutTypeMethod = PopupWindow.class.getDeclaredMethod("getWindowLayoutType", new Class[0]);
        sGetWindowLayoutTypeMethod.setAccessible(true);
        label42: sGetWindowLayoutTypeMethodAttempted = true;
        if (sGetWindowLayoutTypeMethod != null)
          try
          {
            int j = ((Integer)sGetWindowLayoutTypeMethod.invoke(paramPopupWindow, new Object[0])).intValue();
            i = j;
          }
          catch (Exception localException1)
          {
          }
        i = 0;
      }
      catch (Exception localException2)
      {
        break label42;
      }
    }
  }

  public static void setOverlapAnchor(@NonNull PopupWindow paramPopupWindow, boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT >= 23)
      paramPopupWindow.setOverlapAnchor(paramBoolean);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT < 21)
        continue;
      if (!sOverlapAnchorFieldAttempted);
      try
      {
        sOverlapAnchorField = PopupWindow.class.getDeclaredField("mOverlapAnchor");
        sOverlapAnchorField.setAccessible(true);
        sOverlapAnchorFieldAttempted = true;
        if (sOverlapAnchorField == null)
          continue;
        try
        {
          sOverlapAnchorField.set(paramPopupWindow, Boolean.valueOf(paramBoolean));
        }
        catch (IllegalAccessException localIllegalAccessException)
        {
          Log.i("PopupWindowCompatApi21", "Could not set overlap anchor field in PopupWindow", localIllegalAccessException);
        }
      }
      catch (NoSuchFieldException localNoSuchFieldException)
      {
        while (true)
          Log.i("PopupWindowCompatApi21", "Could not fetch mOverlapAnchor field from PopupWindow", localNoSuchFieldException);
      }
    }
  }

  public static void setWindowLayoutType(@NonNull PopupWindow paramPopupWindow, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 23)
      paramPopupWindow.setWindowLayoutType(paramInt);
    while (true)
    {
      return;
      if (!sSetWindowLayoutTypeMethodAttempted);
      try
      {
        Class[] arrayOfClass = new Class[1];
        arrayOfClass[0] = Integer.TYPE;
        sSetWindowLayoutTypeMethod = PopupWindow.class.getDeclaredMethod("setWindowLayoutType", arrayOfClass);
        sSetWindowLayoutTypeMethod.setAccessible(true);
        label52: sSetWindowLayoutTypeMethodAttempted = true;
        if (sSetWindowLayoutTypeMethod == null)
          continue;
        try
        {
          Method localMethod = sSetWindowLayoutTypeMethod;
          Object[] arrayOfObject = new Object[1];
          arrayOfObject[0] = Integer.valueOf(paramInt);
          localMethod.invoke(paramPopupWindow, arrayOfObject);
        }
        catch (Exception localException1)
        {
        }
      }
      catch (Exception localException2)
      {
        break label52;
      }
    }
  }

  public static void showAsDropDown(@NonNull PopupWindow paramPopupWindow, @NonNull View paramView, int paramInt1, int paramInt2, int paramInt3)
  {
    if (Build.VERSION.SDK_INT >= 19)
      paramPopupWindow.showAsDropDown(paramView, paramInt1, paramInt2, paramInt3);
    while (true)
    {
      return;
      int i = paramInt1;
      if ((0x7 & GravityCompat.getAbsoluteGravity(paramInt3, ViewCompat.getLayoutDirection(paramView))) == 5)
        i -= paramPopupWindow.getWidth() - paramView.getWidth();
      paramPopupWindow.showAsDropDown(paramView, i, paramInt2);
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.widget.PopupWindowCompat
 * JD-Core Version:    0.6.2
 */