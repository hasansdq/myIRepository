package androidx.core.widget;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Paint.FontMetricsInt;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.text.Editable;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import androidx.annotation.DrawableRes;
import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.Px;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.annotation.StyleRes;
import androidx.core.text.PrecomputedTextCompat;
import androidx.core.text.PrecomputedTextCompat.Params;
import androidx.core.text.PrecomputedTextCompat.Params.Builder;
import androidx.core.util.Preconditions;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class TextViewCompat
{
  public static final int AUTO_SIZE_TEXT_TYPE_NONE = 0;
  public static final int AUTO_SIZE_TEXT_TYPE_UNIFORM = 1;
  private static final int LINES = 1;
  private static final String LOG_TAG = "TextViewCompat";
  private static Field sMaxModeField;
  private static boolean sMaxModeFieldFetched;
  private static Field sMaximumField;
  private static boolean sMaximumFieldFetched;
  private static Field sMinModeField;
  private static boolean sMinModeFieldFetched;
  private static Field sMinimumField;
  private static boolean sMinimumFieldFetched;

  public static int getAutoSizeMaxTextSize(@NonNull TextView paramTextView)
  {
    int i;
    if (Build.VERSION.SDK_INT >= 27)
      i = paramTextView.getAutoSizeMaxTextSize();
    while (true)
    {
      return i;
      if ((paramTextView instanceof AutoSizeableTextView))
        i = ((AutoSizeableTextView)paramTextView).getAutoSizeMaxTextSize();
      else
        i = -1;
    }
  }

  public static int getAutoSizeMinTextSize(@NonNull TextView paramTextView)
  {
    int i;
    if (Build.VERSION.SDK_INT >= 27)
      i = paramTextView.getAutoSizeMinTextSize();
    while (true)
    {
      return i;
      if ((paramTextView instanceof AutoSizeableTextView))
        i = ((AutoSizeableTextView)paramTextView).getAutoSizeMinTextSize();
      else
        i = -1;
    }
  }

  public static int getAutoSizeStepGranularity(@NonNull TextView paramTextView)
  {
    int i;
    if (Build.VERSION.SDK_INT >= 27)
      i = paramTextView.getAutoSizeStepGranularity();
    while (true)
    {
      return i;
      if ((paramTextView instanceof AutoSizeableTextView))
        i = ((AutoSizeableTextView)paramTextView).getAutoSizeStepGranularity();
      else
        i = -1;
    }
  }

  @NonNull
  public static int[] getAutoSizeTextAvailableSizes(@NonNull TextView paramTextView)
  {
    int[] arrayOfInt;
    if (Build.VERSION.SDK_INT >= 27)
      arrayOfInt = paramTextView.getAutoSizeTextAvailableSizes();
    while (true)
    {
      return arrayOfInt;
      if ((paramTextView instanceof AutoSizeableTextView))
        arrayOfInt = ((AutoSizeableTextView)paramTextView).getAutoSizeTextAvailableSizes();
      else
        arrayOfInt = new int[0];
    }
  }

  public static int getAutoSizeTextType(@NonNull TextView paramTextView)
  {
    int i;
    if (Build.VERSION.SDK_INT >= 27)
      i = paramTextView.getAutoSizeTextType();
    while (true)
    {
      return i;
      if ((paramTextView instanceof AutoSizeableTextView))
        i = ((AutoSizeableTextView)paramTextView).getAutoSizeTextType();
      else
        i = 0;
    }
  }

  @NonNull
  public static Drawable[] getCompoundDrawablesRelative(@NonNull TextView paramTextView)
  {
    int i = 1;
    Drawable[] arrayOfDrawable;
    if (Build.VERSION.SDK_INT >= 18)
      arrayOfDrawable = paramTextView.getCompoundDrawablesRelative();
    while (true)
    {
      return arrayOfDrawable;
      if (Build.VERSION.SDK_INT >= 17)
      {
        if (paramTextView.getLayoutDirection() == i);
        while (true)
        {
          arrayOfDrawable = paramTextView.getCompoundDrawables();
          if (i == 0)
            break;
          Drawable localDrawable1 = arrayOfDrawable[2];
          Drawable localDrawable2 = arrayOfDrawable[0];
          arrayOfDrawable[0] = localDrawable1;
          arrayOfDrawable[2] = localDrawable2;
          break;
          i = 0;
        }
      }
      arrayOfDrawable = paramTextView.getCompoundDrawables();
    }
  }

  public static int getFirstBaselineToTopHeight(@NonNull TextView paramTextView)
  {
    return paramTextView.getPaddingTop() - paramTextView.getPaint().getFontMetricsInt().top;
  }

  public static int getLastBaselineToBottomHeight(@NonNull TextView paramTextView)
  {
    return paramTextView.getPaddingBottom() + paramTextView.getPaint().getFontMetricsInt().bottom;
  }

  public static int getMaxLines(@NonNull TextView paramTextView)
  {
    int i;
    if (Build.VERSION.SDK_INT >= 16)
      i = paramTextView.getMaxLines();
    while (true)
    {
      return i;
      if (!sMaxModeFieldFetched)
      {
        sMaxModeField = retrieveField("mMaxMode");
        sMaxModeFieldFetched = true;
      }
      if ((sMaxModeField != null) && (retrieveIntFromField(sMaxModeField, paramTextView) == 1))
      {
        if (!sMaximumFieldFetched)
        {
          sMaximumField = retrieveField("mMaximum");
          sMaximumFieldFetched = true;
        }
        if (sMaximumField != null)
          i = retrieveIntFromField(sMaximumField, paramTextView);
      }
      else
      {
        i = -1;
      }
    }
  }

  public static int getMinLines(@NonNull TextView paramTextView)
  {
    int i;
    if (Build.VERSION.SDK_INT >= 16)
      i = paramTextView.getMinLines();
    while (true)
    {
      return i;
      if (!sMinModeFieldFetched)
      {
        sMinModeField = retrieveField("mMinMode");
        sMinModeFieldFetched = true;
      }
      if ((sMinModeField != null) && (retrieveIntFromField(sMinModeField, paramTextView) == 1))
      {
        if (!sMinimumFieldFetched)
        {
          sMinimumField = retrieveField("mMinimum");
          sMinimumFieldFetched = true;
        }
        if (sMinimumField != null)
          i = retrieveIntFromField(sMinimumField, paramTextView);
      }
      else
      {
        i = -1;
      }
    }
  }

  @RequiresApi(18)
  private static int getTextDirection(@NonNull TextDirectionHeuristic paramTextDirectionHeuristic)
  {
    int i = 1;
    if (paramTextDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_RTL);
    while (true)
    {
      return i;
      if (paramTextDirectionHeuristic != TextDirectionHeuristics.FIRSTSTRONG_LTR)
        if (paramTextDirectionHeuristic == TextDirectionHeuristics.ANYRTL_LTR)
          i = 2;
        else if (paramTextDirectionHeuristic == TextDirectionHeuristics.LTR)
          i = 3;
        else if (paramTextDirectionHeuristic == TextDirectionHeuristics.RTL)
          i = 4;
        else if (paramTextDirectionHeuristic == TextDirectionHeuristics.LOCALE)
          i = 5;
        else if (paramTextDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_LTR)
          i = 6;
        else if (paramTextDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_RTL)
          i = 7;
    }
  }

  @RequiresApi(18)
  private static TextDirectionHeuristic getTextDirectionHeuristic(@NonNull TextView paramTextView)
  {
    int i = 1;
    TextDirectionHeuristic localTextDirectionHeuristic;
    if ((paramTextView.getTransformationMethod() instanceof PasswordTransformationMethod))
      localTextDirectionHeuristic = TextDirectionHeuristics.LTR;
    while (true)
    {
      label16: return localTextDirectionHeuristic;
      if ((Build.VERSION.SDK_INT >= 28) && ((0xF & paramTextView.getInputType()) == 3))
      {
        int j = Character.getDirectionality(android.icu.text.DecimalFormatSymbols.getInstance(paramTextView.getTextLocale()).getDigitStrings()[0].codePointAt(0));
        if ((j == i) || (j == 2))
          localTextDirectionHeuristic = TextDirectionHeuristics.RTL;
        else
          localTextDirectionHeuristic = TextDirectionHeuristics.LTR;
      }
      else
      {
        if (paramTextView.getLayoutDirection() == i);
        while (true)
          switch (paramTextView.getTextDirection())
          {
          default:
            if (i == 0)
              break label148;
            localTextDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_RTL;
            break label16;
            i = 0;
          case 2:
          case 3:
          case 4:
          case 5:
          case 6:
          case 7:
          }
        label148: localTextDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_LTR;
        continue;
        localTextDirectionHeuristic = TextDirectionHeuristics.ANYRTL_LTR;
        continue;
        localTextDirectionHeuristic = TextDirectionHeuristics.LTR;
        continue;
        localTextDirectionHeuristic = TextDirectionHeuristics.RTL;
        continue;
        localTextDirectionHeuristic = TextDirectionHeuristics.LOCALE;
        continue;
        localTextDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_LTR;
        continue;
        localTextDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_RTL;
      }
    }
  }

  @NonNull
  public static PrecomputedTextCompat.Params getTextMetricsParams(@NonNull TextView paramTextView)
  {
    if (Build.VERSION.SDK_INT >= 28);
    PrecomputedTextCompat.Params.Builder localBuilder;
    for (PrecomputedTextCompat.Params localParams = new PrecomputedTextCompat.Params(paramTextView.getTextMetricsParams()); ; localParams = localBuilder.build())
    {
      return localParams;
      localBuilder = new PrecomputedTextCompat.Params.Builder(new TextPaint(paramTextView.getPaint()));
      if (Build.VERSION.SDK_INT >= 23)
      {
        localBuilder.setBreakStrategy(paramTextView.getBreakStrategy());
        localBuilder.setHyphenationFrequency(paramTextView.getHyphenationFrequency());
      }
      if (Build.VERSION.SDK_INT >= 18)
        localBuilder.setTextDirection(getTextDirectionHeuristic(paramTextView));
    }
  }

  private static Field retrieveField(String paramString)
  {
    Field localField = null;
    try
    {
      localField = TextView.class.getDeclaredField(paramString);
      localField.setAccessible(true);
      return localField;
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      while (true)
        Log.e("TextViewCompat", "Could not retrieve " + paramString + " field.");
    }
  }

  private static int retrieveIntFromField(Field paramField, TextView paramTextView)
  {
    try
    {
      int j = paramField.getInt(paramTextView);
      i = j;
      return i;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      while (true)
      {
        Log.d("TextViewCompat", "Could not retrieve value of " + paramField.getName() + " field.");
        int i = -1;
      }
    }
  }

  public static void setAutoSizeTextTypeUniformWithConfiguration(@NonNull TextView paramTextView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws IllegalArgumentException
  {
    if (Build.VERSION.SDK_INT >= 27)
      paramTextView.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
    while (true)
    {
      return;
      if ((paramTextView instanceof AutoSizeableTextView))
        ((AutoSizeableTextView)paramTextView).setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
    }
  }

  public static void setAutoSizeTextTypeUniformWithPresetSizes(@NonNull TextView paramTextView, @NonNull int[] paramArrayOfInt, int paramInt)
    throws IllegalArgumentException
  {
    if (Build.VERSION.SDK_INT >= 27)
      paramTextView.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfInt, paramInt);
    while (true)
    {
      return;
      if ((paramTextView instanceof AutoSizeableTextView))
        ((AutoSizeableTextView)paramTextView).setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfInt, paramInt);
    }
  }

  public static void setAutoSizeTextTypeWithDefaults(@NonNull TextView paramTextView, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 27)
      paramTextView.setAutoSizeTextTypeWithDefaults(paramInt);
    while (true)
    {
      return;
      if ((paramTextView instanceof AutoSizeableTextView))
        ((AutoSizeableTextView)paramTextView).setAutoSizeTextTypeWithDefaults(paramInt);
    }
  }

  public static void setCompoundDrawablesRelative(@NonNull TextView paramTextView, @Nullable Drawable paramDrawable1, @Nullable Drawable paramDrawable2, @Nullable Drawable paramDrawable3, @Nullable Drawable paramDrawable4)
  {
    int i = 1;
    if (Build.VERSION.SDK_INT >= 18)
      paramTextView.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 17)
      {
        label38: Drawable localDrawable;
        if (paramTextView.getLayoutDirection() == i)
        {
          if (i == 0)
            break label70;
          localDrawable = paramDrawable3;
          label46: if (i == 0)
            break label76;
        }
        while (true)
        {
          paramTextView.setCompoundDrawables(localDrawable, paramDrawable2, paramDrawable1, paramDrawable4);
          break;
          i = 0;
          break label38;
          label70: localDrawable = paramDrawable1;
          break label46;
          label76: paramDrawable1 = paramDrawable3;
        }
      }
      paramTextView.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    }
  }

  public static void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView paramTextView, @DrawableRes int paramInt1, @DrawableRes int paramInt2, @DrawableRes int paramInt3, @DrawableRes int paramInt4)
  {
    int i = 1;
    if (Build.VERSION.SDK_INT >= 18)
      paramTextView.setCompoundDrawablesRelativeWithIntrinsicBounds(paramInt1, paramInt2, paramInt3, paramInt4);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 17)
      {
        label38: int j;
        if (paramTextView.getLayoutDirection() == i)
        {
          if (i == 0)
            break label70;
          j = paramInt3;
          label46: if (i == 0)
            break label76;
        }
        while (true)
        {
          paramTextView.setCompoundDrawablesWithIntrinsicBounds(j, paramInt2, paramInt1, paramInt4);
          break;
          i = 0;
          break label38;
          label70: j = paramInt1;
          break label46;
          label76: paramInt1 = paramInt3;
        }
      }
      paramTextView.setCompoundDrawablesWithIntrinsicBounds(paramInt1, paramInt2, paramInt3, paramInt4);
    }
  }

  public static void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView paramTextView, @Nullable Drawable paramDrawable1, @Nullable Drawable paramDrawable2, @Nullable Drawable paramDrawable3, @Nullable Drawable paramDrawable4)
  {
    int i = 1;
    if (Build.VERSION.SDK_INT >= 18)
      paramTextView.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 17)
      {
        label38: Drawable localDrawable;
        if (paramTextView.getLayoutDirection() == i)
        {
          if (i == 0)
            break label70;
          localDrawable = paramDrawable3;
          label46: if (i == 0)
            break label76;
        }
        while (true)
        {
          paramTextView.setCompoundDrawablesWithIntrinsicBounds(localDrawable, paramDrawable2, paramDrawable1, paramDrawable4);
          break;
          i = 0;
          break label38;
          label70: localDrawable = paramDrawable1;
          break label46;
          label76: paramDrawable1 = paramDrawable3;
        }
      }
      paramTextView.setCompoundDrawablesWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    }
  }

  public static void setCustomSelectionActionModeCallback(@NonNull TextView paramTextView, @NonNull ActionMode.Callback paramCallback)
  {
    paramTextView.setCustomSelectionActionModeCallback(wrapCustomSelectionActionModeCallback(paramTextView, paramCallback));
  }

  public static void setFirstBaselineToTopHeight(@NonNull TextView paramTextView, @IntRange(from=0L) @Px int paramInt)
  {
    Preconditions.checkArgumentNonnegative(paramInt);
    if (Build.VERSION.SDK_INT >= 28)
      paramTextView.setFirstBaselineToTopHeight(paramInt);
    label92: 
    while (true)
    {
      return;
      Paint.FontMetricsInt localFontMetricsInt = paramTextView.getPaint().getFontMetricsInt();
      if ((Build.VERSION.SDK_INT < 16) || (paramTextView.getIncludeFontPadding()));
      for (int i = localFontMetricsInt.top; ; i = localFontMetricsInt.ascent)
      {
        if (paramInt <= Math.abs(i))
          break label92;
        int j = paramInt - -i;
        paramTextView.setPadding(paramTextView.getPaddingLeft(), j, paramTextView.getPaddingRight(), paramTextView.getPaddingBottom());
        break;
      }
    }
  }

  public static void setLastBaselineToBottomHeight(@NonNull TextView paramTextView, @IntRange(from=0L) @Px int paramInt)
  {
    Preconditions.checkArgumentNonnegative(paramInt);
    Paint.FontMetricsInt localFontMetricsInt = paramTextView.getPaint().getFontMetricsInt();
    if ((Build.VERSION.SDK_INT < 16) || (paramTextView.getIncludeFontPadding()));
    for (int i = localFontMetricsInt.bottom; ; i = localFontMetricsInt.descent)
    {
      if (paramInt > Math.abs(i))
      {
        int j = paramInt - i;
        paramTextView.setPadding(paramTextView.getPaddingLeft(), paramTextView.getPaddingTop(), paramTextView.getPaddingRight(), j);
      }
      return;
    }
  }

  public static void setLineHeight(@NonNull TextView paramTextView, @IntRange(from=0L) @Px int paramInt)
  {
    Preconditions.checkArgumentNonnegative(paramInt);
    int i = paramTextView.getPaint().getFontMetricsInt(null);
    if (paramInt != i)
      paramTextView.setLineSpacing(paramInt - i, 1.0F);
  }

  public static void setPrecomputedText(@NonNull TextView paramTextView, @NonNull PrecomputedTextCompat paramPrecomputedTextCompat)
  {
    if (Build.VERSION.SDK_INT >= 28)
      paramTextView.setText(paramPrecomputedTextCompat.getPrecomputedText());
    while (true)
    {
      return;
      if (!getTextMetricsParams(paramTextView).equals(paramPrecomputedTextCompat.getParams()))
        throw new IllegalArgumentException("Given text can not be applied to TextView.");
      paramTextView.setText(paramPrecomputedTextCompat);
    }
  }

  public static void setTextAppearance(@NonNull TextView paramTextView, @StyleRes int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 23)
      paramTextView.setTextAppearance(paramInt);
    while (true)
    {
      return;
      paramTextView.setTextAppearance(paramTextView.getContext(), paramInt);
    }
  }

  public static void setTextMetricsParams(@NonNull TextView paramTextView, @NonNull PrecomputedTextCompat.Params paramParams)
  {
    if (Build.VERSION.SDK_INT >= 18)
      paramTextView.setTextDirection(getTextDirection(paramParams.getTextDirection()));
    if (Build.VERSION.SDK_INT < 23)
    {
      float f = paramParams.getTextPaint().getTextScaleX();
      paramTextView.getPaint().set(paramParams.getTextPaint());
      if (f == paramTextView.getTextScaleX())
        paramTextView.setTextScaleX(1.0F + f / 2.0F);
      paramTextView.setTextScaleX(f);
    }
    while (true)
    {
      return;
      paramTextView.getPaint().set(paramParams.getTextPaint());
      paramTextView.setBreakStrategy(paramParams.getBreakStrategy());
      paramTextView.setHyphenationFrequency(paramParams.getHyphenationFrequency());
    }
  }

  @NonNull
  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public static ActionMode.Callback wrapCustomSelectionActionModeCallback(@NonNull TextView paramTextView, @NonNull ActionMode.Callback paramCallback)
  {
    if ((Build.VERSION.SDK_INT < 26) || (Build.VERSION.SDK_INT > 27) || ((paramCallback instanceof OreoCallback)));
    while (true)
    {
      return paramCallback;
      paramCallback = new OreoCallback(paramCallback, paramTextView);
    }
  }

  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface AutoSizeTextType
  {
  }

  @RequiresApi(26)
  private static class OreoCallback
    implements ActionMode.Callback
  {
    private static final int MENU_ITEM_ORDER_PROCESS_TEXT_INTENT_ACTIONS_START = 100;
    private final ActionMode.Callback mCallback;
    private boolean mCanUseMenuBuilderReferences;
    private boolean mInitializedMenuBuilderReferences;
    private Class mMenuBuilderClass;
    private Method mMenuBuilderRemoveItemAtMethod;
    private final TextView mTextView;

    OreoCallback(ActionMode.Callback paramCallback, TextView paramTextView)
    {
      this.mCallback = paramCallback;
      this.mTextView = paramTextView;
      this.mInitializedMenuBuilderReferences = false;
    }

    private Intent createProcessTextIntent()
    {
      return new Intent().setAction("android.intent.action.PROCESS_TEXT").setType("text/plain");
    }

    private Intent createProcessTextIntentForResolveInfo(ResolveInfo paramResolveInfo, TextView paramTextView)
    {
      Intent localIntent = createProcessTextIntent();
      if (!isEditable(paramTextView));
      for (boolean bool = true; ; bool = false)
        return localIntent.putExtra("android.intent.extra.PROCESS_TEXT_READONLY", bool).setClassName(paramResolveInfo.activityInfo.packageName, paramResolveInfo.activityInfo.name);
    }

    private List<ResolveInfo> getSupportedActivities(Context paramContext, PackageManager paramPackageManager)
    {
      ArrayList localArrayList = new ArrayList();
      if (!(paramContext instanceof Activity));
      while (true)
      {
        return localArrayList;
        Iterator localIterator = paramPackageManager.queryIntentActivities(createProcessTextIntent(), 0).iterator();
        while (localIterator.hasNext())
        {
          ResolveInfo localResolveInfo = (ResolveInfo)localIterator.next();
          if (isSupportedActivity(localResolveInfo, paramContext))
            localArrayList.add(localResolveInfo);
        }
      }
    }

    private boolean isEditable(TextView paramTextView)
    {
      if (((paramTextView instanceof Editable)) && (paramTextView.onCheckIsTextEditor()) && (paramTextView.isEnabled()));
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    private boolean isSupportedActivity(ResolveInfo paramResolveInfo, Context paramContext)
    {
      boolean bool = false;
      if (paramContext.getPackageName().equals(paramResolveInfo.activityInfo.packageName));
      for (bool = true; ; bool = true)
        do
          return bool;
        while ((!paramResolveInfo.activityInfo.exported) || ((paramResolveInfo.activityInfo.permission != null) && (paramContext.checkSelfPermission(paramResolveInfo.activityInfo.permission) != 0)));
    }

    // ERROR //
    private void recomputeProcessTextMenuItems(Menu paramMenu)
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 32	androidx/core/widget/TextViewCompat$OreoCallback:mTextView	Landroid/widget/TextView;
      //   4: invokevirtual 165	android/widget/TextView:getContext	()Landroid/content/Context;
      //   7: astore_2
      //   8: aload_2
      //   9: invokevirtual 169	android/content/Context:getPackageManager	()Landroid/content/pm/PackageManager;
      //   12: astore_3
      //   13: aload_0
      //   14: getfield 34	androidx/core/widget/TextViewCompat$OreoCallback:mInitializedMenuBuilderReferences	Z
      //   17: ifne +54 -> 71
      //   20: aload_0
      //   21: iconst_1
      //   22: putfield 34	androidx/core/widget/TextViewCompat$OreoCallback:mInitializedMenuBuilderReferences	Z
      //   25: aload_0
      //   26: ldc 171
      //   28: invokestatic 177	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
      //   31: putfield 179	androidx/core/widget/TextViewCompat$OreoCallback:mMenuBuilderClass	Ljava/lang/Class;
      //   34: aload_0
      //   35: getfield 179	androidx/core/widget/TextViewCompat$OreoCallback:mMenuBuilderClass	Ljava/lang/Class;
      //   38: astore 20
      //   40: iconst_1
      //   41: anewarray 173	java/lang/Class
      //   44: astore 21
      //   46: aload 21
      //   48: iconst_0
      //   49: getstatic 184	java/lang/Integer:TYPE	Ljava/lang/Class;
      //   52: aastore
      //   53: aload_0
      //   54: aload 20
      //   56: ldc 186
      //   58: aload 21
      //   60: invokevirtual 190	java/lang/Class:getDeclaredMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   63: putfield 192	androidx/core/widget/TextViewCompat$OreoCallback:mMenuBuilderRemoveItemAtMethod	Ljava/lang/reflect/Method;
      //   66: aload_0
      //   67: iconst_1
      //   68: putfield 194	androidx/core/widget/TextViewCompat$OreoCallback:mCanUseMenuBuilderReferences	Z
      //   71: aload_0
      //   72: getfield 194	androidx/core/widget/TextViewCompat$OreoCallback:mCanUseMenuBuilderReferences	Z
      //   75: ifeq +123 -> 198
      //   78: aload_0
      //   79: getfield 179	androidx/core/widget/TextViewCompat$OreoCallback:mMenuBuilderClass	Ljava/lang/Class;
      //   82: aload_1
      //   83: invokevirtual 197	java/lang/Class:isInstance	(Ljava/lang/Object;)Z
      //   86: ifeq +112 -> 198
      //   89: aload_0
      //   90: getfield 192	androidx/core/widget/TextViewCompat$OreoCallback:mMenuBuilderRemoveItemAtMethod	Ljava/lang/reflect/Method;
      //   93: astore 10
      //   95: iconst_m1
      //   96: aload_1
      //   97: invokeinterface 203 1 0
      //   102: iadd
      //   103: istore 11
      //   105: iload 11
      //   107: iflt +131 -> 238
      //   110: aload_1
      //   111: iload 11
      //   113: invokeinterface 207 2 0
      //   118: astore 15
      //   120: aload 15
      //   122: invokeinterface 212 1 0
      //   127: ifnull +45 -> 172
      //   130: ldc 41
      //   132: aload 15
      //   134: invokeinterface 212 1 0
      //   139: invokevirtual 215	android/content/Intent:getAction	()Ljava/lang/String;
      //   142: invokevirtual 141	java/lang/String:equals	(Ljava/lang/Object;)Z
      //   145: ifeq +27 -> 172
      //   148: iconst_1
      //   149: anewarray 4	java/lang/Object
      //   152: astore 16
      //   154: aload 16
      //   156: iconst_0
      //   157: iload 11
      //   159: invokestatic 219	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
      //   162: aastore
      //   163: aload 10
      //   165: aload_1
      //   166: aload 16
      //   168: invokevirtual 225	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   171: pop
      //   172: iinc 11 255
      //   175: goto -70 -> 105
      //   178: astore 19
      //   180: aload_0
      //   181: aconst_null
      //   182: putfield 179	androidx/core/widget/TextViewCompat$OreoCallback:mMenuBuilderClass	Ljava/lang/Class;
      //   185: aload_0
      //   186: aconst_null
      //   187: putfield 192	androidx/core/widget/TextViewCompat$OreoCallback:mMenuBuilderRemoveItemAtMethod	Ljava/lang/reflect/Method;
      //   190: aload_0
      //   191: iconst_0
      //   192: putfield 194	androidx/core/widget/TextViewCompat$OreoCallback:mCanUseMenuBuilderReferences	Z
      //   195: goto -124 -> 71
      //   198: aload_1
      //   199: invokevirtual 229	java/lang/Object:getClass	()Ljava/lang/Class;
      //   202: astore 7
      //   204: iconst_1
      //   205: anewarray 173	java/lang/Class
      //   208: astore 8
      //   210: aload 8
      //   212: iconst_0
      //   213: getstatic 184	java/lang/Integer:TYPE	Ljava/lang/Class;
      //   216: aastore
      //   217: aload 7
      //   219: ldc 186
      //   221: aload 8
      //   223: invokevirtual 190	java/lang/Class:getDeclaredMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   226: astore 9
      //   228: aload 9
      //   230: astore 10
      //   232: goto -137 -> 95
      //   235: astore 6
      //   237: return
      //   238: aload_0
      //   239: aload_2
      //   240: aload_3
      //   241: invokespecial 231	androidx/core/widget/TextViewCompat$OreoCallback:getSupportedActivities	(Landroid/content/Context;Landroid/content/pm/PackageManager;)Ljava/util/List;
      //   244: astore 12
      //   246: iconst_0
      //   247: istore 13
      //   249: iload 13
      //   251: aload 12
      //   253: invokeinterface 232 1 0
      //   258: if_icmpge -21 -> 237
      //   261: aload 12
      //   263: iload 13
      //   265: invokeinterface 236 2 0
      //   270: checkcast 66	android/content/pm/ResolveInfo
      //   273: astore 14
      //   275: aload_1
      //   276: iconst_0
      //   277: iconst_0
      //   278: iload 13
      //   280: bipush 100
      //   282: iadd
      //   283: aload 14
      //   285: aload_3
      //   286: invokevirtual 240	android/content/pm/ResolveInfo:loadLabel	(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;
      //   289: invokeinterface 243 5 0
      //   294: aload_0
      //   295: aload 14
      //   297: aload_0
      //   298: getfield 32	androidx/core/widget/TextViewCompat$OreoCallback:mTextView	Landroid/widget/TextView;
      //   301: invokespecial 245	androidx/core/widget/TextViewCompat$OreoCallback:createProcessTextIntentForResolveInfo	(Landroid/content/pm/ResolveInfo;Landroid/widget/TextView;)Landroid/content/Intent;
      //   304: invokeinterface 249 2 0
      //   309: iconst_1
      //   310: invokeinterface 253 2 0
      //   315: iinc 13 1
      //   318: goto -69 -> 249
      //   321: astore 5
      //   323: goto -86 -> 237
      //   326: astore 4
      //   328: goto -91 -> 237
      //   331: astore 18
      //   333: goto -153 -> 180
      //
      // Exception table:
      //   from	to	target	type
      //   25	71	178	java/lang/ClassNotFoundException
      //   71	172	235	java/lang/IllegalAccessException
      //   198	228	235	java/lang/IllegalAccessException
      //   71	172	321	java/lang/NoSuchMethodException
      //   198	228	321	java/lang/NoSuchMethodException
      //   71	172	326	java/lang/reflect/InvocationTargetException
      //   198	228	326	java/lang/reflect/InvocationTargetException
      //   25	71	331	java/lang/NoSuchMethodException
    }

    public boolean onActionItemClicked(ActionMode paramActionMode, MenuItem paramMenuItem)
    {
      return this.mCallback.onActionItemClicked(paramActionMode, paramMenuItem);
    }

    public boolean onCreateActionMode(ActionMode paramActionMode, Menu paramMenu)
    {
      return this.mCallback.onCreateActionMode(paramActionMode, paramMenu);
    }

    public void onDestroyActionMode(ActionMode paramActionMode)
    {
      this.mCallback.onDestroyActionMode(paramActionMode);
    }

    public boolean onPrepareActionMode(ActionMode paramActionMode, Menu paramMenu)
    {
      recomputeProcessTextMenuItems(paramMenu);
      return this.mCallback.onPrepareActionMode(paramActionMode, paramMenu);
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.widget.TextViewCompat
 * JD-Core Version:    0.6.2
 */