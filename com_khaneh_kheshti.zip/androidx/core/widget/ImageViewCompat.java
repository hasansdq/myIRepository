package androidx.core.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class ImageViewCompat
{
  @Nullable
  public static ColorStateList getImageTintList(@NonNull ImageView paramImageView)
  {
    ColorStateList localColorStateList;
    if (Build.VERSION.SDK_INT >= 21)
      localColorStateList = paramImageView.getImageTintList();
    while (true)
    {
      return localColorStateList;
      if ((paramImageView instanceof TintableImageSourceView))
        localColorStateList = ((TintableImageSourceView)paramImageView).getSupportImageTintList();
      else
        localColorStateList = null;
    }
  }

  @Nullable
  public static PorterDuff.Mode getImageTintMode(@NonNull ImageView paramImageView)
  {
    PorterDuff.Mode localMode;
    if (Build.VERSION.SDK_INT >= 21)
      localMode = paramImageView.getImageTintMode();
    while (true)
    {
      return localMode;
      if ((paramImageView instanceof TintableImageSourceView))
        localMode = ((TintableImageSourceView)paramImageView).getSupportImageTintMode();
      else
        localMode = null;
    }
  }

  public static void setImageTintList(@NonNull ImageView paramImageView, @Nullable ColorStateList paramColorStateList)
  {
    int i;
    if (Build.VERSION.SDK_INT >= 21)
    {
      paramImageView.setImageTintList(paramColorStateList);
      if (Build.VERSION.SDK_INT == 21)
      {
        Drawable localDrawable = paramImageView.getDrawable();
        if ((paramImageView.getImageTintList() == null) || (paramImageView.getImageTintMode() == null))
          break label72;
        i = 1;
        if ((localDrawable != null) && (i != 0))
        {
          if (localDrawable.isStateful())
            localDrawable.setState(paramImageView.getDrawableState());
          paramImageView.setImageDrawable(localDrawable);
        }
      }
    }
    while (true)
    {
      return;
      label72: i = 0;
      break;
      if ((paramImageView instanceof TintableImageSourceView))
        ((TintableImageSourceView)paramImageView).setSupportImageTintList(paramColorStateList);
    }
  }

  public static void setImageTintMode(@NonNull ImageView paramImageView, @Nullable PorterDuff.Mode paramMode)
  {
    int i;
    if (Build.VERSION.SDK_INT >= 21)
    {
      paramImageView.setImageTintMode(paramMode);
      if (Build.VERSION.SDK_INT == 21)
      {
        Drawable localDrawable = paramImageView.getDrawable();
        if ((paramImageView.getImageTintList() == null) || (paramImageView.getImageTintMode() == null))
          break label72;
        i = 1;
        if ((localDrawable != null) && (i != 0))
        {
          if (localDrawable.isStateful())
            localDrawable.setState(paramImageView.getDrawableState());
          paramImageView.setImageDrawable(localDrawable);
        }
      }
    }
    while (true)
    {
      return;
      label72: i = 0;
      break;
      if ((paramImageView instanceof TintableImageSourceView))
        ((TintableImageSourceView)paramImageView).setSupportImageTintMode(paramMode);
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.widget.ImageViewCompat
 * JD-Core Version:    0.6.2
 */