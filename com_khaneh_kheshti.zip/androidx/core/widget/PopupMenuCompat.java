package androidx.core.widget;

import android.os.Build.VERSION;
import android.view.View.OnTouchListener;
import android.widget.PopupMenu;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public final class PopupMenuCompat
{
  @Nullable
  public static View.OnTouchListener getDragToOpenListener(@NonNull Object paramObject)
  {
    if (Build.VERSION.SDK_INT >= 19);
    for (View.OnTouchListener localOnTouchListener = ((PopupMenu)paramObject).getDragToOpenListener(); ; localOnTouchListener = null)
      return localOnTouchListener;
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.widget.PopupMenuCompat
 * JD-Core Version:    0.6.2
 */