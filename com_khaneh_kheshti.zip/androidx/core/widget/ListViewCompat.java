package androidx.core.widget;

import android.os.Build.VERSION;
import android.view.View;
import android.widget.ListView;
import androidx.annotation.NonNull;

public final class ListViewCompat
{
  public static boolean canScrollList(@NonNull ListView paramListView, int paramInt)
  {
    boolean bool = false;
    if (Build.VERSION.SDK_INT >= 19)
      bool = paramListView.canScrollList(paramInt);
    while (true)
    {
      return bool;
      int i = paramListView.getChildCount();
      if (i != 0)
      {
        int j = paramListView.getFirstVisiblePosition();
        if (paramInt > 0)
        {
          int m = paramListView.getChildAt(i - 1).getBottom();
          if ((j + i < paramListView.getCount()) || (m > paramListView.getHeight() - paramListView.getListPaddingBottom()))
            bool = true;
        }
        else
        {
          int k = paramListView.getChildAt(0).getTop();
          if ((j > 0) || (k < paramListView.getListPaddingTop()))
            bool = true;
        }
      }
    }
  }

  public static void scrollListBy(@NonNull ListView paramListView, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 19)
      paramListView.scrollListBy(paramInt);
    while (true)
    {
      return;
      int i = paramListView.getFirstVisiblePosition();
      if (i != -1)
      {
        View localView = paramListView.getChildAt(0);
        if (localView != null)
          paramListView.setSelectionFromTop(i, localView.getTop() - paramInt);
      }
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.widget.ListViewCompat
 * JD-Core Version:    0.6.2
 */