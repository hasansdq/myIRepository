package androidx.core.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public abstract interface TintableImageSourceView
{
  @Nullable
  public abstract ColorStateList getSupportImageTintList();

  @Nullable
  public abstract PorterDuff.Mode getSupportImageTintMode();

  public abstract void setSupportImageTintList(@Nullable ColorStateList paramColorStateList);

  public abstract void setSupportImageTintMode(@Nullable PorterDuff.Mode paramMode);
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.widget.TintableImageSourceView
 * JD-Core Version:    0.6.2
 */