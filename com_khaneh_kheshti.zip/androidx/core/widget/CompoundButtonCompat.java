package androidx.core.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.Log;
import android.widget.CompoundButton;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.lang.reflect.Field;

public final class CompoundButtonCompat
{
  private static final String TAG = "CompoundButtonCompat";
  private static Field sButtonDrawableField;
  private static boolean sButtonDrawableFieldFetched;

  @Nullable
  public static Drawable getButtonDrawable(@NonNull CompoundButton paramCompoundButton)
  {
    Drawable localDrawable;
    if (Build.VERSION.SDK_INT >= 23)
      localDrawable = paramCompoundButton.getButtonDrawable();
    while (true)
    {
      return localDrawable;
      if (!sButtonDrawableFieldFetched);
      try
      {
        sButtonDrawableField = CompoundButton.class.getDeclaredField("mButtonDrawable");
        sButtonDrawableField.setAccessible(true);
        sButtonDrawableFieldFetched = true;
        if (sButtonDrawableField == null);
      }
      catch (NoSuchFieldException localNoSuchFieldException)
      {
        try
        {
          localDrawable = (Drawable)sButtonDrawableField.get(paramCompoundButton);
          continue;
          localNoSuchFieldException = localNoSuchFieldException;
          Log.i("CompoundButtonCompat", "Failed to retrieve mButtonDrawable field", localNoSuchFieldException);
        }
        catch (IllegalAccessException localIllegalAccessException)
        {
          Log.i("CompoundButtonCompat", "Failed to get button drawable via reflection", localIllegalAccessException);
          sButtonDrawableField = null;
        }
        localDrawable = null;
      }
    }
  }

  @Nullable
  public static ColorStateList getButtonTintList(@NonNull CompoundButton paramCompoundButton)
  {
    ColorStateList localColorStateList;
    if (Build.VERSION.SDK_INT >= 21)
      localColorStateList = paramCompoundButton.getButtonTintList();
    while (true)
    {
      return localColorStateList;
      if ((paramCompoundButton instanceof TintableCompoundButton))
        localColorStateList = ((TintableCompoundButton)paramCompoundButton).getSupportButtonTintList();
      else
        localColorStateList = null;
    }
  }

  @Nullable
  public static PorterDuff.Mode getButtonTintMode(@NonNull CompoundButton paramCompoundButton)
  {
    PorterDuff.Mode localMode;
    if (Build.VERSION.SDK_INT >= 21)
      localMode = paramCompoundButton.getButtonTintMode();
    while (true)
    {
      return localMode;
      if ((paramCompoundButton instanceof TintableCompoundButton))
        localMode = ((TintableCompoundButton)paramCompoundButton).getSupportButtonTintMode();
      else
        localMode = null;
    }
  }

  public static void setButtonTintList(@NonNull CompoundButton paramCompoundButton, @Nullable ColorStateList paramColorStateList)
  {
    if (Build.VERSION.SDK_INT >= 21)
      paramCompoundButton.setButtonTintList(paramColorStateList);
    while (true)
    {
      return;
      if ((paramCompoundButton instanceof TintableCompoundButton))
        ((TintableCompoundButton)paramCompoundButton).setSupportButtonTintList(paramColorStateList);
    }
  }

  public static void setButtonTintMode(@NonNull CompoundButton paramCompoundButton, @Nullable PorterDuff.Mode paramMode)
  {
    if (Build.VERSION.SDK_INT >= 21)
      paramCompoundButton.setButtonTintMode(paramMode);
    while (true)
    {
      return;
      if ((paramCompoundButton instanceof TintableCompoundButton))
        ((TintableCompoundButton)paramCompoundButton).setSupportButtonTintMode(paramMode);
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.widget.CompoundButtonCompat
 * JD-Core Version:    0.6.2
 */