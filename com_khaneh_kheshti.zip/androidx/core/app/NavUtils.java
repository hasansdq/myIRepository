package androidx.core.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public final class NavUtils
{
  public static final String PARENT_ACTIVITY = "android.support.PARENT_ACTIVITY";
  private static final String TAG = "NavUtils";

  @Nullable
  public static Intent getParentActivityIntent(@NonNull Activity paramActivity)
  {
    Object localObject1;
    if (Build.VERSION.SDK_INT >= 16)
    {
      localObject1 = paramActivity.getParentActivityIntent();
      if (localObject1 == null);
    }
    while (true)
    {
      return localObject1;
      String str = getParentActivityName(paramActivity);
      if (str == null)
      {
        localObject1 = null;
      }
      else
      {
        ComponentName localComponentName = new ComponentName(paramActivity, str);
        Object localObject2;
        try
        {
          if (getParentActivityName(paramActivity, localComponentName) == null)
          {
            localObject2 = Intent.makeMainActivity(localComponentName);
          }
          else
          {
            Intent localIntent = new Intent().setComponent(localComponentName);
            localObject2 = localIntent;
          }
        }
        catch (PackageManager.NameNotFoundException localNameNotFoundException)
        {
          Log.e("NavUtils", "getParentActivityIntent: bad parentActivityName '" + str + "' in manifest");
          localObject1 = null;
        }
        continue;
        localObject1 = localObject2;
      }
    }
  }

  @Nullable
  public static Intent getParentActivityIntent(@NonNull Context paramContext, @NonNull ComponentName paramComponentName)
    throws PackageManager.NameNotFoundException
  {
    String str = getParentActivityName(paramContext, paramComponentName);
    if (str == null)
    {
      localIntent = null;
      return localIntent;
    }
    ComponentName localComponentName = new ComponentName(paramComponentName.getPackageName(), str);
    if (getParentActivityName(paramContext, localComponentName) == null);
    for (Intent localIntent = Intent.makeMainActivity(localComponentName); ; localIntent = new Intent().setComponent(localComponentName))
      break;
  }

  @Nullable
  public static Intent getParentActivityIntent(@NonNull Context paramContext, @NonNull Class<?> paramClass)
    throws PackageManager.NameNotFoundException
  {
    String str = getParentActivityName(paramContext, new ComponentName(paramContext, paramClass));
    if (str == null)
    {
      localIntent = null;
      return localIntent;
    }
    ComponentName localComponentName = new ComponentName(paramContext, str);
    if (getParentActivityName(paramContext, localComponentName) == null);
    for (Intent localIntent = Intent.makeMainActivity(localComponentName); ; localIntent = new Intent().setComponent(localComponentName))
      break;
  }

  @Nullable
  public static String getParentActivityName(@NonNull Activity paramActivity)
  {
    try
    {
      String str = getParentActivityName(paramActivity, paramActivity.getComponentName());
      return str;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      throw new IllegalArgumentException(localNameNotFoundException);
    }
  }

  @Nullable
  public static String getParentActivityName(@NonNull Context paramContext, @NonNull ComponentName paramComponentName)
    throws PackageManager.NameNotFoundException
  {
    ActivityInfo localActivityInfo = paramContext.getPackageManager().getActivityInfo(paramComponentName, 128);
    Object localObject;
    if (Build.VERSION.SDK_INT >= 16)
    {
      localObject = localActivityInfo.parentActivityName;
      if (localObject == null);
    }
    while (true)
    {
      return localObject;
      if (localActivityInfo.metaData == null)
      {
        localObject = null;
      }
      else
      {
        String str = localActivityInfo.metaData.getString("android.support.PARENT_ACTIVITY");
        if (str == null)
        {
          localObject = null;
        }
        else
        {
          if (str.charAt(0) == '.')
            str = paramContext.getPackageName() + str;
          localObject = str;
        }
      }
    }
  }

  public static void navigateUpFromSameTask(@NonNull Activity paramActivity)
  {
    Intent localIntent = getParentActivityIntent(paramActivity);
    if (localIntent == null)
      throw new IllegalArgumentException("Activity " + paramActivity.getClass().getSimpleName() + " does not have a parent activity name specified." + " (Did you forget to add the android.support.PARENT_ACTIVITY <meta-data> " + " element in your manifest?)");
    navigateUpTo(paramActivity, localIntent);
  }

  public static void navigateUpTo(@NonNull Activity paramActivity, @NonNull Intent paramIntent)
  {
    if (Build.VERSION.SDK_INT >= 16)
      paramActivity.navigateUpTo(paramIntent);
    while (true)
    {
      return;
      paramIntent.addFlags(67108864);
      paramActivity.startActivity(paramIntent);
      paramActivity.finish();
    }
  }

  public static boolean shouldUpRecreateTask(@NonNull Activity paramActivity, @NonNull Intent paramIntent)
  {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 16)
      bool = paramActivity.shouldUpRecreateTask(paramIntent);
    while (true)
    {
      return bool;
      String str = paramActivity.getIntent().getAction();
      if ((str != null) && (!str.equals("android.intent.action.MAIN")))
        bool = true;
      else
        bool = false;
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.app.NavUtils
 * JD-Core Version:    0.6.2
 */