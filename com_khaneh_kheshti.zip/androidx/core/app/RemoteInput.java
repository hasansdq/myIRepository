package androidx.core.app;

import android.content.ClipData;
import android.content.ClipData.Item;
import android.content.ClipDescription;
import android.content.Intent;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public final class RemoteInput
{
  private static final String EXTRA_DATA_TYPE_RESULTS_DATA = "android.remoteinput.dataTypeResultsData";
  public static final String EXTRA_RESULTS_DATA = "android.remoteinput.resultsData";
  public static final String RESULTS_CLIP_LABEL = "android.remoteinput.results";
  private static final String TAG = "RemoteInput";
  private final boolean mAllowFreeFormTextInput;
  private final Set<String> mAllowedDataTypes;
  private final CharSequence[] mChoices;
  private final Bundle mExtras;
  private final CharSequence mLabel;
  private final String mResultKey;

  RemoteInput(String paramString, CharSequence paramCharSequence, CharSequence[] paramArrayOfCharSequence, boolean paramBoolean, Bundle paramBundle, Set<String> paramSet)
  {
    this.mResultKey = paramString;
    this.mLabel = paramCharSequence;
    this.mChoices = paramArrayOfCharSequence;
    this.mAllowFreeFormTextInput = paramBoolean;
    this.mExtras = paramBundle;
    this.mAllowedDataTypes = paramSet;
  }

  public static void addDataResultToIntent(RemoteInput paramRemoteInput, Intent paramIntent, Map<String, Uri> paramMap)
  {
    if (Build.VERSION.SDK_INT >= 26)
      android.app.RemoteInput.addDataResultToIntent(fromCompat(paramRemoteInput), paramIntent, paramMap);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 16)
      {
        Intent localIntent = getClipDataIntentFromIntent(paramIntent);
        if (localIntent == null)
          localIntent = new Intent();
        Iterator localIterator = paramMap.entrySet().iterator();
        while (localIterator.hasNext())
        {
          Map.Entry localEntry = (Map.Entry)localIterator.next();
          String str = (String)localEntry.getKey();
          Uri localUri = (Uri)localEntry.getValue();
          if (str != null)
          {
            Bundle localBundle = localIntent.getBundleExtra(getExtraResultsKeyForData(str));
            if (localBundle == null)
              localBundle = new Bundle();
            localBundle.putString(paramRemoteInput.getResultKey(), localUri.toString());
            localIntent.putExtra(getExtraResultsKeyForData(str), localBundle);
          }
        }
        paramIntent.setClipData(ClipData.newIntent("android.remoteinput.results", localIntent));
      }
      else
      {
        Log.w("RemoteInput", "RemoteInput is only supported from API Level 16");
      }
    }
  }

  public static void addResultsToIntent(RemoteInput[] paramArrayOfRemoteInput, Intent paramIntent, Bundle paramBundle)
  {
    int i = 0;
    if (Build.VERSION.SDK_INT >= 26)
      android.app.RemoteInput.addResultsToIntent(fromCompat(paramArrayOfRemoteInput), paramIntent, paramBundle);
    while (true)
    {
      return;
      if (Build.VERSION.SDK_INT >= 20)
      {
        Bundle localBundle2 = getResultsFromIntent(paramIntent);
        if (localBundle2 == null)
          localBundle2 = paramBundle;
        while (true)
        {
          int k = paramArrayOfRemoteInput.length;
          for (int m = 0; m < k; m++)
          {
            RemoteInput localRemoteInput2 = paramArrayOfRemoteInput[m];
            Map localMap = getDataResultsFromIntent(paramIntent, localRemoteInput2.getResultKey());
            android.app.RemoteInput.addResultsToIntent(fromCompat(new RemoteInput[] { localRemoteInput2 }), paramIntent, localBundle2);
            if (localMap != null)
              addDataResultToIntent(localRemoteInput2, paramIntent, localMap);
          }
          break;
          localBundle2.putAll(paramBundle);
        }
      }
      if (Build.VERSION.SDK_INT >= 16)
      {
        Intent localIntent = getClipDataIntentFromIntent(paramIntent);
        if (localIntent == null)
          localIntent = new Intent();
        Bundle localBundle1 = localIntent.getBundleExtra("android.remoteinput.resultsData");
        if (localBundle1 == null)
          localBundle1 = new Bundle();
        int j = paramArrayOfRemoteInput.length;
        while (i < j)
        {
          RemoteInput localRemoteInput1 = paramArrayOfRemoteInput[i];
          Object localObject = paramBundle.get(localRemoteInput1.getResultKey());
          if ((localObject instanceof CharSequence))
            localBundle1.putCharSequence(localRemoteInput1.getResultKey(), (CharSequence)localObject);
          i++;
        }
        localIntent.putExtra("android.remoteinput.resultsData", localBundle1);
        paramIntent.setClipData(ClipData.newIntent("android.remoteinput.results", localIntent));
      }
      else
      {
        Log.w("RemoteInput", "RemoteInput is only supported from API Level 16");
      }
    }
  }

  @RequiresApi(20)
  static android.app.RemoteInput fromCompat(RemoteInput paramRemoteInput)
  {
    return new android.app.RemoteInput.Builder(paramRemoteInput.getResultKey()).setLabel(paramRemoteInput.getLabel()).setChoices(paramRemoteInput.getChoices()).setAllowFreeFormInput(paramRemoteInput.getAllowFreeFormInput()).addExtras(paramRemoteInput.getExtras()).build();
  }

  @RequiresApi(20)
  static android.app.RemoteInput[] fromCompat(RemoteInput[] paramArrayOfRemoteInput)
  {
    android.app.RemoteInput[] arrayOfRemoteInput;
    if (paramArrayOfRemoteInput == null)
      arrayOfRemoteInput = null;
    while (true)
    {
      return arrayOfRemoteInput;
      arrayOfRemoteInput = new android.app.RemoteInput[paramArrayOfRemoteInput.length];
      for (int i = 0; i < paramArrayOfRemoteInput.length; i++)
        arrayOfRemoteInput[i] = fromCompat(paramArrayOfRemoteInput[i]);
    }
  }

  @RequiresApi(16)
  private static Intent getClipDataIntentFromIntent(Intent paramIntent)
  {
    Intent localIntent = null;
    ClipData localClipData = paramIntent.getClipData();
    if (localClipData == null);
    while (true)
    {
      return localIntent;
      ClipDescription localClipDescription = localClipData.getDescription();
      if ((localClipDescription.hasMimeType("text/vnd.android.intent")) && (localClipDescription.getLabel().equals("android.remoteinput.results")))
        localIntent = localClipData.getItemAt(0).getIntent();
    }
  }

  public static Map<String, Uri> getDataResultsFromIntent(Intent paramIntent, String paramString)
  {
    Object localObject = null;
    if (Build.VERSION.SDK_INT >= 26)
      localObject = android.app.RemoteInput.getDataResultsFromIntent(paramIntent, paramString);
    while (true)
    {
      return localObject;
      if (Build.VERSION.SDK_INT >= 16)
      {
        Intent localIntent = getClipDataIntentFromIntent(paramIntent);
        if (localIntent != null)
        {
          HashMap localHashMap = new HashMap();
          Iterator localIterator = localIntent.getExtras().keySet().iterator();
          while (localIterator.hasNext())
          {
            String str1 = (String)localIterator.next();
            if (str1.startsWith("android.remoteinput.dataTypeResultsData"))
            {
              String str2 = str1.substring("android.remoteinput.dataTypeResultsData".length());
              if (!str2.isEmpty())
              {
                String str3 = localIntent.getBundleExtra(str1).getString(paramString);
                if ((str3 != null) && (!str3.isEmpty()))
                  localHashMap.put(str2, Uri.parse(str3));
              }
            }
          }
          if (localHashMap.isEmpty())
            localHashMap = null;
          localObject = localHashMap;
        }
      }
      else
      {
        Log.w("RemoteInput", "RemoteInput is only supported from API Level 16");
      }
    }
  }

  private static String getExtraResultsKeyForData(String paramString)
  {
    return "android.remoteinput.dataTypeResultsData" + paramString;
  }

  public static Bundle getResultsFromIntent(Intent paramIntent)
  {
    Bundle localBundle = null;
    if (Build.VERSION.SDK_INT >= 20)
      localBundle = android.app.RemoteInput.getResultsFromIntent(paramIntent);
    while (true)
    {
      return localBundle;
      if (Build.VERSION.SDK_INT >= 16)
      {
        Intent localIntent = getClipDataIntentFromIntent(paramIntent);
        if (localIntent != null)
          localBundle = (Bundle)localIntent.getExtras().getParcelable("android.remoteinput.resultsData");
      }
      else
      {
        Log.w("RemoteInput", "RemoteInput is only supported from API Level 16");
      }
    }
  }

  public boolean getAllowFreeFormInput()
  {
    return this.mAllowFreeFormTextInput;
  }

  public Set<String> getAllowedDataTypes()
  {
    return this.mAllowedDataTypes;
  }

  public CharSequence[] getChoices()
  {
    return this.mChoices;
  }

  public Bundle getExtras()
  {
    return this.mExtras;
  }

  public CharSequence getLabel()
  {
    return this.mLabel;
  }

  public String getResultKey()
  {
    return this.mResultKey;
  }

  public boolean isDataOnly()
  {
    if ((!getAllowFreeFormInput()) && ((getChoices() == null) || (getChoices().length == 0)) && (getAllowedDataTypes() != null) && (!getAllowedDataTypes().isEmpty()));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public static final class Builder
  {
    private boolean mAllowFreeFormTextInput = true;
    private final Set<String> mAllowedDataTypes = new HashSet();
    private CharSequence[] mChoices;
    private final Bundle mExtras = new Bundle();
    private CharSequence mLabel;
    private final String mResultKey;

    public Builder(@NonNull String paramString)
    {
      if (paramString == null)
        throw new IllegalArgumentException("Result key can't be null");
      this.mResultKey = paramString;
    }

    @NonNull
    public Builder addExtras(@NonNull Bundle paramBundle)
    {
      if (paramBundle != null)
        this.mExtras.putAll(paramBundle);
      return this;
    }

    @NonNull
    public RemoteInput build()
    {
      return new RemoteInput(this.mResultKey, this.mLabel, this.mChoices, this.mAllowFreeFormTextInput, this.mExtras, this.mAllowedDataTypes);
    }

    @NonNull
    public Bundle getExtras()
    {
      return this.mExtras;
    }

    @NonNull
    public Builder setAllowDataType(@NonNull String paramString, boolean paramBoolean)
    {
      if (paramBoolean)
        this.mAllowedDataTypes.add(paramString);
      while (true)
      {
        return this;
        this.mAllowedDataTypes.remove(paramString);
      }
    }

    @NonNull
    public Builder setAllowFreeFormInput(boolean paramBoolean)
    {
      this.mAllowFreeFormTextInput = paramBoolean;
      return this;
    }

    @NonNull
    public Builder setChoices(@Nullable CharSequence[] paramArrayOfCharSequence)
    {
      this.mChoices = paramArrayOfCharSequence;
      return this;
    }

    @NonNull
    public Builder setLabel(@Nullable CharSequence paramCharSequence)
    {
      this.mLabel = paramCharSequence;
      return this;
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.app.RemoteInput
 * JD-Core Version:    0.6.2
 */