package androidx.core.app;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.IBinder;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.lang.reflect.Method;

public final class BundleCompat
{
  @Nullable
  public static IBinder getBinder(@NonNull Bundle paramBundle, @Nullable String paramString)
  {
    if (Build.VERSION.SDK_INT >= 18);
    for (IBinder localIBinder = paramBundle.getBinder(paramString); ; localIBinder = BundleCompatBaseImpl.getBinder(paramBundle, paramString))
      return localIBinder;
  }

  public static void putBinder(@NonNull Bundle paramBundle, @Nullable String paramString, @Nullable IBinder paramIBinder)
  {
    if (Build.VERSION.SDK_INT >= 18)
      paramBundle.putBinder(paramString, paramIBinder);
    while (true)
    {
      return;
      BundleCompatBaseImpl.putBinder(paramBundle, paramString, paramIBinder);
    }
  }

  static class BundleCompatBaseImpl
  {
    private static final String TAG = "BundleCompatBaseImpl";
    private static Method sGetIBinderMethod;
    private static boolean sGetIBinderMethodFetched;
    private static Method sPutIBinderMethod;
    private static boolean sPutIBinderMethodFetched;

    // ERROR //
    public static IBinder getBinder(Bundle paramBundle, String paramString)
    {
      // Byte code:
      //   0: getstatic 30	androidx/core/app/BundleCompat$BundleCompatBaseImpl:sGetIBinderMethodFetched	Z
      //   3: ifne +33 -> 36
      //   6: ldc 32
      //   8: ldc 34
      //   10: iconst_1
      //   11: anewarray 36	java/lang/Class
      //   14: dup
      //   15: iconst_0
      //   16: ldc 38
      //   18: aastore
      //   19: invokevirtual 42	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   22: putstatic 44	androidx/core/app/BundleCompat$BundleCompatBaseImpl:sGetIBinderMethod	Ljava/lang/reflect/Method;
      //   25: getstatic 44	androidx/core/app/BundleCompat$BundleCompatBaseImpl:sGetIBinderMethod	Ljava/lang/reflect/Method;
      //   28: iconst_1
      //   29: invokevirtual 50	java/lang/reflect/Method:setAccessible	(Z)V
      //   32: iconst_1
      //   33: putstatic 30	androidx/core/app/BundleCompat$BundleCompatBaseImpl:sGetIBinderMethodFetched	Z
      //   36: getstatic 44	androidx/core/app/BundleCompat$BundleCompatBaseImpl:sGetIBinderMethod	Ljava/lang/reflect/Method;
      //   39: ifnull +53 -> 92
      //   42: getstatic 44	androidx/core/app/BundleCompat$BundleCompatBaseImpl:sGetIBinderMethod	Ljava/lang/reflect/Method;
      //   45: aload_0
      //   46: iconst_1
      //   47: anewarray 4	java/lang/Object
      //   50: dup
      //   51: iconst_0
      //   52: aload_1
      //   53: aastore
      //   54: invokevirtual 54	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   57: checkcast 56	android/os/IBinder
      //   60: astore_2
      //   61: aload_2
      //   62: areturn
      //   63: astore 5
      //   65: ldc 8
      //   67: ldc 58
      //   69: aload 5
      //   71: invokestatic 64	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   74: pop
      //   75: goto -43 -> 32
      //   78: astore_3
      //   79: ldc 8
      //   81: ldc 66
      //   83: aload_3
      //   84: invokestatic 64	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   87: pop
      //   88: aconst_null
      //   89: putstatic 44	androidx/core/app/BundleCompat$BundleCompatBaseImpl:sGetIBinderMethod	Ljava/lang/reflect/Method;
      //   92: aconst_null
      //   93: astore_2
      //   94: goto -33 -> 61
      //   97: astore_3
      //   98: goto -19 -> 79
      //   101: astore_3
      //   102: goto -23 -> 79
      //
      // Exception table:
      //   from	to	target	type
      //   6	32	63	java/lang/NoSuchMethodException
      //   42	61	78	java/lang/IllegalAccessException
      //   42	61	97	java/lang/IllegalArgumentException
      //   42	61	101	java/lang/reflect/InvocationTargetException
    }

    // ERROR //
    public static void putBinder(Bundle paramBundle, String paramString, IBinder paramIBinder)
    {
      // Byte code:
      //   0: getstatic 70	androidx/core/app/BundleCompat$BundleCompatBaseImpl:sPutIBinderMethodFetched	Z
      //   3: ifne +38 -> 41
      //   6: ldc 32
      //   8: ldc 72
      //   10: iconst_2
      //   11: anewarray 36	java/lang/Class
      //   14: dup
      //   15: iconst_0
      //   16: ldc 38
      //   18: aastore
      //   19: dup
      //   20: iconst_1
      //   21: ldc 56
      //   23: aastore
      //   24: invokevirtual 42	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   27: putstatic 74	androidx/core/app/BundleCompat$BundleCompatBaseImpl:sPutIBinderMethod	Ljava/lang/reflect/Method;
      //   30: getstatic 74	androidx/core/app/BundleCompat$BundleCompatBaseImpl:sPutIBinderMethod	Ljava/lang/reflect/Method;
      //   33: iconst_1
      //   34: invokevirtual 50	java/lang/reflect/Method:setAccessible	(Z)V
      //   37: iconst_1
      //   38: putstatic 70	androidx/core/app/BundleCompat$BundleCompatBaseImpl:sPutIBinderMethodFetched	Z
      //   41: getstatic 74	androidx/core/app/BundleCompat$BundleCompatBaseImpl:sPutIBinderMethod	Ljava/lang/reflect/Method;
      //   44: ifnull +23 -> 67
      //   47: getstatic 74	androidx/core/app/BundleCompat$BundleCompatBaseImpl:sPutIBinderMethod	Ljava/lang/reflect/Method;
      //   50: aload_0
      //   51: iconst_2
      //   52: anewarray 4	java/lang/Object
      //   55: dup
      //   56: iconst_0
      //   57: aload_1
      //   58: aastore
      //   59: dup
      //   60: iconst_1
      //   61: aload_2
      //   62: aastore
      //   63: invokevirtual 54	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   66: pop
      //   67: return
      //   68: astore 6
      //   70: ldc 8
      //   72: ldc 76
      //   74: aload 6
      //   76: invokestatic 64	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   79: pop
      //   80: goto -43 -> 37
      //   83: astore_3
      //   84: ldc 8
      //   86: ldc 78
      //   88: aload_3
      //   89: invokestatic 64	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   92: pop
      //   93: aconst_null
      //   94: putstatic 74	androidx/core/app/BundleCompat$BundleCompatBaseImpl:sPutIBinderMethod	Ljava/lang/reflect/Method;
      //   97: goto -30 -> 67
      //   100: astore_3
      //   101: goto -17 -> 84
      //   104: astore_3
      //   105: goto -21 -> 84
      //
      // Exception table:
      //   from	to	target	type
      //   6	37	68	java/lang/NoSuchMethodException
      //   47	67	83	java/lang/IllegalAccessException
      //   47	67	100	java/lang/IllegalArgumentException
      //   47	67	104	java/lang/reflect/InvocationTargetException
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.app.BundleCompat
 * JD-Core Version:    0.6.2
 */