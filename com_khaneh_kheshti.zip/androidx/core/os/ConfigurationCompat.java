package androidx.core.os;

import android.content.res.Configuration;
import android.os.Build.VERSION;
import java.util.Locale;

public final class ConfigurationCompat
{
  public static LocaleListCompat getLocales(Configuration paramConfiguration)
  {
    if (Build.VERSION.SDK_INT >= 24);
    Locale[] arrayOfLocale;
    for (LocaleListCompat localLocaleListCompat = LocaleListCompat.wrap(paramConfiguration.getLocales()); ; localLocaleListCompat = LocaleListCompat.create(arrayOfLocale))
    {
      return localLocaleListCompat;
      arrayOfLocale = new Locale[1];
      arrayOfLocale[0] = paramConfiguration.locale;
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.os.ConfigurationCompat
 * JD-Core Version:    0.6.2
 */