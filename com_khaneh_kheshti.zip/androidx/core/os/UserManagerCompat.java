package androidx.core.os;

import android.content.Context;
import android.os.Build.VERSION;
import android.os.UserManager;

public class UserManagerCompat
{
  public static boolean isUserUnlocked(Context paramContext)
  {
    if (Build.VERSION.SDK_INT >= 24);
    for (boolean bool = ((UserManager)paramContext.getSystemService(UserManager.class)).isUserUnlocked(); ; bool = true)
      return bool;
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.os.UserManagerCompat
 * JD-Core Version:    0.6.2
 */