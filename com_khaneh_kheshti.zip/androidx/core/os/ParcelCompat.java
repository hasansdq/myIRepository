package androidx.core.os;

import android.os.Parcel;

public final class ParcelCompat
{
  public static boolean readBoolean(Parcel paramParcel)
  {
    if (paramParcel.readInt() != 0);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public static void writeBoolean(Parcel paramParcel, boolean paramBoolean)
  {
    if (paramBoolean);
    for (int i = 1; ; i = 0)
    {
      paramParcel.writeInt(i);
      return;
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.os.ParcelCompat
 * JD-Core Version:    0.6.2
 */