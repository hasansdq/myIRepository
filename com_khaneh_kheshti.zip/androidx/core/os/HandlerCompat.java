package androidx.core.os;

import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public final class HandlerCompat
{
  public static boolean postDelayed(@NonNull Handler paramHandler, @NonNull Runnable paramRunnable, @Nullable Object paramObject, long paramLong)
  {
    if (Build.VERSION.SDK_INT >= 28);
    Message localMessage;
    for (boolean bool = paramHandler.postDelayed(paramRunnable, paramObject, paramLong); ; bool = paramHandler.sendMessageDelayed(localMessage, paramLong))
    {
      return bool;
      localMessage = Message.obtain(paramHandler, paramRunnable);
      localMessage.obj = paramObject;
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.os.HandlerCompat
 * JD-Core Version:    0.6.2
 */