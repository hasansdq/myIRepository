package androidx.core.os;

import android.os.Build.VERSION;

public final class CancellationSignal
{
  private boolean mCancelInProgress;
  private Object mCancellationSignalObj;
  private boolean mIsCanceled;
  private OnCancelListener mOnCancelListener;

  private void waitForCancelFinishedLocked()
  {
    while (this.mCancelInProgress)
      try
      {
        wait();
      }
      catch (InterruptedException localInterruptedException)
      {
      }
  }

  // ERROR //
  public void cancel()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 26	androidx/core/os/CancellationSignal:mIsCanceled	Z
    //   6: ifeq +8 -> 14
    //   9: aload_0
    //   10: monitorexit
    //   11: goto +107 -> 118
    //   14: aload_0
    //   15: iconst_1
    //   16: putfield 26	androidx/core/os/CancellationSignal:mIsCanceled	Z
    //   19: aload_0
    //   20: iconst_1
    //   21: putfield 20	androidx/core/os/CancellationSignal:mCancelInProgress	Z
    //   24: aload_0
    //   25: getfield 28	androidx/core/os/CancellationSignal:mOnCancelListener	Landroidx/core/os/CancellationSignal$OnCancelListener;
    //   28: astore_2
    //   29: aload_0
    //   30: getfield 30	androidx/core/os/CancellationSignal:mCancellationSignalObj	Ljava/lang/Object;
    //   33: astore_3
    //   34: aload_0
    //   35: monitorexit
    //   36: aload_2
    //   37: ifnull +9 -> 46
    //   40: aload_2
    //   41: invokeinterface 35 1 0
    //   46: aload_3
    //   47: ifnull +18 -> 65
    //   50: getstatic 41	android/os/Build$VERSION:SDK_INT	I
    //   53: bipush 16
    //   55: if_icmplt +10 -> 65
    //   58: aload_3
    //   59: checkcast 43	android/os/CancellationSignal
    //   62: invokevirtual 45	android/os/CancellationSignal:cancel	()V
    //   65: aload_0
    //   66: monitorenter
    //   67: aload_0
    //   68: iconst_0
    //   69: putfield 20	androidx/core/os/CancellationSignal:mCancelInProgress	Z
    //   72: aload_0
    //   73: invokevirtual 48	java/lang/Object:notifyAll	()V
    //   76: aload_0
    //   77: monitorexit
    //   78: goto +40 -> 118
    //   81: astore 6
    //   83: aload_0
    //   84: monitorexit
    //   85: aload 6
    //   87: athrow
    //   88: astore_1
    //   89: aload_0
    //   90: monitorexit
    //   91: aload_1
    //   92: athrow
    //   93: astore 4
    //   95: aload_0
    //   96: monitorenter
    //   97: aload_0
    //   98: iconst_0
    //   99: putfield 20	androidx/core/os/CancellationSignal:mCancelInProgress	Z
    //   102: aload_0
    //   103: invokevirtual 48	java/lang/Object:notifyAll	()V
    //   106: aload_0
    //   107: monitorexit
    //   108: aload 4
    //   110: athrow
    //   111: astore 5
    //   113: aload_0
    //   114: monitorexit
    //   115: aload 5
    //   117: athrow
    //   118: return
    //
    // Exception table:
    //   from	to	target	type
    //   67	85	81	finally
    //   2	36	88	finally
    //   89	91	88	finally
    //   40	65	93	finally
    //   97	108	111	finally
    //   113	115	111	finally
  }

  public Object getCancellationSignalObject()
  {
    Object localObject2;
    if (Build.VERSION.SDK_INT < 16)
      localObject2 = null;
    while (true)
    {
      return localObject2;
      try
      {
        if (this.mCancellationSignalObj == null)
        {
          this.mCancellationSignalObj = new android.os.CancellationSignal();
          if (this.mIsCanceled)
            ((android.os.CancellationSignal)this.mCancellationSignalObj).cancel();
        }
        localObject2 = this.mCancellationSignalObj;
      }
      finally
      {
        localObject1 = finally;
        throw localObject1;
      }
    }
  }

  public boolean isCanceled()
  {
    try
    {
      boolean bool = this.mIsCanceled;
      return bool;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  // ERROR //
  public void setOnCancelListener(OnCancelListener paramOnCancelListener)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 57	androidx/core/os/CancellationSignal:waitForCancelFinishedLocked	()V
    //   6: aload_0
    //   7: getfield 28	androidx/core/os/CancellationSignal:mOnCancelListener	Landroidx/core/os/CancellationSignal$OnCancelListener;
    //   10: aload_1
    //   11: if_acmpne +8 -> 19
    //   14: aload_0
    //   15: monitorexit
    //   16: goto +37 -> 53
    //   19: aload_0
    //   20: aload_1
    //   21: putfield 28	androidx/core/os/CancellationSignal:mOnCancelListener	Landroidx/core/os/CancellationSignal$OnCancelListener;
    //   24: aload_0
    //   25: getfield 26	androidx/core/os/CancellationSignal:mIsCanceled	Z
    //   28: ifeq +7 -> 35
    //   31: aload_1
    //   32: ifnonnull +13 -> 45
    //   35: aload_0
    //   36: monitorexit
    //   37: goto +16 -> 53
    //   40: astore_2
    //   41: aload_0
    //   42: monitorexit
    //   43: aload_2
    //   44: athrow
    //   45: aload_0
    //   46: monitorexit
    //   47: aload_1
    //   48: invokeinterface 35 1 0
    //   53: return
    //
    // Exception table:
    //   from	to	target	type
    //   2	43	40	finally
    //   45	47	40	finally
  }

  public void throwIfCanceled()
  {
    if (isCanceled())
      throw new OperationCanceledException();
  }

  public static abstract interface OnCancelListener
  {
    public abstract void onCancel();
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.os.CancellationSignal
 * JD-Core Version:    0.6.2
 */