package androidx.core.os;

public class OperationCanceledException extends RuntimeException
{
  public OperationCanceledException()
  {
    this(null);
  }

  public OperationCanceledException(String paramString)
  {
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.os.OperationCanceledException
 * JD-Core Version:    0.6.2
 */