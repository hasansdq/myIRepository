package androidx.core.os;

import android.os.Build.VERSION;

public class BuildCompat
{
  @Deprecated
  public static boolean isAtLeastN()
  {
    if (Build.VERSION.SDK_INT >= 24);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  @Deprecated
  public static boolean isAtLeastNMR1()
  {
    if (Build.VERSION.SDK_INT >= 25);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  @Deprecated
  public static boolean isAtLeastO()
  {
    if (Build.VERSION.SDK_INT >= 26);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  @Deprecated
  public static boolean isAtLeastOMR1()
  {
    if (Build.VERSION.SDK_INT >= 27);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  @Deprecated
  public static boolean isAtLeastP()
  {
    if (Build.VERSION.SDK_INT >= 28);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public static boolean isAtLeastQ()
  {
    int i = 1;
    if ((Build.VERSION.CODENAME.length() == i) && (Build.VERSION.CODENAME.charAt(0) >= 'Q') && (Build.VERSION.CODENAME.charAt(0) <= 'Z'));
    while (true)
    {
      return i;
      int j = 0;
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.os.BuildCompat
 * JD-Core Version:    0.6.2
 */