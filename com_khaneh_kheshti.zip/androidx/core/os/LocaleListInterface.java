package androidx.core.os;

import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import java.util.Locale;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
abstract interface LocaleListInterface
{
  public abstract boolean equals(Object paramObject);

  public abstract Locale get(int paramInt);

  @Nullable
  public abstract Locale getFirstMatch(String[] paramArrayOfString);

  public abstract Object getLocaleList();

  public abstract int hashCode();

  @IntRange(from=-1L)
  public abstract int indexOf(Locale paramLocale);

  public abstract boolean isEmpty();

  public abstract void setLocaleList(@NonNull Locale[] paramArrayOfLocale);

  @IntRange(from=0L)
  public abstract int size();

  public abstract String toLanguageTags();

  public abstract String toString();
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.os.LocaleListInterface
 * JD-Core Version:    0.6.2
 */