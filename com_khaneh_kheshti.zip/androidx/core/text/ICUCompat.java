package androidx.core.text;

import android.os.Build.VERSION;
import android.util.Log;
import androidx.annotation.Nullable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Locale;

public final class ICUCompat
{
  private static final String TAG = "ICUCompat";
  private static Method sAddLikelySubtagsMethod;
  private static Method sGetScriptMethod;

  static
  {
    if (Build.VERSION.SDK_INT >= 21);
    while (true)
    {
      try
      {
        sAddLikelySubtagsMethod = Class.forName("libcore.icu.ICU").getMethod("addLikelySubtags", new Class[] { Locale.class });
        return;
      }
      catch (Exception localException2)
      {
        throw new IllegalStateException(localException2);
      }
      try
      {
        Class localClass = Class.forName("libcore.icu.ICU");
        if (localClass != null)
        {
          sGetScriptMethod = localClass.getMethod("getScript", new Class[] { String.class });
          sAddLikelySubtagsMethod = localClass.getMethod("addLikelySubtags", new Class[] { String.class });
        }
      }
      catch (Exception localException1)
      {
        sGetScriptMethod = null;
        sAddLikelySubtagsMethod = null;
        Log.w("ICUCompat", localException1);
      }
    }
  }

  private static String addLikelySubtags(Locale paramLocale)
  {
    String str1 = paramLocale.toString();
    try
    {
      if (sAddLikelySubtagsMethod != null)
      {
        Object[] arrayOfObject = { str1 };
        str2 = (String)sAddLikelySubtagsMethod.invoke(null, arrayOfObject);
        return str2;
      }
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      while (true)
      {
        Log.w("ICUCompat", localIllegalAccessException);
        String str2 = str1;
      }
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      while (true)
        Log.w("ICUCompat", localInvocationTargetException);
    }
  }

  private static String getScript(String paramString)
  {
    try
    {
      if (sGetScriptMethod != null)
      {
        Object[] arrayOfObject = { paramString };
        str = (String)sGetScriptMethod.invoke(null, arrayOfObject);
        return str;
      }
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      while (true)
      {
        Log.w("ICUCompat", localIllegalAccessException);
        String str = null;
      }
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      while (true)
        Log.w("ICUCompat", localInvocationTargetException);
    }
  }

  @Nullable
  public static String maximizeAndGetScript(Locale paramLocale)
  {
    Object localObject = null;
    if (Build.VERSION.SDK_INT >= 21);
    while (true)
    {
      try
      {
        Object[] arrayOfObject = { paramLocale };
        String str2 = ((Locale)sAddLikelySubtagsMethod.invoke(null, arrayOfObject)).getScript();
        localObject = str2;
        return localObject;
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        Log.w("ICUCompat", localInvocationTargetException);
        localObject = paramLocale.getScript();
        continue;
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        Log.w("ICUCompat", localIllegalAccessException);
        continue;
      }
      String str1 = addLikelySubtags(paramLocale);
      if (str1 != null)
        localObject = getScript(str1);
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.text.ICUCompat
 * JD-Core Version:    0.6.2
 */