package androidx.core.text.util;

import android.annotation.SuppressLint;
import android.os.Build.VERSION;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.method.MovementMethod;
import android.text.style.URLSpan;
import android.text.util.Linkify;
import android.text.util.Linkify.MatchFilter;
import android.text.util.Linkify.TransformFilter;
import android.webkit.WebView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.core.util.PatternsCompat;
import java.io.UnsupportedEncodingException;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class LinkifyCompat
{
  private static final Comparator<LinkSpec> COMPARATOR = new Comparator()
  {
    public int compare(LinkifyCompat.LinkSpec paramAnonymousLinkSpec1, LinkifyCompat.LinkSpec paramAnonymousLinkSpec2)
    {
      int i = -1;
      if (paramAnonymousLinkSpec1.start < paramAnonymousLinkSpec2.start);
      while (true)
      {
        return i;
        if (paramAnonymousLinkSpec1.start > paramAnonymousLinkSpec2.start)
          i = 1;
        else if (paramAnonymousLinkSpec1.end < paramAnonymousLinkSpec2.end)
          i = 1;
        else if (paramAnonymousLinkSpec1.end <= paramAnonymousLinkSpec2.end)
          i = 0;
      }
    }
  };
  private static final String[] EMPTY_STRING = new String[0];

  private static void addLinkMovementMethod(@NonNull TextView paramTextView)
  {
    MovementMethod localMovementMethod = paramTextView.getMovementMethod();
    if (((localMovementMethod == null) || (!(localMovementMethod instanceof LinkMovementMethod))) && (paramTextView.getLinksClickable()))
      paramTextView.setMovementMethod(LinkMovementMethod.getInstance());
  }

  public static void addLinks(@NonNull TextView paramTextView, @NonNull Pattern paramPattern, @Nullable String paramString)
  {
    if (shouldAddLinksFallbackToFramework())
      Linkify.addLinks(paramTextView, paramPattern, paramString);
    while (true)
    {
      return;
      addLinks(paramTextView, paramPattern, paramString, null, null, null);
    }
  }

  public static void addLinks(@NonNull TextView paramTextView, @NonNull Pattern paramPattern, @Nullable String paramString, @Nullable Linkify.MatchFilter paramMatchFilter, @Nullable Linkify.TransformFilter paramTransformFilter)
  {
    if (shouldAddLinksFallbackToFramework())
      Linkify.addLinks(paramTextView, paramPattern, paramString, paramMatchFilter, paramTransformFilter);
    while (true)
    {
      return;
      addLinks(paramTextView, paramPattern, paramString, null, paramMatchFilter, paramTransformFilter);
    }
  }

  @SuppressLint({"NewApi"})
  public static void addLinks(@NonNull TextView paramTextView, @NonNull Pattern paramPattern, @Nullable String paramString, @Nullable String[] paramArrayOfString, @Nullable Linkify.MatchFilter paramMatchFilter, @Nullable Linkify.TransformFilter paramTransformFilter)
  {
    if (shouldAddLinksFallbackToFramework())
      Linkify.addLinks(paramTextView, paramPattern, paramString, paramArrayOfString, paramMatchFilter, paramTransformFilter);
    while (true)
    {
      return;
      SpannableString localSpannableString = SpannableString.valueOf(paramTextView.getText());
      if (addLinks(localSpannableString, paramPattern, paramString, paramArrayOfString, paramMatchFilter, paramTransformFilter))
      {
        paramTextView.setText(localSpannableString);
        addLinkMovementMethod(paramTextView);
      }
    }
  }

  public static boolean addLinks(@NonNull Spannable paramSpannable, int paramInt)
  {
    boolean bool;
    if (shouldAddLinksFallbackToFramework())
      bool = Linkify.addLinks(paramSpannable, paramInt);
    while (true)
    {
      return bool;
      if (paramInt == 0)
      {
        bool = false;
      }
      else
      {
        URLSpan[] arrayOfURLSpan = (URLSpan[])paramSpannable.getSpans(0, paramSpannable.length(), URLSpan.class);
        for (int i = -1 + arrayOfURLSpan.length; i >= 0; i--)
          paramSpannable.removeSpan(arrayOfURLSpan[i]);
        if ((paramInt & 0x4) != 0)
          Linkify.addLinks(paramSpannable, 4);
        ArrayList localArrayList = new ArrayList();
        if ((paramInt & 0x1) != 0)
          gatherLinks(localArrayList, paramSpannable, PatternsCompat.AUTOLINK_WEB_URL, new String[] { "http://", "https://", "rtsp://" }, Linkify.sUrlMatchFilter, null);
        if ((paramInt & 0x2) != 0)
          gatherLinks(localArrayList, paramSpannable, PatternsCompat.AUTOLINK_EMAIL_ADDRESS, new String[] { "mailto:" }, null, null);
        if ((paramInt & 0x8) != 0)
          gatherMapLinks(localArrayList, paramSpannable);
        pruneOverlaps(localArrayList, paramSpannable);
        if (localArrayList.size() == 0)
        {
          bool = false;
        }
        else
        {
          Iterator localIterator = localArrayList.iterator();
          while (localIterator.hasNext())
          {
            LinkSpec localLinkSpec = (LinkSpec)localIterator.next();
            if (localLinkSpec.frameworkAddedSpan == null)
              applyLink(localLinkSpec.url, localLinkSpec.start, localLinkSpec.end, paramSpannable);
          }
          bool = true;
        }
      }
    }
  }

  public static boolean addLinks(@NonNull Spannable paramSpannable, @NonNull Pattern paramPattern, @Nullable String paramString)
  {
    if (shouldAddLinksFallbackToFramework());
    for (boolean bool = Linkify.addLinks(paramSpannable, paramPattern, paramString); ; bool = addLinks(paramSpannable, paramPattern, paramString, null, null, null))
      return bool;
  }

  public static boolean addLinks(@NonNull Spannable paramSpannable, @NonNull Pattern paramPattern, @Nullable String paramString, @Nullable Linkify.MatchFilter paramMatchFilter, @Nullable Linkify.TransformFilter paramTransformFilter)
  {
    if (shouldAddLinksFallbackToFramework());
    for (boolean bool = Linkify.addLinks(paramSpannable, paramPattern, paramString, paramMatchFilter, paramTransformFilter); ; bool = addLinks(paramSpannable, paramPattern, paramString, null, paramMatchFilter, paramTransformFilter))
      return bool;
  }

  @SuppressLint({"NewApi"})
  public static boolean addLinks(@NonNull Spannable paramSpannable, @NonNull Pattern paramPattern, @Nullable String paramString, @Nullable String[] paramArrayOfString, @Nullable Linkify.MatchFilter paramMatchFilter, @Nullable Linkify.TransformFilter paramTransformFilter)
  {
    boolean bool1;
    if (shouldAddLinksFallbackToFramework())
      bool1 = Linkify.addLinks(paramSpannable, paramPattern, paramString, paramArrayOfString, paramMatchFilter, paramTransformFilter);
    while (true)
    {
      return bool1;
      if (paramString == null)
        paramString = "";
      if ((paramArrayOfString == null) || (paramArrayOfString.length < 1))
        paramArrayOfString = EMPTY_STRING;
      String[] arrayOfString = new String[1 + paramArrayOfString.length];
      arrayOfString[0] = paramString.toLowerCase(Locale.ROOT);
      int i = 0;
      if (i < paramArrayOfString.length)
      {
        String str1 = paramArrayOfString[i];
        int m = i + 1;
        if (str1 == null);
        for (String str2 = ""; ; str2 = str1.toLowerCase(Locale.ROOT))
        {
          arrayOfString[m] = str2;
          i++;
          break;
        }
      }
      bool1 = false;
      Matcher localMatcher = paramPattern.matcher(paramSpannable);
      while (localMatcher.find())
      {
        int j = localMatcher.start();
        int k = localMatcher.end();
        boolean bool2 = true;
        if (paramMatchFilter != null)
          bool2 = paramMatchFilter.acceptMatch(paramSpannable, j, k);
        if (bool2)
        {
          applyLink(makeUrl(localMatcher.group(0), arrayOfString, localMatcher, paramTransformFilter), j, k, paramSpannable);
          bool1 = true;
        }
      }
    }
  }

  public static boolean addLinks(@NonNull TextView paramTextView, int paramInt)
  {
    boolean bool = false;
    if (shouldAddLinksFallbackToFramework())
      bool = Linkify.addLinks(paramTextView, paramInt);
    while (true)
    {
      return bool;
      if (paramInt != 0)
      {
        CharSequence localCharSequence = paramTextView.getText();
        if ((localCharSequence instanceof Spannable))
        {
          if (addLinks((Spannable)localCharSequence, paramInt))
          {
            addLinkMovementMethod(paramTextView);
            bool = true;
          }
        }
        else
        {
          SpannableString localSpannableString = SpannableString.valueOf(localCharSequence);
          if (addLinks(localSpannableString, paramInt))
          {
            addLinkMovementMethod(paramTextView);
            paramTextView.setText(localSpannableString);
            bool = true;
          }
        }
      }
    }
  }

  private static void applyLink(String paramString, int paramInt1, int paramInt2, Spannable paramSpannable)
  {
    paramSpannable.setSpan(new URLSpan(paramString), paramInt1, paramInt2, 33);
  }

  private static String findAddress(String paramString)
  {
    if (Build.VERSION.SDK_INT >= 28);
    for (String str = WebView.findAddress(paramString); ; str = FindAddress.findAddress(paramString))
      return str;
  }

  private static void gatherLinks(ArrayList<LinkSpec> paramArrayList, Spannable paramSpannable, Pattern paramPattern, String[] paramArrayOfString, Linkify.MatchFilter paramMatchFilter, Linkify.TransformFilter paramTransformFilter)
  {
    Matcher localMatcher = paramPattern.matcher(paramSpannable);
    while (localMatcher.find())
    {
      int i = localMatcher.start();
      int j = localMatcher.end();
      if ((paramMatchFilter == null) || (paramMatchFilter.acceptMatch(paramSpannable, i, j)))
      {
        LinkSpec localLinkSpec = new LinkSpec();
        localLinkSpec.url = makeUrl(localMatcher.group(0), paramArrayOfString, localMatcher, paramTransformFilter);
        localLinkSpec.start = i;
        localLinkSpec.end = j;
        paramArrayList.add(localLinkSpec);
      }
    }
  }

  private static void gatherMapLinks(ArrayList<LinkSpec> paramArrayList, Spannable paramSpannable)
  {
    Object localObject = paramSpannable.toString();
    int i = 0;
    try
    {
      str1 = findAddress((String)localObject);
      if (str1 != null)
      {
        int j = ((String)localObject).indexOf(str1);
        if (j >= 0)
        {
          localLinkSpec = new LinkSpec();
          int k = j + str1.length();
          localLinkSpec.start = (i + j);
          localLinkSpec.end = (i + k);
          String str2 = ((String)localObject).substring(k);
          localObject = str2;
          i += k;
        }
      }
    }
    catch (UnsupportedOperationException localUnsupportedOperationException)
    {
      while (true)
        try
        {
          String str1;
          LinkSpec localLinkSpec;
          String str3 = URLEncoder.encode(str1, "UTF-8");
          localLinkSpec.url = ("geo:0,0?q=" + str3);
          paramArrayList.add(localLinkSpec);
          continue;
          localUnsupportedOperationException = localUnsupportedOperationException;
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException)
        {
        }
    }
  }

  private static String makeUrl(@NonNull String paramString, @NonNull String[] paramArrayOfString, Matcher paramMatcher, @Nullable Linkify.TransformFilter paramTransformFilter)
  {
    if (paramTransformFilter != null)
      paramString = paramTransformFilter.transformUrl(paramMatcher, paramString);
    int i = 0;
    for (int j = 0; ; j++)
    {
      if (j < paramArrayOfString.length)
      {
        String str1 = paramArrayOfString[j];
        int k = paramArrayOfString[j].length();
        if (!paramString.regionMatches(true, 0, str1, 0, k))
          continue;
        i = 1;
        String str2 = paramArrayOfString[j];
        int m = paramArrayOfString[j].length();
        if (!paramString.regionMatches(false, 0, str2, 0, m))
          paramString = paramArrayOfString[j] + paramString.substring(paramArrayOfString[j].length());
      }
      if ((i == 0) && (paramArrayOfString.length > 0))
        paramString = paramArrayOfString[0] + paramString;
      return paramString;
    }
  }

  private static void pruneOverlaps(ArrayList<LinkSpec> paramArrayList, Spannable paramSpannable)
  {
    URLSpan[] arrayOfURLSpan = (URLSpan[])paramSpannable.getSpans(0, paramSpannable.length(), URLSpan.class);
    for (int i = 0; i < arrayOfURLSpan.length; i++)
    {
      LinkSpec localLinkSpec1 = new LinkSpec();
      localLinkSpec1.frameworkAddedSpan = arrayOfURLSpan[i];
      localLinkSpec1.start = paramSpannable.getSpanStart(arrayOfURLSpan[i]);
      localLinkSpec1.end = paramSpannable.getSpanEnd(arrayOfURLSpan[i]);
      paramArrayList.add(localLinkSpec1);
    }
    Collections.sort(paramArrayList, COMPARATOR);
    int j = paramArrayList.size();
    int k = 0;
    while (k < j - 1)
    {
      LinkSpec localLinkSpec2 = (LinkSpec)paramArrayList.get(k);
      LinkSpec localLinkSpec3 = (LinkSpec)paramArrayList.get(k + 1);
      int m = -1;
      if ((localLinkSpec2.start <= localLinkSpec3.start) && (localLinkSpec2.end > localLinkSpec3.start))
      {
        if (localLinkSpec3.end <= localLinkSpec2.end)
          m = k + 1;
        while (true)
        {
          if (m == -1)
            break label294;
          URLSpan localURLSpan = ((LinkSpec)paramArrayList.get(m)).frameworkAddedSpan;
          if (localURLSpan != null)
            paramSpannable.removeSpan(localURLSpan);
          paramArrayList.remove(m);
          j--;
          break;
          if (localLinkSpec2.end - localLinkSpec2.start > localLinkSpec3.end - localLinkSpec3.start)
            m = k + 1;
          else if (localLinkSpec2.end - localLinkSpec2.start < localLinkSpec3.end - localLinkSpec3.start)
            m = k;
        }
      }
      label294: k++;
    }
  }

  private static boolean shouldAddLinksFallbackToFramework()
  {
    if (Build.VERSION.SDK_INT >= 28);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private static class LinkSpec
  {
    int end;
    URLSpan frameworkAddedSpan;
    int start;
    String url;
  }

  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface LinkifyMask
  {
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.text.util.LinkifyCompat
 * JD-Core Version:    0.6.2
 */