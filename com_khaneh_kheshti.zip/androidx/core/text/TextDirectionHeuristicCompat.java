package androidx.core.text;

public abstract interface TextDirectionHeuristicCompat
{
  public abstract boolean isRtl(CharSequence paramCharSequence, int paramInt1, int paramInt2);

  public abstract boolean isRtl(char[] paramArrayOfChar, int paramInt1, int paramInt2);
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.text.TextDirectionHeuristicCompat
 * JD-Core Version:    0.6.2
 */