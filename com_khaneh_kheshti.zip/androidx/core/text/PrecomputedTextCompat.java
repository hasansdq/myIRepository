package androidx.core.text;

import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.os.LocaleList;
import android.text.Layout.Alignment;
import android.text.PrecomputedText;
import android.text.PrecomputedText.Params;
import android.text.PrecomputedText.Params.Builder;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.StaticLayout;
import android.text.StaticLayout.Builder;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.MetricAffectingSpan;
import androidx.annotation.GuardedBy;
import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.annotation.UiThread;
import androidx.core.os.TraceCompat;
import androidx.core.util.ObjectsCompat;
import androidx.core.util.Preconditions;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;

public class PrecomputedTextCompat
  implements Spannable
{
  private static final char LINE_FEED = '\n';

  @GuardedBy("sLock")
  @NonNull
  private static Executor sExecutor = null;
  private static final Object sLock = new Object();

  @NonNull
  private final int[] mParagraphEnds;

  @NonNull
  private final Params mParams;

  @NonNull
  private final Spannable mText;

  @Nullable
  private final PrecomputedText mWrapped;

  @RequiresApi(28)
  private PrecomputedTextCompat(@NonNull PrecomputedText paramPrecomputedText, @NonNull Params paramParams)
  {
    this.mText = paramPrecomputedText;
    this.mParams = paramParams;
    this.mParagraphEnds = null;
    this.mWrapped = paramPrecomputedText;
  }

  private PrecomputedTextCompat(@NonNull CharSequence paramCharSequence, @NonNull Params paramParams, @NonNull int[] paramArrayOfInt)
  {
    this.mText = new SpannableString(paramCharSequence);
    this.mParams = paramParams;
    this.mParagraphEnds = paramArrayOfInt;
    this.mWrapped = null;
  }

  public static PrecomputedTextCompat create(@NonNull CharSequence paramCharSequence, @NonNull Params paramParams)
  {
    Preconditions.checkNotNull(paramCharSequence);
    Preconditions.checkNotNull(paramParams);
    while (true)
    {
      int m;
      try
      {
        TraceCompat.beginSection("PrecomputedText");
        PrecomputedTextCompat localPrecomputedTextCompat;
        if ((Build.VERSION.SDK_INT >= 28) && (paramParams.mWrapped != null))
        {
          localPrecomputedTextCompat = new PrecomputedTextCompat(PrecomputedText.create(paramCharSequence, paramParams.mWrapped), paramParams);
          return localPrecomputedTextCompat;
        }
        ArrayList localArrayList = new ArrayList();
        int i = paramCharSequence.length();
        int j = 0;
        if (j < i)
        {
          m = TextUtils.indexOf(paramCharSequence, '\n', j, i);
          if (m >= 0)
            break label275;
          n = i;
          localArrayList.add(Integer.valueOf(n));
          j = n;
          continue;
        }
        int[] arrayOfInt = new int[localArrayList.size()];
        int k = 0;
        if (k < localArrayList.size())
        {
          arrayOfInt[k] = ((Integer)localArrayList.get(k)).intValue();
          k++;
          continue;
        }
        if (Build.VERSION.SDK_INT >= 23)
        {
          StaticLayout.Builder.obtain(paramCharSequence, 0, paramCharSequence.length(), paramParams.getTextPaint(), 2147483647).setBreakStrategy(paramParams.getBreakStrategy()).setHyphenationFrequency(paramParams.getHyphenationFrequency()).setTextDirection(paramParams.getTextDirection()).build();
          localPrecomputedTextCompat = new PrecomputedTextCompat(paramCharSequence, paramParams, arrayOfInt);
          TraceCompat.endSection();
          continue;
        }
        if (Build.VERSION.SDK_INT < 21)
          continue;
        new StaticLayout(paramCharSequence, paramParams.getTextPaint(), 2147483647, Layout.Alignment.ALIGN_NORMAL, 1.0F, 0.0F, false);
        continue;
      }
      finally
      {
        TraceCompat.endSection();
      }
      label275: int n = m + 1;
    }
  }

  private int findParaIndex(@IntRange(from=0L) int paramInt)
  {
    for (int i = 0; i < this.mParagraphEnds.length; i++)
      if (paramInt < this.mParagraphEnds[i])
        return i;
    throw new IndexOutOfBoundsException("pos must be less than " + this.mParagraphEnds[(-1 + this.mParagraphEnds.length)] + ", gave " + paramInt);
  }

  @UiThread
  public static Future<PrecomputedTextCompat> getTextFuture(@NonNull CharSequence paramCharSequence, @NonNull Params paramParams, @Nullable Executor paramExecutor)
  {
    PrecomputedTextFutureTask localPrecomputedTextFutureTask = new PrecomputedTextFutureTask(paramParams, paramCharSequence);
    if (paramExecutor == null);
    synchronized (sLock)
    {
      if (sExecutor == null)
        sExecutor = Executors.newFixedThreadPool(1);
      paramExecutor = sExecutor;
      paramExecutor.execute(localPrecomputedTextFutureTask);
      return localPrecomputedTextFutureTask;
    }
  }

  public char charAt(int paramInt)
  {
    return this.mText.charAt(paramInt);
  }

  @IntRange(from=0L)
  public int getParagraphCount()
  {
    if (Build.VERSION.SDK_INT >= 28);
    for (int i = this.mWrapped.getParagraphCount(); ; i = this.mParagraphEnds.length)
      return i;
  }

  @IntRange(from=0L)
  public int getParagraphEnd(@IntRange(from=0L) int paramInt)
  {
    Preconditions.checkArgumentInRange(paramInt, 0, getParagraphCount(), "paraIndex");
    if (Build.VERSION.SDK_INT >= 28);
    for (int i = this.mWrapped.getParagraphEnd(paramInt); ; i = this.mParagraphEnds[paramInt])
      return i;
  }

  @IntRange(from=0L)
  public int getParagraphStart(@IntRange(from=0L) int paramInt)
  {
    int i = 0;
    Preconditions.checkArgumentInRange(paramInt, 0, getParagraphCount(), "paraIndex");
    if (Build.VERSION.SDK_INT >= 28)
      i = this.mWrapped.getParagraphStart(paramInt);
    while (true)
    {
      return i;
      if (paramInt != 0)
        i = this.mParagraphEnds[(paramInt - 1)];
    }
  }

  @NonNull
  public Params getParams()
  {
    return this.mParams;
  }

  @Nullable
  @RequiresApi(28)
  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public PrecomputedText getPrecomputedText()
  {
    if ((this.mText instanceof PrecomputedText));
    for (PrecomputedText localPrecomputedText = (PrecomputedText)this.mText; ; localPrecomputedText = null)
      return localPrecomputedText;
  }

  public int getSpanEnd(Object paramObject)
  {
    return this.mText.getSpanEnd(paramObject);
  }

  public int getSpanFlags(Object paramObject)
  {
    return this.mText.getSpanFlags(paramObject);
  }

  public int getSpanStart(Object paramObject)
  {
    return this.mText.getSpanStart(paramObject);
  }

  public <T> T[] getSpans(int paramInt1, int paramInt2, Class<T> paramClass)
  {
    if (Build.VERSION.SDK_INT >= 28);
    for (Object[] arrayOfObject = this.mWrapped.getSpans(paramInt1, paramInt2, paramClass); ; arrayOfObject = this.mText.getSpans(paramInt1, paramInt2, paramClass))
      return arrayOfObject;
  }

  public int length()
  {
    return this.mText.length();
  }

  public int nextSpanTransition(int paramInt1, int paramInt2, Class paramClass)
  {
    return this.mText.nextSpanTransition(paramInt1, paramInt2, paramClass);
  }

  public void removeSpan(Object paramObject)
  {
    if ((paramObject instanceof MetricAffectingSpan))
      throw new IllegalArgumentException("MetricAffectingSpan can not be removed from PrecomputedText.");
    if (Build.VERSION.SDK_INT >= 28)
      this.mWrapped.removeSpan(paramObject);
    while (true)
    {
      return;
      this.mText.removeSpan(paramObject);
    }
  }

  public void setSpan(Object paramObject, int paramInt1, int paramInt2, int paramInt3)
  {
    if ((paramObject instanceof MetricAffectingSpan))
      throw new IllegalArgumentException("MetricAffectingSpan can not be set to PrecomputedText.");
    if (Build.VERSION.SDK_INT >= 28)
      this.mWrapped.setSpan(paramObject, paramInt1, paramInt2, paramInt3);
    while (true)
    {
      return;
      this.mText.setSpan(paramObject, paramInt1, paramInt2, paramInt3);
    }
  }

  public CharSequence subSequence(int paramInt1, int paramInt2)
  {
    return this.mText.subSequence(paramInt1, paramInt2);
  }

  public String toString()
  {
    return this.mText.toString();
  }

  public static final class Params
  {
    private final int mBreakStrategy;
    private final int mHyphenationFrequency;

    @NonNull
    private final TextPaint mPaint;

    @Nullable
    private final TextDirectionHeuristic mTextDir;
    final PrecomputedText.Params mWrapped;

    @RequiresApi(28)
    public Params(@NonNull PrecomputedText.Params paramParams)
    {
      this.mPaint = paramParams.getTextPaint();
      this.mTextDir = paramParams.getTextDirection();
      this.mBreakStrategy = paramParams.getBreakStrategy();
      this.mHyphenationFrequency = paramParams.getHyphenationFrequency();
      this.mWrapped = paramParams;
    }

    Params(@NonNull TextPaint paramTextPaint, @NonNull TextDirectionHeuristic paramTextDirectionHeuristic, int paramInt1, int paramInt2)
    {
      if (Build.VERSION.SDK_INT >= 28);
      for (this.mWrapped = new PrecomputedText.Params.Builder(paramTextPaint).setBreakStrategy(paramInt1).setHyphenationFrequency(paramInt2).setTextDirection(paramTextDirectionHeuristic).build(); ; this.mWrapped = null)
      {
        this.mPaint = paramTextPaint;
        this.mTextDir = paramTextDirectionHeuristic;
        this.mBreakStrategy = paramInt1;
        this.mHyphenationFrequency = paramInt2;
        return;
      }
    }

    public boolean equals(@Nullable Object paramObject)
    {
      boolean bool = true;
      if (paramObject == this);
      while (true)
      {
        return bool;
        if ((paramObject == null) || (!(paramObject instanceof Params)))
        {
          bool = false;
        }
        else
        {
          Params localParams = (Params)paramObject;
          if (this.mWrapped != null)
            bool = this.mWrapped.equals(localParams.mWrapped);
          else if (Build.VERSION.SDK_INT >= 23)
          {
            if (this.mBreakStrategy != localParams.getBreakStrategy())
              bool = false;
            else if (this.mHyphenationFrequency != localParams.getHyphenationFrequency())
              bool = false;
          }
          else if ((Build.VERSION.SDK_INT >= 18) && (this.mTextDir != localParams.getTextDirection()))
            bool = false;
          else if (this.mPaint.getTextSize() != localParams.getTextPaint().getTextSize())
            bool = false;
          else if (this.mPaint.getTextScaleX() != localParams.getTextPaint().getTextScaleX())
            bool = false;
          else if (this.mPaint.getTextSkewX() != localParams.getTextPaint().getTextSkewX())
            bool = false;
          else if (Build.VERSION.SDK_INT >= 21)
          {
            if (this.mPaint.getLetterSpacing() != localParams.getTextPaint().getLetterSpacing())
              bool = false;
            else if (!TextUtils.equals(this.mPaint.getFontFeatureSettings(), localParams.getTextPaint().getFontFeatureSettings()))
              bool = false;
          }
          else if (this.mPaint.getFlags() != localParams.getTextPaint().getFlags())
            bool = false;
          else if (Build.VERSION.SDK_INT >= 24)
          {
            if (!this.mPaint.getTextLocales().equals(localParams.getTextPaint().getTextLocales()))
              bool = false;
          }
          else if ((Build.VERSION.SDK_INT >= 17) && (!this.mPaint.getTextLocale().equals(localParams.getTextPaint().getTextLocale())))
            bool = false;
          else if (this.mPaint.getTypeface() == null)
          {
            if (localParams.getTextPaint().getTypeface() != null)
              bool = false;
          }
          else if (!this.mPaint.getTypeface().equals(localParams.getTextPaint().getTypeface()))
            bool = false;
        }
      }
    }

    @RequiresApi(23)
    public int getBreakStrategy()
    {
      return this.mBreakStrategy;
    }

    @RequiresApi(23)
    public int getHyphenationFrequency()
    {
      return this.mHyphenationFrequency;
    }

    @Nullable
    @RequiresApi(18)
    public TextDirectionHeuristic getTextDirection()
    {
      return this.mTextDir;
    }

    @NonNull
    public TextPaint getTextPaint()
    {
      return this.mPaint;
    }

    public int hashCode()
    {
      int i;
      if (Build.VERSION.SDK_INT >= 24)
      {
        Object[] arrayOfObject5 = new Object[11];
        arrayOfObject5[0] = Float.valueOf(this.mPaint.getTextSize());
        arrayOfObject5[1] = Float.valueOf(this.mPaint.getTextScaleX());
        arrayOfObject5[2] = Float.valueOf(this.mPaint.getTextSkewX());
        arrayOfObject5[3] = Float.valueOf(this.mPaint.getLetterSpacing());
        arrayOfObject5[4] = Integer.valueOf(this.mPaint.getFlags());
        arrayOfObject5[5] = this.mPaint.getTextLocales();
        arrayOfObject5[6] = this.mPaint.getTypeface();
        arrayOfObject5[7] = Boolean.valueOf(this.mPaint.isElegantTextHeight());
        arrayOfObject5[8] = this.mTextDir;
        arrayOfObject5[9] = Integer.valueOf(this.mBreakStrategy);
        arrayOfObject5[10] = Integer.valueOf(this.mHyphenationFrequency);
        i = ObjectsCompat.hash(arrayOfObject5);
      }
      while (true)
      {
        return i;
        if (Build.VERSION.SDK_INT >= 21)
        {
          Object[] arrayOfObject4 = new Object[11];
          arrayOfObject4[0] = Float.valueOf(this.mPaint.getTextSize());
          arrayOfObject4[1] = Float.valueOf(this.mPaint.getTextScaleX());
          arrayOfObject4[2] = Float.valueOf(this.mPaint.getTextSkewX());
          arrayOfObject4[3] = Float.valueOf(this.mPaint.getLetterSpacing());
          arrayOfObject4[4] = Integer.valueOf(this.mPaint.getFlags());
          arrayOfObject4[5] = this.mPaint.getTextLocale();
          arrayOfObject4[6] = this.mPaint.getTypeface();
          arrayOfObject4[7] = Boolean.valueOf(this.mPaint.isElegantTextHeight());
          arrayOfObject4[8] = this.mTextDir;
          arrayOfObject4[9] = Integer.valueOf(this.mBreakStrategy);
          arrayOfObject4[10] = Integer.valueOf(this.mHyphenationFrequency);
          i = ObjectsCompat.hash(arrayOfObject4);
        }
        else if (Build.VERSION.SDK_INT >= 18)
        {
          Object[] arrayOfObject3 = new Object[9];
          arrayOfObject3[0] = Float.valueOf(this.mPaint.getTextSize());
          arrayOfObject3[1] = Float.valueOf(this.mPaint.getTextScaleX());
          arrayOfObject3[2] = Float.valueOf(this.mPaint.getTextSkewX());
          arrayOfObject3[3] = Integer.valueOf(this.mPaint.getFlags());
          arrayOfObject3[4] = this.mPaint.getTextLocale();
          arrayOfObject3[5] = this.mPaint.getTypeface();
          arrayOfObject3[6] = this.mTextDir;
          arrayOfObject3[7] = Integer.valueOf(this.mBreakStrategy);
          arrayOfObject3[8] = Integer.valueOf(this.mHyphenationFrequency);
          i = ObjectsCompat.hash(arrayOfObject3);
        }
        else if (Build.VERSION.SDK_INT >= 17)
        {
          Object[] arrayOfObject2 = new Object[9];
          arrayOfObject2[0] = Float.valueOf(this.mPaint.getTextSize());
          arrayOfObject2[1] = Float.valueOf(this.mPaint.getTextScaleX());
          arrayOfObject2[2] = Float.valueOf(this.mPaint.getTextSkewX());
          arrayOfObject2[3] = Integer.valueOf(this.mPaint.getFlags());
          arrayOfObject2[4] = this.mPaint.getTextLocale();
          arrayOfObject2[5] = this.mPaint.getTypeface();
          arrayOfObject2[6] = this.mTextDir;
          arrayOfObject2[7] = Integer.valueOf(this.mBreakStrategy);
          arrayOfObject2[8] = Integer.valueOf(this.mHyphenationFrequency);
          i = ObjectsCompat.hash(arrayOfObject2);
        }
        else
        {
          Object[] arrayOfObject1 = new Object[8];
          arrayOfObject1[0] = Float.valueOf(this.mPaint.getTextSize());
          arrayOfObject1[1] = Float.valueOf(this.mPaint.getTextScaleX());
          arrayOfObject1[2] = Float.valueOf(this.mPaint.getTextSkewX());
          arrayOfObject1[3] = Integer.valueOf(this.mPaint.getFlags());
          arrayOfObject1[4] = this.mPaint.getTypeface();
          arrayOfObject1[5] = this.mTextDir;
          arrayOfObject1[6] = Integer.valueOf(this.mBreakStrategy);
          arrayOfObject1[7] = Integer.valueOf(this.mHyphenationFrequency);
          i = ObjectsCompat.hash(arrayOfObject1);
        }
      }
    }

    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder("{");
      localStringBuilder.append("textSize=" + this.mPaint.getTextSize());
      localStringBuilder.append(", textScaleX=" + this.mPaint.getTextScaleX());
      localStringBuilder.append(", textSkewX=" + this.mPaint.getTextSkewX());
      if (Build.VERSION.SDK_INT >= 21)
      {
        localStringBuilder.append(", letterSpacing=" + this.mPaint.getLetterSpacing());
        localStringBuilder.append(", elegantTextHeight=" + this.mPaint.isElegantTextHeight());
      }
      if (Build.VERSION.SDK_INT >= 24)
        localStringBuilder.append(", textLocale=" + this.mPaint.getTextLocales());
      while (true)
      {
        localStringBuilder.append(", typeface=" + this.mPaint.getTypeface());
        if (Build.VERSION.SDK_INT >= 26)
          localStringBuilder.append(", variationSettings=" + this.mPaint.getFontVariationSettings());
        localStringBuilder.append(", textDir=" + this.mTextDir);
        localStringBuilder.append(", breakStrategy=" + this.mBreakStrategy);
        localStringBuilder.append(", hyphenationFrequency=" + this.mHyphenationFrequency);
        localStringBuilder.append("}");
        return localStringBuilder.toString();
        if (Build.VERSION.SDK_INT >= 17)
          localStringBuilder.append(", textLocale=" + this.mPaint.getTextLocale());
      }
    }

    public static class Builder
    {
      private int mBreakStrategy;
      private int mHyphenationFrequency;

      @NonNull
      private final TextPaint mPaint;
      private TextDirectionHeuristic mTextDir;

      public Builder(@NonNull TextPaint paramTextPaint)
      {
        this.mPaint = paramTextPaint;
        if (Build.VERSION.SDK_INT >= 23)
        {
          this.mBreakStrategy = 1;
          this.mHyphenationFrequency = 1;
          if (Build.VERSION.SDK_INT < 18)
            break label56;
        }
        label56: for (this.mTextDir = TextDirectionHeuristics.FIRSTSTRONG_LTR; ; this.mTextDir = null)
        {
          return;
          this.mHyphenationFrequency = 0;
          this.mBreakStrategy = 0;
          break;
        }
      }

      @NonNull
      public PrecomputedTextCompat.Params build()
      {
        return new PrecomputedTextCompat.Params(this.mPaint, this.mTextDir, this.mBreakStrategy, this.mHyphenationFrequency);
      }

      @RequiresApi(23)
      public Builder setBreakStrategy(int paramInt)
      {
        this.mBreakStrategy = paramInt;
        return this;
      }

      @RequiresApi(23)
      public Builder setHyphenationFrequency(int paramInt)
      {
        this.mHyphenationFrequency = paramInt;
        return this;
      }

      @RequiresApi(18)
      public Builder setTextDirection(@NonNull TextDirectionHeuristic paramTextDirectionHeuristic)
      {
        this.mTextDir = paramTextDirectionHeuristic;
        return this;
      }
    }
  }

  private static class PrecomputedTextFutureTask extends FutureTask<PrecomputedTextCompat>
  {
    PrecomputedTextFutureTask(@NonNull PrecomputedTextCompat.Params paramParams, @NonNull CharSequence paramCharSequence)
    {
      super();
    }

    private static class PrecomputedTextCallback
      implements Callable<PrecomputedTextCompat>
    {
      private PrecomputedTextCompat.Params mParams;
      private CharSequence mText;

      PrecomputedTextCallback(@NonNull PrecomputedTextCompat.Params paramParams, @NonNull CharSequence paramCharSequence)
      {
        this.mParams = paramParams;
        this.mText = paramCharSequence;
      }

      public PrecomputedTextCompat call()
        throws Exception
      {
        return PrecomputedTextCompat.create(this.mText, this.mParams);
      }
    }
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.core.text.PrecomputedTextCompat
 * JD-Core Version:    0.6.2
 */