package androidx.collection;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class ArraySet<E>
  implements Collection<E>, Set<E>
{
  private static final int BASE_SIZE = 4;
  private static final int CACHE_SIZE = 10;
  private static final boolean DEBUG = false;
  private static final int[] INT = new int[0];
  private static final Object[] OBJECT = new Object[0];
  private static final String TAG = "ArraySet";

  @Nullable
  private static Object[] sBaseCache;
  private static int sBaseCacheSize;

  @Nullable
  private static Object[] sTwiceBaseCache;
  private static int sTwiceBaseCacheSize;
  Object[] mArray;
  private MapCollections<E, E> mCollections;
  private int[] mHashes;
  int mSize;

  public ArraySet()
  {
    this(0);
  }

  public ArraySet(int paramInt)
  {
    if (paramInt == 0)
    {
      this.mHashes = INT;
      this.mArray = OBJECT;
    }
    while (true)
    {
      this.mSize = 0;
      return;
      allocArrays(paramInt);
    }
  }

  public ArraySet(@Nullable ArraySet<E> paramArraySet)
  {
    this();
    if (paramArraySet != null)
      addAll(paramArraySet);
  }

  public ArraySet(@Nullable Collection<E> paramCollection)
  {
    this();
    if (paramCollection != null)
      addAll(paramCollection);
  }

  // ERROR //
  private void allocArrays(int paramInt)
  {
    // Byte code:
    //   0: iload_1
    //   1: bipush 8
    //   3: if_icmpne +103 -> 106
    //   6: ldc 2
    //   8: monitorenter
    //   9: getstatic 68	androidx/collection/ArraySet:sTwiceBaseCache	[Ljava/lang/Object;
    //   12: ifnull +65 -> 77
    //   15: getstatic 68	androidx/collection/ArraySet:sTwiceBaseCache	[Ljava/lang/Object;
    //   18: astore 5
    //   20: aload_0
    //   21: aload 5
    //   23: putfield 52	androidx/collection/ArraySet:mArray	[Ljava/lang/Object;
    //   26: aload 5
    //   28: iconst_0
    //   29: aaload
    //   30: checkcast 69	[Ljava/lang/Object;
    //   33: checkcast 69	[Ljava/lang/Object;
    //   36: putstatic 68	androidx/collection/ArraySet:sTwiceBaseCache	[Ljava/lang/Object;
    //   39: aload_0
    //   40: aload 5
    //   42: iconst_1
    //   43: aaload
    //   44: checkcast 70	[I
    //   47: checkcast 70	[I
    //   50: putfield 50	androidx/collection/ArraySet:mHashes	[I
    //   53: aload 5
    //   55: iconst_1
    //   56: aconst_null
    //   57: aastore
    //   58: aload 5
    //   60: iconst_0
    //   61: aconst_null
    //   62: aastore
    //   63: iconst_m1
    //   64: getstatic 72	androidx/collection/ArraySet:sTwiceBaseCacheSize	I
    //   67: iadd
    //   68: putstatic 72	androidx/collection/ArraySet:sTwiceBaseCacheSize	I
    //   71: ldc 2
    //   73: monitorexit
    //   74: goto +114 -> 188
    //   77: ldc 2
    //   79: monitorexit
    //   80: aload_0
    //   81: iload_1
    //   82: newarray int
    //   84: putfield 50	androidx/collection/ArraySet:mHashes	[I
    //   87: aload_0
    //   88: iload_1
    //   89: anewarray 5	java/lang/Object
    //   92: putfield 52	androidx/collection/ArraySet:mArray	[Ljava/lang/Object;
    //   95: goto +93 -> 188
    //   98: astore 4
    //   100: ldc 2
    //   102: monitorexit
    //   103: aload 4
    //   105: athrow
    //   106: iload_1
    //   107: iconst_4
    //   108: if_icmpne -28 -> 80
    //   111: ldc 2
    //   113: monitorenter
    //   114: getstatic 74	androidx/collection/ArraySet:sBaseCache	[Ljava/lang/Object;
    //   117: ifnull +65 -> 182
    //   120: getstatic 74	androidx/collection/ArraySet:sBaseCache	[Ljava/lang/Object;
    //   123: astore_3
    //   124: aload_0
    //   125: aload_3
    //   126: putfield 52	androidx/collection/ArraySet:mArray	[Ljava/lang/Object;
    //   129: aload_3
    //   130: iconst_0
    //   131: aaload
    //   132: checkcast 69	[Ljava/lang/Object;
    //   135: checkcast 69	[Ljava/lang/Object;
    //   138: putstatic 74	androidx/collection/ArraySet:sBaseCache	[Ljava/lang/Object;
    //   141: aload_0
    //   142: aload_3
    //   143: iconst_1
    //   144: aaload
    //   145: checkcast 70	[I
    //   148: checkcast 70	[I
    //   151: putfield 50	androidx/collection/ArraySet:mHashes	[I
    //   154: aload_3
    //   155: iconst_1
    //   156: aconst_null
    //   157: aastore
    //   158: aload_3
    //   159: iconst_0
    //   160: aconst_null
    //   161: aastore
    //   162: iconst_m1
    //   163: getstatic 76	androidx/collection/ArraySet:sBaseCacheSize	I
    //   166: iadd
    //   167: putstatic 76	androidx/collection/ArraySet:sBaseCacheSize	I
    //   170: ldc 2
    //   172: monitorexit
    //   173: goto +15 -> 188
    //   176: astore_2
    //   177: ldc 2
    //   179: monitorexit
    //   180: aload_2
    //   181: athrow
    //   182: ldc 2
    //   184: monitorexit
    //   185: goto -105 -> 80
    //   188: return
    //
    // Exception table:
    //   from	to	target	type
    //   9	80	98	finally
    //   100	103	98	finally
    //   114	180	176	finally
    //   182	185	176	finally
  }

  private static void freeArrays(int[] paramArrayOfInt, Object[] paramArrayOfObject, int paramInt)
  {
    if (paramArrayOfInt.length == 8)
      try
      {
        if (sTwiceBaseCacheSize < 10)
        {
          paramArrayOfObject[0] = sTwiceBaseCache;
          paramArrayOfObject[1] = paramArrayOfInt;
          for (int j = paramInt - 1; j >= 2; j--)
            paramArrayOfObject[j] = null;
          sTwiceBaseCache = paramArrayOfObject;
          sTwiceBaseCacheSize = 1 + sTwiceBaseCacheSize;
        }
        return;
      }
      finally
      {
        localObject2 = finally;
        throw localObject2;
      }
    else if (paramArrayOfInt.length == 4)
      try
      {
        if (sBaseCacheSize < 10)
        {
          paramArrayOfObject[0] = sBaseCache;
          paramArrayOfObject[1] = paramArrayOfInt;
          for (int i = paramInt - 1; i >= 2; i--)
            paramArrayOfObject[i] = null;
          sBaseCache = paramArrayOfObject;
          sBaseCacheSize = 1 + sBaseCacheSize;
        }
      }
      finally
      {
        localObject1 = finally;
        throw localObject1;
      }
  }

  private MapCollections<E, E> getCollection()
  {
    if (this.mCollections == null)
      this.mCollections = new MapCollections()
      {
        protected void colClear()
        {
          ArraySet.this.clear();
        }

        protected Object colGetEntry(int paramAnonymousInt1, int paramAnonymousInt2)
        {
          return ArraySet.this.mArray[paramAnonymousInt1];
        }

        protected Map<E, E> colGetMap()
        {
          throw new UnsupportedOperationException("not a map");
        }

        protected int colGetSize()
        {
          return ArraySet.this.mSize;
        }

        protected int colIndexOfKey(Object paramAnonymousObject)
        {
          return ArraySet.this.indexOf(paramAnonymousObject);
        }

        protected int colIndexOfValue(Object paramAnonymousObject)
        {
          return ArraySet.this.indexOf(paramAnonymousObject);
        }

        protected void colPut(E paramAnonymousE1, E paramAnonymousE2)
        {
          ArraySet.this.add(paramAnonymousE1);
        }

        protected void colRemoveAt(int paramAnonymousInt)
        {
          ArraySet.this.removeAt(paramAnonymousInt);
        }

        protected E colSetValue(int paramAnonymousInt, E paramAnonymousE)
        {
          throw new UnsupportedOperationException("not a map");
        }
      };
    return this.mCollections;
  }

  private int indexOf(Object paramObject, int paramInt)
  {
    int i = this.mSize;
    int j;
    if (i == 0)
      j = -1;
    while (true)
    {
      return j;
      j = ContainerHelpers.binarySearch(this.mHashes, i, paramInt);
      if ((j >= 0) && (!paramObject.equals(this.mArray[j])))
      {
        for (int k = j + 1; ; k++)
        {
          if ((k >= i) || (this.mHashes[k] != paramInt))
            break label95;
          if (paramObject.equals(this.mArray[k]))
          {
            j = k;
            break;
          }
        }
        label95: for (int m = j - 1; ; m--)
        {
          if ((m < 0) || (this.mHashes[m] != paramInt))
            break label144;
          if (paramObject.equals(this.mArray[m]))
          {
            j = m;
            break;
          }
        }
        label144: j = k ^ 0xFFFFFFFF;
      }
    }
  }

  private int indexOfNull()
  {
    int i = this.mSize;
    int j;
    if (i == 0)
      j = -1;
    while (true)
    {
      return j;
      j = ContainerHelpers.binarySearch(this.mHashes, i, 0);
      if ((j >= 0) && (this.mArray[j] != null))
      {
        for (int k = j + 1; ; k++)
        {
          if ((k >= i) || (this.mHashes[k] != 0))
            break label74;
          if (this.mArray[k] == null)
          {
            j = k;
            break;
          }
        }
        label74: for (int m = j - 1; ; m--)
        {
          if ((m < 0) || (this.mHashes[m] != 0))
            break label116;
          if (this.mArray[m] == null)
          {
            j = m;
            break;
          }
        }
        label116: j = k ^ 0xFFFFFFFF;
      }
    }
  }

  public boolean add(@Nullable E paramE)
  {
    int i = 8;
    int j;
    if (paramE == null)
      j = 0;
    boolean bool;
    for (int k = indexOfNull(); k >= 0; k = indexOf(paramE, j))
    {
      bool = false;
      return bool;
      j = paramE.hashCode();
    }
    int m = k ^ 0xFFFFFFFF;
    if (this.mSize >= this.mHashes.length)
    {
      if (this.mSize < i)
        break label233;
      i = this.mSize + (this.mSize >> 1);
    }
    while (true)
    {
      int[] arrayOfInt = this.mHashes;
      Object[] arrayOfObject = this.mArray;
      allocArrays(i);
      if (this.mHashes.length > 0)
      {
        System.arraycopy(arrayOfInt, 0, this.mHashes, 0, arrayOfInt.length);
        System.arraycopy(arrayOfObject, 0, this.mArray, 0, arrayOfObject.length);
      }
      freeArrays(arrayOfInt, arrayOfObject, this.mSize);
      if (m < this.mSize)
      {
        System.arraycopy(this.mHashes, m, this.mHashes, m + 1, this.mSize - m);
        System.arraycopy(this.mArray, m, this.mArray, m + 1, this.mSize - m);
      }
      this.mHashes[m] = j;
      this.mArray[m] = paramE;
      this.mSize = (1 + this.mSize);
      bool = true;
      break;
      label233: if (this.mSize < 4)
        i = 4;
    }
  }

  public void addAll(@NonNull ArraySet<? extends E> paramArraySet)
  {
    int i = paramArraySet.mSize;
    ensureCapacity(i + this.mSize);
    if (this.mSize == 0)
      if (i > 0)
      {
        System.arraycopy(paramArraySet.mHashes, 0, this.mHashes, 0, i);
        System.arraycopy(paramArraySet.mArray, 0, this.mArray, 0, i);
        this.mSize = i;
      }
    while (true)
    {
      return;
      for (int j = 0; j < i; j++)
        add(paramArraySet.valueAt(j));
    }
  }

  public boolean addAll(@NonNull Collection<? extends E> paramCollection)
  {
    ensureCapacity(this.mSize + paramCollection.size());
    boolean bool = false;
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
      bool |= add(localIterator.next());
    return bool;
  }

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public void append(E paramE)
  {
    int i = this.mSize;
    if (paramE == null);
    for (int j = 0; i >= this.mHashes.length; j = paramE.hashCode())
      throw new IllegalStateException("Array is full");
    if ((i > 0) && (this.mHashes[(i - 1)] > j))
      add(paramE);
    while (true)
    {
      return;
      this.mSize = (i + 1);
      this.mHashes[i] = j;
      this.mArray[i] = paramE;
    }
  }

  public void clear()
  {
    if (this.mSize != 0)
    {
      freeArrays(this.mHashes, this.mArray, this.mSize);
      this.mHashes = INT;
      this.mArray = OBJECT;
      this.mSize = 0;
    }
  }

  public boolean contains(@Nullable Object paramObject)
  {
    if (indexOf(paramObject) >= 0);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean containsAll(@NonNull Collection<?> paramCollection)
  {
    Iterator localIterator = paramCollection.iterator();
    do
      if (!localIterator.hasNext())
        break;
    while (contains(localIterator.next()));
    for (boolean bool = false; ; bool = true)
      return bool;
  }

  public void ensureCapacity(int paramInt)
  {
    if (this.mHashes.length < paramInt)
    {
      int[] arrayOfInt = this.mHashes;
      Object[] arrayOfObject = this.mArray;
      allocArrays(paramInt);
      if (this.mSize > 0)
      {
        System.arraycopy(arrayOfInt, 0, this.mHashes, 0, this.mSize);
        System.arraycopy(arrayOfObject, 0, this.mArray, 0, this.mSize);
      }
      freeArrays(arrayOfInt, arrayOfObject, this.mSize);
    }
  }

  public boolean equals(Object paramObject)
  {
    boolean bool1 = true;
    if (this == paramObject);
    while (true)
    {
      return bool1;
      if ((paramObject instanceof Set))
      {
        Set localSet = (Set)paramObject;
        if (size() != localSet.size())
        {
          bool1 = false;
        }
        else
        {
          int i = 0;
          try
          {
            while (i < this.mSize)
            {
              boolean bool2 = localSet.contains(valueAt(i));
              if (!bool2)
              {
                bool1 = false;
                break;
              }
              i++;
            }
          }
          catch (NullPointerException localNullPointerException)
          {
            bool1 = false;
          }
          catch (ClassCastException localClassCastException)
          {
            bool1 = false;
          }
        }
      }
      else
      {
        bool1 = false;
      }
    }
  }

  public int hashCode()
  {
    int[] arrayOfInt = this.mHashes;
    int i = 0;
    int j = 0;
    int k = this.mSize;
    while (j < k)
    {
      i += arrayOfInt[j];
      j++;
    }
    return i;
  }

  public int indexOf(@Nullable Object paramObject)
  {
    if (paramObject == null);
    for (int i = indexOfNull(); ; i = indexOf(paramObject, paramObject.hashCode()))
      return i;
  }

  public boolean isEmpty()
  {
    if (this.mSize <= 0);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public Iterator<E> iterator()
  {
    return getCollection().getKeySet().iterator();
  }

  public boolean remove(@Nullable Object paramObject)
  {
    int i = indexOf(paramObject);
    if (i >= 0)
      removeAt(i);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean removeAll(@NonNull ArraySet<? extends E> paramArraySet)
  {
    int i = paramArraySet.mSize;
    int j = this.mSize;
    for (int k = 0; k < i; k++)
      remove(paramArraySet.valueAt(k));
    if (j != this.mSize);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean removeAll(@NonNull Collection<?> paramCollection)
  {
    boolean bool = false;
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
      bool |= remove(localIterator.next());
    return bool;
  }

  public E removeAt(int paramInt)
  {
    int i = 8;
    Object localObject = this.mArray[paramInt];
    if (this.mSize <= 1)
    {
      freeArrays(this.mHashes, this.mArray, this.mSize);
      this.mHashes = INT;
      this.mArray = OBJECT;
      this.mSize = 0;
    }
    while (true)
    {
      return localObject;
      if ((this.mHashes.length > i) && (this.mSize < this.mHashes.length / 3))
      {
        if (this.mSize > i)
          i = this.mSize + (this.mSize >> 1);
        int[] arrayOfInt = this.mHashes;
        Object[] arrayOfObject = this.mArray;
        allocArrays(i);
        this.mSize = (-1 + this.mSize);
        if (paramInt > 0)
        {
          System.arraycopy(arrayOfInt, 0, this.mHashes, 0, paramInt);
          System.arraycopy(arrayOfObject, 0, this.mArray, 0, paramInt);
        }
        if (paramInt < this.mSize)
        {
          System.arraycopy(arrayOfInt, paramInt + 1, this.mHashes, paramInt, this.mSize - paramInt);
          System.arraycopy(arrayOfObject, paramInt + 1, this.mArray, paramInt, this.mSize - paramInt);
        }
      }
      else
      {
        this.mSize = (-1 + this.mSize);
        if (paramInt < this.mSize)
        {
          System.arraycopy(this.mHashes, paramInt + 1, this.mHashes, paramInt, this.mSize - paramInt);
          System.arraycopy(this.mArray, paramInt + 1, this.mArray, paramInt, this.mSize - paramInt);
        }
        this.mArray[this.mSize] = null;
      }
    }
  }

  public boolean retainAll(@NonNull Collection<?> paramCollection)
  {
    boolean bool = false;
    for (int i = -1 + this.mSize; i >= 0; i--)
      if (!paramCollection.contains(this.mArray[i]))
      {
        removeAt(i);
        bool = true;
      }
    return bool;
  }

  public int size()
  {
    return this.mSize;
  }

  @NonNull
  public Object[] toArray()
  {
    Object[] arrayOfObject = new Object[this.mSize];
    System.arraycopy(this.mArray, 0, arrayOfObject, 0, this.mSize);
    return arrayOfObject;
  }

  @NonNull
  public <T> T[] toArray(@NonNull T[] paramArrayOfT)
  {
    if (paramArrayOfT.length < this.mSize)
      paramArrayOfT = (Object[])Array.newInstance(paramArrayOfT.getClass().getComponentType(), this.mSize);
    System.arraycopy(this.mArray, 0, paramArrayOfT, 0, this.mSize);
    if (paramArrayOfT.length > this.mSize)
      paramArrayOfT[this.mSize] = null;
    return paramArrayOfT;
  }

  public String toString()
  {
    if (isEmpty());
    StringBuilder localStringBuilder;
    for (String str = "{}"; ; str = localStringBuilder.toString())
    {
      return str;
      localStringBuilder = new StringBuilder(14 * this.mSize);
      localStringBuilder.append('{');
      int i = 0;
      if (i < this.mSize)
      {
        if (i > 0)
          localStringBuilder.append(", ");
        Object localObject = valueAt(i);
        if (localObject != this)
          localStringBuilder.append(localObject);
        while (true)
        {
          i++;
          break;
          localStringBuilder.append("(this Set)");
        }
      }
      localStringBuilder.append('}');
    }
  }

  @Nullable
  public E valueAt(int paramInt)
  {
    return this.mArray[paramInt];
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.collection.ArraySet
 * JD-Core Version:    0.6.2
 */