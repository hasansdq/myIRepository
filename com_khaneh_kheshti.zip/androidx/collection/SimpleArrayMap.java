package androidx.collection;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ConcurrentModificationException;
import java.util.Map;

public class SimpleArrayMap<K, V>
{
  private static final int BASE_SIZE = 4;
  private static final int CACHE_SIZE = 10;
  private static final boolean CONCURRENT_MODIFICATION_EXCEPTIONS = true;
  private static final boolean DEBUG = false;
  private static final String TAG = "ArrayMap";

  @Nullable
  static Object[] mBaseCache;
  static int mBaseCacheSize;

  @Nullable
  static Object[] mTwiceBaseCache;
  static int mTwiceBaseCacheSize;
  Object[] mArray;
  int[] mHashes;
  int mSize;

  public SimpleArrayMap()
  {
    this.mHashes = ContainerHelpers.EMPTY_INTS;
    this.mArray = ContainerHelpers.EMPTY_OBJECTS;
    this.mSize = 0;
  }

  public SimpleArrayMap(int paramInt)
  {
    if (paramInt == 0)
    {
      this.mHashes = ContainerHelpers.EMPTY_INTS;
      this.mArray = ContainerHelpers.EMPTY_OBJECTS;
    }
    while (true)
    {
      this.mSize = 0;
      return;
      allocArrays(paramInt);
    }
  }

  public SimpleArrayMap(SimpleArrayMap<K, V> paramSimpleArrayMap)
  {
    this();
    if (paramSimpleArrayMap != null)
      putAll(paramSimpleArrayMap);
  }

  // ERROR //
  private void allocArrays(int paramInt)
  {
    // Byte code:
    //   0: iload_1
    //   1: bipush 8
    //   3: if_icmpne +105 -> 108
    //   6: ldc 58
    //   8: monitorenter
    //   9: getstatic 60	androidx/collection/SimpleArrayMap:mTwiceBaseCache	[Ljava/lang/Object;
    //   12: ifnull +65 -> 77
    //   15: getstatic 60	androidx/collection/SimpleArrayMap:mTwiceBaseCache	[Ljava/lang/Object;
    //   18: astore 5
    //   20: aload_0
    //   21: aload 5
    //   23: putfield 45	androidx/collection/SimpleArrayMap:mArray	[Ljava/lang/Object;
    //   26: aload 5
    //   28: iconst_0
    //   29: aaload
    //   30: checkcast 61	[Ljava/lang/Object;
    //   33: checkcast 61	[Ljava/lang/Object;
    //   36: putstatic 60	androidx/collection/SimpleArrayMap:mTwiceBaseCache	[Ljava/lang/Object;
    //   39: aload_0
    //   40: aload 5
    //   42: iconst_1
    //   43: aaload
    //   44: checkcast 62	[I
    //   47: checkcast 62	[I
    //   50: putfield 40	androidx/collection/SimpleArrayMap:mHashes	[I
    //   53: aload 5
    //   55: iconst_1
    //   56: aconst_null
    //   57: aastore
    //   58: aload 5
    //   60: iconst_0
    //   61: aconst_null
    //   62: aastore
    //   63: iconst_m1
    //   64: getstatic 64	androidx/collection/SimpleArrayMap:mTwiceBaseCacheSize	I
    //   67: iadd
    //   68: putstatic 64	androidx/collection/SimpleArrayMap:mTwiceBaseCacheSize	I
    //   71: ldc 58
    //   73: monitorexit
    //   74: goto +116 -> 190
    //   77: ldc 58
    //   79: monitorexit
    //   80: aload_0
    //   81: iload_1
    //   82: newarray int
    //   84: putfield 40	androidx/collection/SimpleArrayMap:mHashes	[I
    //   87: aload_0
    //   88: iload_1
    //   89: iconst_1
    //   90: ishl
    //   91: anewarray 5	java/lang/Object
    //   94: putfield 45	androidx/collection/SimpleArrayMap:mArray	[Ljava/lang/Object;
    //   97: goto +93 -> 190
    //   100: astore 4
    //   102: ldc 58
    //   104: monitorexit
    //   105: aload 4
    //   107: athrow
    //   108: iload_1
    //   109: iconst_4
    //   110: if_icmpne -30 -> 80
    //   113: ldc 58
    //   115: monitorenter
    //   116: getstatic 66	androidx/collection/SimpleArrayMap:mBaseCache	[Ljava/lang/Object;
    //   119: ifnull +65 -> 184
    //   122: getstatic 66	androidx/collection/SimpleArrayMap:mBaseCache	[Ljava/lang/Object;
    //   125: astore_3
    //   126: aload_0
    //   127: aload_3
    //   128: putfield 45	androidx/collection/SimpleArrayMap:mArray	[Ljava/lang/Object;
    //   131: aload_3
    //   132: iconst_0
    //   133: aaload
    //   134: checkcast 61	[Ljava/lang/Object;
    //   137: checkcast 61	[Ljava/lang/Object;
    //   140: putstatic 66	androidx/collection/SimpleArrayMap:mBaseCache	[Ljava/lang/Object;
    //   143: aload_0
    //   144: aload_3
    //   145: iconst_1
    //   146: aaload
    //   147: checkcast 62	[I
    //   150: checkcast 62	[I
    //   153: putfield 40	androidx/collection/SimpleArrayMap:mHashes	[I
    //   156: aload_3
    //   157: iconst_1
    //   158: aconst_null
    //   159: aastore
    //   160: aload_3
    //   161: iconst_0
    //   162: aconst_null
    //   163: aastore
    //   164: iconst_m1
    //   165: getstatic 68	androidx/collection/SimpleArrayMap:mBaseCacheSize	I
    //   168: iadd
    //   169: putstatic 68	androidx/collection/SimpleArrayMap:mBaseCacheSize	I
    //   172: ldc 58
    //   174: monitorexit
    //   175: goto +15 -> 190
    //   178: astore_2
    //   179: ldc 58
    //   181: monitorexit
    //   182: aload_2
    //   183: athrow
    //   184: ldc 58
    //   186: monitorexit
    //   187: goto -107 -> 80
    //   190: return
    //
    // Exception table:
    //   from	to	target	type
    //   9	80	100	finally
    //   102	105	100	finally
    //   116	182	178	finally
    //   184	187	178	finally
  }

  private static int binarySearchHashes(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    try
    {
      int i = ContainerHelpers.binarySearch(paramArrayOfInt, paramInt1, paramInt2);
      return i;
    }
    catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException)
    {
    }
    throw new ConcurrentModificationException();
  }

  private static void freeArrays(int[] paramArrayOfInt, Object[] paramArrayOfObject, int paramInt)
  {
    if (paramArrayOfInt.length == 8)
      try
      {
        if (mTwiceBaseCacheSize < 10)
        {
          paramArrayOfObject[0] = mTwiceBaseCache;
          paramArrayOfObject[1] = paramArrayOfInt;
          for (int j = -1 + (paramInt << 1); j >= 2; j--)
            paramArrayOfObject[j] = null;
          mTwiceBaseCache = paramArrayOfObject;
          mTwiceBaseCacheSize = 1 + mTwiceBaseCacheSize;
        }
        return;
      }
      finally
      {
        localObject2 = finally;
        throw localObject2;
      }
    else if (paramArrayOfInt.length == 4)
      try
      {
        if (mBaseCacheSize < 10)
        {
          paramArrayOfObject[0] = mBaseCache;
          paramArrayOfObject[1] = paramArrayOfInt;
          for (int i = -1 + (paramInt << 1); i >= 2; i--)
            paramArrayOfObject[i] = null;
          mBaseCache = paramArrayOfObject;
          mBaseCacheSize = 1 + mBaseCacheSize;
        }
      }
      finally
      {
        localObject1 = finally;
        throw localObject1;
      }
  }

  public void clear()
  {
    if (this.mSize > 0)
    {
      int[] arrayOfInt = this.mHashes;
      Object[] arrayOfObject = this.mArray;
      int i = this.mSize;
      this.mHashes = ContainerHelpers.EMPTY_INTS;
      this.mArray = ContainerHelpers.EMPTY_OBJECTS;
      this.mSize = 0;
      freeArrays(arrayOfInt, arrayOfObject, i);
    }
    if (this.mSize > 0)
      throw new ConcurrentModificationException();
  }

  public boolean containsKey(@Nullable Object paramObject)
  {
    if (indexOfKey(paramObject) >= 0);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean containsValue(Object paramObject)
  {
    if (indexOfValue(paramObject) >= 0);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public void ensureCapacity(int paramInt)
  {
    int i = this.mSize;
    if (this.mHashes.length < paramInt)
    {
      int[] arrayOfInt = this.mHashes;
      Object[] arrayOfObject = this.mArray;
      allocArrays(paramInt);
      if (this.mSize > 0)
      {
        System.arraycopy(arrayOfInt, 0, this.mHashes, 0, i);
        System.arraycopy(arrayOfObject, 0, this.mArray, 0, i << 1);
      }
      freeArrays(arrayOfInt, arrayOfObject, i);
    }
    if (this.mSize != i)
      throw new ConcurrentModificationException();
  }

  public boolean equals(Object paramObject)
  {
    boolean bool1 = true;
    if (this == paramObject);
    while (true)
    {
      return bool1;
      if ((paramObject instanceof SimpleArrayMap))
      {
        SimpleArrayMap localSimpleArrayMap = (SimpleArrayMap)paramObject;
        if (size() != localSimpleArrayMap.size())
        {
          bool1 = false;
        }
        else
        {
          int j = 0;
          try
          {
            while (j < this.mSize)
            {
              Object localObject4 = keyAt(j);
              Object localObject5 = valueAt(j);
              Object localObject6 = localSimpleArrayMap.get(localObject4);
              if (localObject5 == null)
              {
                if (localObject6 != null)
                  break label274;
                if (!localSimpleArrayMap.containsKey(localObject4))
                  break label274;
              }
              else
              {
                boolean bool3 = localObject5.equals(localObject6);
                if (!bool3)
                {
                  bool1 = false;
                  break;
                }
              }
              j++;
            }
          }
          catch (NullPointerException localNullPointerException2)
          {
            bool1 = false;
          }
          catch (ClassCastException localClassCastException2)
          {
            bool1 = false;
          }
        }
      }
      else if ((paramObject instanceof Map))
      {
        Map localMap = (Map)paramObject;
        if (size() != localMap.size())
        {
          bool1 = false;
        }
        else
        {
          int i = 0;
          try
          {
            while (i < this.mSize)
            {
              Object localObject1 = keyAt(i);
              Object localObject2 = valueAt(i);
              Object localObject3 = localMap.get(localObject1);
              if (localObject2 == null)
              {
                if (localObject3 != null)
                  break label279;
                if (!localMap.containsKey(localObject1))
                  break label279;
              }
              else
              {
                boolean bool2 = localObject2.equals(localObject3);
                if (!bool2)
                {
                  bool1 = false;
                  break;
                }
              }
              i++;
            }
          }
          catch (NullPointerException localNullPointerException1)
          {
            bool1 = false;
          }
          catch (ClassCastException localClassCastException1)
          {
            bool1 = false;
          }
        }
      }
      else
      {
        bool1 = false;
        continue;
        label274: bool1 = false;
        continue;
        label279: bool1 = false;
      }
    }
  }

  @Nullable
  public V get(Object paramObject)
  {
    int i = indexOfKey(paramObject);
    if (i >= 0);
    for (Object localObject = this.mArray[(1 + (i << 1))]; ; localObject = null)
      return localObject;
  }

  public int hashCode()
  {
    int[] arrayOfInt = this.mHashes;
    Object[] arrayOfObject = this.mArray;
    int i = 0;
    int j = 0;
    int k = 1;
    int m = this.mSize;
    if (j < m)
    {
      Object localObject = arrayOfObject[k];
      int n = arrayOfInt[j];
      if (localObject == null);
      for (int i1 = 0; ; i1 = localObject.hashCode())
      {
        i += (i1 ^ n);
        j++;
        k += 2;
        break;
      }
    }
    return i;
  }

  int indexOf(Object paramObject, int paramInt)
  {
    int i = this.mSize;
    int j;
    if (i == 0)
      j = -1;
    while (true)
    {
      return j;
      j = binarySearchHashes(this.mHashes, i, paramInt);
      if ((j >= 0) && (!paramObject.equals(this.mArray[(j << 1)])))
      {
        for (int k = j + 1; ; k++)
        {
          if ((k >= i) || (this.mHashes[k] != paramInt))
            break label99;
          if (paramObject.equals(this.mArray[(k << 1)]))
          {
            j = k;
            break;
          }
        }
        label99: for (int m = j - 1; ; m--)
        {
          if ((m < 0) || (this.mHashes[m] != paramInt))
            break label150;
          if (paramObject.equals(this.mArray[(m << 1)]))
          {
            j = m;
            break;
          }
        }
        label150: j = k ^ 0xFFFFFFFF;
      }
    }
  }

  public int indexOfKey(@Nullable Object paramObject)
  {
    if (paramObject == null);
    for (int i = indexOfNull(); ; i = indexOf(paramObject, paramObject.hashCode()))
      return i;
  }

  int indexOfNull()
  {
    int i = this.mSize;
    int j;
    if (i == 0)
      j = -1;
    while (true)
    {
      return j;
      j = binarySearchHashes(this.mHashes, i, 0);
      if ((j >= 0) && (this.mArray[(j << 1)] != null))
      {
        for (int k = j + 1; ; k++)
        {
          if ((k >= i) || (this.mHashes[k] != 0))
            break label78;
          if (this.mArray[(k << 1)] == null)
          {
            j = k;
            break;
          }
        }
        label78: for (int m = j - 1; ; m--)
        {
          if ((m < 0) || (this.mHashes[m] != 0))
            break label122;
          if (this.mArray[(m << 1)] == null)
          {
            j = m;
            break;
          }
        }
        label122: j = k ^ 0xFFFFFFFF;
      }
    }
  }

  int indexOfValue(Object paramObject)
  {
    int i = 2 * this.mSize;
    Object[] arrayOfObject = this.mArray;
    int m;
    int k;
    if (paramObject == null)
    {
      m = 1;
      if (m >= i)
        break label82;
      if (arrayOfObject[m] == null)
        k = m >> 1;
    }
    while (true)
    {
      return k;
      m += 2;
      break;
      for (int j = 1; ; j += 2)
      {
        if (j >= i)
          break label82;
        if (paramObject.equals(arrayOfObject[j]))
        {
          k = j >> 1;
          break;
        }
      }
      label82: k = -1;
    }
  }

  public boolean isEmpty()
  {
    if (this.mSize <= 0);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public K keyAt(int paramInt)
  {
    return this.mArray[(paramInt << 1)];
  }

  @Nullable
  public V put(K paramK, V paramV)
  {
    int i = 8;
    int j = this.mSize;
    int k;
    int m;
    Object localObject;
    if (paramK == null)
    {
      k = 0;
      m = indexOfNull();
      if (m < 0)
        break label73;
      int i1 = 1 + (m << 1);
      localObject = this.mArray[i1];
      this.mArray[i1] = paramV;
    }
    while (true)
    {
      return localObject;
      k = paramK.hashCode();
      m = indexOf(paramK, k);
      break;
      label73: int n = m ^ 0xFFFFFFFF;
      if (j >= this.mHashes.length)
      {
        if (j >= i)
          i = j + (j >> 1);
        int[] arrayOfInt;
        Object[] arrayOfObject;
        while (true)
        {
          arrayOfInt = this.mHashes;
          arrayOfObject = this.mArray;
          allocArrays(i);
          if (j == this.mSize)
            break;
          throw new ConcurrentModificationException();
          if (j < 4)
            i = 4;
        }
        if (this.mHashes.length > 0)
        {
          System.arraycopy(arrayOfInt, 0, this.mHashes, 0, arrayOfInt.length);
          System.arraycopy(arrayOfObject, 0, this.mArray, 0, arrayOfObject.length);
        }
        freeArrays(arrayOfInt, arrayOfObject, j);
      }
      if (n < j)
      {
        System.arraycopy(this.mHashes, n, this.mHashes, n + 1, j - n);
        System.arraycopy(this.mArray, n << 1, this.mArray, n + 1 << 1, this.mSize - n << 1);
      }
      if ((j != this.mSize) || (n >= this.mHashes.length))
        throw new ConcurrentModificationException();
      this.mHashes[n] = k;
      this.mArray[(n << 1)] = paramK;
      this.mArray[(1 + (n << 1))] = paramV;
      this.mSize = (1 + this.mSize);
      localObject = null;
    }
  }

  public void putAll(@NonNull SimpleArrayMap<? extends K, ? extends V> paramSimpleArrayMap)
  {
    int i = paramSimpleArrayMap.mSize;
    ensureCapacity(i + this.mSize);
    if (this.mSize == 0)
      if (i > 0)
      {
        System.arraycopy(paramSimpleArrayMap.mHashes, 0, this.mHashes, 0, i);
        System.arraycopy(paramSimpleArrayMap.mArray, 0, this.mArray, 0, i << 1);
        this.mSize = i;
      }
    while (true)
    {
      return;
      for (int j = 0; j < i; j++)
        put(paramSimpleArrayMap.keyAt(j), paramSimpleArrayMap.valueAt(j));
    }
  }

  @Nullable
  public V remove(Object paramObject)
  {
    int i = indexOfKey(paramObject);
    if (i >= 0);
    for (Object localObject = removeAt(i); ; localObject = null)
      return localObject;
  }

  public V removeAt(int paramInt)
  {
    int i = 8;
    Object localObject = this.mArray[(1 + (paramInt << 1))];
    int j = this.mSize;
    int k;
    if (j <= 1)
    {
      freeArrays(this.mHashes, this.mArray, j);
      this.mHashes = ContainerHelpers.EMPTY_INTS;
      this.mArray = ContainerHelpers.EMPTY_OBJECTS;
      k = 0;
    }
    while (j != this.mSize)
    {
      throw new ConcurrentModificationException();
      k = j - 1;
      if ((this.mHashes.length > i) && (this.mSize < this.mHashes.length / 3))
      {
        if (j > i)
          i = j + (j >> 1);
        int[] arrayOfInt = this.mHashes;
        Object[] arrayOfObject = this.mArray;
        allocArrays(i);
        if (j != this.mSize)
          throw new ConcurrentModificationException();
        if (paramInt > 0)
        {
          System.arraycopy(arrayOfInt, 0, this.mHashes, 0, paramInt);
          System.arraycopy(arrayOfObject, 0, this.mArray, 0, paramInt << 1);
        }
        if (paramInt < k)
        {
          System.arraycopy(arrayOfInt, paramInt + 1, this.mHashes, paramInt, k - paramInt);
          System.arraycopy(arrayOfObject, paramInt + 1 << 1, this.mArray, paramInt << 1, k - paramInt << 1);
        }
      }
      else
      {
        if (paramInt < k)
        {
          System.arraycopy(this.mHashes, paramInt + 1, this.mHashes, paramInt, k - paramInt);
          System.arraycopy(this.mArray, paramInt + 1 << 1, this.mArray, paramInt << 1, k - paramInt << 1);
        }
        this.mArray[(k << 1)] = null;
        this.mArray[(1 + (k << 1))] = null;
      }
    }
    this.mSize = k;
    return localObject;
  }

  public V setValueAt(int paramInt, V paramV)
  {
    int i = 1 + (paramInt << 1);
    Object localObject = this.mArray[i];
    this.mArray[i] = paramV;
    return localObject;
  }

  public int size()
  {
    return this.mSize;
  }

  public String toString()
  {
    if (isEmpty());
    StringBuilder localStringBuilder;
    for (String str = "{}"; ; str = localStringBuilder.toString())
    {
      return str;
      localStringBuilder = new StringBuilder(28 * this.mSize);
      localStringBuilder.append('{');
      int i = 0;
      if (i < this.mSize)
      {
        if (i > 0)
          localStringBuilder.append(", ");
        Object localObject1 = keyAt(i);
        if (localObject1 != this)
        {
          localStringBuilder.append(localObject1);
          label77: localStringBuilder.append('=');
          Object localObject2 = valueAt(i);
          if (localObject2 == this)
            break label120;
          localStringBuilder.append(localObject2);
        }
        while (true)
        {
          i++;
          break;
          localStringBuilder.append("(this Map)");
          break label77;
          label120: localStringBuilder.append("(this Map)");
        }
      }
      localStringBuilder.append('}');
    }
  }

  public V valueAt(int paramInt)
  {
    return this.mArray[(1 + (paramInt << 1))];
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.collection.SimpleArrayMap
 * JD-Core Version:    0.6.2
 */