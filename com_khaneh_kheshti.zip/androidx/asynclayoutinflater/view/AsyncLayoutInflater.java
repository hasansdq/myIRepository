package androidx.asynclayoutinflater.view;

import android.content.Context;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.UiThread;
import androidx.core.util.Pools.SynchronizedPool;
import java.util.concurrent.ArrayBlockingQueue;

public final class AsyncLayoutInflater
{
  private static final String TAG = "AsyncLayoutInflater";
  Handler mHandler;
  private Handler.Callback mHandlerCallback = new Handler.Callback()
  {
    public boolean handleMessage(Message paramAnonymousMessage)
    {
      AsyncLayoutInflater.InflateRequest localInflateRequest = (AsyncLayoutInflater.InflateRequest)paramAnonymousMessage.obj;
      if (localInflateRequest.view == null)
        localInflateRequest.view = AsyncLayoutInflater.this.mInflater.inflate(localInflateRequest.resid, localInflateRequest.parent, false);
      localInflateRequest.callback.onInflateFinished(localInflateRequest.view, localInflateRequest.resid, localInflateRequest.parent);
      AsyncLayoutInflater.this.mInflateThread.releaseRequest(localInflateRequest);
      return true;
    }
  };
  InflateThread mInflateThread;
  LayoutInflater mInflater;

  public AsyncLayoutInflater(@NonNull Context paramContext)
  {
    this.mInflater = new BasicInflater(paramContext);
    this.mHandler = new Handler(this.mHandlerCallback);
    this.mInflateThread = InflateThread.getInstance();
  }

  @UiThread
  public void inflate(@LayoutRes int paramInt, @Nullable ViewGroup paramViewGroup, @NonNull OnInflateFinishedListener paramOnInflateFinishedListener)
  {
    if (paramOnInflateFinishedListener == null)
      throw new NullPointerException("callback argument may not be null!");
    InflateRequest localInflateRequest = this.mInflateThread.obtainRequest();
    localInflateRequest.inflater = this;
    localInflateRequest.resid = paramInt;
    localInflateRequest.parent = paramViewGroup;
    localInflateRequest.callback = paramOnInflateFinishedListener;
    this.mInflateThread.enqueue(localInflateRequest);
  }

  private static class BasicInflater extends LayoutInflater
  {
    private static final String[] sClassPrefixList = { "android.widget.", "android.webkit.", "android.app." };

    BasicInflater(Context paramContext)
    {
      super();
    }

    public LayoutInflater cloneInContext(Context paramContext)
    {
      return new BasicInflater(paramContext);
    }

    protected View onCreateView(String paramString, AttributeSet paramAttributeSet)
      throws ClassNotFoundException
    {
      String[] arrayOfString = sClassPrefixList;
      int i = arrayOfString.length;
      int j = 0;
      String str;
      if (j < i)
        str = arrayOfString[j];
      while (true)
      {
        try
        {
          View localView2 = createView(paramString, str, paramAttributeSet);
          localView1 = localView2;
          if (localView1 != null)
            return localView1;
        }
        catch (ClassNotFoundException localClassNotFoundException)
        {
          j++;
        }
        break;
        View localView1 = super.onCreateView(paramString, paramAttributeSet);
      }
    }
  }

  private static class InflateRequest
  {
    AsyncLayoutInflater.OnInflateFinishedListener callback;
    AsyncLayoutInflater inflater;
    ViewGroup parent;
    int resid;
    View view;
  }

  private static class InflateThread extends Thread
  {
    private static final InflateThread sInstance = new InflateThread();
    private ArrayBlockingQueue<AsyncLayoutInflater.InflateRequest> mQueue = new ArrayBlockingQueue(10);
    private Pools.SynchronizedPool<AsyncLayoutInflater.InflateRequest> mRequestPool = new Pools.SynchronizedPool(10);

    static
    {
      sInstance.start();
    }

    public static InflateThread getInstance()
    {
      return sInstance;
    }

    public void enqueue(AsyncLayoutInflater.InflateRequest paramInflateRequest)
    {
      try
      {
        this.mQueue.put(paramInflateRequest);
        return;
      }
      catch (InterruptedException localInterruptedException)
      {
        throw new RuntimeException("Failed to enqueue async inflate request", localInterruptedException);
      }
    }

    public AsyncLayoutInflater.InflateRequest obtainRequest()
    {
      AsyncLayoutInflater.InflateRequest localInflateRequest = (AsyncLayoutInflater.InflateRequest)this.mRequestPool.acquire();
      if (localInflateRequest == null)
        localInflateRequest = new AsyncLayoutInflater.InflateRequest();
      return localInflateRequest;
    }

    public void releaseRequest(AsyncLayoutInflater.InflateRequest paramInflateRequest)
    {
      paramInflateRequest.callback = null;
      paramInflateRequest.inflater = null;
      paramInflateRequest.parent = null;
      paramInflateRequest.resid = 0;
      paramInflateRequest.view = null;
      this.mRequestPool.release(paramInflateRequest);
    }

    public void run()
    {
      while (true)
        runInner();
    }

    public void runInner()
    {
      try
      {
        localInflateRequest = (AsyncLayoutInflater.InflateRequest)this.mQueue.take();
      }
      catch (InterruptedException localInterruptedException)
      {
        try
        {
          AsyncLayoutInflater.InflateRequest localInflateRequest;
          localInflateRequest.view = localInflateRequest.inflater.mInflater.inflate(localInflateRequest.resid, localInflateRequest.parent, false);
          Message.obtain(localInflateRequest.inflater.mHandler, 0, localInflateRequest).sendToTarget();
          while (true)
          {
            return;
            localInterruptedException = localInterruptedException;
            Log.w("AsyncLayoutInflater", localInterruptedException);
          }
        }
        catch (RuntimeException localRuntimeException)
        {
          while (true)
            Log.w("AsyncLayoutInflater", "Failed to inflate resource in the background! Retrying on the UI thread", localRuntimeException);
        }
      }
    }
  }

  public static abstract interface OnInflateFinishedListener
  {
    public abstract void onInflateFinished(@NonNull View paramView, @LayoutRes int paramInt, @Nullable ViewGroup paramViewGroup);
  }
}

/* Location:           C:\apktool\dex2jar\tsafe_dex2jar.jar
 * Qualified Name:     androidx.asynclayoutinflater.view.AsyncLayoutInflater
 * JD-Core Version:    0.6.2
 */